# Argument reference and exit contract

Covers both commands. `specify` authors or extends; `clarify` gap-checks.

## Grammar

```
/speckit.sketch.specify (-l | -s | -e) -transcript <path> [-spec <path>] [-ai] [--out-dir <path>] [--json]
```

Order does not matter. Long forms `--lightweight`, `--standard`, `--exhaustive`,
`--transcript`, `--spec`, `--ai` are accepted.

## Depth, exactly one

| Flag | Depth | Timebox | Generic questions | AI questions |
|------|-------|---------|-------------------|--------------|
| `-l` | Lightweight | about 1 hour | 34 | 45 |
| `-s` | Standard | about 1 day | 92 | 125 |
| `-e` | Exhaustive | 3 days to 1 week | 122 | 186 |

Counts are cumulative: Standard asks every `[L]` and `[S]` question, Exhaustive
asks all three markers.

Passing two different depth flags, or the same one twice, is exit 2. Passing none
is exit 2. `-d` is not a depth flag; it produces exit 2 with a hint pointing at
`-s`, because `-d` for "detailed" is the mistake this command expects.

## Track: not a flag

Neither command takes `-ai`. Passing it exits 1.

`specify` determines the track from the transcript, against evidence stated in
the completion report, and resolves both tracks so the agent can pick. Ambiguity
resolves to AI-Extended, because Part D marked not applicable is a recorded
decision whereas a generic document has nowhere to record the question was asked.

`clarify` reads the track from the spec: Part D present means AI-Extended. It
also detects the case where Part D exists but Section 13 disclaims it, reported
as `ai_disclaimed_hint`, and the agent then drops the `[AI]` questions.

The AI-Extended track is 20 sections; generic is 14. Parts A, B, C and E are
identical in both, so a spec can move between tracks without rewriting.

`[AI]` questions are not confined to Part D: 24 of 64 sit in Sections 5, 6, 7, 8,
10, 11, 12, 19 and 20.

## Paths

`-transcript` is mandatory. `-spec` is optional.

Both accept an absolute path, a path relative to the working directory, or a path
beginning `~`. Surrounding single or double quotes are tolerated. A path that does
not resolve to a readable file is an error, never a silent fallback:

- bad `-transcript` → exit 3
- bad `-spec` → exit 4
- `-spec` with an extension other than `.docx` or `.md` → exit 5

## Modes

| `-spec` | Mode | Behaviour |
|---------|------|-----------|
| absent | `create` | Author a new spec from the transcript against the depth-graded template |
| present | `enhance` | Treat the given spec as the baseline and extend it with the transcript |

In `enhance` mode the baseline is authoritative for everything the new transcript
does not touch. Silence is not a retraction. Where the two conflict, the
transcript wins and the change is recorded in Document Control.

## Outputs

| Mode | Input format | Writes |
|------|--------------|--------|
| `create` | n/a | `spec.docx` **and** `spec.md` |
| `enhance` | `.docx` | `spec.docx` **and** `spec.md` |
| `enhance` | `.md` | `spec.md` only |

Output directory defaults to the directory holding `-spec`, or the working
directory in `create` mode. Override with `--out-dir`.

When a `.docx` is written, `pandoc` must be on PATH or the run fails at
validation with exit 7 rather than part way through authoring.

## Exit contract

| Code | Meaning |
|------|---------|
| 0 | resolution succeeded, JSON emitted |
| 1 | usage error: unknown flag, or a flag missing its value |
| 2 | depth error: none, several, repeated, or `-d` |
| 3 | transcript error: flag absent, or path does not resolve |
| 4 | spec error: path does not resolve |
| 5 | spec error: extension is neither `.docx` nor `.md` |
| 6 | asset error: a reference file is missing from the extension |
| 7 | tool error: a `.docx` is required but `pandoc` is absent |

`scripts/bash/docx-to-md.sh` and `scripts/bash/md-to-docx.sh` both add exit 8
for a failed conversion, an empty result, or output that is not a readable
`.docx` archive.

## Resolution object

`--json` prints only the resolution. Every path the agent uses must come from
here rather than being re-derived.

```json
{
  "mode": "create",
  "track": "ai",
  "track_name": "AI-Extended",
  "depth": "lightweight",
  "depth_title": "Lightweight",
  "section_count": 20,
  "question_total": 45,
  "gated_sections": "16",
  "transcript": "/abs/path/interview.txt",
  "spec_in": null,
  "spec_in_format": null,
  "out_dir": "/abs/path",
  "write_docx": true,
  "write_md": true,
  "out_docx": "/abs/path/spec.docx",
  "out_md": "/abs/path/spec.md",
  "template_docx": "...", "template_md": "...",
  "catalog_docx": "...",  "catalog_md": "...",
  "example_docx": "...",  "example_md": "...",
  "pandoc": "available",
  "convert_cmd": "…/scripts/bash/docx-to-md.sh \"…/spec.docx\" \"…/spec.md\"",
  "convert_cmd_raw": "pandoc -t gfm \"…/spec.docx\" -o \"…/spec.md\"",
  "convert_writer": "gfm"
}
```

`gated_sections` is `16` on the AI track at Lightweight, `none` otherwise. It is
the only depth-gated section in either track.

## clarify specifics

```
sketch-clarify.sh (-l | -s | -e) [-spec <path>] [--json]
```

`-spec` is optional. Omitted, the spec is discovered in this order:
`check-prerequisites.sh`, then `.specify/feature.json`, then the newest
`specs/*/spec.md`. Reported as `spec_source`.

Markdown only. A `.docx` exits 5, pointing at the companion if one exists, or at
the converter if not. If a `spec.docx` sits beside the `spec.md` being edited,
`stale_docx` names it so the agent can warn that Word version is now behind.

The resolution embeds `question_bank`, the catalog filtered to depth and track,
each question carrying a stable `id`, `section`, `marker` and `text`. That bank
is the ring fence: a question with no id in it is invented by definition.

Regenerate the bank directly:

```bash
python3 scripts/lib/parse_catalog.py <catalog.md> \
  --depth lightweight|standard|exhaustive \
  --track generic|ai \
  --format json|text
```

## Self-test

```bash
scripts/bash/selftest.sh
```

71 assertions: every exit code on both commands, every output rule, every track
and depth combination, the catalog parser against all six published counts, the
ring-fence invariants (unique ids, well-formed ids, marker stripping), and the
converter contract.
