# Changelog

## 0.1.0

Version numbering reset to 0.1.0. Everything below this line, previously
tagged 1.0.0 through 3.1.0 during development, is retained as pre-release
history: the fixes and design decisions it documents are still current, only
the version numbers preceding this reset are superseded.

Content otherwise unchanged from the prior 3.1.0 entry: Sketch Base branding,
no functional change. Commands, flags, resolvers, and templates are untouched;
self-test remains 71 assertions, all passing.

### Added
- **"Sketch Base" designation.** Sketch is the organization's official way to
  extend Spec Kit; Base is its foundational tier, for commands that apply to
  all software development in the organization rather than one domain, team,
  or role. Recorded in three places so it surfaces wherever someone is
  browsing rather than only in prose:
  - `extension.yml`: `"sketch base"` added to `tags`, and both command
    descriptions prefixed `[Sketch Base]`
  - `extension.yml`: the extension description states the tier explicitly
  - `README.md`: opening section explains the tier and how a domain-specific
    or role-specific extension differs (suffixed id, separate package, not
    part of this repository)
- A `Tag` column on the command table in `README.md`.

### Changed
- Extension description generalized from banking-specific framing to
  organization-wide, matching the Base tier's actual scope. The worked
  examples (10-K extraction, counterparty exposure reporting) remain
  banking-flavored; that is illustrative content, not a scope restriction on
  the mechanism itself.
- Removed the standalone `"banking"` tag, superseded by `"sketch base"` as the
  primary classification. Domain-specific tags belong on domain-specific
  extensions (`sketch-xxx`), not on Base.

---

## Pre-release history (superseded version numbers)

## 3.0.0

Renamed the extension, and verified it against GitHub Copilot's actual current
frontmatter and file-layout requirements rather than assuming Claude Code's
conventions would transfer.

### Changed, breaking
- Extension id: `sketchkit` to `sketch`. Package, directory, and every internal
  path (`.specify/extensions/sketch/`) renamed to match.
- Command names restored to the `speckit.{ext-id}.{cmd}` pattern with the new,
  shorter id: `speckit.sketch.specify` and `speckit.sketch.clarify`.
- Script files renamed: `sketch-specify.sh`, `sketch-clarify.sh`,
  `sketch-specify.ps1`.

### Fixed
- **CI naming assertion was checking the wrong prefix.** A blind find-and-replace
  during the rename turned `startswith('sketchkit.')` into
  `startswith('sketch.')`, which does not match the real command names
  (`speckit.sketch.specify` starts with `speckit.`, not `sketch.`). Would have
  failed on the first real CI run. Corrected to `startswith('speckit.sketch.')`.
- **Manual-install instructions pointed at the wrong skill folder.** The
  three-segment name `speckit.sketch.specify` hyphenates in full to
  `speckit-sketch-specify`. The rename's text substitution only touched the word
  "sketchkit," leaving stale instructions that named the folder `sketch-specify`,
  silently dropping the `speckit-` prefix. Both the Claude Code manual-install
  snippet and its explanatory text are corrected.
- Two stale self-test counts, "66 assertions," left over from before the
  docx-authoring fix landed at 71. Corrected in `INSTALL.md` and
  `docs/ARGUMENTS.md`.

### Added
- Verified against GitHub Copilot's actual documented skill format rather than
  assumed: Copilot's own frontmatter fields, `argument-hint`, `user-invocable`,
  `disable-model-invocation`, are exactly the fields this extension's command
  files already carried. No changes needed for compatibility, confirmed rather
  than assumed.
- Documented Copilot's two install modes explicitly, since they are not
  interchangeable: legacy default (`.agent.md` + `.prompt.md`, dotted
  invocation) versus skills (`speckit-<name>/SKILL.md`, hyphenated invocation,
  matching Claude Code's layout). `INSTALL.md` covers manual install for both.
- A note in `docs/HOWTO.md` and `README.md` that the dotted canonical name in
  every example becomes a hyphenated slash command on skills-based agents,
  since that is what most readers will actually type.

## 2.0.1

Fixes a bug that produced a `.docx` Word could not open.

### Fixed
- **The generated Word document was corrupt.** The specify skill said to "author
  the `.docx` first, then generate the Markdown from it", but gave no mechanism
  for authoring a `.docx`. An agent following it wrote text into a file named
  `spec.docx`, and since a `.docx` is a ZIP archive of XML, Word refused to open
  the result. The direction is now reversed: author the Markdown, then convert.

### Added
- `scripts/bash/md-to-docx.sh`: converts the authored Markdown to Word, taking
  `--reference <template.docx>` so fonts, heading styles, table styles and
  colours come from the depth-graded template. Verifies its own output is a
  readable archive with the required parts and exits 8 if not, rather than
  leaving a file that fails to open.
- Resolver emits `authoring_direction`, `convert_cmd_to_docx` and
  `convert_cmd_to_md`.
- Five self-test assertions covering the new converter, including that the
  output is a valid archive and that the house font survives the conversion.
  Total 71.

### Changed
- `create` mode no longer copies the template `.docx` into the feature
  directory. The `.docx` is produced by conversion from the Markdown.
- Extending a `.docx` baseline now explicitly means convert to Markdown, edit,
  convert back. Editing a `.docx` in place is never attempted.

## 2.0.0

Second command, and a breaking change to the first.

### Added
- `/speckit.sketch.clarify`: finds unanswered catalog questions in an existing
  spec and asks up to five, one at a time, with a recommended answer. Follows
  stock `/speckit.clarify` in structure and cadence.
- **Ring fence**: clarify asks only questions present in the shipped catalog,
  each cited by a stable id. Enforced by `scripts/lib/parse_catalog.py`, which
  emits the numbered bank the agent must cite from. Questions the agent judges
  missing are reported under "Outside the catalog" rather than asked.
- Track auto-detection for clarify, read from the spec: Part D present means
  AI-Extended. Detects the case where Part D exists but Section 13 disclaims it.
- Spec discovery for clarify with no `-spec`: `check-prerequisites.sh`, then
  `.specify/feature.json`, then the newest `specs/*/spec.md`.
- Stale `.docx` reporting when clarify edits a `spec.md` with a `spec.docx`
  beside it.
- Self-test grown from 38 to 66 assertions, now covering both commands, the
  catalog parser against all six published counts, and ring-fence invariants.

### Changed, breaking
- **`-ai` removed from specify.** Passing it now exits 1 with an explanation.
  The track is determined by the agent from the transcript, against stated
  evidence, and ambiguity resolves to AI-Extended. In extend mode the baseline
  spec's structure is the hint.
- The specify resolver now emits BOTH tracks under a `tracks` object instead of
  one resolved set. Agents must use `tracks.<track>.*` after deciding.
- Extension id is `sketch`, not `sketch-specify`, now that it carries two
  commands. Command names are `speckit.sketch.specify` and
  `speckit.sketch.clarify`.

### Notes
- `[AI]` questions are not confined to Part D: 24 of the 64 sit in Sections 5, 6,
  7, 8, 10, 11, 12, 19 and 20. The track decision changes the question set across
  the whole document, which is why it is a finding rather than a flag.
- PowerShell parity covers specify only. Clarify runs under Git Bash or WSL on
  Windows; `scripts/powershell/README.md` says so.

## 1.0.0

First release: `/speckit.sketch.specify` only.
