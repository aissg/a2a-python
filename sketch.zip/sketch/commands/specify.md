---
name: "speckit.sketch.specify"
description: "Create or enhance a depth-graded requirement specification from an interview transcript."
argument-hint: "(-l | -s | -e) -transcript <path> [-spec <path>]"
compatibility: "Requires a project initialised with specify init. Requires pandoc when a .docx is written."
metadata:
  author: "sketch"
  source: "commands/specify.md"
  derived-from: "github-spec-kit templates/commands/specify.md"
user-invocable: true
disable-model-invocation: false
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

Unlike `/speckit-specify`, the input here is **not** a natural language feature
description. It is a flag set naming an interview transcript and a depth. The
transcript is the only source of truth for content. You never invent an answer
that the transcript does not support.

## Arguments

| Flag | Required | Meaning |
|------|----------|---------|
| `-l`, `--lightweight` | one of three | First interview depth, about 1 hour |
| `-s`, `--standard` | one of three | Production planning depth, about 1 day |
| `-e`, `--exhaustive` | one of three | Regulated depth, 3 days to 1 week |
| `-transcript <path>` | **yes** | Interview transcript file |
| `-spec <path>` | no | Existing spec to enhance, `.docx` or `.md` |

There is no `-ai` flag. Whether Part D applies is a finding about the source
material, not something the caller asserts, so you determine it. See "Deciding
the track" below.

Rules the resolver enforces, and that you must not work around:

- Exactly one of `-l`, `-s`, `-e`. Two or more is an error, none is an error.
- `-transcript` is mandatory. A path that resolves to no readable file is an
  error, whether given absolute or relative.
- `-spec` is optional. If given and the path does not resolve, that is an error;
  do not silently fall back to authoring from scratch.
- `-spec` accepts `.docx` and `.md` only.

## Pre-Execution Checks

**Resolve and validate the arguments first. Nothing else happens until this passes.**

Run the resolver:

```bash
# Locate the install root: a preset and an extension land in different places.
SK=".specify/extensions/sketch"
[ -d "$SK" ] || { echo "sketch extension is not installed"; exit 1; }

"$SK/scripts/bash/speckit.sketch.specify.sh" $ARGUMENTS --json
```

- On a non-zero exit, stop. Report its `ERROR:` line and `hint:` verbatim to the
  user and do not author anything. Exit codes: `1` usage, `2` depth, `3`
  transcript, `4` spec path, `5` spec format, `6` missing asset, `7` pandoc
  required but absent.
- On success it prints a JSON resolution. Every path you use later comes from
  this object. Do not re-derive paths yourself.

Fields you will use: `mode`, `depth`, `track_hint`, `track_decided_by`,
`transcript`, `spec_in`, `spec_in_format`, `out_dir`, `write_docx`, `write_md`,
`out_docx`, `out_md`, `convert_cmd`, `convert_cmd_to_docx`, and the `tracks`
object.

`tracks` holds BOTH `generic` and `ai`, each with its own `section_count`,
`question_total`, `gated_sections`, `template_docx`, `template_md`,
`catalog_docx`, `catalog_md`, `example_docx`, `example_md`. Once you have
decided the track, use `tracks.<track>.*` throughout and ignore the other.

**Check for extension hooks (before specification)**:
- Check if `.specify/extensions.yml` exists in the project root.
- If it exists, read it and look for entries under the `hooks.before_specify` key
- If the YAML cannot be parsed or is invalid, skip hook checking silently and continue normally
- Filter out hooks where `enabled` is explicitly `false`. Treat hooks without an `enabled` field as enabled by default.
- For each remaining hook, do **not** attempt to interpret or evaluate hook `condition` expressions:
  - If the hook has no `condition` field, or it is null/empty, treat the hook as executable
  - If the hook defines a non-empty `condition`, skip the hook and leave condition evaluation to the HookExecutor implementation
- When constructing slash commands from hook command names, replace dots (`.`) with hyphens (`-`). For example, `sketch.git.commit` → `/sketch-git-commit`.
- For each executable hook, output the following based on its `optional` flag:
  - **Optional hook** (`optional: true`):
    ```
    ## Extension Hooks

    **Optional Pre-Hook**: {extension}
    Command: `/{command}`
    Description: {description}

    Prompt: {prompt}
    To execute: `/{command}`
    ```
  - **Mandatory hook** (`optional: false`):
    ```
    ## Extension Hooks

    **Automatic Pre-Hook**: {extension}
    Executing: `/{command}`
    EXECUTE_COMMAND: {command}

    Wait for the result of the hook command before proceeding to the Outline.
    ```
    After emitting the block above you MUST actually invoke the hook and wait for it to finish before continuing. Run it the same way you would run the command yourself in this agent/session. Emitting the block alone does not run the hook.
- If no hooks are registered or `.specify/extensions.yml` does not exist, skip silently

## Outline

1. **Generate a concise short name** (2-4 words) for the feature:
   - Derive it from the transcript, not from a user description: take the process
     or artifact the interview is about
   - Use action-noun format when possible, preserve technical terms and acronyms
   - Examples: a transcript about keying 10-K financial fields → `10k-field-extraction`;
     a transcript about a weekly counterparty report → `counterparty-exposure-report`
   - In `enhance` mode, reuse the existing spec's feature name rather than coining
     a new one

2. **Branch creation** (optional, via hook):

   If a `before_specify` hook ran successfully above, it will have created or
   switched to a git branch and output JSON containing `BRANCH_NAME` and
   `FEATURE_NUM`. Note these for reference; the branch name does **not** dictate
   the spec directory name. If the user explicitly provided `GIT_BRANCH_NAME`,
   pass it through to the hook.

3. **Create the spec feature directory**:

   Specs live under the default `specs/` directory unless the user explicitly provides `SPECIFY_FEATURE_DIRECTORY`.

   **Resolution order for `SPECIFY_FEATURE_DIRECTORY`**:
   1. If the user explicitly provided `SPECIFY_FEATURE_DIRECTORY`, use it as-is
   2. In `enhance` mode, if `spec_in` already sits inside a `specs/<dir>/`, use that directory and do **not** create a new one
   3. Otherwise auto-generate under `specs/`:
      - Check `.specify/init-options.json` for `feature_numbering` (preferred) or `branch_numbering` (deprecated)
      - If `"timestamp"`: prefix is `YYYYMMDD-HHMMSS`
      - If `"sequential"` or absent: prefix is `NNN`, the next available 3-digit number after scanning `specs/`
      - Directory name is `<prefix>-<short-name>`
      - If `branch_numbering` was used, emit: "⚠️ `branch_numbering` in init-options.json is deprecated. Rename to `feature_numbering`."

   **Create the directory and seed the spec**:
   - `mkdir -p SPECIFY_FEATURE_DIRECTORY`
   - The active template is **not** the stock `spec-template`. Use
     `tracks.<track>.template_docx` and `tracks.<track>.template_md` from the
     resolution, once step 4 has settled the track. These come from this
     extension and already carry the depth grade requested.
   - In `create` mode, the starting point is `tracks.<track>.template_md`. Do not
     copy the template `.docx` into the feature directory: the `.docx` is
     produced by conversion at step 10, from the Markdown you author.
   - In `enhance` mode the starting point is `spec_in`, not the template. The
     template is the structural reference for the sections the new depth adds.
   - Persist the resolved path to `.specify/feature.json`:
     ```json
     {
       "feature_directory": "<resolved feature dir>"
     }
     ```
     Write the actual resolved path (for example `specs/003-10k-field-extraction`),
     not the literal string.

   **IMPORTANT**:
   - Only one feature per invocation
   - The spec directory name and the git branch name are independent
   - The spec directory and file are always created by this command, never by the hook

4. **Decide the track.** This replaces the old `-ai` flag, and it is a finding
   you must justify, not a guess.

   **In `enhance` mode**, the baseline already settled it. `track_hint` reports
   `ai` or `generic` from the baseline's structure. Confirm it against the
   transcript and keep it unless the transcript actively contradicts it, in
   which case say so rather than silently switching tracks.

   **In `create` mode**, read the transcript and answer one question: does this
   feature use a model whose output can be wrong in ways ordinary software
   cannot be?

   Evidence for the **AI-Extended** track, any one of which is sufficient:
   - A model, LLM, classifier, extraction, prediction, scoring, ranking,
     summarisation, or generation is described as doing the work
   - Accuracy, confidence, precision, recall, or a percentage-correct target is
     discussed as a property of the system's output
   - A human review, checking, or correction step exists because the output may
     be wrong
   - Training data, test data with known answers, or evaluation is mentioned
   - Prompt, embedding, vector search, RAG, or fine-tuning appears

   Evidence for the **generic** track:
   - The work is deterministic: rules, thresholds, joins, aggregation, routing,
     reporting, or workflow, where the same input always gives the same output
   - Errors, if discussed, come from bad data or human mistakes, not from the
     system being unsure

   Rules for the call:
   - If the transcript is genuinely ambiguous, choose **AI-Extended**. Part D
     answered "not applicable, this is deterministic" is a recorded decision. A
     generic document on an AI feature has no place to record that Part D was
     ever considered, and that absence is what a reviewer cannot recover.
   - If you choose AI-Extended and Section 13's first question turns out to be
     No, keep Part D and mark Sections 14 to 18 not applicable with that reason.
     Do not regenerate on the generic track.
   - State the decision and the evidence in the Completion Report. One line:
     the track, and what in the transcript decided it.

   Then use `tracks.<your decision>.*` for the template, catalog, example,
   `section_count`, `question_total`, and `gated_sections`.

   Note that `[AI]` questions are not confined to Part D. They also appear in
   Sections 5, 6, 7, 8, 10, 11, 12, 19 and 20, so the track decision changes the
   question set across the whole document, not just Part D.

5. **Load the reference set.** All three, in this order of authority:
   1. `tracks.<track>.template_md`: the structural contract. Reproduce its sections, tables and
      callouts exactly. Never add, remove, rename or reorder a section.
   2. `tracks.<track>.catalog_md`: the interview question catalog for this track. Markers
      `[L]`, `[S]`, `[E]` are cumulative. `[AI]` marks AI-only questions. Its
      **First Interview Key Points** section is the map for Lightweight work.
   3. `tracks.<track>.example_md`: a completed, signed-off specimen at this exact depth. Match
      its tone, brevity and field filling. When unsure, copy it.

6. **IF EXISTS**: Load `.specify/memory/constitution.md` for project principles and governance constraints.

7. Follow this execution flow:
    1. Read the transcript in full. If empty or unreadable: ERROR "Transcript is empty"
    2. In `enhance` mode, read `spec_in` in full first. It is the baseline, not a
       draft to rewrite. If its depth is already at or above the requested depth,
       warn and continue: the transcript may still close open gaps.
    3. Extract key concepts from the transcript
       Identify: actors, actions, data, constraints, numbers, decisions
    4. Walk the catalog for this depth and mark every question Answered, Partial
       or Missing. Use only what a source actually says.
    5. For unclear aspects:
       - Do **not** make informed guesses about facts. An absent number is a gap.
       - Record it as a gap in the Interview Coverage Gaps block, which is where
         this template puts what stock Spec Kit would put in
         `[NEEDS CLARIFICATION]` markers
       - **LIMIT: Maximum 3 questions back to the user**, and only after the
         document is written
       - Prioritize by impact: scope > security/privacy > user experience > technical details
    6. Fill User Scenarios (Section 3)
       If no clear user flow: ERROR "Cannot determine user scenarios"
    7. Generate Functional Requirements (Section 4)
       Every requirement in EARS form:
       `When / While / Where / If <trigger or state>, the <system> shall <response>`
       One behaviour each, testable pass or fail, no implementation detail
    8. Define Acceptance Criteria (Section 19 / 13) and Quality Attributes
       (Section 7). These are separate on purpose: Section 7 holds the
       non-functional target with an owner, Section 19 holds the measurable
       condition that proves it. Never collapse one into the other.
    9. Fill Data & Information (Section 5)
    10. Fill the Interview Coverage Gaps block
    11. Return: SUCCESS (spec ready for planning)

8. Write the specification using the template structure, replacing placeholders
   with concrete detail from the transcript while preserving section order and
   headings. Where a mandatory field has no answer, keep the template's
   bracketed placeholder so the gap stays visible rather than hidden.

9. **Specification Quality Validation**: After writing the initial spec, validate it against quality criteria:

   a. **Create Spec Quality Checklist**: Generate a checklist file at
      `SPECIFY_FEATURE_DIRECTORY/checklists/requirements.md` from
      `checklists/requirements.md` in this extension. It mirrors the template's
      own Review & Acceptance Checklist so the two never diverge.

   b. **Run Validation Check**: Review the spec against each checklist item:
      - For each item, determine if it passes or fails
      - Document specific issues found (quote relevant spec sections)

   c. **Handle Validation Results**:

      - **If all items pass**: mark the checklist complete and proceed to the Mandatory Post-Execution Hooks section

      - **If items fail**:
        1. List the failing items and specific issues
        2. Update the spec to address each issue
        3. Re-run validation until all items pass (max 3 iterations)
        4. If still failing after 3 iterations, record the remainder in Section 20
           Open Items & Risks and warn the user. Never ship a silent defect.

      - **If gaps remain in the Coverage Gaps block**: that is expected output at
        Lightweight, not a failure. Say so in the callout. At Exhaustive, state
        plainly whether any remaining gap would stop a reviewer signing.

   d. **Update Checklist**: after each validation iteration, update the checklist file with current pass/fail status

   Leave the spec's own Review & Acceptance Checklist boxes **unticked**. The
   worked example ships ticked because it is a signed-off specimen; a fresh draft
   is not signed off, and the gate owner ticks them.

10. **Produce the outputs named in the resolution.** Do not decide this yourself:

   | `mode` | `spec_in_format` | Write |
   |--------|------------------|-------|
   | create | n/a | `spec.docx` **and** `spec.md` |
   | enhance | `docx` | `spec.docx` **and** `spec.md` |
   | enhance | `md` | `spec.md` only |

   **Author the Markdown, then convert. Never the other way round.**

   You cannot author a `.docx` directly. A `.docx` is a ZIP archive of XML;
   writing text into a file with that extension produces a file Word refuses to
   open. So:

   1. Author `spec.md` against `tracks.<track>.template_md`, filling every
      section. This is the document. Get it right here.
   2. If `write_docx` is true, convert it, passing the template for the track
      and depth in use as the style reference:

      ```bash
      "$SK/scripts/bash/md-to-docx.sh" <out_md> <out_docx> \
        --reference <tracks.<track>.template_docx>
      ```

      `--reference` is what carries the house styling across: fonts, heading
      styles, table styles and colours come from the template, content comes
      from your Markdown. Omit it and pandoc applies its own defaults and the
      document stops looking like the others.

   3. The converter verifies its own output is a readable ZIP with the required
      parts, and exits 8 rather than leaving a file that fails to open. If it
      exits 8, report that and do not claim the `.docx` was produced.

   Do not call pandoc yourself in either direction. `md-to-docx.sh` and
   `docx-to-md.sh` are the only two conversion points, and each validates what
   it produced.

   **In `enhance` mode from a `.docx` baseline**, the same rule applies. Convert
   the baseline to Markdown first with `"$SK/scripts/bash/docx-to-md.sh"`, edit
   the Markdown, then convert back. Never attempt to edit the `.docx` in place.

   When `write_docx` is false, author the Markdown against
   `tracks.<track>.template_md` and stop there: no conversion is needed.

   `docx-to-md.sh` (the reverse direction, used in enhance mode) uses `-t gfm`
   rather than `-t markdown`, because plain `-t markdown` emits grid tables for
   the wide tables in these templates, which match neither the shipped `.md`
   references nor GitHub's renderer.

## Mandatory Post-Execution Hooks

**You MUST complete this section before reporting completion to the user.**

Check if `.specify/extensions.yml` exists in the project root.
- If it does not exist, or no hooks are registered under `hooks.after_specify`, skip to the Completion Report.
- If it exists, read it and look for entries under the `hooks.after_specify` key.
- If the YAML cannot be parsed or is invalid, skip hook checking silently and continue to the Completion Report.
- Filter out hooks where `enabled` is explicitly `false`. Treat hooks without an `enabled` field as enabled by default.
- For each remaining hook, do **not** attempt to interpret or evaluate hook `condition` expressions:
  - If the hook has no `condition` field, or it is null/empty, treat the hook as executable
  - If the hook defines a non-empty `condition`, skip the hook and leave condition evaluation to the HookExecutor implementation
- When constructing slash commands from hook command names, replace dots (`.`) with hyphens (`-`).
- For each executable hook, output the following based on its `optional` flag:
  - **Mandatory hook** (`optional: false`): **You MUST emit `EXECUTE_COMMAND:` for each mandatory hook**:
    ```
    ## Extension Hooks

    **Automatic Hook**: {extension}
    Executing: `/{command}`
    EXECUTE_COMMAND: {command}
    ```
    After emitting the block above you MUST actually invoke the hook and wait for it to finish before continuing.
  - **Optional hook** (`optional: true`):
    ```
    ## Extension Hooks

    **Optional Hook**: {extension}
    Command: `/{command}`
    Description: {description}

    Prompt: {prompt}
    To execute: `/{command}`
    ```

## Completion Report

Report completion to the user with:
- `SPECIFY_FEATURE_DIRECTORY`: the feature directory path
- `SPEC_FILE`: the Markdown spec path, and the `.docx` path when one was written
- Track and depth used, the evidence in the transcript that decided the track, and the question count resolved out of `tracks.<track>.question_total`
- Coverage Gaps summary: how many sections carry a gap row, and whether any blocks the gate
- Checklist results summary
- Readiness for the next phase. Prefer `/speckit.sketch.clarify` at the same depth, which checks the spec against this extension's own question catalog. `/speckit.clarify` also works but generates its own questions instead of using the catalog.

**NOTE:** Branch creation is handled by the `before_specify` hook (git extension).
Spec directory and file creation are always handled by this core command.

## Quick Guidelines

- Focus on **WHAT** users need and **WHY**.
- Avoid HOW to implement (no tech stack, APIs, code structure).
- Written for business stakeholders, not developers.
- DO NOT create any checklists embedded in the spec beyond the template's own
  Review & Acceptance Checklist. Quality checklists are separate files.

### Section Requirements

- **Every section exists at every depth.** What changes with depth is how many
  questions inside each one the interview covers.
- **When a section does not apply, keep it.** Retain the heading and its callout
  and add a short italic reason. This is a deliberate departure from stock Spec
  Kit, which removes non-applicable sections: deleting one destroys the evidence
  that it was considered, which is what the Coverage Gaps block exists to record.
  Never write "N/A".
- On the AI track at Lightweight only, Section 16 Provenance & Lineage carries
  the template's own not-interrogated note. Keep the note, drop its square
  brackets, as the worked example shows. `tracks.ai.gated_sections` tells you
  when this applies: it is `16` at Lightweight and `none` otherwise.
- On the generic track there is no Part D. If you chose AI-Extended and Section
  13's first question is answered No, keep Part D and mark Sections 14 to 18 not
  applicable with that reason, rather than regenerating on the generic track.

### For AI Generation

When producing this spec from a transcript:

1. **Never guess a fact.** Stock Spec Kit tells you to make informed guesses and
   document them as assumptions. That is wrong here: this document is an audit
   artifact, and a plausible invented number is worse than a visible gap. Every
   figure comes from the transcript or the baseline spec.
2. **Silence is not a retraction.** In `enhance` mode, carry every answered field
   forward. Do not drop an answer because the new transcript did not revisit it.
3. **Newer wins on conflict.** Where the transcript contradicts the baseline, the
   transcript is right. Record the change in Document Control and keep the
   superseded figure visible where it still matters.
4. **The baseline's Coverage Gaps table is the agenda.** Each row either resolves
   and disappears, or survives with what still blocks it.
5. **Think like a tester**: a requirement you could not write a pass or fail test
   for is not finished.
6. **Vague adjectives do not survive.** Either the transcript gives a figure, or
   the term goes in the Review findings table.
7. **Limit clarifications**: maximum 3 questions, asked after delivery, each with
   a short options table showing what each answer would mean.

**Reasonable defaults you may still apply** (structure, never facts): section
order, table shapes, EARS phrasing, ID numbering (`FR-1`, `US-1`, `AC-1`,
`NFR-1`), and the document control layout.

### Acceptance Criteria Guidelines

Acceptance criteria must be:

1. **Measurable**: a specific metric, threshold or observable condition
2. **Technology-agnostic**: no frameworks, languages, databases or tools
3. **User- or control-focused**: an outcome someone can check
4. **Traced**: every criterion names the `FR-n` or `NFR-n` it proves

**Good examples**:

- "A deliberately incomplete extract holds the run and publishes nothing"
- "The drafted report is ready by 06:00 on each parallel-run Monday"
- "The audit trace for a sampled published figure is produced within one working day"

**Bad examples**:

- "The pipeline is fast" (no figure, goes in Review findings instead)
- "API response time under 200ms" (implementation detail)
- "Users are satisfied" (not observable)

## Done When

- [ ] Resolver ran clean, and every path used came from its JSON output
- [ ] Track decided from the transcript or baseline, with the evidence stated in the report
- [ ] Every question at the requested depth answered or logged as a gap, count recorded in Depth and Applicability
- [ ] Every functional requirement in EARS form; from Standard depth, each traced to a scenario
- [ ] Coverage Gaps block complete, including the four assumption checks
- [ ] Template's Review & Acceptance Checklist left unticked for the gate owner
- [ ] Markdown authored first; `.docx` produced from it by `md-to-docx.sh` with the template passed as `--reference`
- [ ] Converter exited 0, meaning the `.docx` was verified as a readable archive
- [ ] Extension hooks dispatched or skipped per the rules above
- [ ] Completion reported with feature directory, spec paths, track, depth, and checklist results
