# PowerShell parity

`sketch-specify.ps1` mirrors the bash resolver: same flags, same validation,
same exit codes.

`sketch-clarify.ps1` is **not yet ported**. On Windows, run the bash resolver
under Git Bash or WSL:

```
bash .specify/extensions/sketch/scripts/bash/sketch-clarify.sh -l --json
```

Both commands also depend on `python3` being on PATH for catalog parsing, which
is required on every platform, not only Windows.
