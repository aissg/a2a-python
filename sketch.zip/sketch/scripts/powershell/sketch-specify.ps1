<#
.SYNOPSIS
  sketch-specify: parse, validate and resolve inputs for /speckit.sketch.specify.

.DESCRIPTION
  Windows parity for scripts/bash/sketch-specify.sh. Same flags, same
  validation, same JSON resolution, same exit codes.

  Exit codes
    0  ok
    1  usage error
    2  depth error (none, or more than one)
    3  transcript error
    4  spec path error
    5  spec format error
    6  asset error
    7  pandoc required but not found
#>

$ErrorActionPreference = 'Stop'
$ExtRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Die([int]$Code, [string]$Message, [string]$Hint = '') {
  Write-Host "ERROR: $Message" -ForegroundColor Red
  if ($Hint) { Write-Host "  hint: $Hint" -ForegroundColor DarkYellow }
  exit $Code
}

function Show-Usage {
  @'
Usage:
  sketch-specify.ps1 (-l | -s | -e) -transcript <path> [-spec <path>] [-ai] [-Json]

Depth, exactly one required:
  -l, -lightweight     first interview, about 1 hour
  -s, -standard        production planning, about 1 day
  -e, -exhaustive      regulated work, 3 days to 1 week

Track:
  (no -ai flag: the track is determined from the transcript by the agent)

Inputs:
  -transcript <path>   REQUIRED. Interview transcript file.
  -spec <path>         OPTIONAL. Existing spec, .docx or .md.

Output rules:
  no -spec        -> writes spec.docx AND spec.md
  -spec *.docx    -> writes spec.docx AND spec.md
  -spec *.md      -> writes spec.md only
'@ | Write-Host
}

# ------------------------------------------------------------------ parse
$depth = ''; $depthFlags = @()
$transcript = ''; $specIn = ''; $haveTranscriptFlag = $false
$jsonOnly = $false; $outDir = ''
$argv = $args

function Set-Depth([string]$value, [string]$flag) {
  $script:depthFlags += $flag
  if ($script:depth -and $script:depth -ne $value) {
    Die 2 "Only one depth may be specified. Found: $($script:depthFlags -join ' ')" `
        'Choose exactly one of -l (lightweight), -s (standard), -e (exhaustive).'
  }
  if ($script:depth) {
    Die 2 "Depth flag repeated: $($script:depthFlags -join ' ')" "Specify -$($value.Substring(0,1)) once."
  }
  $script:depth = $value
}

if ($argv.Count -eq 0) { Show-Usage; Die 1 'No arguments given.' }

for ($i = 0; $i -lt $argv.Count; $i++) {
  switch -Regex ($argv[$i]) {
    '^-(l|lightweight)$' { Set-Depth 'lightweight' $argv[$i] }
    '^-(s|standard)$'    { Set-Depth 'standard'    $argv[$i] }
    '^-(e|exhaustive)$'  { Set-Depth 'exhaustive'  $argv[$i] }
    '^-ai$'              { Die 1 '-ai is not a flag for this command.' 'Whether Part D applies is determined from the transcript, not asserted by the caller. Drop the flag and re-run.' }
    '^-transcript$' {
      $haveTranscriptFlag = $true
      if ($i + 1 -ge $argv.Count -or $argv[$i+1].StartsWith('-')) { Die 1 '-transcript requires a file path.' }
      $transcript = $argv[++$i]
    }
    '^-spec$' {
      if ($i + 1 -ge $argv.Count -or $argv[$i+1].StartsWith('-')) { Die 1 '-spec requires a file path.' }
      $specIn = $argv[++$i]
    }
    '^-outDir$' {
      if ($i + 1 -ge $argv.Count) { Die 1 '-outDir requires a path.' }
      $outDir = $argv[++$i]
    }
    '^-Json$'            { $jsonOnly = $true }
    '^-(h|help|\?)$'     { Show-Usage; exit 0 }
    '^-(d|detailed)$'    { Die 2 "Unknown depth flag '$($argv[$i])'. Standard depth is -s." 'Use -l, -s or -e.' }
    default              { Show-Usage; Die 1 "Unknown argument: $($argv[$i])" }
  }
}

# ------------------------------------------------------------------ validate
if (-not $depth) {
  Die 2 'No depth specified.' 'Add exactly one of -l (lightweight), -s (standard), -e (exhaustive).'
}
if (-not $haveTranscriptFlag) {
  Die 3 '-transcript is required.' 'Pass the interview transcript: -transcript .\notes\interview.txt'
}

function Resolve-ExistingFile([string]$p) {
  if (-not $p) { return $null }
  $p = $p.Trim('"').Trim("'")
  if ($p.StartsWith('~')) { $p = Join-Path $HOME $p.Substring(1) }
  $candidate = if ([System.IO.Path]::IsPathRooted($p)) { $p } else { Join-Path (Get-Location).Path $p }
  if (Test-Path -LiteralPath $candidate -PathType Leaf) { return (Resolve-Path -LiteralPath $candidate).Path }
  return $null
}

$transcriptAbs = Resolve-ExistingFile $transcript
if (-not $transcriptAbs) {
  Die 3 "Transcript not found: '$transcript'" `
      "Checked as an absolute path and relative to $((Get-Location).Path). Give a path that resolves to a readable file."
}

$mode = 'create'; $specInAbs = $null; $specInFormat = $null
if ($specIn) {
  $mode = 'enhance'
  $specInAbs = Resolve-ExistingFile $specIn
  if (-not $specInAbs) {
    Die 4 "Spec file not found: '$specIn'" `
        "Checked as an absolute path and relative to $((Get-Location).Path). Omit -spec to author a new spec instead."
  }
  switch ([System.IO.Path]::GetExtension($specInAbs).ToLower()) {
    '.docx'     { $specInFormat = 'docx' }
    '.md'       { $specInFormat = 'md' }
    '.markdown' { $specInFormat = 'md' }
    default {
      Die 5 "Unsupported spec format: '$([System.IO.Path]::GetExtension($specInAbs))'" '-spec accepts .docx or .md only.'
    }
  }
}

# ------------------------------------------------------------------ output plan
$writeDocx = -not ($mode -eq 'enhance' -and $specInFormat -eq 'md')
$writeMd = $true

if (-not $outDir) {
  $outDir = if ($specInAbs) { Split-Path -Parent $specInAbs } else { (Get-Location).Path }
}
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$outDir = (Resolve-Path -LiteralPath $outDir).Path

# ------------------------------------------------------------------ assets
$depthTitle = $depth.Substring(0,1).ToUpper() + $depth.Substring(1)
if ($track -eq 'ai') {
  $tpl = Join-Path $ExtRoot "templates\ai\AI_Template_$depthTitle"
  $cat = Join-Path $ExtRoot 'questions\ai\AI_Requirement_Interview_Questions_Catalog'
  $exa = Join-Path $ExtRoot "examples\ai\AI_Example_10K_Extraction_$depthTitle"
  $sections = 20; $trackName = 'AI-Extended'
  $qtotal = @{ lightweight = 45; standard = 125; exhaustive = 186 }[$depth]
} else {
  $tpl = Join-Path $ExtRoot "templates\generic\Generic_Template_$depthTitle"
  $cat = Join-Path $ExtRoot 'questions\generic\Generic_Requirement_Interview_Questions_Catalog'
  $exa = Join-Path $ExtRoot "examples\generic\Generic_Example_Risk_Reporting_$depthTitle"
  $sections = 14; $trackName = 'Generic'
  $qtotal = @{ lightweight = 34; standard = 92; exhaustive = 122 }[$depth]
}

foreach ($f in @("$tpl.docx", "$tpl.md", "$cat.docx", "$cat.md", "$exa.docx", "$exa.md")) {
  if (-not (Test-Path -LiteralPath $f -PathType Leaf)) {
    Die 6 "Reference asset missing: $($f.Replace($ExtRoot, '').TrimStart('\'))" `
        'The extension is incomplete. Re-install sketch-specify.'
  }
}

$gated = if ($track -eq 'ai' -and $depth -eq 'lightweight') { '16' } else { 'none' }

# ------------------------------------------------------------------ tooling
$pandoc = if (Get-Command pandoc -ErrorAction SilentlyContinue) { 'available' } else { 'missing' }
if ($writeDocx -and $pandoc -eq 'missing') {
  Die 7 'pandoc not found on PATH, but this invocation writes a .docx and its .md companion.' `
      'Install pandoc, or pass -spec <file>.md to produce Markdown only.'
}

# ------------------------------------------------------------------ emit
$outDocx = if ($writeDocx) { Join-Path $outDir 'spec.docx' } else { $null }
$outMd   = Join-Path $outDir 'spec.md'

$resolution = [ordered]@{
  extension_root = $ExtRoot
  mode           = $mode
  track          = $track
  track_name     = $trackName
  depth          = $depth
  depth_title    = $depthTitle
  section_count  = $sections
  question_total = $qtotal
  gated_sections = $gated
  transcript     = $transcriptAbs
  spec_in        = $specInAbs
  spec_in_format = $specInFormat
  out_dir        = $outDir
  write_docx     = $writeDocx
  write_md       = $writeMd
  out_docx       = $outDocx
  out_md         = $outMd
  template_docx  = "$tpl.docx"
  template_md    = "$tpl.md"
  catalog_docx   = "$cat.docx"
  catalog_md     = "$cat.md"
  example_docx   = "$exa.docx"
  example_md     = "$exa.md"
  pandoc         = $pandoc
  convert_cmd    = "pandoc -t markdown `"$outDocx`" -o `"$outMd`""
}

if (-not $jsonOnly) {
  Write-Host 'sketch-specify resolution'
  Write-Host "  mode              $mode"
  Write-Host "  track             $trackName ($sections sections)"
  Write-Host "  depth             $depthTitle ($qtotal questions cumulative)"
  Write-Host "  gated sections    $gated"
  Write-Host "  transcript        $transcriptAbs"
  Write-Host "  spec in           $(if ($specInAbs) { $specInAbs } else { '<none, authoring from scratch>' })"
  Write-Host "  writes            $(if ($writeDocx) { 'spec.docx + spec.md' } else { 'spec.md only' })"
  Write-Host "  out dir           $outDir"
  Write-Host "  pandoc            $pandoc"
  Write-Host ''
}
$resolution | ConvertTo-Json -Depth 4
