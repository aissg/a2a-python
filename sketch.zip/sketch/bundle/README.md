# sketch bundle

Packages the `sketch` extension as a single, versioned, role-oriented install
so a whole team persona can be provisioned with one command.

```bash
specify bundle validate --path ./bundle     # structural + reference checks
specify bundle build --path ./bundle        # produce a versioned .zip artifact
```

Then host the artifact and add a catalog source, so developers run:

```bash
specify bundle install sketch-requirements
```

## Verify the schema before relying on this

`bundle.yml` here is written against the documented bundle concept: a
hand-written manifest that pins each component to a version and optionally
targets an integration. The top-level `bundle:` block and the idea of a pinned
component list are confirmed; the exact field names inside `components:` are
**not** verified against a primary source in this package.

Before using it, run `specify bundle validate --path ./bundle` and, if it
objects, copy the shape from one of the four example manifests that ship in the
spec-kit repository under `examples/bundles/` (product manager, business analyst,
security researcher, developer). Those are authoritative; this file is a
starting point.

The extension itself does not depend on any of this. `specify extension add
--dev` installs it directly and is fully verified.

## Why bundle a single component

Two reasons, even before you add a second:

- **Version pinning.** `specify extension add sketch` takes whatever the
  catalog currently holds. A bundle pins `2.0.0`, so a project provisioned today
  and one provisioned next quarter get the same thing.
- **A stable onboarding command.** `specify bundle install sketch-requirements`
  keeps working unchanged when you later add a compliance preset or a second
  extension to the same bundle.

Installs are idempotent and confined to the project root, and removing a bundle
never touches components another installed bundle still needs.
