# Engineering constitution

Project principles every project in the bank inherits. The agent reads this
before planning, so these constraints shape the plan rather than being audited
after the fact.

This is a **preset**: it changes how existing commands behave, and adds no
commands of its own.

## I. Specification before implementation

No implementation task is generated from an unwritten assumption. Where a
specification is silent, that silence is recorded as a gap rather than filled
with a plausible default. A visible gap is cheap; an invented requirement that
looks authoritative is expensive and is usually found in production.

## II. Facts come from sources

Every figure in a specification traces to something a person said, a document
stated, or a measurement produced. An absent number is a gap. Industry-standard
defaults are not evidence, and a retention period inferred from convention
reads identically to one a records officer stated. Only one of them survives
review.

## III. Requirements are testable

Every functional requirement is written so that a tester can write a pass or
fail test for it. A requirement nobody can test is not cheaper to write, only
cheaper to skip. EARS form is the house standard:
`When / While / Where / If <trigger>, the <system> shall <response>`.

## IV. Non-functional targets have owners

A target without an owner is a wish. Availability, latency, retention and cost
targets name the person or team accountable for them, and the acceptance
criterion that proves each one is recorded separately from the target itself.

## V. Sections that do not apply are kept

Where a section of a specification does not apply, it stays, with a short
reason. A deleted section is indistinguishable from a section nobody thought
about. This is the difference between a document that shows its work and one
that merely looks complete.

## VI. Regulated work carries its evidence

Where work is regulated, client-facing, or model-driven, the specification
carries the evidence a reviewer will ask for: classification, provenance,
evaluation, and the obligation each retention period derives from. Assembling
that evidence at review time rather than authoring time is how deadlines slip.

## Governance

Amendments to this constitution are merge requests against
`platform/presets/sketch-constitution`, approved by the platform team. The
version is bumped on every substantive change, and bundles pin it like any
other component, so a project's principles are as reproducible as its commands.
