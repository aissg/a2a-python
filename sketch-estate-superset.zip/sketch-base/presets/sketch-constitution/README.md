# sketch-constitution

**Sketch Constitution** · Layer L2 · `status: stable` · v0.1.0

Bank-wide engineering constitution: the non-negotiables every project inherits, written as project principles the agent reads before planning.

A preset changes how existing commands behave and adds no commands of its own. It is installed as part of a bundle, never directly.

The content is in [`memory/constitution.md`](memory/constitution.md), which the agent reads before planning.
