# Implementation Plan: [FEATURE]

**Branch**: `[###-feature-name]` | **Date**: [DATE] | **Spec**: [link]

**Input**: Feature specification from `/specs/[###-feature-name]/spec.md`

<!--
  Sketch plan template. Shipped by the sketch-plan preset, Layer 2.

  Three sections are added to the stock Spec Kit template. Each exists because
  something the specification stated failed to reach any design artifact when
  the stock template was run against a real Sketch spec:

    Governance Context   the AI classification and the stated design principles
                         reached no artifact. Not because the agent ignored
                         them, but because Phase 1 produces entities, contracts
                         and a run guide, and a classification is none of those.

    Evaluation Design    evaluation content survived only as run steps inside
                         quickstart.md. The decisions behind it, sample size,
                         labelling method, target, promotion gate, were nowhere
                         a reviewer could approve them.

    Spec Coverage        establishing what had been dropped required reading
                         every artifact by hand. Nobody does that per feature,
                         so nothing was ever checked.

  Two smaller changes: Technical Context pre-labels the two fields no Sketch
  section can feed, and Constitution Check reports the version it evaluated.

  Work-type bundles extend this file through the SKETCH-SLOT markers below. A
  before_plan hook composes the slots and leaves this file untouched.
-->

## Summary

[Extract from feature spec: primary requirement + technical approach from research]

## Feature Context

**Depth**: [Lightweight | Standard | Exhaustive]

**Deployment target**: [PoC | MVP | Production]

**AI feature**: [Yes | No]

<!--
  Read from the specification, not asserted here. Part D present means Yes.

  If No: mark Governance Context and Evaluation Design NOT APPLICABLE, one line
  each, and leave them in place. Deleting a section is indistinguishable from a
  section nobody thought about, which is Principle V of the constitution.
-->

**Evidence strategy**: [test-driven | evaluation-driven]

<!--
  Follows from AI feature above, not chosen separately. A deterministic feature
  asserts correctness with a test. A model-driven feature measures it against a
  labelled sample. Both still test the deterministic code around the model.
-->

## Governance Context

<!--
  Per-feature readings against the constitution's rules. The constitution states
  what must be true for every project; this states what is true for this one.
  A rule copied here becomes a second copy that drifts. A reading placed in the
  constitution is wrong for every other feature.

  Every field takes one of three values:

    a stated value              answered in the specification
    NOT REQUIRED AT <depth>     deliberately out of scope, passes the gate
    NEEDS CLARIFICATION         a gap nobody decided, FAILS the gate

  Three states, not two. With two, an empty field is indistinguishable from a
  deliberate depth decision, so it reads as compliant.
-->

**AI classification**: [the classification recorded in the specification]

**Decision posture**: [decides autonomously above threshold, recommends below | always recommends | decides autonomously]

**Human review authority**: [role holding approval, and the review service-level target]

**Model and hosting**: [approved endpoint, region]

**Data residency**: [region, and what is stored where]

**Provenance record**: [maintained, and what each output carries | NOT REQUIRED AT <depth>]

**Trace destination**: [collector | NOT REQUIRED AT <depth>]

<!-- SKETCH-SLOT: governance -->

## Evaluation Design

<!--
  The decisions behind the evaluation. The runnable detail belongs in
  quickstart.md and is not duplicated here; this section records the choices a
  reviewer signs off on.

  Fill only where the feature is model-driven. For a deterministic feature,
  write NOT APPLICABLE and the reason, and keep the section.
-->

**Labelled sample**: [size, source, how selected | NOT REQUIRED AT <depth>]

**Sample composition**: [the stated minimums that make the sample representative]

**Ground truth method**: [who labels, whether independently double-keyed, who adjudicates disagreement]

**Primary metric and target**: [metric, target, and the requirement or success criterion it derives from]

**Failure asymmetry**: [which error direction is worse, and therefore which way thresholds lean]

**Confidence calibration**: [how scores are calibrated against the labelled sample | N/A, no score emitted]

<!--
  An uncalibrated score is not permitted. It will be trusted whether or not it
  means anything. Where no score is emitted, say so rather than leaving blank.
-->

**Evaluation level**: [step-level | task-level]

**Promotion gate**: [what must hold before this moves past the current deployment target]

**Re-validation triggers**: [what forces a re-run: model version, prompt or skill version, input distribution shift]

**Where the runnable evaluation lives**: [quickstart.md, and the harness path if separate]

<!-- SKETCH-SLOT: evaluation -->

## Technical Context

<!--
  Language/Version and Testing carry a pre-set marker because no section of the
  Sketch requirement template can feed them: the specification deliberately
  excludes implementation detail. They are planning decisions on every feature
  without exception, so pre-labelling turns a silent invention into a declared
  one.

  Every other field traces to a specification section or carries
  NEEDS CLARIFICATION. Never fill a field from inference and leave it unmarked.
-->

**Language/Version**: [PLANNING DECISION, research.md #_]

**Testing**: [PLANNING DECISION, research.md #_]

**Primary Dependencies**: [value, spec section | PLANNING DECISION, research.md #_ | NEEDS CLARIFICATION]

**Storage**: [value, spec section | NEEDS CLARIFICATION]

**Target Platform**: [value, spec section | NEEDS CLARIFICATION]

**Project Type**: [value, spec section | NEEDS CLARIFICATION]

**Performance Goals**: [value, NFR reference | NEEDS CLARIFICATION]

**Constraints**: [value, spec section | NEEDS CLARIFICATION]

**Scale/Scope**: [value, spec section | NEEDS CLARIFICATION]

<!-- SKETCH-SLOT: technical-context -->

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

**Constitution version evaluated**: [version, and the layers merged]

<!--
  Report the version and the layers. A reviewer needs to know which ruleset this
  plan passed, and a constitution assembled from layers at run time is otherwise
  invisible in the finished plan.

  If the constitution is still an unfilled template, say so and record the
  result as pass-by-default. Do not report a pass on merits.
-->

[Gates determined from the constitution file]

<!-- SKETCH-SLOT: constitution-check -->

## Project Structure

### Documentation (this feature)

```text
specs/[###-feature]/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
└── tasks.md             # Phase 2 output, not created by the plan command
```

### Source Code (repository root)

<!--
  State the layout, the real directories, and the one decision the folder names
  do not show. No option list: a folder tree in a template enforces nothing, and
  the team knows its own layout.

  Examples of the hidden decision, by layout:
    layered      where state lives, and what a service may hold
    web          where validation happens, client or server or both
    pipeline     where side effects are allowed to live
    agent        where the human approval interrupt sits

  Work-type bundles inject a starting layout into the slot below.
-->

**Structure Decision**: [the layout, the real directories, and the hidden decision named above]

<!-- SKETCH-SLOT: structure -->

## Spec Coverage

<!--
  What reached a design artifact, and what did not.

  Content that states what the system does carries through reliably, with or
  without an identifier. What goes missing is classification labels and stated
  principles, because no design artifact has a slot for them. This table makes
  the difference visible in seconds rather than requiring someone to read every
  artifact.
-->

| Spec ID series | Landed in | Unmapped IDs |
|---|---|---|
| FR-* | [artifacts] | [list, or none] |
| NFR-* | [artifacts] | [list, or none] |
| VR-* | [artifacts] | [list, or none] |
| AC-* | [artifacts] | [list, or none] |
| SC-* | [artifacts] | [list, or none] |

**Governance content carried forward**: [where the classification, decision posture and stated principles landed]

**Open items carried forward**: [each open item from the specification, and how research.md handled it]

<!--
  An open item resolved by invention is worse than one carried forward. Where
  the specification left a question open, the plan records that it stayed open
  and what was built instead.
-->

<!-- SKETCH-SLOT: coverage -->

## Complexity Tracking

> Fill ONLY if Constitution Check has violations that must be justified.
> Principles the constitution marks non-negotiable cannot be satisfied here.

| Violation | Why Needed | Simpler Alternative Rejected Because |
|-----------|------------|-------------------------------------|
| [principle breached] | [specific capability gap] | [why the compliant option is insufficient] |
