# sketch-plan

**Sketch Plan** · Layer L2 · `status: alpha` · v0.1.0

Bank-wide plan template. A preset changes how existing commands behave and adds
no commands of its own. It is installed as part of a bundle, never directly.

The content is in [`templates/plan-template.md`](templates/plan-template.md),
which `setup-plan` copies into `specs/<feature>/plan.md` at the start of every
plan run.

## What it adds to the stock template

Three sections, each of which exists because something a Sketch specification
stated failed to reach any design artifact when the stock template was used.

| Section | The failure it fixes |
|---------|----------------------|
| Governance Context | The AI classification and the stated design principles reached no artifact. Phase 1 produces entities, contracts and a run guide; a classification is none of those, so it had nowhere to land. |
| Evaluation Design | Evaluation content survived only as run steps in `quickstart.md`. The decisions behind it, sample size, labelling method, target, promotion gate, were nowhere a reviewer could approve them. |
| Spec Coverage | Finding out what had been dropped meant reading every artifact by hand. So nobody checked. |

Two smaller changes:

- **Technical Context** pre-labels `Language/Version` and `Testing` as planning
  decisions. No section of the Sketch requirement template can feed them, since
  the specification deliberately excludes implementation detail, so they are
  invented on every run of every feature. Pre-labelling makes that visible
  rather than silent.
- **Constitution Check** reports the constitution version and the layers merged.
  A constitution assembled from layers at run time is otherwise invisible in the
  finished plan.

The stock structure option list is replaced by a single Structure Decision
prompt. A folder tree in a template enforces nothing, and maintaining one tree
per paradigm is cost without benefit.

## Three-state fields

Every field in Governance Context takes one of three values:

| Value | Meaning | Gate |
|-------|---------|------|
| a stated value | Answered in the specification | Pass |
| `NOT REQUIRED AT <depth>` | Deliberately out of scope at this depth | Pass |
| `NEEDS CLARIFICATION` | A gap nobody decided | Fail |

Two states cannot distinguish a deliberate depth decision from an omission, so
an empty field reads as compliant. This mirrors constitution Principle V: a
section that does not apply stays, with its reason.

## Slot markers

The template carries `<!-- SKETCH-SLOT: <name> -->` comments at seven points.
They are inert in the base install. A work-type bundle's `before_plan` hook
composes fragments into them, which is how a bundle extends the plan phase
without overriding this file and without forking the plan command.

Slots: `governance`, `evaluation`, `technical-context`, `constitution-check`,
`structure`, `coverage`.

See `sketch-langchain-deep-agent` for a worked example.
