# sketch-base

**One repo, one bundle.** This repository is the `sketch-base` bundle: the
manifest at the root, and the extension and preset it ships inside it.

Layer 2 of the Sketch catalog. Everything here applies to all software
development in the organization, not to one division, workload or role. Every
other bundle in the estate includes this one.

```bash
specify bundle install sketch-base
```

---

## What is in this repository

```
sketch-base/
├── bundle.yml                      this repo IS the sketch-base bundle
├── extensions/
│   └── sketch/                     the base extension: 3 commands, 87 tests
├── presets/
│   ├── sketch-constitution/        engineering principles every project inherits
│   └── sketch-plan/                plan template: governance, evaluation, coverage
├── docs/
└── .gitlab-ci.yml                  validates all three together, releases as one
```

The bundle, its extension and its preset version and release **together**,
because they are one unit. There is no window in which the bundle claims a
version of the extension that was never released.

## Commands

| Command | What it does |
|---------|--------------|
| `/speckit.sketch.specify` | Author or extend a depth-graded requirement spec from raw inputs |
| `/speckit.sketch.independent-read` | Paraphrase and diff the spec in isolation, catching confident misreads |
| `/speckit.sketch.clarify` | Ask up to five questions drawn only from a fixed, reviewable catalog |

Three depths (Lightweight, Standard, Exhaustive), two tracks (generic and
AI-Extended). Neither command takes a track flag: the track is a finding read
from the source material, not an assertion by the caller.

Full usage: [docs/HOWTO-USE.md](docs/HOWTO-USE.md).
Extension internals: [extensions/sketch/README.md](extensions/sketch/README.md).

## Why one repo per bundle

The alternative is a monorepo holding every extension and bundle in the bank.
It fails at scale for reasons that are structural, not procedural:

**Hundreds of contributors on one repository.** Branch and merge request volume
from fifteen divisions, most of it unrelated to any given reader. Finding the
three merge requests that affect you means filtering out ninety that do not.

**Unrelated version churn.** A tag is repository-wide. Tagging a fix to one
division's extension moves the version of everything, or forces a tag-naming
convention that every pipeline then has to parse.

**Subfolder ownership is not isolation.** GitLab CODEOWNERS routes *approval*
by path, which is real, but everyone still shares one branch namespace, one
pipeline, one issue tracker and one clone. "Please only touch your own folders"
fails at the first urgent fix.

One repo per bundle gives each team its own branches, its own tags, its own
pipeline and its own permissions, enforced by GitLab's own project boundary
rather than by convention.

## How bundles share an extension

A bundle repository owns the extensions only it uses. When an extension is
genuinely used by several bundles, it moves to a **shared** repository and
other bundles pin it by version through the catalog rather than copying it.

Shared does not mean one repo each. The repo boundary follows ownership and
release cadence, never artifact count: six platform-team utilities share
`platform/sketch-shared`, and `skt-threat` sits apart only because AI security
owns it. Each keeps its own version; the repo tag is a release train carrying
several assets.

That is the difference between composing and forking. A fix ships once from the
owning repository, and every bundle picks it up on its next version bump. In
`bundle.yml`, a component owned by this repo carries a `source:` path; a
component owned elsewhere carries only a version.

## Verify this repository

```bash
bash extensions/sketch/scripts/bash/selftest.sh
```

Expect `87 passed, 0 failed`. The pipeline runs the same thing, plus manifest
validation across the bundle, extension and preset together.

## Releasing

```bash
# 1. bump versions in bundle.yml and the component's own manifest, together
# 2. merge through a reviewed merge request
# 3. tag
git tag spec-kit-sketch-v0.3.0 && git push origin spec-kit-sketch-v0.3.0
# 4. open a merge request against sketch-catalog bumping this bundle
```

The pipeline creates a **GitLab Release** carrying three assets, the same shape
the [Spec2Cloud](https://github.com/Azure-Samples/Spec2Cloud) community
extension uses:

| Asset | Extract into |
|---|---|
| `extension.zip` | `.specify/extensions/sketch/` |
| `preset-constitution.zip` | `.specify/presets/sketch-constitution/` |
| `preset-plan.zip` | `.specify/presets/sketch-plan/` |
| `bundle.zip` | the whole bundle, the normal install |

Giving permanent install URLs:

```
<project>/-/releases/spec-kit-sketch-v0.3.0/downloads/bundle.zip
<project>/-/releases/permalink/latest/downloads/bundle.zip
```

**New to GitLab?** [docs/GITLAB-STEP-BY-STEP.md](docs/GITLAB-STEP-BY-STEP.md)
walks from an empty project to a working install in eight steps.

Step 4 is the one people forget. Publishing makes the archive *fetchable*; the
catalog makes it *discoverable*. CI prints that reminder on every tag.

Full detail: [docs/RELEASING.md](docs/RELEASING.md).

## Where this sits

```
platform/
├── sketch-base            <- this repository
├── sketch-catalog             schema, CI templates, catalog.d/ fragments
├── sketch-fullstack           bundle + its extensions
├── sketch-shared              6 extensions several bundles pin
├── sketch-security            skt-threat, owned by AI security
└── mirrors/<name>             community extensions, tag-pinned
domains/
└── <division>/
    └── sketch-<bundle>        bundle + its extensions, owned by the division
```

Requires the `specify` CLI, `python3`, and `pandoc` only for invocations that
write a `.docx`.
