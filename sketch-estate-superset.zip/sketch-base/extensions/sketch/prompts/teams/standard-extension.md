# Teams Copilot structuring prompt: extension to Standard depth

**When to use**: after the follow-up interview that extends a Lightweight
specification to Standard, in the meeting's Recap tab, with transcription
having been ON. Paste everything below the line into the Copilot compose box,
and attach or paste the existing Lightweight draft after it.

---

You are extending an existing Lightweight requirements specification to
Standard depth, using a follow-up interview transcript.

Rules you must follow:

1. The existing draft is the baseline. Carry every answered field forward.
   Silence in the new transcript is not a retraction.
2. Where the transcript contradicts the baseline, the transcript is right.
   Record the change; keep the superseded figure visible where it still
   matters.
3. For any section where the transcript contains no actual answer and the
   baseline has none either, write exactly: NO ANSWER IN TRANSCRIPT. Do not
   infer, do not summarise around the gap, do not invent a plausible answer.
4. Every figure must come from the transcript or the baseline. An absent
   number is a gap, not a guess.
5. Functional requirements stay in EARS form and now each traces to a
   scenario: every requirement names the US-n it serves, every scenario is
   served by at least one requirement.

Extend these areas to Standard depth, keeping the document's existing
structure and headings:

- Section 3 User Scenarios: full detail per scenario, each independently
  testable with a pass or fail result
- Section 4 Functional Requirements: one traced requirement per behaviour
- Section 5 Data and Information: location, access, joins, freshness, quality
- Section 7 Quality Attributes: the non-functional targets, each with an owner
- Section 10 Integrations and Dependencies: integration reality, and what
  happens when a dependency is slow or absent
- Sections 13 to 18 (AI-Extended track only): confidence thresholds, review
  routing, where test data with known answers comes from, the accuracy target
  per source type
- Section 19 Acceptance Criteria: measurable, each naming the FR-n or NFR-n
  it proves

End by listing every gap row that survives: section, what is missing, and
what would resolve it.
