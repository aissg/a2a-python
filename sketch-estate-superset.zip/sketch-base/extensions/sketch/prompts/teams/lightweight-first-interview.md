# Teams Copilot structuring prompt: first interview (Lightweight)

**When to use**: after the first one-hour interview, in the meeting's Recap
tab, with transcription having been ON. Paste everything below the line into
the Copilot compose box.

**Track**: if the conversation described a model doing the work, an accuracy
target, a human review step, or test data with known answers, use the
AI-Extended section list (Part D included). Otherwise use the Generic list.
When in doubt, use AI-Extended.

---

You are structuring a requirements interview transcript into a draft
requirements specification at Lightweight depth.

Rules you must follow:

1. For any section where the transcript contains no actual answer, write
   exactly: NO ANSWER IN TRANSCRIPT. Do not infer, do not summarise around the
   gap, do not invent a plausible answer.
2. Every figure you write must come from the transcript. If a number was not
   said, the field is a gap, not a guess.
3. Write functional requirements in EARS form: When / While / Where / If
   <trigger or state>, the <system> shall <response>. One behaviour each.
4. Keep each section short. Lightweight is a one-hour interview: a section is
   three to six lines, not an essay.

Structure the output under these headings:

Part A Context
1. Purpose and Current State: how it is done today, what goes wrong, what changes
2. Scope and Stakeholders: what is in, what is out, who may do what

Part B Behaviour
3. User Scenarios: the distinct ways it is used, ordered by value
4. Functional Requirements: EARS form, one per line
5. Data and Information: datasets, source of truth, known defects
6. Delivery and Presentation: where the output lands, what the user sees on failure

Part C Quality and Constraints
7. Quality Attributes: volume, rhythm, availability, response, cost
8. Security, Privacy and Compliance: who may access, what data, which obligations
9. Audit, Logging and Retention: what must be recorded and for how long
10. Integrations and Dependencies: what it talks to, who owns each
11. Failure and Edge Cases: bad input, overload, unexpected shapes
12. Constraints and Decisions: what was fixed before this work began

Part D AI Governance (AI-Extended track only)
13. AI Classification and Justification: which topic, why a model rather than rules
14. AI Behaviour and Output Validation: correctness rules on model output
15. Confidence and Human Review: who reviews what the system is unsure about
16. Provenance and Lineage: not interrogated at Lightweight; note this
17. Evaluation and Test Evidence: test data with known answers, accuracy target
18. Model Lifecycle and Monitoring: what is watched after go-live

Part E Closure
19. Acceptance Criteria: measurable conditions that define done
20. Open Items and Risks: decisions genuinely open, delivery risks

Appendix A Glossary: each term defined once
Appendix B Compliance Mapping: obligations mentioned, mapped to sections

End with the four assumption checks, each marked answered or
NO ANSWER IN TRANSCRIPT: delivery surface, accuracy expectation, human review
path, test data.
