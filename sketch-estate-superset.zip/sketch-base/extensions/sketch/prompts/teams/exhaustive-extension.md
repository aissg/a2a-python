# Teams Copilot structuring prompt: extension to Exhaustive depth

**When to use**: after the interview series that extends a Standard
specification to Exhaustive (regulated or client-facing work), in the
meeting's Recap tab, with transcription having been ON. Paste everything below
the line into the Copilot compose box, and attach or paste the existing
Standard draft after it.

---

You are extending an existing Standard requirements specification to
Exhaustive depth, using the follow-up interview transcript. Exhaustive is the
depth a regulated build stands on: the document is audit evidence.

Rules you must follow:

1. The existing draft is the baseline. Carry every answered field forward.
   Silence in the new transcript is not a retraction.
2. Where the transcript contradicts the baseline, the transcript is right.
   Record the change; keep the superseded figure visible where it still
   matters.
3. For any section where the transcript contains no actual answer and the
   baseline has none either, write exactly: NO ANSWER IN TRANSCRIPT. At
   Exhaustive, a surviving gap is a signing decision, not a footnote.
4. Every figure must come from the transcript or the baseline. An absent
   number is a gap, not a guess.
5. Functional requirements stay in EARS form, each traced to a scenario.

Extend these areas to Exhaustive depth, keeping the document's existing
structure and headings:

- Section 8 Security, Privacy and Compliance: segregation of duties, abuse
  cases, cross-border transfer
- Section 9 Audit, Logging and Retention: audit readership, and what must be
  producible for examination, with the obligation each retention period
  derives from
- Section 11 Failure and Edge Cases: concurrent action, extended outage,
  unexpected shapes
- Section 13 AI Classification and Justification (AI track): model risk
  classification, and whether the system decides or recommends
- Section 16 Provenance and Lineage (AI track): what each output records, and
  whether it is reproducible; interrogated in full at this depth
- Section 17 Evaluation and Test Evidence (AI track): where truth comes from,
  the accuracy target per source type, and who signed the test data
- Section 18 Model Lifecycle and Monitoring (AI track): re-validation trigger
  and cadence, and what is watched after go-live
- Appendix B Compliance Mapping: traceability from each applicable control to
  the section that satisfies it, without restating control text

End with two lists: every gap row that survives with what blocks it, and a
plain statement of whether any surviving gap would stop a reviewer signing.
