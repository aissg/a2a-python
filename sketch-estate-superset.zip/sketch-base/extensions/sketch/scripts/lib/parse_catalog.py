#!/usr/bin/env python3
"""
parse_catalog.py: turn an interview question catalog into a numbered question bank.

This is what makes the clarify ring-fence enforceable rather than advisory. The
agent is handed a bank of questions that already exist, each with a stable id,
and told to cite the id it is asking. A question with no id in this bank is, by
definition, invented.

Usage:
    parse_catalog.py <catalog.md> --depth lightweight|standard|exhaustive
                                  [--track generic|ai]
                                  [--format json|text]

Depth is cumulative: standard includes [L] and [S]; exhaustive includes all three.
Track ai includes questions marked [AI]; track generic excludes them.

Emits JSON:
    {
      "catalog": "<path>", "depth": "...", "track": "...",
      "total_in_catalog": N, "in_scope": N,
      "questions": [
        {"id": "Q-013-02", "part": "D", "part_name": "AI Governance",
         "section": 13, "section_name": "AI Classification & Justification",
         "marker": "L", "ai": true, "text": "..."}
      ],
      "sections": [{"section": 1, "name": "...", "part": "A", "count": 4}]
    }
"""

import argparse
import json
import re
import sys
from pathlib import Path

PART_RE = re.compile(r'^#\s+Part\s+([A-E]):\s*(.+?)\s*$')
APPENDIX_RE = re.compile(r'^#\s+Appendix\s+([AB]):\s*(.+?)\s*$')
SECTION_RE = re.compile(r'^##\s+(\d+)\.\s*(.+?)\s*$')
QUESTION_RE = re.compile(r'^\s*-\s+\*\*\[([LSE])\]\*\*\s*(.+?)\s*$')

DEPTH_INCLUDES = {
    "lightweight": {"L"},
    "standard": {"L", "S"},
    "exhaustive": {"L", "S", "E"},
}


def parse(catalog_path: Path):
    text = catalog_path.read_text(encoding="utf-8")

    # Body only: skip the First Interview Key Points preamble and the trailing
    # Depth Grading Summary, neither of which holds numbered catalog questions.
    start = text.find("# Part A:")
    if start == -1:
        raise SystemExit(f"ERROR: no '# Part A:' heading found in {catalog_path}")
    end = text.find("## Depth Grading Summary")
    body = text[start:end if end != -1 else len(text)]

    questions = []
    sections = []
    part, part_name = None, None
    section, section_name = None, None
    per_section_seq = 0

    for line in body.split("\n"):
        m = PART_RE.match(line)
        if m:
            part, part_name = m.group(1), m.group(2)
            continue

        m = APPENDIX_RE.match(line)
        if m:
            part, part_name = f"Appendix {m.group(1)}", m.group(2)
            # appendices carry their own pseudo-section number for stable ids
            section = 100 + (0 if m.group(1) == "A" else 1)
            section_name = f"Appendix {m.group(1)}: {m.group(2)}"
            per_section_seq = 0
            sections.append({"section": section, "name": section_name,
                             "part": part, "count": 0})
            continue

        m = SECTION_RE.match(line)
        if m:
            section, section_name = int(m.group(1)), m.group(2)
            per_section_seq = 0
            sections.append({"section": section, "name": section_name,
                             "part": part, "count": 0})
            continue

        m = QUESTION_RE.match(line)
        if m and section is not None:
            marker, raw = m.group(1), m.group(2)
            is_ai = "[AI]" in raw
            # strip the inline marker so the question reads cleanly when asked
            clean = raw.replace("`[AI]`", "").replace("[AI]", "").strip()
            per_section_seq += 1
            questions.append({
                "id": f"Q-{section:03d}-{per_section_seq:02d}",
                "part": part,
                "part_name": part_name,
                "section": section,
                "section_name": section_name,
                "marker": marker,
                "ai": is_ai,
                "text": clean,
            })
            sections[-1]["count"] += 1

    return questions, sections


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("catalog")
    ap.add_argument("--depth", required=True,
                    choices=["lightweight", "standard", "exhaustive"])
    ap.add_argument("--track", default="ai", choices=["generic", "ai"])
    ap.add_argument("--format", default="json", choices=["json", "text"])
    args = ap.parse_args()

    path = Path(args.catalog)
    if not path.is_file():
        print(f"ERROR: catalog not found: {args.catalog}", file=sys.stderr)
        return 6

    all_q, sections = parse(path)
    allowed = DEPTH_INCLUDES[args.depth]

    in_scope = [
        q for q in all_q
        if q["marker"] in allowed and (args.track == "ai" or not q["ai"])
    ]

    # recount per section against what is actually in scope
    counts = {}
    for q in in_scope:
        counts[q["section"]] = counts.get(q["section"], 0) + 1
    scoped_sections = [
        {**s, "count": counts.get(s["section"], 0)} for s in sections
    ]

    if args.format == "text":
        for q in in_scope:
            flag = " [AI]" if q["ai"] else ""
            print(f'{q["id"]}  [{q["marker"]}]{flag}  S{q["section"]} {q["section_name"]}')
            print(f'    {q["text"]}')
        print(f"\n{len(in_scope)} of {len(all_q)} catalog questions in scope "
              f"({args.track} track, {args.depth} depth)")
        return 0

    print(json.dumps({
        "catalog": str(path),
        "depth": args.depth,
        "track": args.track,
        "total_in_catalog": len(all_q),
        "in_scope": len(in_scope),
        "sections": scoped_sections,
        "questions": in_scope,
    }, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
