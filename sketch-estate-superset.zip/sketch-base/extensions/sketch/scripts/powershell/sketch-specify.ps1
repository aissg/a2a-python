<#
.SYNOPSIS
  sketch-specify: parse, validate and resolve inputs for /speckit.sketch.specify.

.DESCRIPTION
  Windows parity for scripts/bash/sketch-specify.sh. Same flags, same
  validation, same JSON resolution, same exit codes.

  There is no -ai flag. Whether Part D applies is a finding about the source
  material, not something the caller asserts, so this script resolves BOTH
  tracks and the agent decides which to use after reading the raw inputs (in
  create mode) or the baseline spec (in enhance mode).

  Exit codes
    0  ok
    1  usage error
    2  depth error (none, or more than one)
    3  raw input error (no -raw given, or a path does not resolve)
    4  spec path error
    5  spec format error
    6  asset error
    7  pandoc required but not found
#>

$ErrorActionPreference = 'Stop'
$ExtRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Die([int]$Code, [string]$Message, [string]$Hint = '') {
  Write-Host "ERROR: $Message" -ForegroundColor Red
  if ($Hint) { Write-Host "  hint: $Hint" -ForegroundColor DarkYellow }
  exit $Code
}

function Show-Usage {
  @'
Usage:
  sketch-specify.ps1 (-l | -s | -e) -raw <path> [-raw <path> ...] [-spec <path>] [-Json]

Depth, exactly one required:
  -l, -lightweight     first interview, about 1 hour
  -s, -standard        production planning, about 1 day
  -e, -exhaustive      regulated work, 3 days to 1 week

Track:
  (no -ai flag: the track is determined from the raw inputs by the agent)

Inputs:
  -raw <path>          REQUIRED, repeatable. A raw input file: meeting
                       notes, an interview transcript, an existing
                       requirement document, an email export, anything
                       the draft should be grounded in. Pass several to
                       combine sources: -raw notes.txt -raw old-req.docx
  -spec <path>         OPTIONAL. Existing spec, .docx or .md.

Output rules:
  no -spec        -> writes spec.docx AND spec.md
  -spec *.docx    -> writes spec.docx AND spec.md
  -spec *.md      -> writes spec.md only
'@ | Write-Host
}

# ------------------------------------------------------------------ parse
$depth = ''; $depthFlags = @()
$rawInputs = @(); $specIn = ''
$jsonOnly = $false; $outDir = ''
$argv = $args

function Set-Depth([string]$value, [string]$flag) {
  $script:depthFlags += $flag
  if ($script:depth -and $script:depth -ne $value) {
    Die 2 "Only one depth may be specified. Found: $($script:depthFlags -join ' ')" `
        'Choose exactly one of -l (lightweight), -s (standard), -e (exhaustive).'
  }
  if ($script:depth) {
    Die 2 "Depth flag repeated: $($script:depthFlags -join ' ')" "Specify -$($value.Substring(0,1)) once."
  }
  $script:depth = $value
}

if ($argv.Count -eq 0) { Show-Usage; Die 1 'No arguments given.' }

for ($i = 0; $i -lt $argv.Count; $i++) {
  switch -Regex ($argv[$i]) {
    '^-(l|lightweight)$' { Set-Depth 'lightweight' $argv[$i] }
    '^-(s|standard)$'    { Set-Depth 'standard'    $argv[$i] }
    '^-(e|exhaustive)$'  { Set-Depth 'exhaustive'  $argv[$i] }
    '^-ai$'              { Die 1 '-ai is not a flag for this command.' 'Whether Part D applies is determined from the raw inputs, not asserted by the caller. Drop the flag and re-run.' }
    '^-raw$' {
      if ($i + 1 -ge $argv.Count -or $argv[$i+1].StartsWith('-')) { Die 1 '-raw requires a file path.' }
      $rawInputs += $argv[++$i]
    }
    '^-transcript$' {
      Die 1 '-transcript was renamed to -raw in sketch 0.3.0.' 'Use -raw <file>; repeat it for several inputs: -raw notes.txt -raw old-req.docx'
    }
    '^-spec$' {
      if ($i + 1 -ge $argv.Count -or $argv[$i+1].StartsWith('-')) { Die 1 '-spec requires a file path.' }
      $specIn = $argv[++$i]
    }
    '^-outDir$' {
      if ($i + 1 -ge $argv.Count) { Die 1 '-outDir requires a path.' }
      $outDir = $argv[++$i]
    }
    '^-Json$'            { $jsonOnly = $true }
    '^-(h|help|\?)$'     { Show-Usage; exit 0 }
    '^-(d|detailed)$'    { Die 2 "Unknown depth flag '$($argv[$i])'. Standard depth is -s." 'Use -l, -s or -e.' }
    default              { Show-Usage; Die 1 "Unknown argument: $($argv[$i])" }
  }
}

# ------------------------------------------------------------------ validate
if (-not $depth) {
  Die 2 'No depth specified.' 'Add exactly one of -l (lightweight), -s (standard), -e (exhaustive).'
}
if ($rawInputs.Count -lt 1) {
  Die 3 'At least one -raw input is required.' 'Pass the source material: -raw .\notes\interview.txt (repeat -raw for several files).'
}

function Resolve-ExistingFile([string]$p) {
  if (-not $p) { return $null }
  $p = $p.Trim('"').Trim("'")
  if ($p.StartsWith('~')) { $p = Join-Path $HOME $p.Substring(1) }
  $candidate = if ([System.IO.Path]::IsPathRooted($p)) { $p } else { Join-Path (Get-Location).Path $p }
  if (Test-Path -LiteralPath $candidate -PathType Leaf) { return (Resolve-Path -LiteralPath $candidate).Path }
  return $null
}

$rawAbs = @()
foreach ($raw in $rawInputs) {
  $resolved = Resolve-ExistingFile $raw
  if (-not $resolved) {
    Die 3 "Raw input not found: '$raw'" `
        "Checked as an absolute path and relative to $((Get-Location).Path). Give a path that resolves to a readable file."
  }
  $rawAbs += $resolved
}

$mode = 'create'; $specInAbs = $null; $specInFormat = $null
if ($specIn) {
  $mode = 'enhance'
  $specInAbs = Resolve-ExistingFile $specIn
  if (-not $specInAbs) {
    Die 4 "Spec file not found: '$specIn'" `
        "Checked as an absolute path and relative to $((Get-Location).Path). Omit -spec to author a new spec instead."
  }
  switch ([System.IO.Path]::GetExtension($specInAbs).ToLower()) {
    '.docx'     { $specInFormat = 'docx' }
    '.md'       { $specInFormat = 'md' }
    '.markdown' { $specInFormat = 'md' }
    default {
      Die 5 "Unsupported spec format: '$([System.IO.Path]::GetExtension($specInAbs))'" '-spec accepts .docx or .md only.'
    }
  }
}

# ------------------------------------------------------------------ output plan
$writeDocx = -not ($mode -eq 'enhance' -and $specInFormat -eq 'md')
$writeMd = $true

if (-not $outDir) {
  $outDir = if ($specInAbs) { Split-Path -Parent $specInAbs } else { (Get-Location).Path }
}
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$outDir = (Resolve-Path -LiteralPath $outDir).Path

# ------------------------------------------------- track determination context
# Track is not a flag: both tracks are resolved, the agent decides.
# In enhance mode the baseline already answered the question structurally.
$trackHint = 'unknown'; $trackDecidedBy = 'agent reads raw inputs'
if ($mode -eq 'enhance' -and $specInFormat -eq 'md') {
  $head = Get-Content -LiteralPath $specInAbs -ErrorAction SilentlyContinue
  if ($head -match '^#{1,2} *(Part D|13\. *AI Classification)') { $trackHint = 'ai' } else { $trackHint = 'generic' }
  $trackDecidedBy = 'baseline spec structure, confirm against raw inputs'
} elseif ($mode -eq 'enhance') {
  $trackDecidedBy = 'baseline spec (.docx): agent inspects, confirm against raw inputs'
}

# ------------------------------------------------------------------ assets
$depthTitle = $depth.Substring(0,1).ToUpper() + $depth.Substring(1)
$genTpl = Join-Path $ExtRoot "templates\generic\Generic_Template_$depthTitle"
$genCat = Join-Path $ExtRoot 'questions\generic\Generic_Requirement_Interview_Questions_Catalog'
$genExa = Join-Path $ExtRoot "examples\generic\Generic_Example_Risk_Reporting_$depthTitle"
$aiTpl  = Join-Path $ExtRoot "templates\ai\AI_Template_$depthTitle"
$aiCat  = Join-Path $ExtRoot 'questions\ai\AI_Requirement_Interview_Questions_Catalog'
$aiExa  = Join-Path $ExtRoot "examples\ai\AI_Example_10K_Extraction_$depthTitle"

foreach ($f in @("$genTpl.docx", "$genTpl.md", "$genCat.docx", "$genCat.md", "$genExa.docx", "$genExa.md",
                 "$aiTpl.docx", "$aiTpl.md", "$aiCat.docx", "$aiCat.md", "$aiExa.docx", "$aiExa.md")) {
  if (-not (Test-Path -LiteralPath $f -PathType Leaf)) {
    Die 6 "Reference asset missing: $($f.Replace($ExtRoot, '').TrimStart('\'))" `
        'The extension is incomplete. Re-install sketch.'
  }
}

$genQ = @{ lightweight = 34; standard = 92;  exhaustive = 122 }[$depth]
$aiQ  = @{ lightweight = 45; standard = 125; exhaustive = 186 }[$depth]
$gated = if ($depth -eq 'lightweight') { '16' } else { 'none' }

# ------------------------------------------------------------------ tooling
$pandoc = if (Get-Command pandoc -ErrorAction SilentlyContinue) { 'available' } else { 'missing' }
if ($writeDocx -and $pandoc -eq 'missing') {
  Die 7 'pandoc not found on PATH, but this invocation writes a .docx and its .md companion.' `
      'Install pandoc, or pass -spec <file>.md to produce Markdown only.'
}

# ------------------------------------------------------------------ emit
$outDocx = if ($writeDocx) { Join-Path $outDir 'spec.docx' } else { $null }
$outMd   = Join-Path $outDir 'spec.md'

$resolution = [ordered]@{
  extension_root   = $ExtRoot
  command          = 'speckit.sketch.specify'
  mode             = $mode
  depth            = $depth
  depth_title      = $depthTitle
  track_decided_by = $trackDecidedBy
  track_hint       = $trackHint
  raw              = $rawAbs
  spec_in          = $specInAbs
  spec_in_format   = $specInFormat
  out_dir          = $outDir
  write_docx       = $writeDocx
  write_md         = $writeMd
  out_docx         = $outDocx
  out_md           = $outMd
  tracks           = [ordered]@{
    generic = [ordered]@{
      track_name     = 'Generic'
      section_count  = 14
      question_total = $genQ
      gated_sections = 'none'
      template_docx  = "$genTpl.docx"
      template_md    = "$genTpl.md"
      catalog_docx   = "$genCat.docx"
      catalog_md     = "$genCat.md"
      example_docx   = "$genExa.docx"
      example_md     = "$genExa.md"
    }
    ai = [ordered]@{
      track_name     = 'AI-Extended'
      section_count  = 20
      question_total = $aiQ
      gated_sections = $gated
      template_docx  = "$aiTpl.docx"
      template_md    = "$aiTpl.md"
      catalog_docx   = "$aiCat.docx"
      catalog_md     = "$aiCat.md"
      example_docx   = "$aiExa.docx"
      example_md     = "$aiExa.md"
    }
  }
  pandoc             = $pandoc
  authoring_direction = 'author .md first, then convert to .docx with md-to-docx.sh --reference'
}

if (-not $jsonOnly) {
  Write-Host 'sketch-specify resolution'
  Write-Host "  mode              $mode"
  Write-Host "  depth             $depthTitle"
  Write-Host "  track             NOT SET: $trackDecidedBy (hint: $trackHint)"
  Write-Host "                    generic -> 14 sections, $genQ questions"
  Write-Host "                    ai      -> 20 sections, $aiQ questions, gated: $gated"
  foreach ($e in $rawAbs) { Write-Host "  raw               $e" }
  Write-Host "  spec in           $(if ($specInAbs) { $specInAbs } else { '<none, authoring from scratch>' })"
  Write-Host "  writes            $(if ($writeDocx) { 'spec.docx + spec.md' } else { 'spec.md only' })"
  Write-Host "  out dir           $outDir"
  Write-Host "  pandoc            $pandoc"
  Write-Host ''
}
$resolution | ConvertTo-Json -Depth 5
