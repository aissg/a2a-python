<#
.SYNOPSIS
  sketch-clarify: resolve inputs for /speckit.sketch.clarify.

.DESCRIPTION
  Windows parity for scripts/bash/sketch-clarify.sh. Same flags, same
  validation, same JSON resolution, same exit codes.

  One deliberate difference: the bash resolver can invoke Spec Kit's
  check-prerequisites.sh for spec discovery; under PowerShell that shell
  script is skipped and discovery uses .specify/feature.json, then the newest
  specs/*/spec.md. Pass -spec to pin the target explicitly.

  Exit codes
    0  ok
    1  usage error
    2  depth error (none, or more than one)
    3  spec error (not found, or none discoverable)
    5  spec error (not Markdown)
    6  asset error
#>

$ErrorActionPreference = 'Stop'
$ExtRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Die([int]$Code, [string]$Message, [string]$Hint = '') {
  Write-Host "ERROR: $Message" -ForegroundColor Red
  if ($Hint) { Write-Host "  hint: $Hint" -ForegroundColor DarkYellow }
  exit $Code
}

function Show-Usage {
  @'
Usage:
  sketch-clarify.ps1 (-l | -s | -e) [-spec <path>] [-Json]

Depth, exactly one required:
  -l, -lightweight     check against the 34/45 Lightweight questions
  -s, -standard        check against the 92/125 Standard questions
  -e, -exhaustive      check against the 122/186 Exhaustive questions

Inputs:
  -spec <path>         OPTIONAL. Spec to clarify (.md). Omitted means
                       discover the active feature spec.
'@ | Write-Host
}

function Resolve-ExistingFile([string]$p) {
  if (-not $p) { return $null }
  $p = $p.Trim('"').Trim("'")
  if ($p.StartsWith('~')) { $p = $HOME + $p.Substring(1) }
  if (-not [System.IO.Path]::IsPathRooted($p)) { $p = Join-Path (Get-Location) $p }
  if ((Test-Path $p -PathType Leaf)) { return (Resolve-Path $p).Path }
  return $null
}

# Catalog parsing needs a real Windows interpreter. A bare 'python3' on PATH
# can be a Git Bash shim (a document, not an application), which PowerShell
# cannot execute, so only .exe candidates are accepted.
function Resolve-Python {
  foreach ($cand in @('python3.exe', 'python.exe')) {
    $cmd = Get-Command $cand -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.CommandType -eq 'Application') { return $cmd.Source }
  }
  return $null
}

# ------------------------------------------------------------------ parse
$depth = ''; $depthFlags = @(); $specIn = ''; $jsonOnly = $false
$argv = $args

function Set-Depth([string]$value, [string]$flag) {
  $script:depthFlags += $flag
  if ($script:depth -and $script:depth -ne $value) {
    Die 2 "Only one depth may be specified. Found: $($script:depthFlags -join ' ')" `
        'Choose exactly one of -l (lightweight), -s (standard), -e (exhaustive).'
  }
  if ($script:depth) {
    Die 2 "Depth flag repeated: $($script:depthFlags -join ' ')" "Specify -$($value.Substring(0,1)) once."
  }
  $script:depth = $value
}

if ($argv.Count -eq 0) { Show-Usage; Die 1 'No arguments given.' }

for ($i = 0; $i -lt $argv.Count; $i++) {
  switch -Regex ($argv[$i]) {
    '^--?(l|lightweight)$' { Set-Depth 'lightweight' $argv[$i] }
    '^--?(s|standard)$'    { Set-Depth 'standard'    $argv[$i] }
    '^--?(e|exhaustive)$'  { Set-Depth 'exhaustive'  $argv[$i] }
    '^--?ai$'              { Die 1 '-ai is not a flag for this command.' 'The track is read from the spec: a spec with Part D is treated as AI-Extended.' }
    '^--?spec$' {
      if ($i + 1 -ge $argv.Count -or $argv[$i+1].StartsWith('-')) { Die 1 '-spec requires a file path.' }
      $specIn = $argv[$i+1]; $i++
    }
    '^--?json$'            { $jsonOnly = $true }
    '^--?(d|detailed)$'    { Die 2 "Unknown depth flag '$($argv[$i])'. Standard depth is -s." 'Use -l, -s or -e.' }
    '^--?(h|help)$'        { Show-Usage; exit 0 }
    default                { Show-Usage; Die 1 "Unknown argument: $($argv[$i])" }
  }
}

if (-not $depth) { Die 2 'No depth specified.' 'Add exactly one of -l (lightweight), -s (standard), -e (exhaustive).' }

# ---------------------------------------------------------------- locate spec
$specAbs = ''; $specSource = ''
if ($specIn) {
  $specAbs = Resolve-ExistingFile $specIn
  if (-not $specAbs) { Die 3 "Spec not found: '$specIn'" "Checked as an absolute path and relative to $(Get-Location)." }
  $specSource = '-spec argument'
} else {
  $fj = '.specify/feature.json'
  if (Test-Path $fj) {
    try {
      $fd = (Get-Content $fj -Raw | ConvertFrom-Json).feature_directory
      if ($fd -and (Test-Path (Join-Path $fd 'spec.md'))) {
        $specAbs = (Resolve-Path (Join-Path $fd 'spec.md')).Path
        $specSource = '.specify/feature.json'
      }
    } catch { }
  }
  if (-not $specAbs) {
    $newest = Get-ChildItem 'specs/*/spec.md' -ErrorAction SilentlyContinue |
              Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($newest) { $specAbs = $newest.FullName; $specSource = 'newest specs/*/spec.md' }
  }
  if (-not $specAbs) {
    Die 3 'No spec found to clarify.' 'Pass -spec <path>, or run this from a Spec Kit project with a spec in specs/.'
  }
}

$ext = [System.IO.Path]::GetExtension($specAbs).ToLower()
if ($ext -eq '.docx') {
  $companion = [System.IO.Path]::ChangeExtension($specAbs, '.md')
  if (Test-Path $companion) {
    Die 5 "Clarification edits Markdown, not .docx: '$specAbs'" "A companion exists. Re-run with -spec `"$companion`"."
  }
  Die 5 "Clarification edits Markdown, not .docx: '$specAbs'" "Convert first: $ExtRoot/scripts/bash/docx-to-md.sh `"$specAbs`""
}
if ($ext -ne '.md' -and $ext -ne '.markdown') {
  Die 5 "Unsupported spec format: '$ext'" 'Clarification operates on .md.'
}

$specDir = Split-Path $specAbs -Parent

# ---------------------------------------------------------------- detect track
$content = Get-Content $specAbs -Raw
$aiPresent = $false
if ($content -match '(?m)^#{1,2} *(Part D|13\. *AI Classification)') { $aiPresent = $true }

$aiDisclaimed = $false
if ($aiPresent) {
  $sec13 = ''
  if ($content -match '(?ms)^#{1,2} *13\..*?(?=^#{1,2} *14\.|\z)') { $sec13 = $Matches[0] }
  if ($sec13 -match 'not applicable|not an AI|no[,.] *this is not|non-AI') { $aiDisclaimed = $true }
}

if ($aiPresent) {
  $track = 'ai'; $trackName = 'AI-Extended'; $sections = 20
  $cat = Join-Path $ExtRoot 'questions/ai/AI_Requirement_Interview_Questions_Catalog'
  switch ($depth) { 'lightweight' { $qtotal = 45 } 'standard' { $qtotal = 125 } 'exhaustive' { $qtotal = 186 } }
} else {
  $track = 'generic'; $trackName = 'Generic'; $sections = 14
  $cat = Join-Path $ExtRoot 'questions/generic/Generic_Requirement_Interview_Questions_Catalog'
  switch ($depth) { 'lightweight' { $qtotal = 34 } 'standard' { $qtotal = 92 } 'exhaustive' { $qtotal = 122 } }
}

foreach ($f in @("$cat.docx", "$cat.md")) {
  if (-not (Test-Path $f -PathType Leaf)) {
    Die 6 "Reference asset missing: $($f.Substring($ExtRoot.Length + 1))" 'The extension is incomplete. Re-install sketch.'
  }
}

# ---------------------------------------------------------------- stale docx
$staleDocx = $null
$docxPath = [System.IO.Path]::ChangeExtension($specAbs, '.docx')
if (Test-Path $docxPath) { $staleDocx = $docxPath }

# ---------------------------------------------------------------- checklist
$checklist = $null
$cl = Join-Path $specDir 'checklists/requirements.md'
if (Test-Path $cl) { $checklist = $cl }

# ---------------------------------------------------------------- question bank
$parser = Join-Path $ExtRoot 'scripts/lib/parse_catalog.py'
if (-not (Test-Path $parser -PathType Leaf)) {
  Die 6 'Reference asset missing: scripts/lib/parse_catalog.py' 'The extension is incomplete. Re-install sketch.'
}
$py = Resolve-Python
if (-not $py) { Die 6 'No python3.exe or python.exe found on PATH.' 'Catalog parsing requires python3 on every platform.' }
$bankRaw = & $py $parser "$cat.md" --depth $depth --track $track
if ($LASTEXITCODE -ne 0) { Die 6 'Failed to parse the question catalog.' }
$bank = $bankRaw | ConvertFrom-Json

$result = [ordered]@{
  extension_root          = $ExtRoot
  command                 = 'speckit.sketch.clarify'
  depth                   = $depth
  depth_title             = (Get-Culture).TextInfo.ToTitleCase($depth)
  track                   = $track
  track_name              = $trackName
  track_decided_by        = "spec content: Part D $(if ($aiPresent) { 'present' } else { 'absent' })"
  ai_sections_present     = $aiPresent
  ai_disclaimed_hint      = $aiDisclaimed
  section_count           = $sections
  question_total_at_depth = $qtotal
  questions_in_scope      = $bank.in_scope
  max_questions_per_session = 5
  spec                    = $specAbs
  spec_dir                = $specDir
  spec_source             = $specSource
  stale_docx              = $staleDocx
  checklist               = $checklist
  catalog_md              = "$cat.md"
  catalog_docx            = "$cat.docx"
  question_bank_cmd       = "`"$py`" `"$parser`" `"$cat.md`" --depth $depth --track $track"
  question_bank           = $bank
}

$json = $result | ConvertTo-Json -Depth 6
if ($jsonOnly) {
  $json
} else {
  @"
sketch-clarify resolution
  spec              $specAbs
  found via         $specSource
  track             $trackName ($sections sections), decided from the spec
  ai sections       present=$aiPresent  disclaimed_hint=$aiDisclaimed
  depth             $depth ($qtotal questions at this depth)
  questions in bank $($bank.in_scope)
  ask at most       5, one at a time
"@
  $json
}
