<#
.SYNOPSIS
  sketch-independent-read: resolve inputs for /speckit.sketch.independent-read.

.DESCRIPTION
  Windows parity for scripts/bash/sketch-independent-read.sh. Same flags,
  same validation, same JSON resolution, same exit codes.

  Exit codes
    0  ok
    1  usage error
    3  spec error (not found, or none discoverable)
    5  spec error (not Markdown)
    6  asset error
    9  verify error (-Verify requested but no earlier findings file exists)
#>

$ErrorActionPreference = 'Stop'
$ExtRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Die([int]$Code, [string]$Message, [string]$Hint = '') {
  Write-Host "ERROR: $Message" -ForegroundColor Red
  if ($Hint) { Write-Host "  hint: $Hint" -ForegroundColor DarkYellow }
  exit $Code
}

function Resolve-ExistingFile([string]$p) {
  if (-not $p) { return $null }
  $p = $p.Trim('"').Trim("'")
  if ($p.StartsWith('~')) { $p = $HOME + $p.Substring(1) }
  if (-not [System.IO.Path]::IsPathRooted($p)) { $p = Join-Path (Get-Location) $p }
  if ((Test-Path $p -PathType Leaf)) { return (Resolve-Path $p).Path }
  return $null
}

# ------------------------------------------------------------------ parse
$specIn = ''; $verify = $false; $jsonOnly = $false
$argv = $args

for ($i = 0; $i -lt $argv.Count; $i++) {
  switch -Regex ($argv[$i]) {
    '^--?spec$' {
      if ($i + 1 -ge $argv.Count -or $argv[$i+1].StartsWith('-')) { Die 1 '-spec requires a file path.' }
      $specIn = $argv[$i+1]; $i++
    }
    '^--?verify$'          { $verify = $true }
    '^--?json$'            { $jsonOnly = $true }
    '^--?(h|help)$'        { Write-Host 'Usage: sketch-independent-read.ps1 [-spec <path>] [-Verify] [-Json]'; exit 0 }
    default                { Die 1 "Unknown argument: $($argv[$i])" }
  }
}

# ---------------------------------------------------------------- locate spec
$specAbs = ''; $specSource = ''
if ($specIn) {
  $specAbs = Resolve-ExistingFile $specIn
  if (-not $specAbs) { Die 3 "Spec not found: '$specIn'" "Checked as an absolute path and relative to $(Get-Location)." }
  $specSource = '-spec argument'
} else {
  $fj = '.specify/feature.json'
  if (Test-Path $fj) {
    try {
      $fd = (Get-Content $fj -Raw | ConvertFrom-Json).feature_directory
      if ($fd -and (Test-Path (Join-Path $fd 'spec.md'))) {
        $specAbs = (Resolve-Path (Join-Path $fd 'spec.md')).Path
        $specSource = '.specify/feature.json'
      }
    } catch { }
  }
  if (-not $specAbs) {
    $newest = Get-ChildItem 'specs/*/spec.md' -ErrorAction SilentlyContinue |
              Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($newest) { $specAbs = $newest.FullName; $specSource = 'newest specs/*/spec.md' }
  }
  if (-not $specAbs) {
    Die 3 'No spec found to read.' 'Pass -spec <path>, or run this from a Spec Kit project with a spec in specs/.'
  }
}

$ext = [System.IO.Path]::GetExtension($specAbs).ToLower()
if ($ext -eq '.docx') {
  $companion = [System.IO.Path]::ChangeExtension($specAbs, '.md')
  if (Test-Path $companion) {
    Die 5 "The independent read operates on Markdown, not .docx: '$specAbs'" "A companion exists. Re-run with -spec `"$companion`"."
  }
  Die 5 "The independent read operates on Markdown, not .docx: '$specAbs'" "Convert first: $ExtRoot/scripts/bash/docx-to-md.sh `"$specAbs`""
}
if ($ext -ne '.md' -and $ext -ne '.markdown') {
  Die 5 "Unsupported spec format: '$ext'" 'The read operates on .md.'
}

$specDir = Split-Path $specAbs -Parent
$reviewsDir = Join-Path $specDir 'reviews'
$today = Get-Date -Format 'yyyy-MM-dd'

# ---------------------------------------------------------------- track hint
$aiPresent = $false
if ((Get-Content $specAbs -Raw) -match '(?m)^#{1,2} *(Part D|13\. *AI Classification)') { $aiPresent = $true }
$track = if ($aiPresent) { 'ai' } else { 'generic' }

# ---------------------------------------------------------------- mode + findings
if ($verify) {
  $mode = 'verify'
  $latest = Get-ChildItem (Join-Path $reviewsDir 'independent-read-*.md') -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (-not $latest) {
    Die 9 "--verify requested but no earlier findings file exists under $reviewsDir." `
          'Run /speckit.sketch.independent-read without --verify first, then clarify, then --verify.'
  }
  $findingsFile = $latest.FullName
} else {
  $mode = 'read'
  $findingsFile = Join-Path $reviewsDir "independent-read-$today.md"
}

$checklist = $null
$cl = Join-Path $specDir 'checklists/requirements.md'
if (Test-Path $cl) { $checklist = $cl }

$result = [ordered]@{
  extension_root    = $ExtRoot
  command           = 'speckit.sketch.independent-read'
  mode              = $mode
  track_hint        = $track
  track_decided_by  = "spec content: Part D $(if ($aiPresent) { 'present' } else { 'absent' })"
  spec              = $specAbs
  spec_dir          = $specDir
  spec_source       = $specSource
  reviews_dir       = $reviewsDir
  findings_file     = $findingsFile
  checklist         = $checklist
  read_only         = $true
  next_after_read   = 'speckit.sketch.clarify'
  next_after_verify = 'speckit.plan'
}

$json = $result | ConvertTo-Json -Depth 4
if ($jsonOnly) {
  $json
} else {
  @"
sketch-independent-read resolution
  mode          $mode
  spec          $specAbs
  found via     $specSource
  track hint    $track
  findings file $findingsFile
"@
  $json
}
