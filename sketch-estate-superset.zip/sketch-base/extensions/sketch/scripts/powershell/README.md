# PowerShell parity

All three resolvers have full Windows parity, with the same flags, same
validation, same JSON resolution and same exit codes as the bash versions:

- `sketch-specify.ps1`
- `sketch-clarify.ps1`
- `sketch-independent-read.ps1`

Two deliberate differences from bash:

1. Spec discovery skips Spec Kit's `check-prerequisites.sh` (a shell script
   PowerShell cannot execute) and uses `.specify/feature.json`, then the
   newest `specs/*/spec.md`. Pass `-spec` to pin the target explicitly.
2. Catalog parsing needs a real Windows interpreter: only `python3.exe` or
   `python.exe` on PATH is accepted. A Git Bash `python3` shim is a document,
   not an application, and PowerShell cannot execute it.

Example:

```
powershell -ExecutionPolicy Bypass -File `
  .specify/extensions/sketch/scripts/powershell/sketch-clarify.ps1 -l -Json
```
