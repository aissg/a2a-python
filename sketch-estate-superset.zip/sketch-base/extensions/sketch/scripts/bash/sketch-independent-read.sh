#!/usr/bin/env bash
# sketch-independent-read: resolve inputs for /speckit.sketch.independent-read.
#
# Locates the spec, decides whether this is a first read or a --verify pass,
# and hands back the paths the agent needs. Does not read findings aloud and
# never edits the spec: the read is reported into reviews/, the spec is
# changed only by /speckit.sketch.clarify.
#
# Exit codes
#   0  ok
#   1  usage error (unknown flag, missing value)
#   3  spec error (not found, or none discoverable)
#   5  spec error (unsupported format: the read operates on .md)
#   6  asset error (a reference file is missing from the extension)
#   9  verify error (--verify requested but no earlier findings file exists)

set -euo pipefail

EXT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
. "$EXT_ROOT/scripts/bash/lib/common.sh"

usage() {
  cat <<'EOF'
Usage:
  sketch-independent-read.sh [-spec <path>] [--verify] [--json]

Inputs:
  -spec <path>   OPTIONAL. Spec to read. Omitted means discover the active
                 feature spec (check-prerequisites.sh, then feature.json,
                 then newest specs/*/spec.md).
  --verify       Verify pass: re-read only the findings logged by the latest
                 first read and mark each resolved or failed. Run after
                 /speckit.sketch.clarify, before /speckit.plan.

Other:
  --json         emit the resolution as JSON only
  -h, --help     this text

The command never edits the spec. Findings are written to
<spec_dir>/reviews/independent-read-<date>.md; --verify updates the same file.
EOF
}

SPEC_IN=""; VERIFY=0; JSON_ONLY=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    -spec|--spec)
      [[ $# -ge 2 && "${2:0:1}" != "-" ]] || die 1 "-spec requires a file path."
      SPEC_IN="$2"; shift 2 ;;
    --verify)  VERIFY=1; shift ;;
    --json)    JSON_ONLY=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) usage >&2; die 1 "Unknown argument: $1" ;;
  esac
done

# ---------------------------------------------------------------- locate spec
SPEC_ABS=""; SPEC_SOURCE=""
if [[ -n "$SPEC_IN" ]]; then
  SPEC_ABS="$(resolve_existing_file "$SPEC_IN")" || die 3 \
    "Spec not found: '$SPEC_IN'" \
    "Checked as an absolute path and relative to $(pwd)."
  SPEC_SOURCE="-spec argument"
else
  for cand in ".specify/scripts/bash/check-prerequisites.sh"; do
    if [[ -x "$cand" ]]; then
      FOUND="$("$cand" --json --paths-only 2>/dev/null \
               | python3 -c "import json,sys
try: print(json.load(sys.stdin).get('FEATURE_SPEC',''))
except Exception: print('')" 2>/dev/null || true)"
      if [[ -n "$FOUND" && -f "$FOUND" ]]; then
        SPEC_ABS="$(resolve_existing_file "$FOUND")" && SPEC_SOURCE="check-prerequisites.sh"
        break
      fi
    fi
  done
  if [[ -z "$SPEC_ABS" && -f ".specify/feature.json" ]]; then
    FD="$(python3 -c "import json;print(json.load(open('.specify/feature.json')).get('feature_directory',''))" 2>/dev/null || true)"
    [[ -n "$FD" && -f "$FD/spec.md" ]] && { SPEC_ABS="$(resolve_existing_file "$FD/spec.md")"; SPEC_SOURCE=".specify/feature.json"; }
  fi
  if [[ -z "$SPEC_ABS" ]]; then
    NEWEST="$(ls -t specs/*/spec.md 2>/dev/null | head -1 || true)"
    [[ -n "$NEWEST" ]] && { SPEC_ABS="$(resolve_existing_file "$NEWEST")"; SPEC_SOURCE="newest specs/*/spec.md"; }
  fi
  [[ -n "$SPEC_ABS" ]] || die 3 "No spec found to read." \
    "Pass -spec <path>, or run this from a Spec Kit project with a spec in specs/."
fi

case "$(lower "${SPEC_ABS##*.}")" in
  md|markdown) : ;;
  docx)
    COMPANION="${SPEC_ABS%.docx}.md"
    if [[ -f "$COMPANION" ]]; then
      die 5 "The independent read operates on Markdown, not .docx: '$SPEC_ABS'" \
            "A companion exists. Re-run with -spec \"$COMPANION\"."
    fi
    die 5 "The independent read operates on Markdown, not .docx: '$SPEC_ABS'" \
          "Convert first: $EXT_ROOT/scripts/bash/docx-to-md.sh \"$SPEC_ABS\""
    ;;
  *) die 5 "Unsupported spec format: '${SPEC_ABS##*.}'" "The read operates on .md." ;;
esac

SPEC_DIR="$(cd "$(dirname "$SPEC_ABS")" && pwd)"
REVIEWS_DIR="$SPEC_DIR/reviews"
TODAY="$(date +%F)"

# ---------------------------------------------------------------- track hint
AI_SECTIONS_PRESENT=false
if grep -qE '^#{1,2} *(Part D|13\. *AI Classification)' "$SPEC_ABS" 2>/dev/null; then
  AI_SECTIONS_PRESENT=true
fi
if [[ "$AI_SECTIONS_PRESENT" == "true" ]]; then TRACK="ai"; else TRACK="generic"; fi

# ---------------------------------------------------------------- mode + findings
if [[ $VERIFY -eq 1 ]]; then
  MODE="verify"
  FINDINGS_FILE="$(ls -t "$REVIEWS_DIR"/independent-read-*.md 2>/dev/null | head -1 || true)"
  [[ -n "$FINDINGS_FILE" ]] || die 9 \
    "--verify requested but no earlier findings file exists under $REVIEWS_DIR." \
    "Run /speckit.sketch.independent-read without --verify first, then clarify, then --verify."
else
  MODE="read"
  FINDINGS_FILE="$REVIEWS_DIR/independent-read-$TODAY.md"
fi

CHECKLIST="$SPEC_DIR/checklists/requirements.md"
CHECKLIST_JSON="null"
[[ -f "$CHECKLIST" ]] && CHECKLIST_JSON="\"$(jesc "$CHECKLIST")\""

emit_json() {
  cat <<EOF
{
  "extension_root": "$(jesc "$EXT_ROOT")",
  "command": "speckit.sketch.independent-read",
  "mode": "$MODE",
  "track_hint": "$TRACK",
  "track_decided_by": "spec content: Part D $( [[ "$AI_SECTIONS_PRESENT" == "true" ]] && echo present || echo absent )",
  "spec": "$(jesc "$SPEC_ABS")",
  "spec_dir": "$(jesc "$SPEC_DIR")",
  "spec_source": "$SPEC_SOURCE",
  "reviews_dir": "$(jesc "$REVIEWS_DIR")",
  "findings_file": "$(jesc "$FINDINGS_FILE")",
  "checklist": $CHECKLIST_JSON,
  "read_only": true,
  "next_after_read": "speckit.sketch.clarify",
  "next_after_verify": "speckit.plan"
}
EOF
}

if [[ $JSON_ONLY -eq 1 ]]; then
  emit_json
else
  cat <<EOF
sketch-independent-read resolution
  mode          $MODE
  spec          $SPEC_ABS
  found via     $SPEC_SOURCE
  track hint    $TRACK
  findings file $FINDINGS_FILE
EOF
  echo
  emit_json
fi
