#!/usr/bin/env bash
# selftest.sh: exercises every documented rule for all three commands.
# Exits non-zero on any failure. Assertions that need pandoc are skipped
# (counted, not failed) when pandoc is absent, matching the converter section.
set -uo pipefail
EXT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SPEC="$EXT_ROOT/scripts/bash/sketch-specify.sh"
CLAR="$EXT_ROOT/scripts/bash/sketch-clarify.sh"
IR="$EXT_ROOT/scripts/bash/sketch-independent-read.sh"
PARSE="$EXT_ROOT/scripts/lib/parse_catalog.py"
CONV="$EXT_ROOT/scripts/bash/docx-to-md.sh"
TODOCX="$EXT_ROOT/scripts/bash/md-to-docx.sh"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
cd "$TMP"

command -v pandoc >/dev/null 2>&1 && HAVE_PANDOC=1 || HAVE_PANDOC=0

PASS=0; FAIL=0; SKIP=0
ok()   { PASS=$((PASS+1)); printf '  ok    %s\n' "$1"; }
bad()  { FAIL=$((FAIL+1)); printf '  FAIL  %s\n' "$1"; }
skip() { SKIP=$((SKIP+1)); printf '  skip  %s\n' "$1"; }
code() { local want="$1" label="$2" script="$3"; shift 3
         bash "$script" "$@" --json >/dev/null 2>&1
         local got=$?; [[ "$got" == "$want" ]] && ok "$label" || bad "$label (want $want got $got)"; }
field(){ local key="$1" want="$2" label="$3" script="$4"; shift 4
         local got; got=$(bash "$script" "$@" --json 2>/dev/null \
           | python3 -c "import json,sys
d=json.load(sys.stdin)
k='$key'.split('.')
for p in k: d=d[p]
print(d)" 2>/dev/null)
         [[ "$got" == "$want" ]] && ok "$label" || bad "$label ($key: want $want got $got)"; }
# pfield: a field assertion whose resolver call writes a .docx and therefore
# needs pandoc. Skipped (not failed) when pandoc is absent.
pfield(){ if [[ "$HAVE_PANDOC" -eq 1 ]]; then field "$@"; else skip "$3 (needs pandoc)"; fi; }

printf 'meeting notes body\n' > t.txt
printf 'second source body\n' > t2.txt
printf '# spec\n' > s.md
cp "$EXT_ROOT/examples/ai/AI_Example_10K_Extraction_Lightweight.docx" s.docx
mkdir -p specs/001-ai specs/002-gen
cp "$EXT_ROOT/examples/ai/AI_Example_10K_Extraction_Lightweight.md" specs/001-ai/spec.md
cp "$EXT_ROOT/examples/generic/Generic_Example_Risk_Reporting_Standard.md" specs/002-gen/spec.md

echo "specify: errors"
bash "$SPEC" >/dev/null 2>&1; [[ $? -eq 1 ]] && ok "no args" || bad "no args"
code 2 "two depths"        "$SPEC" -l -s -raw t.txt
code 2 "repeated depth"    "$SPEC" -l -l -raw t.txt
code 2 "no depth"          "$SPEC" -raw t.txt
code 2 "-d hints at -s"    "$SPEC" -d -raw t.txt
code 3 "no -raw"           "$SPEC" -l
code 3 "bad raw input"     "$SPEC" -l -raw nope.txt
code 3 "one bad raw of two" "$SPEC" -l -raw t.txt -raw nope.txt
code 1 "-transcript rejected" "$SPEC" -l -transcript t.txt
code 4 "bad spec"          "$SPEC" -l -raw t.txt -spec nope.md
code 5 "spec .txt"         "$SPEC" -l -raw t.txt -spec t.txt
code 1 "unknown flag"      "$SPEC" -l -raw t.txt -zz
code 1 "-ai now rejected"  "$SPEC" -ai -l -raw t.txt

echo "specify: multiple raw inputs"
got=$(bash "$SPEC" -l -raw t.txt -raw t2.txt -spec s.md --json 2>/dev/null | python3 -c "import json,sys;print(len(json.load(sys.stdin)['raw']))")
[[ "$got" == "2" ]] && ok "two -raw inputs both resolve" || bad "two -raw inputs (want 2 got $got)"

echo "specify: output plan"
pfield write_docx True  "create writes docx"        "$SPEC" -l -raw t.txt
pfield write_md   True  "create writes md"         "$SPEC" -l -raw t.txt
pfield write_docx True  "enhance docx writes both" "$SPEC" -l -raw t.txt -spec s.docx
field write_docx False "enhance md writes md only" "$SPEC" -l -raw t.txt -spec s.md
field mode  enhance    "enhance mode detected"     "$SPEC" -l -raw t.txt -spec s.md

echo "specify: both tracks resolved, no track asserted"
pfield track_hint unknown "create leaves track open"     "$SPEC" -l -raw t.txt
pfield tracks.generic.section_count 14  "generic 14 sections" "$SPEC" -l -raw t.txt
pfield tracks.ai.section_count      20  "ai 20 sections"      "$SPEC" -l -raw t.txt
pfield tracks.generic.question_total 34 "generic L 34"        "$SPEC" -l -raw t.txt
pfield tracks.ai.question_total      45 "ai L 45"             "$SPEC" -l -raw t.txt
pfield tracks.generic.question_total 92 "generic S 92"        "$SPEC" -s -raw t.txt
pfield tracks.ai.question_total     125 "ai S 125"            "$SPEC" -s -raw t.txt
pfield tracks.generic.question_total 122 "generic E 122"      "$SPEC" -e -raw t.txt
pfield tracks.ai.question_total     186 "ai E 186"            "$SPEC" -e -raw t.txt
pfield tracks.ai.gated_sections      16 "ai L gates s16"      "$SPEC" -l -raw t.txt
pfield tracks.ai.gated_sections    none "ai S gates nothing"  "$SPEC" -s -raw t.txt
field track_hint ai      "enhance from ai spec"     "$SPEC" -s -raw t.txt -spec specs/001-ai/spec.md
field track_hint generic "enhance from generic spec" "$SPEC" -s -raw t.txt -spec specs/002-gen/spec.md

echo "clarify: errors"
bash "$CLAR" >/dev/null 2>&1; [[ $? -eq 1 ]] && ok "no args" || bad "no args"
code 2 "two depths"      "$CLAR" -l -s -spec specs/001-ai/spec.md
code 2 "no depth"        "$CLAR" -spec specs/001-ai/spec.md
code 3 "bad spec"        "$CLAR" -l -spec nope.md
code 5 "docx rejected"   "$CLAR" -l -spec s.docx
code 1 "-ai rejected"    "$CLAR" -l -ai
code 1 "unknown flag"    "$CLAR" -l -zz

echo "clarify: track read from the spec"
field track ai      "ai spec -> ai track"           "$CLAR" -l -spec specs/001-ai/spec.md
field track generic "generic spec -> generic track" "$CLAR" -s -spec specs/002-gen/spec.md
field ai_sections_present True  "part D detected"    "$CLAR" -l -spec specs/001-ai/spec.md
field ai_sections_present False "part D absent"      "$CLAR" -s -spec specs/002-gen/spec.md
field questions_in_scope 45  "ai L bank = 45"        "$CLAR" -l -spec specs/001-ai/spec.md
field questions_in_scope 186 "ai E bank = 186"       "$CLAR" -e -spec specs/001-ai/spec.md
field questions_in_scope 92  "generic S bank = 92"   "$CLAR" -s -spec specs/002-gen/spec.md
field max_questions_per_session 5 "5-question cap"   "$CLAR" -l -spec specs/001-ai/spec.md

echo "clarify: discovery and stale docx"
field spec_source "newest specs/*/spec.md" "discovers a spec with no -spec" "$CLAR" -l
cp "$EXT_ROOT/examples/ai/AI_Example_10K_Extraction_Lightweight.docx" specs/001-ai/spec.docx
got=$(bash "$CLAR" -l -spec specs/001-ai/spec.md --json 2>/dev/null | python3 -c "import json,sys;print('yes' if json.load(sys.stdin)['stale_docx'] else 'no')")
[[ "$got" == "yes" ]] && ok "stale docx flagged" || bad "stale docx flagged (got $got)"

echo "independent-read: errors"
bash "$IR" >/dev/null 2>&1; [[ $? -eq 0 ]] && ok "no args resolves (discovery)" || bad "no args (want 0, discovery should find a spec)"
code 1 "unknown flag"  "$IR" -zz
code 3 "bad spec"      "$IR" -spec nope.md
code 5 "docx rejected" "$IR" -spec s.docx

echo "independent-read: read mode resolution"
field mode read "read mode is the default" "$IR" -spec specs/001-ai/spec.md
field track_hint ai "track hint from spec" "$IR" -spec specs/001-ai/spec.md
field track_hint generic "generic spec track hint" "$IR" -spec specs/002-gen/spec.md
field read_only True "read-only contract" "$IR" -spec specs/001-ai/spec.md
field next_after_read speckit.sketch.clarify "read points at clarify" "$IR" -spec specs/001-ai/spec.md
field spec_source "-spec argument" "-spec discovery" "$IR" -spec specs/001-ai/spec.md

echo "independent-read: verify gating"
code 9 "verify without findings" "$IR" --verify -spec specs/002-gen/spec.md
mkdir -p specs/002-gen/reviews
printf '# Independent Read\n\n**Status**: OPEN\n' > specs/002-gen/reviews/independent-read-2026-01-01.md
field mode verify "verify mode with findings present" "$IR" --verify -spec specs/002-gen/spec.md
field next_after_verify speckit.plan "verify points at plan" "$IR" --verify -spec specs/002-gen/spec.md

echo "catalog parser: counts match published figures"
AI="$EXT_ROOT/questions/ai/AI_Requirement_Interview_Questions_Catalog.md"
GEN="$EXT_ROOT/questions/generic/Generic_Requirement_Interview_Questions_Catalog.md"
pc() { python3 "$PARSE" "$1" --depth "$2" --track "$3" | python3 -c "import json,sys;print(json.load(sys.stdin)['in_scope'])"; }
for spec in "ai lightweight ai 45" "ai standard ai 125" "ai exhaustive ai 186" \
            "ai lightweight generic 34" "ai standard generic 92" "ai exhaustive generic 122" \
            "gen lightweight generic 34" "gen standard generic 92" "gen exhaustive generic 122"; do
  set -- $spec
  src=$([[ "$1" == "ai" ]] && echo "$AI" || echo "$GEN")
  got=$(pc "$src" "$2" "$3")
  [[ "$got" == "$4" ]] && ok "$1 catalog / $2 / $3 = $4" || bad "$1 catalog / $2 / $3 want $4 got $got"
done

echo "ring fence: every bank question has a stable id and a section"
python3 - "$PARSE" "$AI" <<'PY'
import json, subprocess, sys, re
parse, cat = sys.argv[1], sys.argv[2]
d = json.loads(subprocess.check_output(["python3", parse, cat, "--depth", "exhaustive", "--track", "ai"]).decode())
qs = d["questions"]
bad = 0
ids = [q["id"] for q in qs]
if len(ids) != len(set(ids)):
    print("  FAIL  ids are not unique"); bad += 1
else:
    print("  ok    all %d ids unique" % len(ids))
if all(re.fullmatch(r"Q-\d{3}-\d{2}", i) for i in ids):
    print("  ok    all ids match Q-<section>-<seq>")
else:
    print("  FAIL  malformed id present"); bad += 1
if all(q["section"] and q["text"] for q in qs):
    print("  ok    every question has a section and text")
else:
    print("  FAIL  question missing section or text"); bad += 1
if all("[AI]" not in q["text"] for q in qs):
    print("  ok    inline [AI] marker stripped from question text")
else:
    print("  FAIL  [AI] marker left in text"); bad += 1
ai_out = sorted({q["section"] for q in qs if q["ai"] and q["section"] < 13})
print("  ok    AI questions outside Part D in sections %s" % ai_out)
sys.exit(1 if bad else 0)
PY
if [[ $? -eq 0 ]]; then PASS=$((PASS+5)); else FAIL=$((FAIL+1)); fi

echo "converter"
if command -v pandoc >/dev/null 2>&1; then
  cp "$EXT_ROOT/templates/ai/AI_Template_Lightweight.docx" out.docx
  if bash "$CONV" out.docx out.md >/dev/null 2>&1; then
    [[ "$(grep -cE '^## [0-9]+\.' out.md)" == "20" ]] && ok "companion has 20 sections" || bad "companion sections"
    [[ "$(grep -cE '^# Part ' out.md)" == "5" ]]      && ok "companion has 5 parts"    || bad "companion parts"
    [[ "$(grep -cE '^ *-{5,}' out.md)" == "0" ]]      && ok "no grid tables"           || bad "grid tables present"
    [[ "$(grep -cE '^#{1,2} \*\*' out.md)" == "0" ]]  && ok "headings de-bolded"       || bad "bold headings"
  else bad "converter run"; fi
  bash "$CONV" missing.docx >/dev/null 2>&1; [[ $? -eq 4 ]] && ok "docx-to-md rejects missing input" || bad "docx-to-md missing-input code"
  bash "$CONV" s.md >/dev/null 2>&1;         [[ $? -eq 1 ]] && ok "docx-to-md rejects non-docx"      || bad "docx-to-md non-docx code"

  # md -> docx: the direction an agent must use, since it cannot author a .docx
  TPL_MD="$EXT_ROOT/templates/ai/AI_Template_Lightweight.md"
  TPL_DOCX="$EXT_ROOT/templates/ai/AI_Template_Lightweight.docx"
  if bash "$TODOCX" "$TPL_MD" made.docx --reference "$TPL_DOCX" >/dev/null 2>&1; then
    python3 - made.docx <<'PYZ'
import sys, zipfile
p = sys.argv[1]
try:
    z = zipfile.ZipFile(p)
except zipfile.BadZipFile:
    sys.exit(1)
sys.exit(0 if "word/document.xml" in z.namelist() and z.testzip() is None else 1)
PYZ
    [[ $? -eq 0 ]] && ok "md-to-docx output is a valid readable .docx" || bad "md-to-docx output not a valid .docx"
    got=$(python3 -c "
import zipfile,re
x=zipfile.ZipFile('made.docx').read('word/styles.xml').decode('utf8','replace')
print('yes' if 'Frutiger 45 Light' in x else 'no')")
    [[ "$got" == "yes" ]] && ok "reference-doc carried the house font across" || bad "styling lost (font: $got)"
  else bad "md-to-docx run"; fi
  bash "$TODOCX" missing.md o.docx --reference "$TPL_DOCX" >/dev/null 2>&1; [[ $? -eq 4 ]] && ok "md-to-docx rejects missing input" || bad "md-to-docx missing-input code"
  bash "$TODOCX" "$TPL_MD" o.docx --reference missing.docx >/dev/null 2>&1;  [[ $? -eq 4 ]] && ok "md-to-docx rejects missing reference" || bad "md-to-docx missing-reference code"
  bash "$TODOCX" s.docx o.docx --reference "$TPL_DOCX" >/dev/null 2>&1;      [[ $? -eq 1 ]] && ok "md-to-docx rejects non-md input" || bad "md-to-docx non-md code"
else
  printf '  skip  pandoc not installed\n'
fi

printf '\n%d passed, %d failed, %d skipped\n' "$PASS" "$FAIL" "$SKIP"
[[ "$FAIL" -eq 0 ]]
