#!/usr/bin/env bash
# docx-to-md.sh [--writer markdown|gfm] <spec.docx> [spec.md]
#
# Produces the Markdown companion for a requirement spec written as .docx.
# Single conversion point for the extension: nothing else shells out to pandoc.
#
# Writer choice matters, and the default is deliberate.
#
#   -t gfm       (default) GFM pipe tables. Matches the .md templates and worked
#                examples shipped here, and renders as tables on GitHub and in
#                Spec Kit's downstream commands.
#   -t markdown  pandoc's own extended Markdown. Emits grid tables (rows of
#                dashes) for wide tables: valid pandoc Markdown, but it does not
#                match the shipped references and does not render on GitHub.
#                Available via --writer markdown when byte-parity with a
#                pandoc-native toolchain is required.
#
# Either way the heading text is de-emphasised afterwards: Word carries bold runs
# inside its Heading styles, so pandoc emits "## **1. Purpose**" where the
# shipped templates use "## 1. Purpose".
#
# Exit codes: 1 usage, 4 input missing, 7 pandoc missing, 8 conversion failed

set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib/common.sh"

WRITER="gfm"
if [[ "${1:-}" == "--writer" ]]; then
  [[ $# -ge 2 ]] || die 1 "--writer requires a value: markdown or gfm"
  case "$2" in
    markdown|gfm) WRITER="$2" ;;
    *) die 1 "Unsupported writer '$2'. Use markdown or gfm." ;;
  esac
  shift 2
fi

[[ $# -ge 1 ]] || die 1 "Usage: docx-to-md.sh [--writer markdown|gfm] <spec.docx> [spec.md]"

IN_ABS="$(resolve_existing_file "$1")" || die 4 "Input not found: '$1'" \
  "Checked as an absolute path and relative to $(pwd)."
[[ "$(lower "${IN_ABS##*.}")" == "docx" ]] || die 1 "Input must be a .docx file: '$1'"

OUT="${2:-${IN_ABS%.docx}.md}"
command -v pandoc >/dev/null 2>&1 || die 7 "pandoc not found on PATH." \
  "Install pandoc to produce the Markdown companion."

pandoc -t "$WRITER" "$IN_ABS" -o "$OUT" || die 8 "pandoc failed converting '$IN_ABS'."
[[ -s "$OUT" ]] || die 8 "pandoc produced an empty file: '$OUT'."

# Strip the bold wrapper Word leaves around heading text.
python3 - "$OUT" <<'PY'
import re, sys
p = sys.argv[1]
with open(p, encoding='utf-8') as fh:
    text = fh.read()
text = re.sub(r'(?m)^(\#{1,6}\s+)\*\*(.+?)\*\*\s*$', r'\1\2', text)
with open(p, 'w', encoding='utf-8') as fh:
    fh.write(text)
PY

printf 'wrote %s (writer: %s)\n' "$OUT" "$WRITER"
