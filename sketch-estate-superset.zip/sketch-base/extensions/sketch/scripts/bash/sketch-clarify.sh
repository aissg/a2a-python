#!/usr/bin/env bash
# sketch-clarify: resolve inputs for /speckit.sketch.clarify.
#
# Locates the spec, decides which track applies by reading the spec itself, and
# hands back the catalog question bank in scope for the requested depth. Does
# not ask anything and does not edit the spec: that is the agent's job.
#
# Exit codes
#   0  ok
#   1  usage error (unknown flag, missing value)
#   2  depth error (none given, or more than one)
#   3  spec error (not found, or none discoverable)
#   5  spec error (unsupported format for clarification)
#   6  asset error (a reference file is missing from the extension)

set -euo pipefail

EXT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
. "$EXT_ROOT/scripts/bash/lib/common.sh"

usage() {
  cat <<'EOF'
Usage:
  sketch-clarify.sh (-l | -s | -e) [-spec <path>] [--json]

Depth, exactly one required:
  -l, --lightweight      check against the 34/45 Lightweight questions
  -s, --standard         check against the 92/125 Standard questions
  -e, --exhaustive       check against the 122/186 Exhaustive questions

Inputs:
  -spec <path>           Spec to clarify (.md). Omitted means discover the
                         active feature spec from the Spec Kit project.

Other:
  --json                 emit the resolution as JSON only
  -h, --help             this text

Track is not a flag. It is read from the spec: a spec carrying Part D
(Sections 13 to 18) is treated as AI-Extended, otherwise generic.
EOF
}

DEPTH=""; DEPTH_FLAGS=(); SPEC_IN=""; JSON_ONLY=0

set_depth() {
  DEPTH_FLAGS+=("$2")
  if [[ -n "$DEPTH" && "$DEPTH" != "$1" ]]; then
    die 2 "Only one depth may be specified. Found: ${DEPTH_FLAGS[*]}" \
          "Choose exactly one of -l (lightweight), -s (standard), -e (exhaustive)."
  fi
  [[ -n "$DEPTH" ]] && die 2 "Depth flag repeated: ${DEPTH_FLAGS[*]}" "Specify it once."
  DEPTH="$1"
}

[[ $# -eq 0 ]] && { usage; die 1 "No arguments given."; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    -l|--lightweight) set_depth lightweight "$1"; shift ;;
    -s|--standard)    set_depth standard    "$1"; shift ;;
    -e|--exhaustive)  set_depth exhaustive  "$1"; shift ;;
    -spec|--spec)
      [[ $# -ge 2 && "${2:0:1}" != "-" ]] || die 1 "-spec requires a file path."
      SPEC_IN="$2"; shift 2 ;;
    --json)    JSON_ONLY=1; shift ;;
    -h|--help) usage; exit 0 ;;
    -ai|--ai)
      die 1 "-ai is not a flag for this command." \
            "The track is read from the spec: a spec with Part D is treated as AI-Extended."
      ;;
    -d|--detailed) die 2 "Unknown depth flag '$1'. Standard depth is -s." "Use -l, -s or -e." ;;
    *) usage >&2; die 1 "Unknown argument: $1" ;;
  esac
done

[[ -n "$DEPTH" ]] || die 2 "No depth specified." \
  "Add exactly one of -l (lightweight), -s (standard), -e (exhaustive)."

# ---------------------------------------------------------------- locate spec
SPEC_ABS=""; SPEC_SOURCE=""
if [[ -n "$SPEC_IN" ]]; then
  SPEC_ABS="$(resolve_existing_file "$SPEC_IN")" || die 3 \
    "Spec not found: '$SPEC_IN'" \
    "Checked as an absolute path and relative to $(pwd)."
  SPEC_SOURCE="-spec argument"
else
  # 1. Spec Kit's own prerequisite check, if the project provides it
  for cand in ".specify/scripts/bash/check-prerequisites.sh"; do
    if [[ -x "$cand" ]]; then
      FOUND="$("$cand" --json --paths-only 2>/dev/null \
               | python3 -c "import json,sys
try: print(json.load(sys.stdin).get('FEATURE_SPEC',''))
except Exception: print('')" 2>/dev/null || true)"
      if [[ -n "$FOUND" && -f "$FOUND" ]]; then
        SPEC_ABS="$(resolve_existing_file "$FOUND")" && SPEC_SOURCE="check-prerequisites.sh"
        break
      fi
    fi
  done
  # 2. .specify/feature.json, written by speckit.sketch.specify and speckit.specify
  if [[ -z "$SPEC_ABS" && -f ".specify/feature.json" ]]; then
    FD="$(python3 -c "import json;print(json.load(open('.specify/feature.json')).get('feature_directory',''))" 2>/dev/null || true)"
    [[ -n "$FD" && -f "$FD/spec.md" ]] && { SPEC_ABS="$(resolve_existing_file "$FD/spec.md")"; SPEC_SOURCE=".specify/feature.json"; }
  fi
  # 3. the most recently modified specs/*/spec.md
  if [[ -z "$SPEC_ABS" ]]; then
    NEWEST="$(ls -t specs/*/spec.md 2>/dev/null | head -1 || true)"
    [[ -n "$NEWEST" ]] && { SPEC_ABS="$(resolve_existing_file "$NEWEST")"; SPEC_SOURCE="newest specs/*/spec.md"; }
  fi
  [[ -n "$SPEC_ABS" ]] || die 3 "No spec found to clarify." \
    "Pass -spec <path>, or run this from a Spec Kit project with a spec in specs/."
fi

case "$(lower "${SPEC_ABS##*.}")" in
  md|markdown) : ;;
  docx)
    COMPANION="${SPEC_ABS%.docx}.md"
    if [[ -f "$COMPANION" ]]; then
      die 5 "Clarification edits Markdown, not .docx: '$SPEC_ABS'" \
            "A companion exists. Re-run with -spec \"$COMPANION\"."
    fi
    die 5 "Clarification edits Markdown, not .docx: '$SPEC_ABS'" \
          "Convert first: $EXT_ROOT/scripts/bash/docx-to-md.sh \"$SPEC_ABS\""
    ;;
  *) die 5 "Unsupported spec format: '${SPEC_ABS##*.}'" "Clarification operates on .md." ;;
esac

SPEC_DIR="$(cd "$(dirname "$SPEC_ABS")" && pwd)"

# ---------------------------------------------------------------- detect track
# Structural: does the spec carry Part D / Sections 13 to 18 at all?
AI_SECTIONS_PRESENT=false
if grep -qE '^#{1,2} *(Part D|13\. *AI Classification)' "$SPEC_ABS" 2>/dev/null; then
  AI_SECTIONS_PRESENT=true
fi

# Semantic hint: Part D may be present but explicitly disclaimed in Section 13.
# Reported as a hint only. The agent reads Section 13 and makes the final call.
AI_DISCLAIMED_HINT=false
if [[ "$AI_SECTIONS_PRESENT" == "true" ]]; then
  SEC13="$(awk '/^#{1,2} *13\./{f=1} /^#{1,2} *14\./{f=0} f' "$SPEC_ABS" 2>/dev/null || true)"
  if printf '%s' "$SEC13" | grep -qiE 'not applicable|not an AI|no[,.] *this is not|non-AI'; then
    AI_DISCLAIMED_HINT=true
  fi
fi

if [[ "$AI_SECTIONS_PRESENT" == "true" ]]; then
  TRACK="ai"; TRACK_NAME="AI-Extended"; SECTIONS=20
  CAT="$EXT_ROOT/questions/ai/AI_Requirement_Interview_Questions_Catalog"
  case "$DEPTH" in lightweight) QTOTAL=45 ;; standard) QTOTAL=125 ;; exhaustive) QTOTAL=186 ;; esac
else
  TRACK="generic"; TRACK_NAME="Generic"; SECTIONS=14
  CAT="$EXT_ROOT/questions/generic/Generic_Requirement_Interview_Questions_Catalog"
  case "$DEPTH" in lightweight) QTOTAL=34 ;; standard) QTOTAL=92 ;; exhaustive) QTOTAL=122 ;; esac
fi

for f in "$CAT.docx" "$CAT.md"; do
  [[ -r "$f" ]] || die 6 "Reference asset missing: ${f#"$EXT_ROOT"/}" \
    "The extension is incomplete. Re-install sketch."
done

# ---------------------------------------------------------------- stale docx
STALE_DOCX="null"
if [[ -f "${SPEC_ABS%.md}.docx" ]]; then
  STALE_DOCX="\"$(jesc "${SPEC_ABS%.md}.docx")\""
fi

# ---------------------------------------------------------------- checklist
CHECKLIST="$SPEC_DIR/checklists/requirements.md"
CHECKLIST_JSON="null"
[[ -f "$CHECKLIST" ]] && CHECKLIST_JSON="\"$(jesc "$CHECKLIST")\""

# ---------------------------------------------------------------- question bank
PARSER="$EXT_ROOT/scripts/lib/parse_catalog.py"
[[ -r "$PARSER" ]] || die 6 "Reference asset missing: scripts/lib/parse_catalog.py" \
  "The extension is incomplete. Re-install sketch."
BANK="$(python3 "$PARSER" "$CAT.md" --depth "$DEPTH" --track "$TRACK")" \
  || die 6 "Failed to parse the question catalog."
IN_SCOPE="$(printf '%s' "$BANK" | python3 -c "import json,sys;print(json.load(sys.stdin)['in_scope'])")"

emit_json() {
  cat <<EOF
{
  "extension_root": "$(jesc "$EXT_ROOT")",
  "command": "speckit.sketch.clarify",
  "depth": "$DEPTH",
  "depth_title": "$(title_case "$DEPTH")",
  "track": "$TRACK",
  "track_name": "$TRACK_NAME",
  "track_decided_by": "spec content: Part D $( [[ "$AI_SECTIONS_PRESENT" == "true" ]] && echo present || echo absent )",
  "ai_sections_present": $AI_SECTIONS_PRESENT,
  "ai_disclaimed_hint": $AI_DISCLAIMED_HINT,
  "section_count": $SECTIONS,
  "question_total_at_depth": $QTOTAL,
  "questions_in_scope": $IN_SCOPE,
  "max_questions_per_session": 5,
  "spec": "$(jesc "$SPEC_ABS")",
  "spec_dir": "$(jesc "$SPEC_DIR")",
  "spec_source": "$SPEC_SOURCE",
  "stale_docx": $STALE_DOCX,
  "checklist": $CHECKLIST_JSON,
  "catalog_md": "$(jesc "$CAT.md")",
  "catalog_docx": "$(jesc "$CAT.docx")",
  "question_bank_cmd": "python3 \"$(jesc "$PARSER")\" \"$(jesc "$CAT.md")\" --depth $DEPTH --track $TRACK",
  "question_bank": $BANK
}
EOF
}

if [[ $JSON_ONLY -eq 1 ]]; then
  emit_json
else
  cat <<EOF
sketch-clarify resolution
  spec              $SPEC_ABS
  found via         $SPEC_SOURCE
  track             $TRACK_NAME ($SECTIONS sections), decided from the spec
  ai sections       present=$AI_SECTIONS_PRESENT  disclaimed_hint=$AI_DISCLAIMED_HINT
  depth             $(title_case "$DEPTH") ($QTOTAL questions at this depth)
  questions in bank $IN_SCOPE
  ask at most       5, one at a time
  catalog           ${CAT#"$EXT_ROOT"/}.md
  checklist         ${CHECKLIST_JSON//\"/}
  stale docx        ${STALE_DOCX//\"/}
EOF
  echo
  emit_json
fi
