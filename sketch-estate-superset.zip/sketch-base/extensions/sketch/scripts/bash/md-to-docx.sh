#!/usr/bin/env bash
# md-to-docx.sh <spec.md> <spec.docx> --reference <template.docx>
#
# Produces the Word document from the authored Markdown.
#
# This exists because an agent cannot author a .docx directly. A .docx is a ZIP
# of XML; writing text into a file named spec.docx produces a file Word refuses
# to open. So the agent authors Markdown, which it can do natively, and this
# converts it, carrying the template's styling across via pandoc's
# --reference-doc: fonts, heading styles, table styles and colours all come from
# the reference, while the content comes from the Markdown.
#
# Always pass the depth-graded template for the track in use as --reference.
# Without it pandoc applies its own default styling and the house look is lost.
#
# Exit codes: 1 usage, 4 input missing, 7 pandoc missing, 8 conversion failed

set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib/common.sh"

REFERENCE=""
ARGS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --reference|--reference-doc)
      [[ $# -ge 2 ]] || die 1 "--reference requires a path to a template .docx"
      REFERENCE="$2"; shift 2 ;;
    -h|--help)
      echo "Usage: md-to-docx.sh <spec.md> <spec.docx> --reference <template.docx>"; exit 0 ;;
    *) ARGS+=("$1"); shift ;;
  esac
done

[[ ${#ARGS[@]} -ge 2 ]] || die 1 \
  "Usage: md-to-docx.sh <spec.md> <spec.docx> --reference <template.docx>"

IN_ABS="$(resolve_existing_file "${ARGS[0]}")" || die 4 \
  "Input not found: '${ARGS[0]}'" "Checked as an absolute path and relative to $(pwd)."
[[ "$(lower "${IN_ABS##*.}")" == "md" ]] || die 1 "Input must be a .md file: '${ARGS[0]}'"
OUT="${ARGS[1]}"

command -v pandoc >/dev/null 2>&1 || die 7 "pandoc not found on PATH." \
  "Install pandoc to produce the Word document."

REF_ARGS=()
if [[ -n "$REFERENCE" ]]; then
  REF_ABS="$(resolve_existing_file "$REFERENCE")" || die 4 \
    "Reference template not found: '$REFERENCE'" \
    "Pass the template .docx for the track and depth in use."
  REF_ARGS=(--reference-doc="$REF_ABS")
else
  printf 'WARNING: no --reference given; house styling will NOT be applied.\n' >&2
fi

pandoc "$IN_ABS" -o "$OUT" "${REF_ARGS[@]}" \
  || die 8 "pandoc failed converting '$IN_ABS' to '$OUT'."

[[ -s "$OUT" ]] || die 8 "pandoc produced an empty file: '$OUT'."

# A .docx must be a readable ZIP. Catch a malformed result here rather than
# letting the user discover it when Word refuses to open the file.
python3 - "$OUT" <<'PY'
import sys, zipfile
p = sys.argv[1]
try:
    z = zipfile.ZipFile(p)
except zipfile.BadZipFile:
    print(f"ERROR: '{p}' is not a valid .docx (not a ZIP archive).", file=sys.stderr)
    sys.exit(8)
missing = [n for n in ("word/document.xml", "[Content_Types].xml") if n not in z.namelist()]
if missing:
    print(f"ERROR: '{p}' is missing required parts: {missing}", file=sys.stderr)
    sys.exit(8)
bad = z.testzip()
if bad:
    print(f"ERROR: '{p}' has a corrupt entry: {bad}", file=sys.stderr)
    sys.exit(8)
PY

printf 'wrote %s%s\n' "$OUT" \
  "$( [[ -n "$REFERENCE" ]] && echo " (styled from $(basename "$REFERENCE"))" )"
