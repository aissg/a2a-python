#!/usr/bin/env bash
# Shared helpers for sketch-specify scripts.

# die <exit_code> <message> [hint]
die() {
  local code="$1"; shift
  printf 'ERROR: %s\n' "$1" >&2
  if [[ $# -ge 2 && -n "${2:-}" ]]; then
    printf '  hint: %s\n' "$2" >&2
  fi
  exit "$code"
}

lower() { printf '%s' "$1" | tr '[:upper:]' '[:lower:]'; }

title_case() {
  local s
  s="$(lower "$1")"
  printf '%s' "$(printf '%s' "${s:0:1}" | tr '[:lower:]' '[:upper:]')${s:1}"
}

# Resolve a user-supplied path to an absolute path, accepting either an
# absolute path or one relative to the current working directory.
# Prints the absolute path on success; returns 1 if it is not a readable file.
resolve_existing_file() {
  local p="$1" abs=""
  [[ -n "$p" ]] || return 1
  # strip a surrounding pair of quotes if the caller passed them through
  p="${p%\"}"; p="${p#\"}"
  p="${p%\'}"; p="${p#\'}"
  # expand a leading ~
  [[ "$p" == "~"* ]] && p="${HOME}${p:1}"
  if [[ "$p" == /* ]]; then
    abs="$p"
  else
    abs="$(pwd)/$p"
  fi
  [[ -f "$abs" && -r "$abs" ]] || return 1
  # normalise . and .. without requiring realpath
  ( cd "$(dirname "$abs")" >/dev/null 2>&1 && printf '%s/%s\n' "$(pwd)" "$(basename "$abs")" )
}

# Minimal JSON string escaping for the values we emit (paths and words).
jesc() {
  local s="$1"
  s="${s//\\/\\\\}"
  s="${s//\"/\\\"}"
  printf '%s' "$s"
}
