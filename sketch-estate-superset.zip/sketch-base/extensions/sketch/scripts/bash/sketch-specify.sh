#!/usr/bin/env bash
# sketch-specify: parse, validate and resolve inputs for /speckit.sketch.specify.
#
# There is no -ai flag. Whether Part D applies is a finding about the source
# material, not something the caller asserts, so this script resolves BOTH
# tracks and the agent decides which to use after reading the raw inputs (in
# create mode) or the baseline spec (in enhance mode).
#
# Exit codes
#   0  ok
#   1  usage error (unknown flag, missing value)
#   2  depth error (none given, or more than one)
#   3  raw input error (no -raw given, or a path does not resolve)
#   4  spec error (path does not resolve)
#   5  spec error (unsupported extension)
#   6  asset error (a reference file is missing from the extension)
#   7  tool error (pandoc required for this invocation but not found)

set -euo pipefail

EXT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
. "$EXT_ROOT/scripts/bash/lib/common.sh"

usage() {
  cat <<'EOF'
Usage:
  sketch-specify.sh (-l | -s | -e) -raw <path> [-raw <path> ...] [-spec <path>] [--json]

Depth, exactly one required:
  -l, --lightweight      first interview, about 1 hour
  -s, --standard         production planning, about 1 day
  -e, --exhaustive       regulated work, 3 days to 1 week

Inputs:
  -raw <path>            REQUIRED, repeatable. A raw input file: meeting
                         notes, an interview transcript, an existing
                         requirement document, an email export, anything
                         the draft should be grounded in. Pass several to
                         combine sources: -raw notes.txt -raw old-req.docx
  -spec <path>           OPTIONAL. Existing requirement spec, .docx or .md.
                         Omitted  -> author a new spec from the raw inputs.
                         Provided -> enhance that spec with the raw inputs.

Other:
  --json                 emit the resolution as JSON only
  --out-dir <path>       output directory (default: alongside -spec, else ./)
  -h, --help             this text

Track is not a flag. The agent reads the raw inputs (or the baseline spec) and
decides whether Part D, AI Governance, applies. Both tracks are resolved here.

Output rules:
  no -spec        -> writes spec.docx AND spec.md
  -spec *.docx    -> writes spec.docx AND spec.md
  -spec *.md      -> writes spec.md only
EOF
}

DEPTH=""; DEPTH_FLAGS=(); RAW_INPUTS=(); SPEC_IN=""
JSON_ONLY=0; OUT_DIR=""

set_depth() {
  DEPTH_FLAGS+=("$2")
  if [[ -n "$DEPTH" && "$DEPTH" != "$1" ]]; then
    die 2 "Only one depth may be specified. Found: ${DEPTH_FLAGS[*]}" \
          "Choose exactly one of -l (lightweight), -s (standard), -e (exhaustive)."
  fi
  [[ -n "$DEPTH" ]] && die 2 "Depth flag repeated: ${DEPTH_FLAGS[*]}" "Specify it once."
  DEPTH="$1"
}

[[ $# -eq 0 ]] && { usage; die 1 "No arguments given."; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    -l|--lightweight) set_depth lightweight "$1"; shift ;;
    -s|--standard)    set_depth standard    "$1"; shift ;;
    -e|--exhaustive)  set_depth exhaustive  "$1"; shift ;;
    -raw|--raw)
      [[ $# -ge 2 && "${2:0:1}" != "-" ]] || die 1 "-raw requires a file path."
      RAW_INPUTS+=("$2"); shift 2 ;;
    -transcript|--transcript)
      die 1 "-transcript was renamed to -raw in sketch 0.3.0." \
            "Use -raw <file>; repeat it for several inputs: -raw notes.txt -raw old-req.docx"
      ;;
    -spec|--spec)
      [[ $# -ge 2 && "${2:0:1}" != "-" ]] || die 1 "-spec requires a file path."
      SPEC_IN="$2"; shift 2 ;;
    --out-dir)
      [[ $# -ge 2 ]] || die 1 "--out-dir requires a path."
      OUT_DIR="$2"; shift 2 ;;
    --json)    JSON_ONLY=1; shift ;;
    -h|--help) usage; exit 0 ;;
    -ai|--ai)
      die 1 "-ai is not a flag for this command." \
            "Whether Part D applies is determined from the raw inputs, not asserted by the caller. Drop the flag and re-run."
      ;;
    -d|--detailed) die 2 "Unknown depth flag '$1'. Standard depth is -s." "Use -l, -s or -e." ;;
    *) usage >&2; die 1 "Unknown argument: $1" ;;
  esac
done

[[ -n "$DEPTH" ]] || die 2 "No depth specified." \
  "Add exactly one of -l (lightweight), -s (standard), -e (exhaustive)."

[[ ${#RAW_INPUTS[@]} -ge 1 ]] || die 3 "At least one -raw input is required." \
  "Pass the source material: -raw ./notes/interview.txt (repeat -raw for several files)."

RAW_ABS=()
for raw in "${RAW_INPUTS[@]}"; do
  resolved="$(resolve_existing_file "$raw")" || die 3 \
    "Raw input not found: '$raw'" \
    "Checked as an absolute path and relative to $(pwd). Give a path that resolves to a readable file."
  RAW_ABS+=("$resolved")
done

MODE="create"; SPEC_IN_ABS=""; SPEC_IN_FORMAT=""
if [[ -n "$SPEC_IN" ]]; then
  MODE="enhance"
  SPEC_IN_ABS="$(resolve_existing_file "$SPEC_IN")" || die 4 \
    "Spec file not found: '$SPEC_IN'" \
    "Checked as an absolute path and relative to $(pwd). Omit -spec to author a new spec instead."
  case "$(lower "${SPEC_IN_ABS##*.}")" in
    docx) SPEC_IN_FORMAT="docx" ;;
    md|markdown) SPEC_IN_FORMAT="md" ;;
    *) die 5 "Unsupported spec format: '${SPEC_IN_ABS##*.}'" "-spec accepts .docx or .md only." ;;
  esac
fi

# ---------------------------------------------------------------- output plan
if [[ "$MODE" == "enhance" && "$SPEC_IN_FORMAT" == "md" ]]; then OUT_DOCX=false; else OUT_DOCX=true; fi
OUT_MD=true

if [[ -z "$OUT_DIR" ]]; then
  if [[ -n "$SPEC_IN_ABS" ]]; then OUT_DIR="$(dirname "$SPEC_IN_ABS")"; else OUT_DIR="$(pwd)"; fi
fi
mkdir -p "$OUT_DIR"; OUT_DIR="$(cd "$OUT_DIR" && pwd)"

# ------------------------------------------------- track determination context
# In enhance mode the baseline already answered the question structurally.
TRACK_HINT="unknown"; TRACK_DECIDED_BY="agent reads raw inputs"
if [[ "$MODE" == "enhance" && "$SPEC_IN_FORMAT" == "md" ]]; then
  if grep -qE '^#{1,2} *(Part D|13\. *AI Classification)' "$SPEC_IN_ABS" 2>/dev/null; then
    TRACK_HINT="ai"
  else
    TRACK_HINT="generic"
  fi
  TRACK_DECIDED_BY="baseline spec structure, confirm against raw inputs"
elif [[ "$MODE" == "enhance" ]]; then
  TRACK_DECIDED_BY="baseline spec (.docx): agent inspects, confirm against raw inputs"
fi

# ---------------------------------------------------------------- assets
DEPTH_TITLE="$(title_case "$DEPTH")"
GEN_TPL="$EXT_ROOT/templates/generic/Generic_Template_${DEPTH_TITLE}"
GEN_CAT="$EXT_ROOT/questions/generic/Generic_Requirement_Interview_Questions_Catalog"
GEN_EXA="$EXT_ROOT/examples/generic/Generic_Example_Risk_Reporting_${DEPTH_TITLE}"
AI_TPL="$EXT_ROOT/templates/ai/AI_Template_${DEPTH_TITLE}"
AI_CAT="$EXT_ROOT/questions/ai/AI_Requirement_Interview_Questions_Catalog"
AI_EXA="$EXT_ROOT/examples/ai/AI_Example_10K_Extraction_${DEPTH_TITLE}"

for f in "$GEN_TPL.docx" "$GEN_TPL.md" "$GEN_CAT.docx" "$GEN_CAT.md" "$GEN_EXA.docx" "$GEN_EXA.md" \
         "$AI_TPL.docx" "$AI_TPL.md" "$AI_CAT.docx" "$AI_CAT.md" "$AI_EXA.docx" "$AI_EXA.md"; do
  [[ -r "$f" ]] || die 6 "Reference asset missing: ${f#"$EXT_ROOT"/}" \
    "The extension is incomplete. Re-install sketch."
done

case "$DEPTH" in
  lightweight) GEN_Q=34; AI_Q=45  ;;
  standard)    GEN_Q=92; AI_Q=125 ;;
  exhaustive)  GEN_Q=122; AI_Q=186 ;;
esac
AI_GATED="none"; [[ "$DEPTH" == "lightweight" ]] && AI_GATED="16"

PANDOC_STATUS="available"; command -v pandoc >/dev/null 2>&1 || PANDOC_STATUS="missing"
if [[ "$OUT_DOCX" == "true" && "$PANDOC_STATUS" == "missing" ]]; then
  die 7 "pandoc not found on PATH, but this invocation writes a .docx and its .md companion." \
        "Install pandoc, or pass -spec <file>.md to produce Markdown only."
fi

raw_json() {
  local out="" e
  for e in "${RAW_ABS[@]}"; do
    [[ -n "$out" ]] && out+=", "
    out+="\"$(jesc "$e")\""
  done
  printf '%s' "$out"
}

emit_json() {
  cat <<EOF
{
  "extension_root": "$(jesc "$EXT_ROOT")",
  "command": "speckit.sketch.specify",
  "mode": "$MODE",
  "depth": "$DEPTH",
  "depth_title": "$DEPTH_TITLE",
  "track_decided_by": "$TRACK_DECIDED_BY",
  "track_hint": "$TRACK_HINT",
  "raw": [ $(raw_json) ],
  "spec_in": $( [[ -n "$SPEC_IN_ABS" ]] && printf '"%s"' "$(jesc "$SPEC_IN_ABS")" || printf 'null' ),
  "spec_in_format": $( [[ -n "$SPEC_IN_FORMAT" ]] && printf '"%s"' "$SPEC_IN_FORMAT" || printf 'null' ),
  "out_dir": "$(jesc "$OUT_DIR")",
  "write_docx": $OUT_DOCX,
  "write_md": $OUT_MD,
  "out_docx": $( [[ "$OUT_DOCX" == "true" ]] && printf '"%s"' "$(jesc "$OUT_DIR/spec.docx")" || printf 'null' ),
  "out_md": "$(jesc "$OUT_DIR/spec.md")",
  "tracks": {
    "generic": {
      "track_name": "Generic",
      "section_count": 14,
      "question_total": $GEN_Q,
      "gated_sections": "none",
      "template_docx": "$(jesc "$GEN_TPL.docx")",
      "template_md": "$(jesc "$GEN_TPL.md")",
      "catalog_docx": "$(jesc "$GEN_CAT.docx")",
      "catalog_md": "$(jesc "$GEN_CAT.md")",
      "example_docx": "$(jesc "$GEN_EXA.docx")",
      "example_md": "$(jesc "$GEN_EXA.md")"
    },
    "ai": {
      "track_name": "AI-Extended",
      "section_count": 20,
      "question_total": $AI_Q,
      "gated_sections": "$AI_GATED",
      "template_docx": "$(jesc "$AI_TPL.docx")",
      "template_md": "$(jesc "$AI_TPL.md")",
      "catalog_docx": "$(jesc "$AI_CAT.docx")",
      "catalog_md": "$(jesc "$AI_CAT.md")",
      "example_docx": "$(jesc "$AI_EXA.docx")",
      "example_md": "$(jesc "$AI_EXA.md")"
    }
  },
  "pandoc": "$PANDOC_STATUS",
  "convert_cmd_to_docx": "$(jesc "$EXT_ROOT/scripts/bash/md-to-docx.sh") \"$(jesc "$OUT_DIR/spec.md")\" \"$(jesc "$OUT_DIR/spec.docx")\" --reference <tracks.TRACK.template_docx>",
  "convert_cmd_to_md": "$(jesc "$EXT_ROOT/scripts/bash/docx-to-md.sh") \"$(jesc "$OUT_DIR/spec.docx")\" \"$(jesc "$OUT_DIR/spec.md")\"",
  "authoring_direction": "author .md first, then convert to .docx with md-to-docx.sh --reference",
  "convert_writer": "gfm"
}
EOF
}

if [[ $JSON_ONLY -eq 1 ]]; then
  emit_json
else
  printf 'sketch-specify resolution\n'
  printf '  mode              %s\n' "$MODE"
  printf '  depth             %s\n' "$DEPTH_TITLE"
  printf '  track             NOT SET: %s (hint: %s)\n' "$TRACK_DECIDED_BY" "$TRACK_HINT"
  printf '                    generic -> 14 sections, %s questions\n' "$GEN_Q"
  printf '                    ai      -> 20 sections, %s questions, gated: %s\n' "$AI_Q" "$AI_GATED"
  for e in "${RAW_ABS[@]}"; do printf '  raw               %s\n' "$e"; done
  printf '  spec in           %s\n' "${SPEC_IN_ABS:-<none, authoring from scratch>}"
  printf '  writes            %s\n' "$( [[ "$OUT_DOCX" == "true" ]] && echo "spec.docx + spec.md" || echo "spec.md only" )"
  printf '  out dir           %s\n' "$OUT_DIR"
  printf '  pandoc            %s\n' "$PANDOC_STATUS"
  echo
  emit_json
fi
