---
name: "speckit.sketch.independent-read"
description: "Read a requirement spec the way Fagan inspection reads one: paraphrase each requirement and scenario in isolation, diff the paraphrase against the text, and log confident misreads. --verify confirms each logged finding closed after clarify."
argument-hint: "[-spec <path>] [--verify]"
compatibility: "Requires a project initialised with specify init. Operates on Markdown specs. Never edits the spec."
metadata:
  author: "sketch"
  source: "commands/independent-read.md"
  derived-from: "Fagan inspection (IBM, 1976), adapted to the Sketch requirement workflow"
user-invocable: true
disable-model-invocation: false
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

The input is a flag set, not free text: an optional spec path, and an optional
`--verify`.

| Flag | Required | Meaning |
|------|----------|---------|
| `-spec <path>` | no | Spec to read. Omitted means discover the active feature spec |
| `--verify` | no | Verify pass after clarify: re-check only the logged findings |

## What this command is

A Fagan independent read placed inside the delivery sequence. You are not the
author and not the clarifier: you paraphrase each requirement and each user
scenario **in isolation**, then diff your paraphrase against what the spec
actually says. Where the two diverge, the text is ambiguous in a way
`/speckit.sketch.clarify` cannot catch, because clarify only notices what it is
itself unsure about. A confident misread is text that is clear but means two
different things to two readers.

Two rules define the command:

1. **Read-only.** You never edit the spec. Findings go to a review file; the
   spec changes only through `/speckit.sketch.clarify`.
2. **Isolation.** Paraphrase each item from its own text alone, before reading
   surrounding sections. Context is how misreads get rationalised away.

## Where it sits

```
/speckit.sketch.specify  ->  /speckit.sketch.independent-read
-> /speckit.sketch.clarify  ->  /speckit.sketch.independent-read --verify
-> /speckit.plan
```

The first read runs **before** clarify, so it sees the draft before any
questions touch it. The verify pass runs **after** clarify and confirms each
logged defect actually closed, not just that the file changed.

## Pre-Execution Checks

Run the resolver and stop on any non-zero exit:

```bash
SK=".specify/extensions/sketch"
[ -d "$SK" ] || { echo "sketch extension is not installed"; exit 1; }

"$SK/scripts/bash/sketch-independent-read.sh" $ARGUMENTS --json
```

On non-zero exit, report its `ERROR:` line and `hint:` verbatim and stop.
Exit codes: `1` usage, `3` spec not found, `5` spec not Markdown, `6` missing
asset, `9` verify requested but no earlier findings file exists.

The resolution gives you: `mode`, `track_hint`, `spec`, `spec_dir`,
`reviews_dir`, `findings_file`, `checklist`. Every path you use comes from here.

**Check for extension hooks (before clarify)**: this command shares the
clarify hook point. Check `.specify/extensions.yml` under
`hooks.before_clarify` and dispatch exactly as `/speckit.sketch.clarify` does:
optional hooks are offered, mandatory hooks are executed and awaited, invalid
YAML is skipped silently, hooks with a non-empty `condition` are left to the
HookExecutor.

## Outline: first read (mode = read)

1. **Read the spec in full once**, for orientation only. Note the track from
   `track_hint`: Part D present means AI-Extended.

2. **Build the item list.** Every functional requirement (`FR-n`), every
   non-functional target (`NFR-n`), and every user scenario (`US-n`) is an
   item. Nothing else is: context sections inform the diff but are not items.

3. **Paraphrase in isolation.** For each item, cover the rest of the document
   mentally and restate the item in your own words: what triggers it, what the
   system does, what observable result follows. Do this from the item's own
   text only.

4. **Diff each paraphrase against the spec.** Compare your restatement with:
   - the scenario the requirement traces to, and vice versa
   - the acceptance criterion that claims to prove it
   - any other section that mentions the same behaviour

   A **finding** is any of:
   - **Divergence**: your paraphrase and another section cannot both be true
   - **Double reading**: the text supports two defensible interpretations and
     nothing in the document selects one
   - **Orphan**: a requirement no scenario needs, or a scenario no requirement
     serves (already a checklist item; log it here only if it also misleads)
   - **Silent number**: a figure stated in one section and contradicted or
     repeated differently in another

   Not findings: style, brevity, missing facts (those are Coverage Gaps, owned
   by specify and clarify), and anything you are merely unsure about. This
   pass catches what reads cleanly and means two things, not what reads badly.

5. **Write the findings file** at `findings_file`, creating `reviews_dir` if
   needed:

   ```markdown
   # Independent Read: [FEATURE NAME]

   **Date**: YYYY-MM-DD
   **Spec**: [path]
   **Track / Depth**: [track] / [depth]
   **Status**: OPEN

   ## Findings

   | Id | Item | Type | Finding | Suggested resolution | Verify |
   |----|------|------|---------|----------------------|--------|
   | IR-1 | FR-3 | double reading | <text supports both X and Y> | <which section should win> | open |
   ```

   One row per finding, ids stable (`IR-1`, `IR-2`, ...). If there are no
   findings, write the file with an empty table and `Status: CLEAN`: the
   absence of findings is evidence, and a reviewer at the gate looks for it.

6. **Report.** Summarise findings by type, name the file, and recommend
   `/speckit.sketch.clarify` at the same depth. Clarify receives this file as
   a second source of questions alongside its catalog bank: each finding is
   input to a catalog question where one exists, and to "Outside the catalog"
   where none does.

## Outline: verify pass (mode = verify)

1. **Read the findings file** at `findings_file` (the resolver located the
   latest). If its status is CLEAN, say so and stop: there is nothing to
   verify.

2. **For each finding**, re-paraphrase only the flagged item against its
   current spec text, post-clarify:
   - **Resolved**: the text now admits one reading, and it is the intended one
   - **Failed**: the divergence or double reading survives

   Confirm closure, not motion: a section that was edited but still supports
   two readings is Failed.

3. **Update the same findings file** in place: set each row's Verify cell to
   `resolved` or `failed`, with one line of evidence. Set `Status:` to
   `VERIFIED` when every row is resolved, otherwise `FAILED`.

4. **Refuse to pass on open failures.** If any row is `failed`, say plainly
   that the spec is not ready for `/speckit.plan`, name the surviving
   findings, and send the user back to `/speckit.sketch.clarify`. Never mark a
   finding resolved to make the gate green.

## Mandatory Post-Execution Hooks

Check `.specify/extensions.yml` under `hooks.after_clarify` and dispatch
exactly as `/speckit.sketch.clarify` does, then report completion.

## Completion Report

- Mode (first read or verify), spec path, track
- Items read (counts of FR / NFR / US), findings logged, by type
- Findings file path and its status (OPEN / CLEAN / VERIFIED / FAILED)
- Verify pass: per-finding resolved or failed, with the surviving failures named
- Suggested next command: `/speckit.sketch.clarify` after a first read;
  `/speckit.plan` after a clean verify

## Done When

- [ ] Resolver ran clean and every path used came from its JSON
- [ ] Every FR, NFR and US paraphrased in isolation before any cross-section comparison
- [ ] Findings file written, ids stable, one row per finding, or Status CLEAN
- [ ] The spec was not edited, in either mode
- [ ] Verify pass confirmed closure per finding, and refused to pass on any failure
- [ ] Completion reported with findings by type and the next command
