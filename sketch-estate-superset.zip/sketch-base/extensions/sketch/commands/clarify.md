---
name: "speckit.sketch.clarify"
description: "Find gaps in a requirement spec by asking up to 5 questions drawn only from the interview question catalog, and encode the answers back into the spec."
argument-hint: "(-l | -s | -e) [-spec <path>]"
compatibility: "Requires a project initialised with specify init. Operates on Markdown specs."
metadata:
  author: "sketch"
  source: "commands/clarify.md"
  derived-from: "github-spec-kit templates/commands/clarify.md"
user-invocable: true
disable-model-invocation: false
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

The input is a flag set, not free text: a depth, and optionally a spec path.

| Flag | Required | Meaning |
|------|----------|---------|
| `-l`, `--lightweight` | one of three | Check against the Lightweight question set |
| `-s`, `--standard` | one of three | Check against the Standard question set |
| `-e`, `--exhaustive` | one of three | Check against the Exhaustive question set |
| `-spec <path>` | no | Spec to clarify. Omitted means discover the active feature spec |

There is no `-ai` flag. Whether AI questions apply is read from the spec.

## How this differs from `/speckit.clarify`

Stock clarify generates its questions at runtime from a 10-category ambiguity
taxonomy. It invents the question text on the spot, so no two runs are
guaranteed to ask the same thing.

This command does not invent questions. It works from the interview question
catalog that ships with the extension, a fixed, versioned, human-authored set,
and asks only questions that already exist in it. Everything else, the 5-question
cap, one question at a time, the recommendation-first presentation, incremental
write-back, checklist re-validation, follows stock clarify exactly.

The reason is auditability. A reviewer can read the catalog before any session
happens and know what will be asked. That is not possible with generated
questions.

## Pre-Execution Checks

**Check for extension hooks (before clarification)**:
- Check if `.specify/extensions.yml` exists in the project root.
- If it exists, read it and look for entries under the `hooks.before_clarify` key
- If the YAML cannot be parsed or is invalid, skip hook checking silently and continue normally
- Filter out hooks where `enabled` is explicitly `false`. Treat hooks without an `enabled` field as enabled by default.
- For each remaining hook, do **not** attempt to interpret or evaluate hook `condition` expressions:
  - If the hook has no `condition` field, or it is null/empty, treat the hook as executable
  - If the hook defines a non-empty `condition`, skip the hook and leave condition evaluation to the HookExecutor implementation
- When constructing slash commands from hook command names, replace dots (`.`) with hyphens (`-`). For example, `speckit.git.commit` → `/speckit-git-commit`.
- For each executable hook, output the following based on its `optional` flag:
  - **Optional hook** (`optional: true`):
    ```
    ## Extension Hooks

    **Optional Pre-Hook**: {extension}
    Command: `/{command}`
    Description: {description}

    Prompt: {prompt}
    To execute: `/{command}`
    ```
  - **Mandatory hook** (`optional: false`):
    ```
    ## Extension Hooks

    **Automatic Pre-Hook**: {extension}
    Executing: `/{command}`
    EXECUTE_COMMAND: {command}

    Wait for the result of the hook command before proceeding to the Outline.
    ```
    After emitting the block above you MUST actually invoke the hook and wait for it to finish before continuing. Run it the same way you would run the command yourself in this agent/session (the invocation may differ from the literal `{command}` id shown above, e.g. a skills-mode agent runs it as `/skill:speckit-...` or `$speckit-...`). Emitting the block alone does not run the hook.
- If no hooks are registered or `.specify/extensions.yml` does not exist, skip silently

## Outline

Goal: find the questions at the requested depth that the spec does not yet
answer, ask the highest-impact few, and record the answers in the spec.

This runs after `/speckit.sketch.specify` and before `/speckit.plan`. If the
user says they are skipping clarification, you may proceed, but warn that
downstream rework risk increases.

Execution steps:

1. **Resolve.** Run the resolver and stop on any non-zero exit:

   ```bash
   SK=".specify/extensions/sketch"
   [ -d "$SK" ] || { echo "sketch extension is not installed"; exit 1; }

   "$SK/scripts/bash/sketch-clarify.sh" $ARGUMENTS --json
   ```

   On non-zero exit, report its `ERROR:` line and `hint:` verbatim and stop.
   Exit codes: `1` usage, `2` depth, `3` spec not found, `5` spec not Markdown,
   `6` missing asset.

   The resolution gives you: `spec`, `track`, `ai_sections_present`,
   `ai_disclaimed_hint`, `depth`, `questions_in_scope`, `checklist`,
   `stale_docx`, and `question_bank`. Every path you use comes from here.

2. **IF EXISTS**: Load `.specify/memory/constitution.md` for project principles and governance constraints.

3. **Confirm the track.** The resolver decides it structurally: a spec carrying
   Part D is AI-Extended, otherwise generic. Two cases need your judgement:

   - `ai_disclaimed_hint: true` means Part D is present but Section 13 appears to
     say this is not an AI feature. Read Section 13. If it does say No, drop
     every `ai: true` question from the bank and clarify the generic set only.
     State this in the Completion Report.
   - `ai_sections_present: false` on a spec whose subject matter is plainly a
     model, is a finding worth reporting: the spec may be on the wrong track.
     Do not silently switch. Report it and continue with the generic set.

   Note that `ai: true` questions are not confined to Part D. They also appear
   in Sections 5, 6, 7, 8, 10, 11, 12, 19 and 20.

4. **Load the question bank.** It is already in the resolution under
   `question_bank.questions`, filtered to the depth and track, each with a stable
   `id` (`Q-<section>-<seq>`), `section`, `marker` and `text`. To re-read it:

   ```bash
   python3 "$SK/scripts/lib/parse_catalog.py" <catalog_md> --depth <depth> --track <track>
   ```

5. **Score every question in the bank against the spec.** For each one, read the
   section it belongs to and mark it:

   - **Answered**: the spec states a specific, usable answer
   - **Partial**: the spec gestures at it but leaves a figure, owner, or
     condition unstated
   - **Missing**: the spec is silent, or carries the template's bracketed
     placeholder, or logs it as a gap in Interview Coverage Gaps

   Build this coverage map internally. Do not print it unless you end up asking
   nothing.

6. **Queue up to 5 questions.** From Partial and Missing only, ordered by:

   1. The four assumption checks first, when unresolved: delivery surface,
      accuracy expectation, human review path, test data. These break projects
      when left unexamined.
   2. Then by impact on architecture, data modelling, test design, operational
      readiness, or compliance validation.
   3. Then by (Impact x Uncertainty) where more than 5 remain.

   Spread across sections rather than taking five from one. Skip anything whose
   answer would not change the build or the evidence.

7. **Ring-fence, and this is the rule that defines this command.**

   - Every question you ask **MUST** come from the bank, cited by its `id`.
   - Ask it in the catalog's own words. You may shorten a long question or split
     a compound one, but you may not replace it with a question of your own.
   - If you believe something important is missing from the catalog, do **not**
     ask it. Record it in the Completion Report under "Outside the catalog" so
     the catalog can be amended. The catalog is the reviewable artifact; a
     question that bypasses it is unreviewable by definition.
   - Never reveal queued questions in advance.

8. **Sequential questioning loop.** Present EXACTLY ONE question at a time.

   For a question with meaningful discrete options:
   - **Analyze the options** and pick the most suitable, based on best practice
     for this kind of system, risk reduction, and anything the spec already
     commits to.
   - Present the recommendation first, then the table:

     ```
     **Q-008-03** (Section 8, Security, Privacy & Compliance) [S]

     <the catalog question, in its own words>

     **Recommended:** Option B - <1-2 sentences of reasoning>
     ```

     | Option | Description |
     |--------|-------------|
     | A | <description> |
     | B | <description> |
     | C | <description> (add D/E as needed up to 5) |
     | Short | Provide a different short answer (<=5 words) |

   - Then: `You can reply with the option letter (e.g., "A"), accept the recommendation by saying "yes" or "recommended", or provide your own short answer.`

   For a question with no meaningful discrete options:
   - `**Suggested:** <your proposed answer> - <brief reasoning>`
   - Then: `Format: Short answer (<=5 words). You can accept the suggestion by saying "yes" or "suggested", or provide your own answer.`

   After each answer:
   - "yes" / "recommended" / "suggested" means take your own stated proposal.
   - Otherwise check the answer maps to an option or fits the length constraint.
   - If ambiguous, ask once for disambiguation. That does not consume a new
     question slot.
   - Record it in working memory and move on.

   Stop when: all high-impact gaps are closed, or the user says "done" / "good" /
   "stop" / "proceed", or you have asked 5.

   If the bank has no Partial or Missing entries worth asking, say
   "No unanswered catalog questions worth clarifying at <depth> depth." and skip
   to the Completion Report.

9. **Integrate after EACH accepted answer.** Do not batch.

   - On the first answer this session, ensure a `## Clarifications` section
     exists, placed after the front matter and before Part A. Under it create
     `### Session YYYY-MM-DD`.
   - Append: `- Q-<id> (S<section>): <question> → A: <answer>`
   - Then apply the answer to the section it belongs to. The question's own
     `section` field tells you where, which is the advantage of a catalog keyed
     to the template: a Section 8 question's answer goes in Section 8.
     - If that field holds the template's bracketed placeholder, replace it.
     - If Interview Coverage Gaps has a row for that section, update or remove
       the row to match what is now answered.
     - If the answer contradicts an earlier vague statement, replace the
       statement. Leave no contradictory text.
     - Requirements added or changed must be in EARS form:
       `When / While / Where / If <trigger or state>, the <system> shall <response>`
     - A non-functional target goes in Section 7 with an owner. Its measurable
       condition goes in Section 19. Never collapse the two.
   - Save the spec after each integration. Preserve heading order and hierarchy;
     never reorder unrelated sections.

10. **Validate after each write and once at the end.**
    - Exactly one Clarifications bullet per accepted answer, no duplicates
    - Total asked <= 5
    - No lingering placeholder that an answer was meant to resolve
    - No contradictory earlier statement left behind
    - Only new headings allowed: `## Clarifications`, `### Session YYYY-MM-DD`
    - Terminology consistent with Appendix A across every section touched

11. **Re-validate the spec quality checklist** if `checklist` is non-null in the
    resolution:
    1. Read the checklist file.
    2. Identify all GitHub task-list checkbox lines: `- [ ]`, `- [x]`, `- [X]`, outside code fences. Ignore all other content.
    3. Record each line's current state and text into a before-snapshot.
    4. Re-evaluate each item against the **updated** spec.
    5. Update only where the state actually changes: `[ ]` to `[x]` if it now passes, `[x]` to `[ ]` if it now fails. Leave unchanged markers alone, preserving case.
    6. Save the checklist. **Only toggle the marker.** Headings, notes, ordering and whitespace must be untouched, to avoid noisy diffs.
    7. Compute newly passing, regressions, and still unchecked.
    8. Record before/after counts as checked/total, for example "12/16 → 15/16".

12. **Report the stale `.docx` if there is one.** If `stale_docx` is non-null,
    the Word version no longer matches the Markdown you just edited. Say so
    plainly in the Completion Report. Do not attempt to regenerate it: converting
    Markdown back to `.docx` loses the template's styling. The clarifications
    must be applied to the `.docx` by re-running
    `/speckit.sketch.specify` with `-spec <the .docx>`, or by hand.

Behavior rules:

- If the spec file is missing, tell the user to run `/speckit.sketch.specify` first. Do not create a spec here.
- Never exceed 5 asked questions. Disambiguation retries do not count.
- Never ask a question the spec already answers.
- Never invent a question. If it is not in the bank, it is not asked.
- Respect early termination ("stop", "done", "proceed").
- If the quota is reached with high-impact gaps remaining, list them under Deferred with the reason.

Context for prioritization: $ARGUMENTS

## Mandatory Post-Execution Hooks

**You MUST complete this section before reporting completion to the user.**

Check if `.specify/extensions.yml` exists in the project root.
- If it does not exist, or no hooks are registered under `hooks.after_clarify`, skip to the Completion Report.
- If it exists, read it and look for entries under the `hooks.after_clarify` key.
- If the YAML cannot be parsed or is invalid, skip hook checking silently and continue to the Completion Report.
- Filter out hooks where `enabled` is explicitly `false`. Treat hooks without an `enabled` field as enabled by default.
- For each remaining hook, do **not** attempt to interpret or evaluate hook `condition` expressions:
  - If the hook has no `condition` field, or it is null/empty, treat the hook as executable
  - If the hook defines a non-empty `condition`, skip the hook and leave condition evaluation to the HookExecutor implementation
- When constructing slash commands from hook command names, replace dots (`.`) with hyphens (`-`).
- For each executable hook, output the following based on its `optional` flag:
  - **Mandatory hook** (`optional: false`), **you MUST emit `EXECUTE_COMMAND:` for each mandatory hook**:
    ```
    ## Extension Hooks

    **Automatic Hook**: {extension}
    Executing: `/{command}`
    EXECUTE_COMMAND: {command}
    ```
    After emitting the block above you MUST actually invoke the hook and wait for it to finish before continuing.
  - **Optional hook** (`optional: true`):
    ```
    ## Extension Hooks

    **Optional Hook**: {extension}
    Command: `/{command}`
    Description: {description}

    Prompt: {prompt}
    To execute: `/{command}`
    ```

## Completion Report

- Questions asked and answered, each cited by catalog id
- Path to the updated spec
- Sections touched, by number and name
- Track used, and how it was decided. Note it explicitly if `ai_disclaimed_hint` changed the outcome
- Spec quality checklist status, if re-validated: before/after counts, items newly checked, any regressions, anything still unchecked
- Coverage summary by part, counting bank questions at this depth:

  | Part | Answered | Partial | Missing | Asked this session |
  |------|----------|---------|---------|--------------------|
  | A Context | | | | |
  | B Behaviour | | | | |
  | C Quality & Constraints | | | | |
  | D AI Governance (AI track only) | | | | |
  | E Closure | | | | |
  | Appendices | | | | |

- **Outside the catalog**: anything you judged worth asking that the catalog does not contain. This is the feedback loop that keeps the catalog honest. Say "none" if there is nothing.
- Stale `.docx` warning, if `stale_docx` was non-null
- Deferred items, if the 5-question quota was reached with gaps remaining
- Suggested next command: `/speckit.sketch.clarify` again at a deeper depth, `/speckit.sketch.specify -spec` to extend, or `/speckit.plan`

## Done When

- [ ] Resolver ran clean and every path used came from its JSON
- [ ] Track confirmed, including the disclaimed-Part-D case
- [ ] Every question asked was cited by catalog id, and none was invented
- [ ] At most 5 questions asked, one at a time, each with a recommendation
- [ ] Each answer written into the spec immediately, in its own section, in EARS form where it is a requirement
- [ ] Interview Coverage Gaps updated to match what is now answered
- [ ] Checklist re-validated if present
- [ ] Stale `.docx` reported if one exists
- [ ] Completion reported with coverage by part and any out-of-catalog findings
