# Mapping stock `spec-template` onto the sketch templates

Reference: `spec-template.md` from GitHub Spec Kit, 131 lines, four top-level
sections. Target: the AI-Extended track, 20 sections plus 2 appendices.

## Stock section, and where its content goes

| Stock section | Contents | Lands in |
|---|---|---|
| User Scenarios & Testing | User stories P1-P3, plain-language journey, `Why this priority`, `Independent Test`, Given/When/Then, plus Edge Cases as two prompt questions | **Section 3** near field for field. Edge Cases expands into **Section 11** |
| Requirements → Functional Requirements | `FR-001: System MUST ...` prose, `[NEEDS CLARIFICATION]` markers | **Section 4**, rewritten as EARS. Markers become rows in the Interview Coverage Gaps block |
| Requirements → Key Entities | Entity name and a few attributes | **Section 5**, which additionally asks for source of truth, classification, joins, volume and known defects |
| Success Criteria | `SC-001` measurable outcomes | Splits: the target with an owner goes to **Section 7**, the measurable condition to **Section 19** |
| Assumptions | One list holding assumptions, scope boundaries and dependencies | Splits: scope to **Section 2**, dependencies to **Section 10**, fixed decisions and rejected options to **Section 12** |

## Sections with no stock destination

Part A: 1 Purpose & Current State, 2 Scope & Stakeholders.
Part B: 6 Delivery & Presentation.
Part C: 8 Security, Privacy & Compliance; 9 Audit, Logging & Retention.
Part D: 13 through 18, all six.
Part E: 20 Open Items & Risks.
Appendices: A Glossary, B Compliance Mapping.

Fourteen of twenty-two blocks. That is the reason this extension overrides the
template rather than adapting to it.

## The three behavioural divergences, and why

**Guessing.** Stock: "Make informed guesses. Use context, industry standards,
and common patterns to fill gaps." Here: never for a fact. A retention period
invented from industry standard reads identically to one a records officer
stated, and only one of them survives a review. Structure may be defaulted, facts
may not.

**Removing sections.** Stock: "When a section doesn't apply, remove it entirely
(don't leave as N/A)." Here: keep the heading and its callout, add a short italic
reason. A removed section is indistinguishable from a section nobody thought
about.

**NFR placement.** Stock has no non-functional requirements section, so an
availability target can only be filed as `SC-00n`. That turns a requirement with
an owner into a metric with neither an owner nor a test. Sections 7 and 19 are
separate here for exactly that reason.

## Mechanics preserved unchanged

Frontmatter contract. `$ARGUMENTS` handling. `before_specify` and
`after_specify` hook protocol, including `enabled` and `condition` handling, the
dot-to-hyphen command naming, and `EXECUTE_COMMAND` emission.
`SPECIFY_FEATURE_DIRECTORY` resolution order with `feature_numbering`
(`timestamp` / `sequential`) and the `branch_numbering` deprecation warning.
`.specify/feature.json` persistence. `constitution.md` loading. The
quality-checklist loop capped at 3 iterations. Max 3 clarifications, prioritised
scope > security/privacy > user experience > technical detail, presented as an
options table. Completion report fields. `Done When`.

Downstream commands are unaffected: `/speckit-clarify` and `/speckit-plan` read
`spec.md` from the feature directory as before.
