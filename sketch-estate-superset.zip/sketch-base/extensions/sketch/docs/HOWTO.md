# How to use sketch

Full documentation for all three commands. If you have not installed it yet, see
[INSTALL.md](../INSTALL.md).

- [The idea in one page](#the-idea-in-one-page)
- [Before your first run](#before-your-first-run)
- [Walkthrough: first interview to signed-off spec](#walkthrough-first-interview-to-signed-off-spec)
- [Command reference: specify](#command-reference-specify)
- [Command reference: clarify](#command-reference-clarify)
- [Depths and tracks](#depths-and-tracks)
- [Working with the question catalog](#working-with-the-question-catalog)
- [Word and Markdown](#word-and-markdown)
- [Reading the resolution JSON](#reading-the-resolution-json)
- [Troubleshooting](#troubleshooting)
- [FAQ](#faq)

---

## The idea in one page

Three claims, and everything else follows from them.

**A requirement document is an interview record, not a prompt expansion.** Stock
`/speckit.specify` grows a sentence you typed into a spec. sketch starts from
a transcript of a conversation that actually happened with the business, so every
figure in the document traces to something somebody said.

**Depth is a ladder, not a setting you pick once.** Every use case starts with the
same one-hour interview and a Lightweight document. Only work that needs more
climbs to Standard, then Exhaustive, and each rung extends the document the rung
below produced rather than restarting it.

**Questions are authored and reviewed in advance, not generated.** The interview
question catalog is a fixed, versioned file. A reviewer can read all 186
Exhaustive questions before a single interview happens and confirm the process
asks what governance requires. `clarify` may only ask from that file.

The last one is the difference from stock `/speckit.clarify`, which invents its
questions at runtime from an ambiguity taxonomy. Both approaches are reasonable;
only one is auditable in advance.

---

### A note on the slash form you will actually type

Every example below writes the command as `/speckit.sketch.specify`, its
canonical dotted name. What you actually type depends on your agent. Claude
Code and Copilot in skills mode fold the dots into hyphens, so you will type
`/speckit-sketch-specify`. Copilot's legacy mode keeps the dots as written. If
autocomplete does not find the dotted form, try the hyphenated one; see
[INSTALL.md](../INSTALL.md#github-copilot-needs-one-decision-first-which-of-its-two-modes)
for which mode you are on.

## Before your first run

You need a transcript. Anything readable as text: a Teams transcript export,
meeting notes, a pasted email thread. It does not need cleaning up first.

If the interview happened in Teams, `prompts/teams/` ships the three saved
structuring prompts the Copilot-in-Recap workflow runs on: one for the first
Lightweight interview and one for each extension. Paste the prompt for your
rung into the Recap Copilot pane, then save Copilot's output as the
transcript input here. Each prompt carries the NO ANSWER IN TRANSCRIPT rule,
so a section the conversation never covered comes back marked rather than
invented.

What the transcript should cover for a Lightweight run, roughly the first hour of
a conversation:

- How the work is done today, and what goes wrong
- Where the new thing helps, and whether plain rules would do instead
- The data: what it is, where it comes from, which system is authoritative
- Volume and rhythm: how much, how often
- What comes out, and where it lands
- The four assumption checks: delivery surface, accuracy expectation, human
  review path, test data

Gaps are fine. Missing answers become visible rows in the document's Interview
Coverage Gaps section rather than invented values, which is the point.

---

## Walkthrough: first interview to signed-off spec

### 1. First interview, Lightweight

```
/speckit.sketch.specify -l -raw ./notes/first-interview.txt -raw ./notes/sponsor-email.txt
```

The agent resolves arguments, reads every raw input, decides the track, and
authors the document. You get:

```
specs/003-10k-field-extraction/
├── spec.docx                    the document of record, in house styling
├── spec.md                      Markdown companion for the toolchain
└── checklists/requirements.md   quality checklist, unticked
```

The completion report tells you the track it chose and why, the question count
resolved out of the depth total, how many sections carry a gap, and up to three
follow-up questions.

Expect gaps at this tier. A Lightweight document with visible gaps is the correct
first-pass output, not a failure.

### 2. An independent read, before questions

```
/speckit.sketch.independent-read
```

No depth flag and no edits: the command paraphrases every requirement and
scenario in isolation, diffs each paraphrase against the document, and logs
confident misreads, text that reads cleanly but supports two interpretations,
to `reviews/independent-read-<date>.md`. It catches what clarify cannot:
clarify notices what it is itself unsure about, not what it confidently
misread.

The findings file becomes a second source of questions for the next step,
alongside the catalog bank.

### 3. Check it against the catalog

```
/speckit.sketch.clarify -l
```

No `-spec` needed: it finds the active feature spec. It scores all 45 Lightweight
questions against the document, queues the highest-impact gaps, and asks up to
five, one at a time:

```
**Q-015-02** (Section 15, Confidence & Human Review) [L]

What happens to a field the system is not confident about?

**Recommended:** Option B - Routing low-confidence fields to a review queue
matches the human-in-the-loop expectation already stated in Section 2, and
avoids silently publishing a value nobody checked.

| Option | Description |
|--------|-------------|
| A | Publish it with the confidence score attached |
| B | Route it to a review queue for an analyst to confirm |
| C | Reject the whole document and require manual keying |
| Short | Provide a different short answer (<=5 words) |

You can reply with the option letter (e.g., "A"), accept the recommendation by
saying "yes" or "recommended", or provide your own short answer.
```

Reply `yes` to take the recommendation, `B` to pick one, or type your own short
answer. Each answer is written into the spec **immediately**, into the section the
question belongs to, plus a line under `## Clarifications`. Stopping halfway
still leaves the answers you gave durably saved.

Say `done`, `stop` or `proceed` to end early.

### 4. Extend to Standard after a follow-up session

```
/speckit.sketch.specify -s -raw ./notes/followup.txt -spec ./specs/003-10k-field-extraction/spec.docx
```

The existing document is the baseline, not a draft to rewrite. Every answered
field carries forward. Where the new raw inputs contradict it, the newer answer
wins and the change is recorded in Document Control. The old Coverage Gaps table
is the agenda for the new session: each row either resolves and disappears, or
survives with what still blocks it.

Standard adds the `Traces to` column, so every requirement cites a scenario, and
a detail block per scenario.

### 5. Check against the deeper set

```
/speckit.sketch.clarify -s
```

Now scoring against 125 questions rather than 45. The 80 newly in scope are the
`[S]` tier.

### 6. Exhaustive, when it is regulated

```
/speckit.sketch.specify -e -raw ./notes/mon.txt -raw ./notes/wed.txt -raw ./notes/fri.txt -spec ./specs/003-10k-field-extraction/spec.docx
/speckit.sketch.clarify -e
```

### 7. Verify the findings closed

```
/speckit.sketch.independent-read --verify
```

Re-paraphrases only the items flagged in the latest findings file against
their post-clarify text, and marks each resolved or failed. Closure, not
motion: a section that was edited but still supports two readings is failed.
While any failure survives, the spec is not ready to plan.

### 8. Hand off
```
/speckit.plan
```

Downstream Spec Kit commands read `spec.md` from the feature directory exactly as
they would for any spec.

---

## Command reference: specify

```
/speckit.sketch.specify (-l | -s | -e) -raw <path> [-raw <path> ...] [-spec <path>]
```

| Flag | Required | Meaning |
|------|----------|---------|
| `-l`, `--lightweight` | one of three | First interview, about 1 hour |
| `-s`, `--standard` | one of three | Production planning, about 1 day |
| `-e`, `--exhaustive` | one of three | Regulated work, 3 days to 1 week |
| `-raw <path>` | yes, repeatable | Raw input: meeting notes, a transcript, an existing requirement document, an email export |
| `-spec <path>` | no | Existing spec to extend, `.docx` or `.md` |

Repeat `-raw` to combine several sources: `-raw notes.txt -raw old-req.docx`.
The agent reads every input; where two conflict, the most recent dated
document wins and the conflict is recorded in Document Control.

Paths may be absolute, relative to the working directory, or start with `~`.
A path that does not resolve is an error, never a silent fallback.

### Modes

| `-spec` | Mode | Behaviour |
|---------|------|-----------|
| absent | `create` | Author a new spec against the depth-graded template |
| present | `enhance` | Treat the given spec as the baseline and extend it |

### Outputs

| Mode | Input | Writes |
|------|-------|--------|
| `create` | n/a | `spec.docx` **and** `spec.md` |
| `enhance` | `.docx` | `spec.docx` **and** `spec.md` |
| `enhance` | `.md` | `spec.md` only |

When both are written, the `.docx` is authored first and the Markdown generated
from it, so the two cannot drift.

### Running the resolver directly

Useful for checking what a command would do without running the agent:

```bash
.specify/extensions/sketch/scripts/bash/sketch-specify.sh \
  -l -raw ./notes/interview.txt
```

```
sketch-specify resolution
  mode              create
  depth             Lightweight
  track             NOT SET: agent reads transcript (hint: unknown)
                    generic -> 14 sections, 34 questions
                    ai      -> 20 sections, 45 questions, gated: 16
  transcript        /path/notes/interview.txt
  spec in           <none, authoring from scratch>
  writes            spec.docx + spec.md
  out dir           /path
  pandoc            available
```

---

## Command reference: clarify

```
/speckit.sketch.clarify (-l | -s | -e) [-spec <path>]
```

| Flag | Required | Meaning |
|------|----------|---------|
| `-l`, `-s`, `-e` | one of three | Which question set to check against |
| `-spec <path>` | no | Spec to clarify, `.md` only |

Omit `-spec` and it finds the spec itself, in this order:

1. `.specify/scripts/bash/check-prerequisites.sh`, if the project has it
2. `.specify/feature.json`
3. The most recently modified `specs/*/spec.md`

The route taken is reported as `spec_source`.

### What it does

1. Reads the track from the spec: Part D present means AI-Extended
2. Loads the catalog question bank for that track and depth
3. Scores every question as Answered, Partial or Missing
4. Queues up to five, prioritising the four assumption checks, then impact
5. Asks them one at a time, each with a recommended answer
6. Writes each answer into the spec immediately
7. Re-validates `checklists/requirements.md` if present
8. Reports coverage by part, and anything worth asking that the catalog lacks

### The ring fence

Every question is cited by catalog id, for example `Q-008-03`. The agent cannot
ask a question that is not in the bank. If it judges something important to be
missing, it reports it under **Outside the catalog** rather than asking it, so
the catalog can be amended and reviewed.

That report is the feedback loop. If the same item shows up across several
sessions, add it to the catalog rather than leaving the agent to work around it.

### Running clarify at a deeper depth than the spec

Legitimate and useful. Running `-s` against a Lightweight document shows exactly
which questions the next tier would add, before you commit to the session that
answers them.

---

## Command reference: independent-read

```
/speckit.sketch.independent-read [-spec <path>] [--verify]
```

### What it does

A Fagan independent read inside the delivery sequence. It paraphrases every
functional requirement, non-functional target and user scenario in isolation,
diffs each paraphrase against the rest of the document, and logs divergences,
double readings, orphans and silent number conflicts to
`<spec_dir>/reviews/independent-read-<date>.md`, one stable id (`IR-1`,
`IR-2`, ...) per finding.

Two rules define it: read-only (the spec changes only through clarify), and
isolation (each item is paraphrased from its own text before any cross-section
comparison, because context is how misreads get rationalised away).

A first read with no findings writes the file with `Status: CLEAN`: the
absence of findings is evidence a gate reviewer looks for.

### The verify pass

`--verify` runs after clarify and re-paraphrases only the flagged items
against their current text. Each finding is marked resolved or failed in the
same file; the file's status becomes VERIFIED or FAILED. Any surviving failure
means the spec goes back to clarify, not forward to plan. With no earlier
findings file, the resolver exits 9.

### What it is not

Not a gap checker (that is clarify, against the catalog), not a style pass,
and not a second opinion on facts the interview never covered. It catches one
thing: text that reads cleanly and means two things.

---

## Depths and tracks

### Depths

| Depth | Timebox | Purpose | Generic | AI |
|-------|---------|---------|---------|-----|
| Lightweight | ~1 hour | Estimate, or a proof-of-concept decision | 34 | 45 |
| Standard | ~1 day | Production planning, once prioritised | 92 | 125 |
| Exhaustive | 3 days to 1 week | Regulated, client-facing, defensible estimate | 122 | 186 |

Cumulative: Standard asks every `[L]` and `[S]` question; Exhaustive asks all
three markers.

Only Section 16, Provenance & Lineage, is depth-gated, and only on the AI track
at Lightweight, where the template carries its own not-interrogated note.

### Tracks

| | Generic | AI-Extended |
|---|---|---|
| Part A Context | 1-2 | 1-2 |
| Part B Behaviour | 3-6 | 3-6 |
| Part C Quality & Constraints | 7-12 | 7-12 |
| Part D AI Governance | none | 13-18 |
| Part E Closure | 19-20 | 19-20 |
| Appendices | A, B | A, B |
| **Sections** | **14** | **20** |

Parts A, B, C and E are identical, so a spec can move between tracks without
rewriting anything.

### Neither command takes a track flag

`specify` decides from the transcript. Evidence for AI-Extended: a model doing
the work, an accuracy or confidence target, a human review step that exists
because output may be wrong, test data with known answers, prompts or retrieval.
Evidence for generic: deterministic rules, thresholds, joins, aggregation,
reporting, where the same input always gives the same output.

**Ambiguity resolves to AI-Extended.** Part D answered "not applicable, this is
deterministic" is a recorded decision. A generic document has nowhere to record
that Part D was ever considered, and that absence is what a reviewer cannot
recover later.

`clarify` reads the track from the spec instead, and handles the case where Part
D exists but Section 13 disclaims it: it flags `ai_disclaimed_hint`, the agent
confirms by reading Section 13, and drops the `[AI]` questions.

### AI questions are not only in Part D

Of the 64 `[AI]` questions, 40 are in Sections 13 to 18. The other 24 are spread
across Sections 5, 6, 7, 8, 10, 11, 12, 19 and 20. The track decision changes the
question set across the whole document, which is why it is a finding rather than
a flag you assert before reading anything.

---

## Working with the question catalog

The catalog ships in both `.docx` (for reviewers) and `.md` (for tooling):

```
questions/generic/Generic_Requirement_Interview_Questions_Catalog.{docx,md}
questions/ai/AI_Requirement_Interview_Questions_Catalog.{docx,md}
```

### Reading the bank for a given depth and track

```bash
python3 .specify/extensions/sketch/scripts/lib/parse_catalog.py \
  .specify/extensions/sketch/questions/ai/AI_Requirement_Interview_Questions_Catalog.md \
  --depth standard --track ai --format text
```

```
Q-001-01  [L]  S1 Purpose & Current State
    Why does this work exist? What problem is being solved?
Q-001-02  [L]  S1 Purpose & Current State
    Before we talk about the change: how is this done today? Walk me through the
    current process and what it produces.
...
125 of 186 catalog questions in scope (ai track, standard depth)
```

`--format json` gives the machine-readable form the agent consumes, with `id`,
`part`, `section`, `section_name`, `marker`, `ai` and `text` per question.

### Question ids

`Q-<section>-<sequence>`, so `Q-008-03` is the third question in Section 8. Ids
are stable as long as the catalog's question order within a section does not
change. Inserting a question mid-section renumbers the ones after it, so add new
questions at the end of their section if you care about id stability across
versions.

### Amending the catalog

The catalog is a plain Markdown file with a strict line format:

```markdown
## 8. Security, Privacy & Compliance

- **[S]** Who may access this, and how is that entitlement managed?
- **[E]** `[AI]` What threat assumptions apply to the model itself?
```

Marker in `**[L]**` / `**[S]**` / `**[E]**`, then optionally `` `[AI]` ``, then
the question. After editing, re-run the self-test: it checks the parsed counts
against the published figures, so a malformed line shows up immediately.

Keep the `.docx` in step with the `.md`. They are the same content in two forms,
and reviewers will read the `.docx`.

---

## Word and Markdown

**Markdown is authored first; Word is converted from it.** This is the one
direction that works. A `.docx` is a ZIP archive of XML, so an agent writing text
into a file with that extension produces something Word refuses to open with a
"file is corrupt" error. The agent writes `spec.md`, then:

```bash
.specify/extensions/sketch/scripts/bash/md-to-docx.sh \
  spec.md spec.docx \
  --reference .specify/extensions/sketch/templates/ai/AI_Template_Lightweight.docx
```

`--reference` is what keeps the house look: pandoc takes fonts, heading styles,
table styles and colours from the template and the content from your Markdown.
Without it you get pandoc's defaults and the document stops matching the others.
Always pass the template for the track and depth actually in use.

The converter checks its own output is a readable archive with the required
parts, and exits 8 rather than leaving a file that fails to open.

### The reverse direction

`docx-to-md.sh` converts an existing Word spec to Markdown, used when extending
a `.docx` baseline:

```bash
.specify/extensions/sketch/scripts/bash/docx-to-md.sh spec.docx spec.md
```

It uses `-t gfm` rather than `-t markdown` on purpose: plain `-t markdown` emits
grid tables (rows of dashes) for the wide tables in these templates, which match
neither the shipped references nor GitHub's renderer. It also strips the bold
wrapper Word leaves inside heading text. Pass `--writer markdown` if a
pandoc-native toolchain downstream needs that form.

Editing a `.docx` in place is never attempted. Extending one means converting to
Markdown, editing, and converting back.

### clarify edits Markdown only

Pointed at a `.docx` it exits 5, offering the companion if one exists. If a
`spec.docx` sits beside the `spec.md` it edits, it reports that Word file as
**stale**, because converting Markdown back to `.docx` would lose the template
styling. Re-apply the clarifications by running:

```
/speckit.sketch.specify -s -raw <the same raw inputs> -spec ./specs/003-x/spec.docx
```

or by hand. This is a real limitation, stated rather than hidden.

---

## Reading the resolution JSON

Both commands accept `--json` on their resolver, and both skills consume that
output rather than deriving paths themselves. Useful when debugging.

```bash
.specify/extensions/sketch/scripts/bash/sketch-clarify.sh -s --json | python3 -m json.tool
```

Fields worth knowing:

| Field | Command | Meaning |
|-------|---------|---------|
| `mode` | specify | `create` or `enhance` |
| `tracks` | specify | Both tracks resolved; agent picks after deciding |
| `track_hint` | specify | `ai` / `generic` in enhance mode, `unknown` in create |
| `write_docx`, `write_md` | specify | The output plan, decided here not by the agent |
| `track`, `track_name` | clarify | Read from the spec |
| `ai_sections_present` | clarify | Part D found in the spec |
| `ai_disclaimed_hint` | clarify | Part D present but Section 13 looks like a No |
| `questions_in_scope` | clarify | Size of the question bank at this depth and track |
| `question_bank` | clarify | The bank itself, the ring fence |
| `stale_docx` | clarify | A `.docx` that will be behind after editing |
| `checklist` | clarify | Quality checklist to re-validate, or null |

---

## Troubleshooting

### Exit codes

| Code | Meaning | Fix |
|------|---------|-----|
| 1 | Usage: unknown flag, flag missing its value, or `-ai` | `-ai` was removed; the track is determined, not asserted |
| 2 | Depth: none, several, or repeated | Pass exactly one of `-l`, `-s`, `-e` |
| 3 | Input: no transcript (specify), no spec found (clarify) | Check the path, or pass `-spec` explicitly |
| 4 | `-spec` path does not resolve | Absolute or relative both work; the file must be readable |
| 5 | Format: not `.docx`/`.md` (specify), not `.md` (clarify) | Convert first, or point at the companion |
| 6 | A reference file is missing from the extension | Re-install; the copy is incomplete |
| 7 | A `.docx` is needed but pandoc is absent | Install pandoc, or work Markdown-only |
| 8 | Conversion failed or produced an empty file | From the converter; check the input `.docx` opens |

### Common situations

**"No unanswered catalog questions worth clarifying."** The spec answers
everything at that depth. Try the next depth up to see what it would add.

**Clarify asks about something already answered.** The answer is probably present
but vague: a target with no figure, an owner unnamed. That scores Partial, which
is deliberate. If it is genuinely answered clearly, that is worth reporting.

**Track came out wrong.** For `specify`, the completion report states the
evidence it used; if that evidence is thin, say so and re-run. For `clarify`, the
track follows the spec's structure, so fix the spec rather than the flag.

**The `.docx` and `.md` disagree.** Clarify edits Markdown only. Re-run specify
with `-spec <the .docx>` to bring Word back in step.

**Word says the file is corrupt or has errors.** The `.docx` was written
directly instead of converted. Check the agent ran `md-to-docx.sh`; a valid
`.docx` opens as a ZIP archive:

```bash
python3 -c "import zipfile; zipfile.ZipFile('spec.docx'); print('valid')"
```

If that raises `BadZipFile`, delete the file and re-run. The `spec.md` beside it
is unaffected and holds the content, so nothing is lost.

**Everything errors with exit 6.** Assets missing. Most often a copy that passed
through something which mangled the `.docx` files. Re-extract from the zip.

---

## FAQ

**Can I use this alongside stock `/speckit.specify`?**
Yes. They are separate commands with separate names. Nothing is overridden.

**Can I run stock `/speckit.clarify` on a sketch spec?**
Yes, and it will work: it applies its own 10-category taxonomy and generates its
own questions. You lose the ring fence, so use it when you want fresh eyes rather
than catalog coverage.

**Why is there no `-ai` flag any more?**
Because whether Part D applies is discoverable from the source material, and
asserting it wrongly silently drops 24 AI questions from sections outside Part D
that nobody would think to check.

**Can I add my own questions?**
Yes, edit the catalog and re-run the self-test. See
[Amending the catalog](#amending-the-catalog).

**Does clarify ever invent a question?**
No. It cites a catalog id for every question. Anything it judges missing goes in
the report under "Outside the catalog" instead of being asked.

**What if the interview never happened, and I only have a description?**
Write the description to a file and pass it as the transcript. The gaps will be
large and honestly recorded, which is the right outcome: the document will show
how much was never discussed.

**How do I know which version is installed?**
`specify extension info sketch`, or read `extension.yml`.
