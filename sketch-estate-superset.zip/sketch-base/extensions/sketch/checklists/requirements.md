# Specification Quality Checklist: [FEATURE NAME]

**Purpose**: Validate specification completeness and quality before proceeding to planning
**Created**: [DATE]
**Feature**: [Link to spec.md]
**Track / Depth**: [Generic | AI-Extended] / [Lightweight | Standard | Exhaustive]

## Content Quality

- [ ] No implementation detail (languages, frameworks, product names) appears in the specification
- [ ] Focused on user value and business need
- [ ] Written for business stakeholders, not developers
- [ ] Every section of the template is present, in template order, none renamed or removed
- [ ] Sections that do not apply keep their heading with a short italic reason, never "N/A"

## Requirement Completeness

- [ ] Every requirement is in EARS form and testable pass or fail
- [ ] From Standard depth: every requirement carries a Traces to entry, and every scenario is served by a requirement
- [ ] Acceptance criteria are measurable and each names the FR-n or NFR-n it proves
- [ ] Non-functional targets sit in Section 7 with an owner, not collapsed into acceptance criteria
- [ ] Every number in the document comes from the transcript or the baseline spec
- [ ] No vague adjective survives unquantified; each is either given a figure or logged in Review findings
- [ ] Scope is bounded: what is delivered, and what is deferred or rejected with a reason
- [ ] Dependencies and constraints identified

## Coverage Honesty

- [ ] Interview Coverage Gaps block complete, with its callout, legend and tables intact
- [ ] Every unanswered question at this depth appears as a gap row, or in Not relevant with a real reason
- [ ] The four assumption checks are resolved or each logged as its own gap row
- [ ] Nothing was invented to fill a gap
- [ ] Depth and Applicability records the count actually resolved

## Feature Readiness

- [ ] User scenarios cover the primary flows, including at least one failure path
- [ ] AI track only: Part D complete for this depth, with Section 16 handled per the depth rule
- [ ] Appendix B maps each applicable control to the section that satisfies it, without restating control text
- [ ] The template's own Review & Acceptance Checklist is left unticked for the gate owner

## Notes

- Items marked incomplete require spec updates before `/speckit-clarify` or `/speckit-plan`
- Gaps are expected at Lightweight. At Exhaustive, state plainly whether any remaining gap would stop a reviewer signing.
