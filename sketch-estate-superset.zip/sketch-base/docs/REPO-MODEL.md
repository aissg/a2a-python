# The repository model

Why this is one repository per bundle, and what that means when you add the
next one.

---

## The rule

**One repository per bundle.** The bundle manifest sits at the root; the
extensions and presets that only that bundle uses live inside it.

```
sketch-base/                          platform/sketch-fullstack/
├── bundle.yml                        ├── bundle.yml
├── extensions/                       ├── extensions/
│   └── sketch/                       │   ├── skt-fullstack/
├── presets/                          │   ├── skt-api/
│   ├── sketch-constitution/          │   └── skt-testing/
│   └── sketch-plan/                  │
└── .gitlab-ci.yml                    └── .gitlab-ci.yml
```

Each is a separate GitLab project: its own branches, tags, pipeline, issues and
permissions.

## What this replaced, and why

The first design was one repository for the whole estate, with subfolder
ownership via CODEOWNERS. It does not survive contact with fifteen divisions.

**Branch and merge request volume.** Hundreds of contributors on one project
means most merge requests are irrelevant to any given reader. Finding the three
that affect you means filtering out ninety that do not, every day.

**Unrelated version churn.** A git tag is repository-wide. Tagging a fix in one
division moves the version of everything else, or forces a tag-naming
convention every pipeline then has to parse and filter.

**Subfolder ownership is approval routing, not isolation.** CODEOWNERS decides
who approves a path, which is genuinely useful. It does not give a team its own
branch namespace, its own pipeline, its own release cadence or its own clone.
Those come from the project boundary, and nothing below the project boundary
substitutes for them.

Isolation has to be structural. "Please only touch your own folders" fails at
the first urgent fix at 6pm.

## Where an extension lives

| Situation | Home |
|-----------|------|
| Used by one bundle | Inside that bundle's repository, under `extensions/` |
| Used by several bundles | A shared repository, pinned by others through the catalog |

The second case is the exception, not the default. Start an extension inside
the bundle that needs it. Promote it when a second bundle genuinely needs it,
which is a real signal rather than a prediction.

### Promoted does not mean one repo each

A shared extension moves to a **shared** repository, not to a repository of its
own. The repo boundary follows **ownership and release cadence**, never artifact
count.

Six platform-team utilities therefore share `platform/sketch-shared`:

```
platform/sketch-shared/
├── extensions/
│   ├── skt-pdfx/          each keeps its own version in its own manifest
│   ├── skt-docconv/
│   ├── skt-uml/
│   ├── skt-graph/
│   ├── skt-datasci/
│   └── skt-mlops/
└── .gitlab-ci.yml         one pipeline, one tag, six assets
```

`skt-threat` sits in `platform/sketch-security` instead, and that split is
justified by ownership: `@sketch/ai-security` owns it, not the platform team.

One repo per extension would be the fragmentation this whole model exists to
avoid: six repositories, six pipelines, six READMEs, six release processes, all
maintained by one team, for six small components that always ship together.

### How several components release from one repo

The same way `sketch-base` ships `extension.zip` and one `preset-<name>.zip` per
preset from a single tag, and the same way the Spec2Cloud community extension ships three assets from
one release.

Each component keeps its own version in its own manifest. The repository tag is
a **release train**, not a shared version: it is named for the highest component
version in the release, and each component is published as its own asset at its
own version. The catalog pins each independently, so a bundle depending on
`skt-pdfx 1.2.0` is unaffected when `skt-uml` moves to `2.0.0`.

In `bundle.yml`:

```yaml
components:
  # lives here: source names the path, versions move together by construction
  - { type: extension, id: sketch, version: "0.3.0", source: "extensions/sketch" }

  # lives elsewhere: pinned by version, resolved through the catalog
  - { type: extension, id: skt-pdfx, version: "1.4.0" }
```

## Composing, never forking

When two bundles need the same capability, both pin it. Neither copies it.

A fix ships once from the owning repository, and every bundle picks it up on
its next version bump. The alternative is the same fix applied in four places,
three of them eventually wrong, and nobody knowing which three.

## What stays central

One repository, small and stable: **sketch-catalog**.

```
sketch-catalog/
├── catalog.schema.yml     the contract
├── catalog.yml            GENERATED aggregate the CLI reads
├── catalog.d/             one fragment per division
├── ci/                    reusable pipeline templates
└── CODEOWNERS             routes each fragment to its division
```

It holds no extensions and no bundles. It holds the contract: the schema, the
CI templates every other repository includes, and the id registry that stops
two divisions claiming one name.

This is the only repository where a merge request from one division is visible
to another, and each division owns exactly one file in it.

## Adding a bundle

1. Create a project: `platform/sketch-<name>` or
   `domains/<division>/sketch-<name>`.
2. `bundle.yml` at the root, `extensions/` beside it.
3. `.gitlab-ci.yml` including the shared template from `sketch-catalog`.
4. Grant the owning team Maintainer on the project.
5. Open a merge request adding the bundle to your division's catalog fragment.

Steps 1 to 4 need no central involvement. Step 5 is reviewed by your division's
leads, not by the platform team.

## Ownership, concretely

| Level | Who | Role |
|-------|-----|------|
| `platform/` subgroup | Platform team | Maintainer |
| `domains/<division>/` subgroup | That division's leads | Maintainer |
| Each bundle project | The owning team | Maintainer, inherited |
| `sketch-catalog` project | Division leads | Developer, **direct invite** |

The direct invite matters: `@group` approval rules count direct members only,
so a lead who is only a member of a nested subgroup does not satisfy a rule
naming the parent, and every catalog merge request stalls waiting for an
approval that cannot arrive.
