# Releasing sketch-base

A release is a tag on a reviewed commit. Nothing is released from a laptop.

**This is not a PyPI package.** Only the `specify` CLI is distributed through
PyPI. A bundle release is an archive at a stable URL, which is what the
pipeline produces.

---

## The four steps

```bash
# 1. bump versions together, in the same commit
#    bundle.yml                              bundle.version
#    extensions/sketch/extension.yml         extension.version   (if it changed)
#    presets/sketch-constitution/preset.yml  preset.version      (if it changed)
#    presets/sketch-plan/preset.yml          preset.version      (if it changed)
#    bundle.yml components[].version         to match

# 2. merge through a reviewed merge request

# 3. tag the merged commit
git tag spec-kit-sketch-v0.3.0 && git push origin spec-kit-sketch-v0.3.0

# 4. open a merge request against sketch-catalog bumping sketch-base
```

Step 4 is the one people forget. Publishing makes the archive **fetchable**.
The catalog makes it **discoverable**. Until the fragment merges,
`specify bundle install sketch-base` still resolves to the previous version.
CI prints this reminder on every tag.

## Why the versions move together

The bundle pins its components at exact versions, and for components living in
this repository the pin and the component's own manifest must agree. CI fails
the build otherwise.

That is the benefit of one repo per bundle: the two cannot drift. In a shared
repository, a bundle can pin a version of an extension that was tagged in a
different commit, and the mismatch is only discovered when someone installs it.

## What the pipeline does

| Stage | Job | Runs on | Checks |
|-------|-----|---------|--------|
| validate | `manifests` | every push | Bundle, extension and preset agree; commands are `speckit.sketch.*`; every referenced file exists |
| validate | `tag-matches-manifest` | tags | Tag and `bundle.version` agree |
| test | `selftest` | every push | The extension's 87 assertions |
| test | `house-style` | every push | Advisory, never blocks |
| release | `publish` | `v*` tags | Builds the archive, uploads to the Package Registry |
| verify | `verify-published` | `v*` tags | Downloads it back, confirms `bundle.yml` and the extension manifest are inside |

`verify-published` exists because a release nobody can download is not a
release, and the failure is otherwise found by the first person to install it.

## Versioning

SemVer, exact, no ranges anywhere.

| Change | Bump |
|--------|------|
| A command removed, or its arguments change incompatibly | major |
| A command added, or behaviour extended compatibly | minor |
| Fix with no interface change | patch |

Below `1.0.0`, treat minor as the breaking bump. That is the convention in use:
this bundle went `0.1.0` to `0.3.0` across two interface changes.

**Any component version moving is at least a minor bundle bump.** The
combination changed, so the thing being shipped changed. A bundle version
identifies a tested combination, not a date.

## Where releases land

The pipeline creates a **GitLab Release** with three assets, matching the
layout the Spec2Cloud community extension uses:

| Asset | Extract into |
|---|---|
| `extension.zip` | `.specify/extensions/sketch/` |
| `preset-constitution.zip` | `.specify/presets/sketch-constitution/` |
| `preset-plan.zip` | `.specify/presets/sketch-plan/` |
| `bundle.zip` | the whole bundle, the normal install |

Each zip holds the files **inside** its component folder, not the folder
itself. That is what `specify ... --from` expects, and CI fails the build if a
manifest is not at the archive root.

Permanent URLs, the same shape for every release:

```
<project>/-/releases/spec-kit-sketch-v0.3.0/downloads/bundle.zip
<project>/-/releases/permalink/latest/downloads/bundle.zip
```

The second is a moving pointer to the newest release, so documentation does not
need editing on every version. Install directly, bypassing the catalog, which
is useful for testing a release candidate:

```bash
specify bundle install sketch-base --from <that URL>
```

Not the supported path for developers: they install by name from the catalog.

> **Verify once before relying on this.** Every documented `--from` example
> upstream uses a GitHub URL. It is almost certainly agnostic, since it fetches
> a zip over HTTP, but GitLab-shaped URLs are not shown in the upstream docs.
> Test it once and confirm.

New to GitLab? [GITLAB-STEP-BY-STEP.md](GITLAB-STEP-BY-STEP.md) walks the whole
thing from an empty project to a working install.

## Troubleshooting

**`tag-matches-manifest` fails.** The tag and `bundle.version` disagree. Delete
the tag, fix the manifest, tag again:
`git tag -d spec-kit-sketch-v0.3.0 && git push origin :refs/tags/spec-kit-sketch-v0.3.0`.

**`manifests` says a component version does not match.** `bundle.yml` pins a
version that the component's own manifest does not declare. Bump both in the
same commit.

**`publish` returns 401 or 403.** `CI_JOB_TOKEN` lacks Package Registry write,
or the registry is disabled. Settings, then General, then Visibility.

**Selftest fails on pandoc.** The extension writes `.docx`, so the test image
needs pandoc. It is installed in `before_script`; check that step ran.
