# How to use Sketch

For developers, business analysts and architects who want to use what the
catalog provides. If you are authoring an extension instead, see
the catalog repository's authoring guide.

- [Setup, once per machine](#setup-once-per-machine)
- [Install a bundle](#install-a-bundle)
- [The three base commands](#the-three-base-commands)
- [A full worked run](#a-full-worked-run)
- [Depths and tracks](#depths-and-tracks)
- [Claude Code and GitHub Copilot](#claude-code-and-github-copilot)
- [Troubleshooting](#troubleshooting)

---

## Setup, once per machine

```bash
# 1. the CLI itself (this is the only PyPI package involved)
uv tool install specify-cli        # or: pip install specify-cli

# 2. point at the bank's catalog rather than the public one
export SPECKIT_CATALOG_URL="https://<gitlab-pages-host>/catalog.yml"
```

Put the export in your shell profile, or let whatever provisions your developer
environment set it. Ask the platform team for the current URL.

Also needed: `python3` on PATH always, and `pandoc` only if you will produce
Word documents.

## Install a bundle

```bash
cd /path/to/your/project
specify init                          # if not already a Spec Kit project
specify bundle install sketch-base
```

Browse what is available first:

```bash
specify bundle list                   # bundles in the catalog
specify extension list                # what this project has installed
```

**Install bundles, not extensions.** `specify extension add` works, but it is
reserved for extension authors working in incubation. Bundles pin exact
versions; installing extensions individually means nothing guarantees the
combination you end up with was ever tested together.

## The three base commands

Every bundle includes the `sketch` base, so these are always available.

| Command | Purpose |
|---------|---------|
| `/speckit.sketch.specify` | Author a spec from raw inputs, or extend an existing one |
| `/speckit.sketch.independent-read` | Paraphrase and diff the spec, catching confident misreads |
| `/speckit.sketch.clarify` | Ask up to five catalog questions to close gaps |

### specify

```
/speckit.sketch.specify (-l | -s | -e) -input <path> [-spec <path>]
```

- exactly one depth: `-l` Lightweight, `-s` Standard, `-e` Exhaustive
- `-input` is required: a transcript, meeting notes, or an existing document
- `-spec` is optional: with it, the existing spec is extended rather than
  replaced

No `-ai` flag. Whether the AI governance sections apply is read from the source
material, not asserted by you. Ambiguity resolves toward including them,
because a section marked "not applicable, this is deterministic" is a recorded
decision, whereas a spec without the section has nowhere to record that the
question was ever asked.

### independent-read

```
/speckit.sketch.independent-read [-spec <path>] [--verify]
```

Reads the spec and writes nothing to it. It paraphrases each requirement in
isolation and diffs the paraphrase against the original, which surfaces text
that is clear to two readers and means different things to each. Run it
**before** clarify: clarify only notices what it is itself uncertain about,
which is a narrower net than an independent restatement.

`--verify` re-reads only the findings logged by the first pass and marks each
resolved or failed. Run it after clarify, before planning.

### clarify

```
/speckit.sketch.clarify (-l | -s | -e) [-spec <path>]
```

Scores every catalog question at that depth against the spec, queues the
highest-impact gaps, and asks at most five, one at a time, each with a
recommended answer you can accept by replying `yes`.

Each answer is written into the spec immediately, into the section the question
belongs to. Stopping halfway still leaves everything you answered saved.

**It cannot invent a question.** Every question is cited by a catalog id such
as `Q-008-03`, drawn from a versioned file. If it judges something important to
be missing from the catalog, it reports that under "Outside the catalog" rather
than asking it, which is the feedback loop that keeps the catalog honest.

## A full worked run

```bash
# 1. after the first interview, an hour of conversation
/speckit.sketch.specify -l -input ./notes/first-interview.txt

# 2. read it independently before answering any questions
/speckit.sketch.independent-read

# 3. close the gaps the Lightweight question set cares about
/speckit.sketch.clarify -l

# 4. confirm the findings from step 2 actually closed
/speckit.sketch.independent-read --verify

# 5. after a follow-up session, extend to Standard
/speckit.sketch.specify -s -input ./notes/followup.txt -spec ./specs/003-x/spec.docx
/speckit.sketch.clarify -s

# 6. hand off to the rest of Spec Kit
/speckit.plan
```

Steps 2 and 4 are the ones people skip. They are also where the defects that
survive into implementation are caught, because a confident misread produces no
uncertainty for clarify to detect.

## Depths and tracks

| Depth | Timebox | Purpose | Generic | AI-Extended |
|-------|---------|---------|---------|-------------|
| Lightweight | ~1 hour | Estimate or proof-of-concept decision | 34 | 45 |
| Standard | ~1 day | Production planning, once prioritised | 92 | 125 |
| Exhaustive | 3 days to 1 week | Regulated, client-facing, defensible | 122 | 186 |

Cumulative: Standard asks every Lightweight question plus its own.

Start Lightweight always. Extend only if the work needs it. Each depth extends
the document the one below produced rather than restarting it.

The AI-Extended track adds Part D (Sections 13 to 18, AI governance). Worth
knowing: of the 64 AI-specific questions, only 40 are in Part D. The other 24
sit in Sections 5, 6, 7, 8, 10, 11, 12, 19 and 20, so the track decision
changes the question set across the whole document.

## Claude Code and GitHub Copilot

Both are supported, and both read the same command files.

| Agent | Skills go to | You type |
|-------|-------------|----------|
| Claude Code | `.claude/skills/` | `/speckit-sketch-specify` |
| Copilot, skills mode | `.github/skills/` | `/speckit-sketch-specify` |
| Copilot, legacy default | `.github/agents/` + `.github/prompts/` | `/speckit.sketch.specify` |

Skills-based agents hyphenate every dot in the command name. Copilot's legacy
mode keeps the dots. If autocomplete does not find one form, try the other.

Copilot defaults to legacy mode unless the project was initialised with
`--integration-options="--skills"`. Legacy is deprecated upstream; prefer skills
mode on a fresh setup.

## Troubleshooting

**`specify bundle install` cannot find the bundle.**
Check `SPECKIT_CATALOG_URL` is set and reachable: `curl "$SPECKIT_CATALOG_URL"`.
Without it the CLI reads the public catalog, which has none of this.

**The command does not appear in my agent.**
Restart the agent; skills are loaded at startup. Then check the right directory
from the table above actually contains the skill folder.

**Installed a bundle but the commands do nothing useful.**
Check the bundle's status. Most bundles here are `status: planned`: their pins
resolve and CI passes, but the components have no runnable commands yet. Only
`sketch-base` is installable today. The bundle's README says so at the
top.

**Exit 7 from specify.**
`pandoc` is not on PATH and the run needs to write a `.docx`. Install pandoc, or
pass `-spec <file>.md` to stay in Markdown.

**Word says the generated `.docx` is corrupt.**
This was a real bug, fixed in sketch 0.2.0. Confirm you are on 0.3.0 or later:
`specify extension list`. A valid `.docx` opens as a zip archive:
`python3 -c "import zipfile; zipfile.ZipFile('spec.docx'); print('valid')"`.
Your `spec.md` holds the same content and is unaffected either way.

**Clarify says "no unanswered catalog questions".**
The spec answers everything at that depth. Try the next depth up to see what it
would add.

**Permission prompts on every command in Claude Code.**
The commands shell out to resolver scripts. Choose "always allow" when prompted,
or add the script paths to `.claude/settings.json` under `permissions.allow`.
Do not reach for `--dangerously-skip-permissions`.
