# GitLab, step by step

Written for someone who has not set up a GitLab project before. Follow it in
order and you will end with a working release that a colleague can install with
one command.

Roughly 45 minutes the first time. Every step says what to click, what to
expect, and how to tell it worked.

- [Step 0. What you need](#step-0-what-you-need)
- [Step 1. Create the project](#step-1-create-the-project)
- [Step 2. Push the code](#step-2-push-the-code)
- [Step 3. Watch the first pipeline](#step-3-watch-the-first-pipeline)
- [Step 4. Turn on the Package Registry](#step-4-turn-on-the-package-registry)
- [Step 5. Protect the release tags](#step-5-protect-the-release-tags)
- [Step 6. Cut your first release](#step-6-cut-your-first-release)
- [Step 7. Install what you released](#step-7-install-what-you-released)
- [Step 8. Publish the catalog site](#step-8-publish-the-catalog-site)
- [Understanding the pipeline file](#understanding-the-pipeline-file)
- [When something goes wrong](#when-something-goes-wrong)

---

## Step 0. What you need

| Thing | How to check | If missing |
|---|---|---|
| A GitLab account with permission to create projects | Sign in, look for **New project** | Ask your GitLab administrator |
| Git on your machine | `git --version` | Install Git |
| GitLab Runners available | Any project, **Settings > CI/CD > Runners** | Ask your administrator; without runners no pipeline runs |

**Runners are the one thing you cannot work around.** A runner is the machine
that executes your pipeline. On gitlab.com shared runners are usually on by
default. On a self-managed instance someone has to provide them. If the Runners
page shows none available, stop and sort that out first, because every step
after this depends on it.

---

## Step 1. Create the project

1. Top left, select **+**, then **New project/repository**.
2. Choose **Create blank project**.
3. Fill in:
   - **Project name**: `sketch-base`
   - **Project URL**: pick the group it belongs in, for example `platform`
   - **Visibility**: Private, unless your organization says otherwise
4. **Untick "Initialize repository with a README".** You are pushing existing
   code, and an initial commit here makes step 2 awkward.
5. Select **Create project**.

You land on an empty project page showing push instructions. Leave that tab
open; you need the URL from it.

---

## Step 2. Push the code

Unzip `sketch-base.zip`, then from inside the `sketch-base` folder:

```bash
cd sketch-base
git init
git add .
git commit -m "Sketch Base 0.3.0"
git branch -M main
git remote add origin https://gitlab.example.com/platform/sketch-base.git
git push -u origin main
```

Replace the remote URL with the one GitLab showed you in step 1.

**What you should see:** the push completes, and refreshing the project page
shows your files.

If it asks for a password and rejects your account password, GitLab wants a
token, not a password. **Right sidebar > Edit profile > Access tokens**, create
one with the `write_repository` scope, and use that token as the password.

---

## Step 3. Watch the first pipeline

Pushing triggers a pipeline automatically, because the repository contains a
`.gitlab-ci.yml` file. Go to **Build > Pipelines**.

You should see one pipeline with these jobs:

| Job | What it checks |
|---|---|
| `manifests` | The bundle, extension and preset agree with each other |
| `selftest` | The extension's 87 assertions |
| `house-style` | Writing conventions; advisory, never blocks |

Select the pipeline to watch, then select any job to see its log.

**Expect green.** If `selftest` fails, read its log: the failing assertion is
named. If the whole pipeline shows "pending" forever, you have no runner, so go
back to step 0.

**What did not run:** the `package`, `release` and `verify` jobs. They only run
on a tag, which is step 6. Seeing them absent here is correct.

---

## Step 4. Turn on the Package Registry

The release assets are stored in the project's Package Registry, so it has to
be enabled.

1. **Settings > General**
2. Expand **Visibility, project features, permissions**
3. Find **Packages** and make sure it is **on**
4. **Save changes**

**How to tell it worked:** the left sidebar now shows **Deploy > Package
Registry**. It is empty for now.

Skip this and step 6 fails with a `403 Forbidden` that reads as a permissions
problem when it is really a disabled feature.

---

## Step 5. Protect the release tags

The tag is what triggers a release, so it should not be something anyone can
push by accident.

1. **Settings > Repository**
2. Expand **Protected tags**
3. **Tag**: type `spec-kit-sketch-v*` and select the "Create wildcard" option
4. **Allowed to create**: Maintainers
5. Select **Protect**

Do the same for the branch if it is not already done: **Protected branches**,
`main`, allowed to merge Maintainers, allowed to push No one.

**Why this matters:** without it, a tag pushed from anyone's laptop publishes a
release. With it, only Maintainers can, and only through a reviewed commit.

---

## Step 6. Cut your first release

This is the moment everything else was setting up.

```bash
# make sure you are on the commit you want to release
git checkout main
git pull

# the tag must exactly match bundle.yml's version, prefixed
git tag spec-kit-sketch-v0.3.0
git push origin spec-kit-sketch-v0.3.0
```

The tag format is `spec-kit-sketch-v<version>`, matching the convention the
Spec2Cloud community extension uses. The pipeline refuses a tag whose version
disagrees with `bundle.yml`, so if you mistype it you get a clear error rather
than a wrong release.

Go to **Build > Pipelines**. A new pipeline is running with more jobs than
before:

| Job | What it does |
|---|---|
| `build-assets` | Builds `extension.zip`, one `preset-<name>.zip` per directory under `presets/`, and `bundle.zip`, then checks each has its manifest at the root |
| `upload-assets` | Uploads all three to the Package Registry |
| `create-release` | Creates the GitLab Release and links the assets |
| `verify-release` | Downloads each asset back and confirms it opens |

**How to tell it worked:** go to **Deploy > Releases**. You see
**Sketch Base 0.3.0** with three assets attached.

`verify-release`'s log ends with the exact install command to copy.

### If you need to redo a tag

```bash
git tag -d spec-kit-sketch-v0.3.0
git push origin :refs/tags/spec-kit-sketch-v0.3.0
# fix whatever was wrong, then tag again
```

Deleting a tag does not delete the Release. Remove that under **Deploy >
Releases** if you need a clean retry.

---

## Step 7. Install what you released

This is the payoff, and it is worth doing once so you have seen it work.

```bash
cd /tmp && mkdir install-test && cd install-test
specify init
specify bundle install sketch-base --from \
  https://gitlab.example.com/platform/sketch-base/-/releases/spec-kit-sketch-v0.3.0/downloads/bundle.zip
```

That URL shape is worth understanding, because it is the same shape for every
release you will ever cut:

```
<project URL>/-/releases/<tag>/downloads/<asset name>
```

It is permanent. GitLab redirects it to wherever the asset actually lives, so
it keeps working even if storage moves.

There is also a moving "latest" form, which is what to put in documentation so
you are not editing links on every release:

```
https://gitlab.example.com/platform/sketch-base/-/releases/permalink/latest/downloads/bundle.zip
```

**How to tell it worked:** `specify extension list` shows `sketch`, and your
agent offers `/speckit-sketch-specify`.

---

## Step 8. Publish the catalog site

Do this in the `sketch-catalog` project, after repeating steps 1 to 3 for it.

The catalog pipeline already has a `pages` job. Two rules govern it, and both
are unforgiving:

- the job **must** be named `pages`
- it **must** publish a directory called `public`

Rename either and Pages silently does nothing.

1. Push `sketch-catalog` and let the pipeline run on `main`.
2. Go to **Deploy > Pages**. It shows your site URL, something like
   `https://platform.gitlab.example.com/sketch-catalog/`.
3. Open it. You should see the browsable catalog.

Then tell every developer to point their CLI at it:

```bash
export SPECKIT_CATALOG_URL="https://platform.gitlab.example.com/sketch-catalog/catalog.yml"
```

Put that in whatever provisions developer machines. Once it is set, people
install by name and never touch a URL:

```bash
specify bundle install sketch-base
```

**Note:** on some instances Pages takes a few minutes to appear after the first
deploy, and may require the administrator to have enabled it. If **Deploy >
Pages** is missing entirely, ask your administrator whether Pages is turned on.

---

## Understanding the pipeline file

You do not need this to use the pipeline, but it helps when changing it.

```yaml
stages: [validate, test, package, release, verify]
```

Stages run in order. Every job in a stage runs in parallel, and the next stage
waits for the whole previous one.

```yaml
.on_release_tag:
  rules:
    - if: $CI_COMMIT_TAG =~ /^spec-kit-sketch-v\d+\.\d+\.\d+$/
```

A name starting with `.` is a hidden template, not a job. Jobs pull it in with
`extends:`. This one says "only run when the thing being built is a tag shaped
like a release tag", which is why nothing published in step 3.

```yaml
  artifacts:
    paths: ["dist/"]
```

Artifacts pass files from one job to the next. `build-assets` makes the zips,
`upload-assets` needs them, and artifacts are how they travel.

```yaml
  needs: ["upload-assets", "selftest", "tag-matches-manifest"]
```

`needs` makes a job wait for specific jobs rather than a whole stage. Here it
means the release is never created unless the tests passed.

Variables GitLab provides for free, used throughout:

| Variable | What it holds |
|---|---|
| `CI_COMMIT_TAG` | The tag, when the pipeline was triggered by one |
| `CI_PROJECT_URL` | Your project's web URL |
| `CI_API_V4_URL` | The API base, for uploads |
| `CI_JOB_TOKEN` | Short-lived credential; no secret setup needed |
| `CI_PAGES_URL` | Where Pages will serve the site |

`CI_JOB_TOKEN` is why you never configured a password anywhere. GitLab issues
it per job and it expires when the job ends.

---

## When something goes wrong

**Pipeline stuck on "pending" forever.**
No runner is available. **Settings > CI/CD > Runners**. This is the single most
common first-time problem and no amount of YAML fixes it.

**`403 Forbidden` in `upload-assets`.**
The Package Registry is off. Step 4.

**`ERROR: tag ... implies version X, but bundle.version is Y`.**
Exactly what it says. Either the tag or the manifest is wrong. Delete the tag,
fix, retag.

**`create-release` fails with "tag already exists" or similar.**
A Release already exists for that tag. Delete it under **Deploy > Releases**,
then re-run the pipeline from **Build > Pipelines**.

**`verify-release` gets a 404.**
The Release exists but the asset link is wrong. Check that `direct_asset_path`
in `create-release` starts with a `/`. This field was called `filepath` before
GitLab 15.9; if you are on an older instance, rename it.

**The install URL 404s in a browser but works in CI.**
Private project. Either sign in first, or the person installing needs a token.
Expected behaviour, not a bug.

**`selftest` fails on pandoc.**
The job installs pandoc in `before_script`. Check that step ran; a network
policy blocking apt is the usual cause.

**Pages deployed but the URL 404s.**
Wait five minutes. Then confirm the job is named exactly `pages` and publishes
exactly `public`.

**A merge request cannot be approved by the right people.**
CODEOWNERS group approvals count **direct** members only. Someone who inherits
membership from a parent group does not satisfy the rule. Invite the group
directly to the project.

---

## What to do next

1. Repeat steps 1 to 3 for `sketch-catalog`.
2. Do step 8 to get the site and `SPECKIT_CATALOG_URL` live.
3. Add the catalog entry for your release: a merge request against
   `sketch-catalog` bumping the version in `catalog.d/platform.yml`.
4. Tell one colleague to run `specify bundle install sketch-base` and watch it
   work without a URL.

Step 3 is the one people skip. Publishing makes an artifact **fetchable**; the
catalog makes it **discoverable**. Until the catalog entry moves, everyone
installing by name still gets the old version.
