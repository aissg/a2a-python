# Contributing to sketch-base

This repository is Layer 2: it applies to all software development in the
organization. The bar is correspondingly high, and the blast radius of a change
is every project in the bank.

## Before opening a merge request

```bash
bash extensions/sketch/scripts/bash/selftest.sh     # expect 87 passed, 0 failed
```

CI runs the same, plus manifest validation across the bundle, extension and
preset together.

## Does your change belong here

| Change | Where |
|--------|-------|
| Affects every division, workload and role | Here |
| A workload capability | `platform/sketch-<workload>` |
| A division's capability | `domains/<division>/sketch-<bundle>` |
| Still figuring it out | `incubation/<your-team>/` |

The test is whether a team in a division you have never spoken to would want
it. If not, it is not Layer 2.

## House conventions

Enforced or checked, not preferences:

- **Command names are `speckit.sketch.{cmd}`.** Spec Kit rejects anything else.
- **Versions move together.** The bundle pin and the component's own manifest
  must agree; CI fails otherwise.
- **Exact versions.** No ranges in any pin, ever.
- **Facts come from sources.** The extension never invents a value; an absent
  number is a visible gap. Preserve that when changing command behaviour.
- **No em-dashes or en-dashes** in Markdown or YAML. Checked, advisory.

## Adding a command

1. Read `extensions/sketch/commands/specify.md` first: the resolver pattern,
   the exit-code contract, and the hook protocol are all demonstrated there.
2. Add a resolver under `scripts/bash/`. The command body never derives paths
   itself; it runs the resolver and uses the JSON.
3. Extend `scripts/bash/selftest.sh`. Every exit code, every flag combination.
4. Declare it in `extensions/sketch/extension.yml`.
5. Bump the extension version and the bundle pin in the same commit.

## Releasing

See [docs/RELEASING.md](docs/RELEASING.md). Four steps, and the fourth is a
merge request against `sketch-catalog` that people forget.
