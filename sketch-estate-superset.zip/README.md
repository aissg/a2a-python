# Sketch estate: base, catalog, and the first work type

Three repositories, as one snapshot. This is not a repository itself: it is the
three that are, so the changes can be reviewed together before they are split
into three merge requests.

```
sketch-base/                     MODIFIED   Layer 2, bank-wide
sketch-catalog/                  MODIFIED   the contract and the id registry
sketch-langchain-deep-agent/     NEW        Layer 3, the first work type
```

- [What changed](#what-changed)
- [The problem the work type solves](#the-problem-the-work-type-solves)
- [How the pieces meet at plan time](#how-the-pieces-meet-at-plan-time)
- [What was verified](#what-was-verified)
- [What was not verified](#what-was-not-verified)
- [Splitting this into merge requests](#splitting-this-into-merge-requests)

---

## What changed

### sketch-base, 0.3.0 to 0.4.0

Unchanged: the `sketch` extension and its three commands, `specify`, `clarify`
and `independent-read`, at 0.3.0. The interview catalogs, templates, worked
examples and the 87-assertion selftest are all untouched.

Added: **`presets/sketch-plan/`**, a bank-wide plan template. It is Layer 2 by the
same argument the constitution is: it applies to all software development in the
organization, not to one division or work type. Putting it in a work-type bundle
would leave every other team on the stock Spec Kit template, and therefore with no
governance section at all.

| Change | File |
|--------|------|
| New preset | `presets/sketch-plan/` |
| Third component, version bump | `bundle.yml` |
| One asset per preset, derived from the directory | `.gitlab-ci.yml` |
| Asset naming and preset list | `README.md`, `docs/RELEASING.md`, `docs/GITLAB-STEP-BY-STEP.md`, `docs/REPO-MODEL.md` |

**One breaking change to note:** `preset.zip` is now `preset-constitution.zip`,
because there are two presets. Catalog `install_url` entries were updated in the
same change. Tags before 0.4.0 keep their original asset names, so nothing
already released breaks.

The packaging loop derives asset names from the `presets/` directory rather than
naming them, so a third preset needs no pipeline change. Verified by running the
loop: it produces `preset-constitution.zip` and `preset-plan.zip`, each with
`preset.yml` at the root.

### What sketch-plan adds to the stock plan template

Three sections. Each exists because something a Sketch specification **stated**
failed to reach any design artifact when the stock template was run against it:

| Section | The failure it fixes |
|---------|----------------------|
| Governance Context | The AI classification and the stated design principles reached no artifact at all. Phase 1 produces entities, contracts and a run guide, and a classification is none of those, so there was nowhere for it to land |
| Evaluation Design | Evaluation content survived only as run steps inside `quickstart.md`. The decisions behind it, sample size, labelling method, target, promotion gate, were nowhere a reviewer could approve them |
| Spec Coverage | Establishing what had been dropped meant reading every generated artifact by hand. So nobody checked |

Plus two smaller changes. `Technical Context` pre-labels `Language/Version` and
`Testing` as planning decisions, because no section of the Sketch requirement
template can feed them and they are therefore invented on every run of every
feature. `Constitution Check` reports the version and the layers it evaluated.

The stock structure option list is replaced by a single Structure Decision prompt.
A folder tree in a template enforces nothing, and one tree per paradigm is cost
without benefit.

### sketch-catalog

Four edits to `catalog.d/platform.yml`:

| | Entry |
|---|---|
| New preset | `sketch-plan`, L2, alpha |
| New extension | `skt-deepagent`, L3, alpha, `effect: read-write` |
| New bundle | `sketch-langchain-deep-agent`, alpha, four components |
| Edited | `sketch-base` bundle, third component and 0.4.0 |
| Edited | `sketch-constitution` preset, renamed asset URL |

`catalog.yml` was regenerated. `validate_catalog.py` reports 0 errors and 0
warnings across all 16 fragments, so every pin resolves and matches exactly.

### sketch-langchain-deep-agent, new

One bundle, one extension, `skt-deepagent` at 13 characters with the reserved
`skt-` prefix. It pins the base and both bank-wide presets through the catalog
rather than copying them.

## The problem the work type solves

Spec Kit resolves **one file per name** and never merges. It walks the priority
stack, takes the first match, and stops.

That is fine for most things and fatal for two. A constitution cannot be layered
by presets: the bank-wide principles and a work type's principles are both
constitutions, so shipping them as two presets means picking one, and copying the
base into each work type means the same control exists in triplicate and drifts
within a year. A plan template cannot be extended by presets either, and unlike
prose it has an expected section order, so even concatenation would produce two
Technical Contexts and a Structure Decision in the middle of the file.

So the composition happens in a `before_plan` hook instead.

## How the pieces meet at plan time

The ordering comes from the plan command's own instructions: run the
`before_plan` hooks and **wait for the result before proceeding to the Outline**.
Outline step 1 then runs `setup-plan`, which copies `plan-template.md` and
resolves the constitution path. So a hook that writes those two files finishes
before anything reads them.

```
/speckit.sketch.specify -s -input notes.md        sketch-base extension
       │                                          writes specs/<n>/spec.md
       ▼
/speckit.sketch.independent-read                  catches confident misreads
/speckit.sketch.clarify                           closes catalog gaps
       │
       ▼
/speckit.plan                                     stock Spec Kit, unmodified
       │
       ├─ before_plan ── speckit.skt-deepagent.context
       │                   │
       │                   ├─ constitution.base.md      (I to VI, sketch-base)
       │                   │  + constitution.d/10-deep-agent.md  (VII to XVI)
       │                   │  ────────► .specify/memory/constitution.md
       │                   │
       │                   └─ plan-template.base.md     (sketch-plan, slots empty)
       │                      + plan.d/*.md into SKETCH-SLOT markers
       │                      ────────► .specify/templates/plan-template.md
       │
       ├─ setup-plan      copies the composed template into specs/<n>/plan.md
       ├─ Constitution Check gate, against all 16 principles
       └─ Phase 0 research, Phase 1 design
```

Nothing in Spec Kit is modified. The plan command stays stock, `setup-plan` stays
stock, and an upgrade costs nothing.

**Idempotency** comes from pristine `.base.md` snapshots. The hook runs on every
plan run, so naive appending would compound; instead every run rebuilds from the
snapshot and overwrites the output. Four consecutive runs give a byte-identical
file. If a snapshot is deleted, the composer recovers it by stripping its own
marker block rather than baking a merged file in as the new base.

## What was verified

Everything below was run, not reasoned about.

| Check | Result |
|-------|--------|
| `sketch-base` manifests job | OK, 3 components, 3 commands |
| `sketch-base` selftest | 87 passed, 0 failed |
| `sketch-base` house-style job | OK |
| Preset packaging loop | `preset-constitution.zip`, `preset-plan.zip`, both with `preset.yml` at root |
| `validate_catalog.py` | 16 fragments, 0 errors, 0 warnings |
| `build_catalog.py` | Aggregate regenerated, every new pin resolves |
| `skt-deepagent` manifests job | OK, 4 components, 1 command, 1 hook |
| `skt-deepagent` selftest | 39 passed, 0 failed |
| House style across all three repos | No em-dash or en-dash anywhere |

The 39 deep agent assertions cover the full composition path, idempotency across
four runs, principle ordering staying contiguous with the base `## Governance`
section last, a layer edit reaching the next run, snapshot recovery, both degraded
paths (no bank-wide constitution, and the stock plan template in place, each
warning and proceeding rather than failing), `--check` writing nothing, and the
house style rule.

End to end with the real base constitution and the real plan template: 2
constitution layers merged into 19 sections, 4 plan slots filled, a 410-line
composed plan template.

## What was not verified

Four things, each cheap to check, each failing visibly rather than silently. Full
detail in
[`sketch-langchain-deep-agent/docs/VERIFY.md`](sketch-langchain-deep-agent/docs/VERIFY.md).

1. **The `hooks.before_plan` entry shape in `extension.yml`.** Field names are
   inferred from how `templates/commands/plan.md` consumes
   `.specify/extensions.yml`. Run `specify extension add --dev .` and read the
   generated file. If wrong, the hook never runs.
2. **The `provides.templates` type value in `sketch-plan`.** `sketch-constitution`
   uses `type: memory`; `type: template` is the analogous value for a file under
   `templates/`, but it is inferred. If wrong, the template is not installed and
   the composer warns.
3. **Where `setup-plan` reads the plan template from.** The composer writes to
   `.specify/templates/plan-template.md`, where a preset installs it. **Check this
   one first:** it is the only failure that looks like success in the hook output.
   Run a plan and grep the generated `plan.md` for "Harness configuration".
4. **The PowerShell composer.** Mirrors the bash logic and was not executed, since
   the build environment has no PowerShell.

## Splitting this into merge requests

Three, in this order, because the catalog invariants require every pin to resolve.

**1. `sketch-base`** Add the preset, the bundle component, the CI change and the
doc updates. Tag `spec-kit-sketch-v0.4.0`. Confirm both preset assets appear on
the Release before moving on.

**2. `sketch-langchain-deep-agent`** New project under
`platform/bundles/`. Grant the owning team Maintainer. Tag
`spec-kit-sketch-deepagent-v0.1.0`.

**3. `sketch-catalog`** All four fragment edits in one merge request against
`catalog.d/platform.yml`. Reviewed by division leads, not the platform team.
`catalog.yml` is generated, so let CI rebuild it rather than committing the copy
here.

Doing the catalog first would fail validation: the pins would name a release that
does not exist yet.

**Before any of it**, verify item 3 above. It is the assumption the whole
mechanism rests on, and it takes one plan run to settle.
