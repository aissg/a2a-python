# LangChain Deep Agent, the harness and what it means for governance

Research behind the constitution layer. Every principle in
`constitution.d/10-deep-agent.md` names a configuration argument or a middleware,
and this file records what those are and where the facts came from.

## What the harness provides

Deep Agents is an opinionated framework on LangChain and LangGraph. The
capabilities below are middleware you configure rather than behaviour you
implement, which is the fact the whole constitution layer rests on: a bespoke
loop over model calls has no configuration surface to inspect.

| Middleware | Provides |
|------------|----------|
| Todo list | Task planning, breaking work into steps |
| Filesystem | Context management with pluggable backends |
| Subagents | Delegation through a task tool |
| Store | Persistence across threads |
| Human-in-the-loop | Approval workflows for sensitive operations |
| Skills | On-demand loading of specialised capabilities |
| Rubric | Self-evaluated iteration |

## The configuration surface

`create_deep_agent()` takes, in the Python form:

```python
agent = create_deep_agent(
    name="my-assistant",
    model="...",
    tools=[...],
    system_prompt="...",
    subagents=[research_agent, code_agent],
    backend=FilesystemBackend(root_dir=".", virtual_mode=True),
    interrupt_on={"write_file": True},
    skills=["./skills/"],
    checkpointer=MemorySaver(),
    store=InMemoryStore(),
)
```

Each argument maps to a principle:

| Argument | Principle | Why it is governed |
|----------|-----------|--------------------|
| `backend` | VIII | Determines what the agent can reach and whether it persists |
| `interrupt_on` | IX | The only mechanism that stops an unattended write |
| `checkpointer` | X | Without it a run cannot be replayed or defended |
| `store` | X | Cross-thread persistence, so a residency and namespace question |
| `skills` | XI | Determines which instruction set actually runs |
| `subagents` | XV | Each is a second agent with its own capabilities |

## Backends, and the one that is prohibited

| Backend | Character |
|---------|-----------|
| `StateBackend` | Files in agent state, ephemeral |
| `FilesystemBackend` | Real filesystem, `virtual_mode` confines it |
| `StoreBackend` | Durable, namespaced, survives the thread |
| `CompositeBackend` | Routes different paths to different backends |
| `LocalShellBackend` | Unrestricted local shell execution |

`LocalShellBackend` is prohibited outright in principle VIII. There is no
argument that scopes it, so there is nothing to review: either the agent can run
arbitrary shell commands or it cannot.

`CompositeBackend` routing is worth stating in the plan because a route is a data
boundary. The documented namespacing pattern routes `/skills/` to a
`StoreBackend` whose namespace is derived from the assistant id and the user
identity, which is how independent per-tenant skill libraries are built. A
namespace expression that widens is a data boundary that widens.

## Skills: the two facts that drive principle XI

A skill is a directory:

```
skills/
└── my-skill/
    ├── SKILL.md        required: YAML frontmatter plus markdown instructions
    ├── helper.py       optional supporting files
    └── templates/
```

Frontmatter carries `name` (lowercase alphanumeric and hyphens, capped at 64
characters), `description`, and optionally `license`, per the Agent Skills
specification. Sources are passed as bare paths or `(path, label)` tuples, and
the middleware reads them through the backend rather than the filesystem
directly, which is what makes them portable across backends.

**Fact one: later sources override earlier ones.** Skills load in source order.
So the order of the `skills` list determines which instruction set actually runs
when two sources define the same skill name. Two deployments with the same skill
list in a different order are two different agents, and neither the skill files
nor the agent code shows it. This is why principle XI requires the order to be
recorded in the plan.

**Fact two: progressive disclosure defers bodies, not metadata.** The middleware
injects skill metadata into the system prompt and loads the full body on demand.
That is a real token saving, and it is also why every skill's `description` is in
context on every run whether or not it is used. The inventory is therefore a
bounded resource with a per-run cost, rather than a folder anyone may add to. The
plan fragment asks for the count and the metadata cost for that reason.

Both facts also make the skill path the least obvious injection route in the
system, which is the specific reason principle XIV names skill bodies alongside
retrieved documents and tool output.

## Human-in-the-loop

`interrupt_on={"write_file": True}` is the approval mechanism. It is a
configuration argument, which means conformance to principle IX is checkable: for
every tool with a write or external side-effect class, is it in the dictionary.

That is the difference between this and a system prompt instructing the model to
ask before writing. The second is a request the model may decline.

## Subagents

Subagents receive their own tools and, optionally, their own skill sets. A
general-purpose subagent inherits skills from the parent when `skills` is passed
to `create_deep_agent`. Since inheritance is the default and narrowing is
explicit, principle XV requires the plan to state which applies: an unstated
subagent capability is a second agent nobody reviewed.

## Rubric middleware is not evaluation

`RubricMiddleware` performs self-evaluated iteration: the agent scores its own
output and revises. That is a useful quality mechanism and it is not evidence. A
model scoring itself does not substitute for a labelled set, which is why
principle XVI says so explicitly rather than leaving it for someone to argue.

## Sources

- LangChain Deep Agents documentation, skills page
- `deepagents` Python API reference: `middleware/skills`, backends
- `langchain-ai/langchain-skills`, the `deep-agents-core` skill covering harness
  setup and the SKILL.md format
- `langchain-ai/deepagents` repository wiki, skills system

Retrieved August 2026. The framework is moving quickly, so re-check the backend
list and the `create_deep_agent` signature before each release of this layer.
Two things in particular would need a principle change: a new backend class, and
any change to skill source override semantics.
