# Verify before releasing

Four things in this bundle are inferred from documentation and command text
rather than confirmed against a running Spec Kit. Each is cheap to check and
each fails visibly rather than silently.

## 1. The hooks entry shape in extension.yml

**Inferred from**: how `templates/commands/plan.md` consumes
`.specify/extensions.yml`. It reads `extension`, `command`, `description`,
`prompt`, `optional`, `enabled` and `condition` from each hook entry, so the
manifest uses those names.

**Check**:

```bash
cd /path/to/a/test/project
specify extension add --dev /path/to/extensions/skt-deepagent
cat .specify/extensions.yml
```

Confirm an entry exists under `hooks.before_plan` naming
`speckit.skt-deepagent.context`. If the field names differ, correct
`extension.yml` to match.

**If wrong**: the hook never runs, so `constitution.md` keeps only principles I
to VI and the plan template keeps empty slots. Visible on the first plan run.

## 2. The provides.templates type value in sketch-plan

**Inferred from**: `sketch-constitution` uses `type: memory` for
`memory/constitution.md`, so `type: template` is the analogous value for a file
under `templates/`.

**Check**: install the preset and confirm the file lands at
`.specify/templates/plan-template.md`.

**If wrong**: the template is not installed, the composer warns "no plan template
found", and the plan uses the stock template.

## 3. Where setup-plan reads the plan template from

**Assumed**: `.specify/templates/plan-template.md`, which is where a preset
installs it, and therefore where the composer writes.

**Check**:

```bash
cat .specify/scripts/powershell/setup-plan.ps1     # or bash/setup-plan.sh
```

Look for the path it copies from. If it resolves through a separate override
directory, change `TPL_OUT` in both composer variants to that path and keep
`TPL_BASE` where the preset installs.

**If wrong**: the composer runs, reports slots filled, and the plan uses a
different file. This is the one failure mode that looks like success in the hook
output, so check it before anything else. A quick confirmation: run a plan and
grep the generated `specs/<feature>/plan.md` for "Harness configuration".

## 4. The PowerShell composer

**Not executed**: no PowerShell in the build environment. The logic mirrors the
bash variant, including the snapshot discipline, the Governance insertion point
and the JSON shape.

**Check**:

```powershell
.specify\extensions\skt-deepagent\scripts\powershell\deep-agent-context.ps1
# run it three times, then confirm one marker pair:
Select-String -Path .specify\memory\constitution.md -Pattern 'SKETCH-LAYER-BEGIN' | Measure-Object
```

Expect exactly one match. The bash selftest covers the same assertion, so port
the interesting cases if the two ever diverge.

## Also worth confirming

**sketch-base CI needs a second preset asset.** The pipeline hardcodes
`presets/sketch-constitution` into `preset.zip`. Adding `sketch-plan` means a
second asset. See `docs/CI-PATCH.md` in the base additions.

**Catalog registration.** Three new entries go into
`catalog.d/platform.yml`: the `sketch-plan` preset, the `skt-deepagent`
extension, and the `sketch-langchain-deep-agent` bundle. The catalog invariants
require every bundle component to exist as an entry and every pin to match
exactly, so `validate_catalog.py` will catch an omission.
