# skt-deepagent

**Sketch Deep Agent** · Layer L3 · `status: alpha` · v0.1.0

The work-type extension for LangChain Deep Agent applications. One command,
invoked by a `before_plan` hook rather than by hand.

For the full explanation of the mechanism, see the
[bundle README](../../README.md). In short:

- `constitution.d/10-deep-agent.md` holds principles VII to XVI. The composer
  merges them with the bank-wide base into the single file the plan command reads,
  because Spec Kit resolves one file per name and never merges.
- `plan.d/*.md` hold the plan sections. The composer fills the `SKETCH-SLOT`
  markers in the Sketch plan template.
- Both run in a `before_plan` hook, which the plan command waits for before
  `setup-plan` copies the template. That ordering is what makes this work without
  forking anything.

## Contents

| Path | Role |
|------|------|
| `commands/deep-agent-context.md` | The hook command. Runs the composer, reports the result |
| `constitution.d/10-deep-agent.md` | Principles VII to XVI |
| `plan.d/10-governance.md` | Harness configuration, skills inventory, interrupt policy |
| `plan.d/20-evaluation.md` | Task-level and adversarial evaluation |
| `plan.d/30-bounds.md` | Bounds and subagents |
| `plan.d/40-structure.md` | Starting layout |
| `scripts/bash/deep-agent-context.sh` | The composer |
| `scripts/bash/selftest.sh` | 39 assertions |
| `scripts/powershell/deep-agent-context.ps1` | PowerShell variant |

## Run it by hand

Useful when diagnosing, and the fastest way to see what it does:

```bash
scripts/bash/deep-agent-context.sh            # compose
scripts/bash/deep-agent-context.sh --check    # report, write nothing
scripts/bash/deep-agent-context.sh --json     # machine-readable
```

## Development

```bash
specify extension add --dev /path/to/skt-deepagent
bash scripts/bash/selftest.sh
```

The selftest builds throwaway projects, so it needs `git` and `python3` and
touches nothing outside a temporary directory.
