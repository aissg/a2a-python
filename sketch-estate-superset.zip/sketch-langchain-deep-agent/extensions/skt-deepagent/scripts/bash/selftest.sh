#!/usr/bin/env bash
# Selftest for skt-deepagent. Builds throwaway projects that mimic a real
# install and asserts what the composer produces.
#
# Run from anywhere:  bash extensions/skt-deepagent/scripts/bash/selftest.sh
# Exits non-zero on the first failed assertion.

set -uo pipefail

EXT_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

PASS=0
FAIL=0

ok()   { PASS=$((PASS+1)); printf '  ok    %s\n' "$1"; }
bad()  { FAIL=$((FAIL+1)); printf '  FAIL  %s\n' "$1"; }
check(){ if eval "$2"; then ok "$1"; else bad "$1"; fi; }

# Build a project that looks like one where the bundle has been installed.
#   $1  destination
#   $2  "with-base" or "no-base"        bank-wide constitution present
#   $3  "sketch-plan" or "stock-plan"   which plan template is installed
make_project() {
  local dest="$1" base_mode="$2" plan_mode="$3"
  mkdir -p "$dest/.specify/memory" "$dest/.specify/templates" \
           "$dest/.specify/extensions/skt-deepagent"
  ( cd "$dest" && git init -q . )
  cp -r "$EXT_SRC/." "$dest/.specify/extensions/skt-deepagent/"

  if [[ "$base_mode" == "with-base" ]]; then
    cat > "$dest/.specify/memory/constitution.md" <<'MD'
# Engineering constitution

## I. Specification before implementation

Body.

## VI. Regulated work carries its evidence

Body.

## Governance

Amendment procedure.
MD
  fi

  if [[ "$plan_mode" == "sketch-plan" ]]; then
    cat > "$dest/.specify/templates/plan-template.md" <<'MD'
# Implementation Plan: [FEATURE]

## Governance Context

**AI classification**: [value]

<!-- SKETCH-SLOT: governance -->

## Evaluation Design

**Labelled sample**: [value]

<!-- SKETCH-SLOT: evaluation -->

## Technical Context

**Language/Version**: [PLANNING DECISION]

<!-- SKETCH-SLOT: technical-context -->

## Project Structure

**Structure Decision**: [value]

<!-- SKETCH-SLOT: structure -->

## Spec Coverage

<!-- SKETCH-SLOT: coverage -->
MD
  else
    printf '# Implementation Plan: [FEATURE]\n\n## Technical Context\n\n**Language/Version**: [value]\n' \
      > "$dest/.specify/templates/plan-template.md"
  fi
}

run_hook() {
  ( cd "$1" && bash .specify/extensions/skt-deepagent/scripts/bash/deep-agent-context.sh "${@:2}" )
}

echo "skt-deepagent selftest"
echo

# ---------------------------------------------------------------- 1. happy path
echo "1. full install, base constitution and Sketch plan template present"
P="$WORK/full"
make_project "$P" with-base sketch-plan
OUT="$(run_hook "$P" 2>&1)"
C="$P/.specify/memory/constitution.md"
T="$P/.specify/templates/plan-template.md"

check "composer exits zero"                        "[[ -n \"\$OUT\" ]]"
check "constitution.base.md snapshot captured"     "[[ -f '$P/.specify/memory/constitution.base.md' ]]"
check "plan-template.base.md snapshot captured"    "[[ -f '$P/.specify/templates/plan-template.base.md' ]]"
check "reports 2 constitution layers"              "grep -q '2 layer' <<< \"\$OUT\""
check "reports 4 slots filled"                     "grep -q 'slots filled: 4' <<< \"\$OUT\""
check "base principle I survives the merge"        "grep -q 'I. Specification before implementation' '$C'"
check "layer principle VII present"                "grep -q 'VII. Approved harness' '$C'"
check "layer principle XVI present"                "grep -q 'XVI. Task-level evidence' '$C'"
check "LocalShellBackend prohibition present"      "grep -q 'LocalShellBackend' '$C'"
check "harness configuration injected into plan"   "grep -q 'Harness configuration' '$T'"
check "skills inventory injected into plan"        "grep -q 'Skills inventory' '$T'"
check "interrupt policy injected into plan"        "grep -q 'Interrupt policy' '$T'"
check "bounds injected into plan"                  "grep -q 'Recursion limit' '$T'"
check "agent evaluation injected into plan"        "grep -q 'Adversarial cases' '$T'"
check "starting layout injected into plan"         "grep -q 'harness/' '$T'"
check "unmapped slot left intact for future use"   "grep -q 'SKETCH-SLOT: coverage' '$T'"

# Principle numbering must stay contiguous: the layer goes before the base's
# trailing Governance section, not after it.
ORDER="$(grep -o '^## [A-Za-z.IVX]*' "$C" | tr '\n' ' ')"
check "Governance section ends the merged file"    "[[ \"\$(grep '^## ' '$C' | tail -1)\" == '## Governance' ]]"
check "VII follows VI with no section between"     "grep -A1 'VI. Regulated work' '$C' | grep -q 'Approved harness' || grep -q 'VII' '$C'"

# ------------------------------------------------------------- 2. idempotency
echo
echo "2. idempotency across repeated plan runs"
SIZE1="$(wc -c < "$C")"
run_hook "$P" >/dev/null 2>&1
run_hook "$P" >/dev/null 2>&1
run_hook "$P" >/dev/null 2>&1
SIZE4="$(wc -c < "$C")"

check "constitution byte size unchanged after 4 runs" "[[ '$SIZE1' == '$SIZE4' ]]"
check "exactly one layer BEGIN marker"                "[[ \$(grep -cF 'SKETCH-LAYER-BEGIN' '$C') -eq 1 ]]"
check "exactly one layer END marker"                  "[[ \$(grep -cF 'SKETCH-LAYER-END' '$C') -eq 1 ]]"
check "principle VII appears exactly once"            "[[ \$(grep -c 'VII. Approved harness' '$C') -eq 1 ]]"
check "harness section appears exactly once in plan"  "[[ \$(grep -c 'Harness configuration' '$T') -eq 1 ]]"

# ------------------------------------------- 3. layer edit picked up next run
echo
echo "3. a layer edit reaches the next plan run"
echo "" >> "$P/.specify/extensions/skt-deepagent/constitution.d/10-deep-agent.md"
echo "## XVII. Selftest marker" >> "$P/.specify/extensions/skt-deepagent/constitution.d/10-deep-agent.md"
run_hook "$P" >/dev/null 2>&1
check "edited layer content appears in the output"    "grep -q 'XVII. Selftest marker' '$C'"
check "base still present after the edit"             "grep -q 'I. Specification before implementation' '$C'"

# --------------------------------------------- 4. recovery from a lost snapshot
echo
echo "4. recovery when the base snapshot is deleted but the merged file remains"
rm -f "$P/.specify/memory/constitution.base.md"
OUT="$(run_hook "$P" 2>&1)"
check "recovery reported"                             "grep -q 'recovered constitution.base.md' <<< \"\$OUT\""
check "base principle survives recovery"              "grep -q 'I. Specification before implementation' '$C'"
check "layer not duplicated by recovery"              "[[ \$(grep -c 'VII. Approved harness' '$C') -eq 1 ]]"

# ------------------------------------------------- 5. degraded: no base present
echo
echo "5. degraded, no bank-wide constitution installed"
P2="$WORK/nobase"
make_project "$P2" no-base sketch-plan
OUT="$(run_hook "$P2" 2>&1)"
check "warns that the base is missing"                "grep -q 'no bank-wide constitution' <<< \"\$OUT\""
check "layer still written so planning can proceed"   "grep -q 'VII. Approved harness' '$P2/.specify/memory/constitution.md'"

# ---------------------------------------------- 6. degraded: stock plan template
echo
echo "6. degraded, stock Spec Kit plan template in place"
P3="$WORK/stock"
make_project "$P3" with-base stock-plan
OUT="$(run_hook "$P3" 2>&1)"
check "warns that no slot markers were found"         "grep -q 'no SKETCH-SLOT markers' <<< \"\$OUT\""
check "reports zero slots filled"                     "grep -q 'slots filled: 0' <<< \"\$OUT\""
check "constitution still merged regardless"          "grep -q 'VII. Approved harness' '$P3/.specify/memory/constitution.md'"

# --------------------------------------------------------------- 7. json output
echo
echo "7. machine-readable output"
J="$(run_hook "$P" --json 2>/dev/null)"
check "json parses"                                   "python3 -c 'import json,sys; json.loads(sys.argv[1])' \"\$J\""
check "json reports ok true"                          "python3 -c 'import json,sys; sys.exit(0 if json.loads(sys.argv[1])[\"ok\"] else 1)' \"\$J\""
check "json reports 4 slots filled"                   "python3 -c 'import json,sys; sys.exit(0 if json.loads(sys.argv[1])[\"plan_template\"][\"slots_filled\"]==4 else 1)' \"\$J\""
check "json reports 2 constitution layers"            "python3 -c 'import json,sys; sys.exit(0 if json.loads(sys.argv[1])[\"constitution\"][\"layers\"]==2 else 1)' \"\$J\""

# ----------------------------------------------------------- 8. check-only mode
echo
echo "8. check mode writes nothing"
P4="$WORK/checkonly"
make_project "$P4" with-base sketch-plan
BEFORE="$(md5sum "$P4/.specify/templates/plan-template.md" | cut -d' ' -f1)"
run_hook "$P4" --check >/dev/null 2>&1
AFTER="$(md5sum "$P4/.specify/templates/plan-template.md" | cut -d' ' -f1)"
check "plan template untouched in check mode"         "[[ '$BEFORE' == '$AFTER' ]]"

# ------------------------------------------------------------ 9. house style
echo
echo "9. house style, no em-dash or en-dash in shipped markdown"
HITS="$(grep -rlP '\x{2014}|\x{2013}' "$EXT_SRC" --include='*.md' --include='*.yml' 2>/dev/null | wc -l)"
check "no dash characters in shipped files"           "[[ '$HITS' -eq 0 ]]"

echo
echo "-------------------------------------------"
printf 'passed %d, failed %d\n' "$PASS" "$FAIL"
[[ $FAIL -eq 0 ]] || exit 1
