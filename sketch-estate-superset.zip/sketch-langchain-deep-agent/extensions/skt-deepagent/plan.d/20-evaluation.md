### Agent evaluation

<!--
  Injected by the skt-deepagent before_plan hook.

  Agents fail on trajectory rather than on individual calls, so the fields above
  are completed at task level. Step-level numbers may be recorded alongside but
  do not satisfy the promotion gate.
-->

**Task cases**: [count, and the workflows covered]

**Adversarial cases**: [one per tool in `interrupt_on`; name the tool and the attack]

**Injection cases**: [cases where retrieved content, a skill body, or tool output attempts to add a tool, change a bound or redirect a destination, per Principle XIV]

**Trajectory scoring**: [how a run is judged complete and correct, not merely finished]

**Bound cases**: [runs that must terminate on a bound rather than loop, per Principle XII]

**Self-evaluation in use**: [RubricMiddleware configured, or none. Where configured, state that it is a quality mechanism and not part of the promotion evidence]

**Replay basis**: [how a recorded run is reproduced from the checkpointer for review]
