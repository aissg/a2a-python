### Harness configuration

<!--
  Injected by the skt-deepagent before_plan hook.

  One row per argument to create_deep_agent(). The constitution states which
  values are permitted; this states which were chosen. A row left blank is a
  configuration decision nobody made, which for an agent is the same as a
  capability nobody reviewed.
-->

| Argument | Value | Principle |
|---|---|---|
| `model` | [approved endpoint, region] | base, VII |
| `backend` | [StateBackend / FilesystemBackend virtual_mode / StoreBackend / CompositeBackend, with routes] | VIII |
| `checkpointer` | [class, and what keys the run identifier] | X |
| `store` | [class and namespace, or none] | X |
| `interrupt_on` | [tools requiring approval] | IX |
| `skills` | [sources in resolution order] | XI |
| `subagents` | [names, or none] | XV |

**Backend routes**: [every CompositeBackend route, or "single backend, no routes"]

**Store namespace**: [the namespace tuple, and what widens it | no store]

### Skills inventory

<!--
  Skill metadata is loaded into the system prompt for every skill on every run.
  Only the body is deferred. The inventory is therefore a bounded resource, not
  a folder anyone may add to, and its size is a design decision.
-->

| Skill | Source and version | Loaded for | Tools it reaches |
|---|---|---|---|
| [name] | [registry source, version] | [main agent / named subagent] | [tools, or none] |

**Resolution order**: [the source list in order, and what each later source overrides]

**Inventory size**: [count, and the token cost of the always-loaded metadata]

### Interrupt policy

| Tool | Side-effect class | Interrupt | Approving role |
|---|---|---|---|
| [name] | [read / write / external] | [yes / approved-automation entry] | [role, or n/a for read] |

**Where the interrupt surfaces**: [how the approver sees the pending action and decides]
