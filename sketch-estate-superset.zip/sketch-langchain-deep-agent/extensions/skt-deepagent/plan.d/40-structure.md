<!--
  Injected by the skt-deepagent before_plan hook. A starting layout for a Deep
  Agent, not a mandate. Adjust it and record what changed.

  The separation is not stylistic. Each directory below is versioned, reviewed
  or audited differently: skills resolve to registry versions, tools carry a
  declared side-effect class, and the harness holds bounds that must not appear
  as prompt text.
-->

```text
src/
├── harness/          create_deep_agent() call, bounds, interrupt_on, backend wiring
│                     no business logic: this is the configuration surface a
│                     reviewer reads to check Principles VIII to XIII
├── tools/            one module per tool, side-effect class declared
├── subagents/        one per delegated role, own tools and bounds
└── clients/          model endpoint and system-of-record clients

skills/               resolved from the registry, never authored here unversioned
                      the local tree mirrors what the registry provides

eval/
├── cases/            task-level, including adversarial and injection cases
└── harness/          runner and trajectory scoring

tests/
├── tools/            per-tool, no model in the loop
├── harness/          bound enforcement and interrupt routing, stubbed model
└── contract/         tool input and output shapes
```

**The decision the folder names do not show**: where the human approval
interrupt sits in the flow, and what the approver sees when it fires.
