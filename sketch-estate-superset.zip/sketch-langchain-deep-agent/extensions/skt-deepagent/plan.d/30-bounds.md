### Bounds

<!--
  Injected by the skt-deepagent before_plan hook.

  Enforced in configuration. A limit stated in a system prompt is a request the
  model may decline, and does not satisfy Principle XII.
-->

| Bound | Value | Enforced in |
|---|---|---|
| Recursion limit or maximum steps | [n] | [config location] |
| Wall-clock timeout | [duration] | [config location] |
| Token or cost ceiling per run | [value] | [config location] |
| Maximum subagent depth | [n, not above 2] | [config location] |

**On breach**: [what terminates, and where the reason is recorded]

### Subagents

| Subagent | Tools | Interrupts | Skill sources | Bounds |
|---|---|---|---|---|
| [name] | [tools] | [tools requiring approval] | [inherited / narrowed to] | [own, or parent's] |

**Inheritance**: [state explicitly whether subagents inherit the parent's skills, per Principle XV]
