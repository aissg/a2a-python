---
description: "Compose the deep agent constitution layer and inject the deep agent plan sections, before the plan command reads either"
---

# Deep agent plan context

Runs as a `before_plan` hook. The plan command waits for it, then runs
`setup-plan`, which copies `plan-template.md` into the feature folder and reads
`.specify/memory/constitution.md`. Both of those files are what this command
produces, which is why it has to finish first.

Nothing here is interpretive. The work is done by a script, and this command
runs it and reports the result.

## User Input

```text
$ARGUMENTS
```

Consider it if not empty, but note that this command takes no arguments of its
own. Guidance for the planning phase belongs on `/speckit.plan` itself.

## Outline

1. **Run the composer** from the repository root. Use the variant matching this
   project's script type, and pass `--json` so the result is parseable:

   - Bash: `.specify/extensions/skt-deepagent/scripts/bash/deep-agent-context.sh --json`
   - PowerShell: `.specify/extensions/skt-deepagent/scripts/powershell/deep-agent-context.ps1 -Json`

   Where only one variant is present, run that one.

2. **Parse the result** and report:
   - the constitution path, the number of layers merged, and the byte size
   - how many plan template slots were filled
   - every entry in `notes` and `warnings`, verbatim

3. **On `ok: false`**, report the error exactly as returned and stop. Do not
   continue to the Outline of the plan command, and do not write either file by
   hand. A constitution assembled by an agent rather than by the composer is a
   ruleset nobody reviewed.

## What it produces

| File | Role |
|------|------|
| `.specify/memory/constitution.md` | Generated. Bank-wide base plus the deep agent layer, the single file the plan command reads |
| `.specify/memory/constitution.base.md` | The pristine bank-wide base, captured on first run |
| `.specify/templates/plan-template.md` | Generated. The Sketch plan template with the deep agent sections composed into its slots |
| `.specify/templates/plan-template.base.md` | The pristine template as the sketch-plan preset installed it |

The two `.base.md` files are the reason repeated plan runs cannot accumulate
duplicated sections: every run rebuilds from them rather than from its own
previous output.

## Key rules

- Never edit `constitution.md` or `plan-template.md` directly. They are
  generated. Edits belong in `constitution.d/10-deep-agent.md` or in `plan.d/`.
- Never edit the `.base.md` snapshots. They mirror what the presets installed.
- Report warnings rather than suppressing them. A missing bank-wide
  constitution means the project is running on the deep agent layer alone,
  without the base principles, and that must be visible in the plan run.
- Where the composer reports zero slots filled, say so. It means the stock
  Spec Kit plan template is in place rather than the Sketch one, so the
  governance and evaluation sections are absent from this plan.

## Done When

- [ ] Composer run and its JSON parsed
- [ ] Constitution layer count, plan slot count, notes and warnings reported
- [ ] Any failure surfaced verbatim, with the plan run stopped
