# Changelog

## 0.1.0

- First release of the LangChain Deep Agent work type
- `skt-deepagent` extension: `before_plan` hook composing the constitution and
  the plan template, bash and PowerShell variants
- Constitution layer: principles VII to XVI, covering harness, backend
  confinement, interrupts, durable state, skill versioning, bounds, tracing,
  injection, subagents and task-level evidence
- Four plan fragments: harness configuration and skills inventory, agent
  evaluation, bounds and subagents, starting layout
- Selftest covering idempotency across repeated runs, principle ordering, and
  the degraded paths where the base constitution or the Sketch plan template is
  absent
