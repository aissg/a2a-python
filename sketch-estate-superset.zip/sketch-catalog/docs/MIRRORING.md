# Mirroring a community extension

How an extension from outside the organization becomes installable inside it,
using [Spec2Cloud](https://github.com/Azure-Samples/Spec2Cloud) as the worked
example.

The rule: **the catalog never points at an external URL.** It points at an
internal mirror that has been scanned and pinned.

---

## Why not just reference upstream

Three reasons, in order of how much they matter.

**Nothing upstream is reviewed.** The community catalog carries an explicit
no-review, no-endorsement disclaimer. An extension executes in a developer's
environment with their credentials.

**Availability.** A repository being renamed, deleted or made private should not
stop anyone provisioning a project.

**Pinning has to be real.** A tag upstream can be moved by force-push. A mirror
you control cannot change under you.

---

## The process

### 1. Mirror the repository at a tag

Create `platform/mirrors/spec2cloud` and import the upstream repo. In GitLab:
**New project > Import project > Repository by URL**.

Then check out the exact tag you intend to ship and nothing else:

```bash
git checkout spec-kit-spec2cloud-v1.1.0
```

Never track a branch. A mirror that auto-updates is not a mirror, it is a live
dependency with extra steps.

### 2. Scan it

Read what the commands actually do, particularly anything that writes files,
calls a network endpoint, or reads credentials. For Spec2Cloud that means the
`deploy` command, which shells out to `azd` and `az` against a live
subscription.

Record the outcome. `verified: false` in the catalog until a human has signed
off; `verified: true` after.

### 3. Republish it internally

The upstream release layout is already what Spec Kit expects:

```
extension.zip   the files inside extensions/spec2cloud/
preset.zip      the files inside presets/spec2cloud/
workflow.yml
```

Republish those same assets as an internal GitLab Release on the mirror
project, using the same tag. The pipeline in `sketch-base` is a working example
of producing exactly this shape; copy its `build-assets`, `upload-assets` and
`create-release` jobs.

### 4. Point the catalog at the mirror

```yaml
spec2cloud:
  version: "1.1.0"
  repo: platform/mirrors/spec2cloud
  layer: L3
  status: alpha
  origin: community          # marks it on the site as a community mirror
  verified: false            # until a human has reviewed it
  upstream_release: "https://github.com/Azure-Samples/Spec2Cloud/releases/download/spec-kit-spec2cloud-v1.1.0/extension.zip"
  install_url: "https://gitlab.example.com/platform/mirrors/spec2cloud/-/releases/spec-kit-spec2cloud-v1.1.0/downloads/extension.zip"
```

`upstream_release` is recorded for provenance. `install_url` is what anyone
actually uses. The site shows a warning on any entry with `origin: community`
telling people to install from the mirror.

### 5. Bundle it

An extension in no bundle cannot be installed by anyone. Add it to one:

```yaml
sketch-azure:
  components:
    - { type: extension, id: sketch, version: "0.3.0" }
    - { type: extension, id: spec2cloud, version: "1.1.0" }
    - { type: preset, id: sketch-constitution, version: "0.1.0" }
```

---

## Updating a mirror

1. Fetch upstream, check out the new tag.
2. Diff it against the tag you currently ship. **Read the diff.** This is the
   step that makes a mirror worth having.
3. Re-scan anything that changed in command behaviour.
4. Cut a new internal release at the new tag.
5. One merge request bumping the catalog entry, and bumping any bundle that
   should adopt it.

A bundle pinning `1.1.0` keeps working on `1.1.0` until someone chooses to move
it. That is the point of pinning.

## Cadence

Review when a bundle needs a newer version, not on a schedule. A mirror nobody
depends on does not need to be current.
