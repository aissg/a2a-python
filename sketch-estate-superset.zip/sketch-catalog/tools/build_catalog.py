#!/usr/bin/env python3
"""
build_catalog.py: aggregate catalog.d/ fragments into the served catalog.

Each division owns one fragment in catalog.d/. This merges them into a single
catalog.yml, which is what SPECKIT_CATALOG_URL points at and what the CLI
actually reads. A domain merge request touches only its own fragment, so
divisions publish independently without a central merge queue.

Validation runs first: an invalid fragment set produces no output at all,
rather than a partially-correct catalog that fails confusingly at install time.

Usage:
    build_catalog.py [--catalog-dir catalog.d] [--out catalog.yml]
                     [--format yaml|json] [--skip-validate]

Exit codes:
    0  catalog written
    1  validation failed, nothing written
    2  could not read inputs or write the output
"""

import argparse
import json
import subprocess
import sys
from datetime import date
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: pyyaml is required. pip install pyyaml", file=sys.stderr)
    sys.exit(2)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    here = Path(__file__).resolve().parent
    root = here.parent
    ap.add_argument("--catalog-dir", default=str(root / "catalog.d"))
    ap.add_argument("--out", default=str(root / "catalog.yml"))
    ap.add_argument("--format", choices=["yaml", "json"], default="yaml")
    ap.add_argument("--skip-validate", action="store_true",
                    help="skip validation; for local inspection only, never in CI")
    args = ap.parse_args()

    catalog_dir = Path(args.catalog_dir)
    if not catalog_dir.is_dir():
        print(f"ERROR: catalog directory not found: {catalog_dir}", file=sys.stderr)
        return 2

    # ------------------------------------------------------------- validate
    if not args.skip_validate:
        validator = here / "validate_catalog.py"
        result = subprocess.run(
            [sys.executable, str(validator),
             "--catalog-dir", str(catalog_dir),
             "--schema", str(root / "catalog.schema.yml")],
            capture_output=True, text=True,
        )
        sys.stdout.write(result.stdout)
        sys.stderr.write(result.stderr)
        if result.returncode != 0:
            print("Validation failed. Catalog not written.", file=sys.stderr)
            return 1

    # ------------------------------------------------------------- aggregate
    fragments = sorted(
        p for p in catalog_dir.glob("*.yml") if not p.name.startswith("_")
    )

    merged = {
        "schema_version": "1.0",
        "catalog": {
            "id": "sketch-org",
            "name": "Sketch: the bank's Spec Kit catalog",
            "updated_at": date.today().isoformat(),
            "generated_by": "platform/catalog/tools/build_catalog.py",
            "source_fragments": [f.name for f in fragments],
        },
        "extensions": {},
        "presets": {},
        "bundles": {},
    }

    for frag in fragments:
        with open(frag, encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        for section in ("extensions", "presets", "bundles"):
            for entry_id, entry in (data.get(section) or {}).items():
                enriched = dict(entry)
                enriched["_fragment"] = frag.name
                merged[section][entry_id] = enriched

    # ------------------------------------------------------------- write
    out = Path(args.out)
    try:
        if args.format == "json":
            out = out.with_suffix(".json")
            out.write_text(json.dumps(merged, indent=2, sort_keys=False) + "\n",
                           encoding="utf-8")
        else:
            header = (
                "# GENERATED FILE, DO NOT EDIT BY HAND.\n"
                "#\n"
                "# Built by platform/catalog/tools/build_catalog.py from the\n"
                "# fragments in catalog.d/. To change an entry, edit your\n"
                "# division's fragment and open a merge request: CODEOWNERS\n"
                "# routes it to your division's leads automatically.\n"
                "#\n"
                "# This file is what SPECKIT_CATALOG_URL serves to the CLI.\n"
                "\n"
            )
            body = yaml.safe_dump(merged, sort_keys=False, allow_unicode=True,
                                  default_flow_style=False, width=100)
            out.write_text(header + body, encoding="utf-8")
    except OSError as exc:
        print(f"ERROR: cannot write {out}: {exc}", file=sys.stderr)
        return 2

    print(f"Wrote {out}")
    print(f"  {len(merged['extensions'])} extension(s)")
    print(f"  {len(merged['presets'])} preset(s)")
    print(f"  {len(merged['bundles'])} bundle(s)")
    print(f"  from {len(fragments)} fragment(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
