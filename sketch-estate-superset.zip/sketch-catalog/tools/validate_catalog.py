#!/usr/bin/env python3
"""
validate_catalog.py: enforce the Sketch catalog contract.

Validates every fragment in catalog.d/ against catalog.schema.yml, then checks
the cross-fragment invariants that no single fragment can check on its own:
unique ids, bundle pins that resolve to real entries at exactly the pinned
version, and reserved-prefix rules.

Runs in CI on every merge request touching the catalog. A fragment that fails
here never reaches the aggregated catalog that developers read.

Usage:
    validate_catalog.py [--catalog-dir catalog.d] [--schema catalog.schema.yml]
                        [--quiet]

Exit codes:
    0  everything valid
    1  one or more errors
    2  could not read the schema or the catalog directory
"""

import argparse
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: pyyaml is required. pip install pyyaml", file=sys.stderr)
    sys.exit(2)


class Findings:
    """Collects errors and warnings, keyed by the fragment they came from."""

    def __init__(self):
        self.errors = []
        self.warnings = []

    def error(self, where, msg):
        self.errors.append((where, msg))

    def warn(self, where, msg):
        self.warnings.append((where, msg))

    def report(self, quiet=False):
        for where, msg in self.warnings:
            print(f"  WARN   {where}: {msg}")
        for where, msg in self.errors:
            print(f"  ERROR  {where}: {msg}")
        if not quiet:
            print()
            print(f"{len(self.errors)} error(s), {len(self.warnings)} warning(s)")
        return 1 if self.errors else 0


def load_yaml(path, findings, where):
    try:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
        if data is None:
            findings.error(where, "file is empty")
            return None
        if not isinstance(data, dict):
            findings.error(where, f"top level must be a mapping, got {type(data).__name__}")
            return None
        return data
    except yaml.YAMLError as exc:
        findings.error(where, f"invalid YAML: {exc}")
        return None
    except OSError as exc:
        findings.error(where, f"cannot read: {exc}")
        return None


def check_entry(kind, entry_id, entry, spec, schema, where, findings):
    """Validate one extension, preset or bundle entry against its shape."""
    if not isinstance(entry, dict):
        findings.error(where, f"{kind} '{entry_id}': entry must be a mapping")
        return

    for field in spec.get("required", []):
        if field not in entry:
            findings.error(where, f"{kind} '{entry_id}': missing required field '{field}'")

    constraints = spec.get("constraints", {})

    if "id_pattern" in constraints and not re.match(constraints["id_pattern"], entry_id):
        findings.error(where, f"{kind} '{entry_id}': id must match {constraints['id_pattern']}")

    if "id_max_length" in constraints and len(entry_id) > constraints["id_max_length"]:
        findings.error(
            where,
            f"{kind} '{entry_id}': id is {len(entry_id)} chars, "
            f"max {constraints['id_max_length']} (ids are typed in every command)",
        )

    version = entry.get("version")
    if version is not None and "version_pattern" in constraints:
        if not re.match(constraints["version_pattern"], str(version)):
            findings.error(
                where,
                f"{kind} '{entry_id}': version '{version}' must be exact SemVer "
                f"(x.y.z), no ranges",
            )

    layer = entry.get("layer")
    if layer is not None and layer not in schema.get("layers", {}):
        findings.error(
            where,
            f"{kind} '{entry_id}': unknown layer '{layer}', "
            f"expected one of {sorted(schema['layers'])}",
        )

    category = entry.get("category")
    if category is not None and category not in schema.get("categories", []):
        findings.error(
            where,
            f"{kind} '{entry_id}': unknown category '{category}', "
            f"expected one of {schema['categories']}",
        )

    status = entry.get("status")
    if status is not None and status not in schema.get("statuses", {}):
        findings.error(
            where,
            f"{kind} '{entry_id}': unknown status '{status}', "
            f"expected one of {sorted(schema['statuses'])}",
        )

    effect = entry.get("effect")
    if effect is not None and effect not in schema.get("effects", {}):
        findings.error(
            where,
            f"{kind} '{entry_id}': unknown effect '{effect}', "
            f"expected one of {sorted(schema['effects'])}",
        )

    # Reserved prefix: skt- is Sketch Layer 3 / Layer X only.
    for prefix in constraints.get("reserved_prefixes", {}):
        if entry_id.startswith(prefix) and layer not in ("L3", "LX"):
            findings.error(
                where,
                f"{kind} '{entry_id}': the '{prefix}' prefix is reserved for "
                f"layer L3 or LX, this entry is {layer}",
            )

    if kind == "bundle":
        components = entry.get("components")
        if not isinstance(components, list) or not components:
            findings.error(where, f"bundle '{entry_id}': components must be a non-empty list")
            return
        valid_types = schema.get("component_types", [])
        for i, comp in enumerate(components):
            if not isinstance(comp, dict):
                findings.error(where, f"bundle '{entry_id}': component {i} must be a mapping")
                continue
            for field in ("type", "id", "version"):
                if field not in comp:
                    findings.error(
                        where, f"bundle '{entry_id}': component {i} missing '{field}'"
                    )
            ctype = comp.get("type")
            if ctype is not None and ctype not in valid_types:
                findings.error(
                    where,
                    f"bundle '{entry_id}': component '{comp.get('id')}' has type "
                    f"'{ctype}', expected one of {valid_types}",
                )
            cver = comp.get("version")
            if cver is not None and not re.match(r"^[0-9]+\.[0-9]+\.[0-9]+$", str(cver)):
                findings.error(
                    where,
                    f"bundle '{entry_id}': component '{comp.get('id')}' version "
                    f"'{cver}' must be an exact pin",
                )


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    here = Path(__file__).resolve().parent.parent
    ap.add_argument("--catalog-dir", default=str(here / "catalog.d"))
    ap.add_argument("--schema", default=str(here / "catalog.schema.yml"))
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    findings = Findings()

    schema_path = Path(args.schema)
    if not schema_path.is_file():
        print(f"ERROR: schema not found: {schema_path}", file=sys.stderr)
        return 2
    schema = load_yaml(schema_path, findings, "catalog.schema.yml")
    if schema is None:
        findings.report(args.quiet)
        return 2

    catalog_dir = Path(args.catalog_dir)
    if not catalog_dir.is_dir():
        print(f"ERROR: catalog directory not found: {catalog_dir}", file=sys.stderr)
        return 2

    fragments = sorted(
        p for p in catalog_dir.glob("*.yml") if not p.name.startswith("_")
    )
    if not fragments:
        print(f"ERROR: no fragments found in {catalog_dir}", file=sys.stderr)
        return 2

    if not args.quiet:
        print(f"Validating {len(fragments)} fragment(s) against {schema_path.name}")
        print()

    # ------------------------------------------------------------ per fragment
    all_extensions = {}
    all_presets = {}
    all_bundles = {}
    origin = {}          # id -> fragment that declared it

    for frag in fragments:
        where = frag.name
        data = load_yaml(frag, findings, where)
        if data is None:
            continue

        for section, store, spec_key in (
            ("extensions", all_extensions, "extension_entry"),
            ("presets", all_presets, "preset_entry"),
            ("bundles", all_bundles, "bundle_entry"),
        ):
            entries = data.get(section) or {}
            if not isinstance(entries, dict):
                findings.error(where, f"'{section}' must be a mapping of id to entry")
                continue
            kind = section[:-1]
            for entry_id, entry in entries.items():
                if entry_id in origin:
                    findings.error(
                        where,
                        f"duplicate id '{entry_id}', already declared in {origin[entry_id]}",
                    )
                    continue
                origin[entry_id] = where
                check_entry(kind, entry_id, entry, schema[spec_key], schema, where, findings)
                store[entry_id] = entry

    # --------------------------------------------------------- cross-fragment
    installable = {**all_extensions, **all_presets}
    bundled_extensions = set()

    for bundle_id, bundle in all_bundles.items():
        where = origin.get(bundle_id, "?")
        components = bundle.get("components")
        if not isinstance(components, list):
            continue

        seen_ids = set()
        for comp in components:
            if not isinstance(comp, dict):
                continue
            cid, cver = comp.get("id"), comp.get("version")
            if cid is None:
                continue

            if cid in seen_ids:
                findings.error(where, f"bundle '{bundle_id}': component '{cid}' listed twice")
            seen_ids.add(cid)

            if cid not in installable:
                findings.error(
                    where,
                    f"bundle '{bundle_id}': component '{cid}' is not in the catalog",
                )
                continue

            if cid in all_extensions:
                bundled_extensions.add(cid)

            actual = str(installable[cid].get("version"))
            if cver is not None and str(cver) != actual:
                findings.error(
                    where,
                    f"bundle '{bundle_id}': pins '{cid}' at {cver}, "
                    f"but the catalog has {actual}",
                )

        must = schema["bundle_entry"]["constraints"].get("must_include_extension")
        if must and must not in seen_ids:
            findings.error(
                where,
                f"bundle '{bundle_id}': must include the '{must}' base extension",
            )

    # requires targets must resolve
    for ext_id, ext in all_extensions.items():
        for dep_id in (ext.get("requires") or {}):
            if dep_id not in installable:
                findings.error(
                    origin.get(ext_id, "?"),
                    f"extension '{ext_id}': requires '{dep_id}', which is not in the catalog",
                )

    # Every installable extension should belong to at least one bundle, since a
    # bundle is the only route a developer has to install anything. Entries
    # still marked 'planned' are exempt: reserving an id before deciding which
    # bundle it joins is normal, and warning about it would train people to
    # ignore warnings.
    for ext_id, ext in all_extensions.items():
        if ext.get("status") == "planned":
            continue
        if ext_id not in bundled_extensions:
            findings.warn(
                origin.get(ext_id, "?"),
                f"extension '{ext_id}' is {ext.get('status', 'stable')} but belongs "
                f"to no bundle; developers have no way to install it",
            )

    if not args.quiet:
        print(f"  {len(all_extensions)} extension(s), {len(all_presets)} preset(s), "
              f"{len(all_bundles)} bundle(s)")
        print()

    return findings.report(args.quiet)


if __name__ == "__main__":
    sys.exit(main())
