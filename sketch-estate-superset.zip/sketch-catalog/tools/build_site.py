#!/usr/bin/env python3
"""
build_site.py: render the catalog as a static browsable site.

Produces the same experience as the public community catalog at
speckit-community.github.io/extensions, served from GitLab Pages instead of
GitHub Pages: a front page with highlighted and recently-updated entries, a
browse-all page, and a detail page per entry carrying the exact
`specify ... --from` command to copy.

No templating dependency and no JavaScript build step. One stdlib script, so
the CI job needs nothing but python and pyyaml.

Usage:
    build_site.py [--catalog catalog.yml] [--out public] [--base-url ""]

Exit codes:
    0  site written
    2  could not read the catalog
"""

import argparse
import html
import json
import sys
from datetime import date, datetime
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: pyyaml is required. pip install pyyaml", file=sys.stderr)
    sys.exit(2)


# --------------------------------------------------------------------- style
CSS = """
:root{--ink:#1f2328;--muted:#636c76;--line:#d1d9e0;--bg:#fff;--soft:#f6f8fa;
--accent:#b02a30;--ok:#1a7f37;--warn:#9a6700;--plan:#636c76}
*{box-sizing:border-box}
body{margin:0;font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif;
color:var(--ink);background:var(--bg)}
a{color:#0969da;text-decoration:none}a:hover{text-decoration:underline}
code,pre,.mono{font-family:ui-monospace,SFMono-Regular,"SF Mono",Menlo,Consolas,monospace}
header.top{border-bottom:1px solid var(--line);background:var(--soft)}
.wrap{max-width:1080px;margin:0 auto;padding:0 24px}
header.top .wrap{display:flex;align-items:center;height:60px}
.brand{font-weight:600;font-size:16px;color:var(--ink)}
.brand span{color:var(--accent)}
header.top nav{margin-left:auto;font-size:14px}
header.top nav a{margin-left:20px}
h1{font-size:30px;margin:32px 0 4px;font-weight:600}
h2{font-size:19px;margin:36px 0 14px;font-weight:600;padding-bottom:7px;border-bottom:1px solid var(--line)}
h3{font-size:16px;margin:26px 0 8px}
.lede{color:var(--muted);margin:0 0 8px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px}
.card{border:1px solid var(--line);border-radius:7px;padding:15px;background:var(--bg);
display:flex;flex-direction:column;gap:7px}
.card:hover{border-color:#8c959f}
.card .nm{font-weight:600;font-size:15px}
.card .ds{color:var(--muted);font-size:13.5px;flex:1}
.card .ft{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted)}
.pill{display:inline-block;padding:1px 8px;border-radius:20px;font-size:11.5px;
border:1px solid var(--line);background:var(--soft);color:var(--muted)}
.pill.stable{color:var(--ok);border-color:#aceebb;background:#eafbf0}
.pill.alpha{color:var(--warn);border-color:#f5d9a8;background:#fff8e5}
.pill.planned{color:var(--plan)}
.pill.l2{color:var(--accent);border-color:#f0c2c4;background:#fdf1f1}
.pill.community{color:#8250df;border-color:#e0d3fb;background:#f7f3ff}
.ver{font-family:ui-monospace,monospace;font-size:12px;color:var(--muted)}
table{border-collapse:collapse;width:100%;font-size:14px;margin:10px 0}
th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}
th{background:var(--soft);font-weight:600;font-size:13px}
pre{background:var(--soft);border:1px solid var(--line);border-radius:7px;padding:13px;
overflow-x:auto;font-size:13px;margin:8px 0}
.install{position:relative}
.install pre{background:#1f2328;color:#e6edf3;border-color:#1f2328}
.cols{display:grid;grid-template-columns:1fr 290px;gap:36px;align-items:start}
aside{font-size:14px}
aside h4{font-size:12px;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);
margin:20px 0 7px;font-weight:600}
aside ul{list-style:none;margin:0;padding:0}
aside li{padding:3px 0}
.note{border-left:3px solid var(--warn);background:#fff8e5;padding:11px 14px;
border-radius:0 5px 5px 0;font-size:13.5px;margin:14px 0}
.note.danger{border-color:var(--accent);background:#fdf1f1}
footer{margin-top:56px;border-top:1px solid var(--line);background:var(--soft);
padding:22px 0;font-size:13px;color:var(--muted)}
.filter{width:100%;padding:9px 12px;font-size:14px;border:1px solid var(--line);
border-radius:7px;margin:14px 0}
.tag{font-size:12px;color:var(--muted);margin-right:7px}
.crumb{font-size:13px;color:var(--muted);margin:22px 0 0}
@media(max-width:820px){.cols{grid-template-columns:1fr}}
"""

FILTER_JS = """
<script>
(function(){
  var box=document.getElementById('filter');
  if(!box)return;
  box.addEventListener('input',function(){
    var q=this.value.toLowerCase().trim();
    var n=0;
    document.querySelectorAll('[data-search]').forEach(function(el){
      var hit=!q||el.getAttribute('data-search').indexOf(q)>-1;
      el.style.display=hit?'':'none';
      if(hit)n++;
    });
    var c=document.getElementById('count');
    if(c)c.textContent=n+(n===1?' entry':' entries');
  });
})();
</script>
"""


def e(x):
    return html.escape(str(x if x is not None else ""))


def page(title, body, base="", extra=""):
    return f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(title)}</title>
<meta name="description" content="The organization's Spec Kit catalog: browse and install governed bundles and extensions.">
<style>{CSS}</style>
</head><body>
<header class="top"><div class="wrap">
  <a class="brand" href="{base}index.html">Sketch <span>Catalog</span></a>
  <nav>
    <a href="{base}all.html">Browse</a>
    <a href="{base}install.html">Install</a>
    <a href="{base}about.html">About</a>
  </nav>
</div></header>
<div class="wrap">{body}</div>
<footer><div class="wrap">
  The organization's internal Spec Kit catalog. Entries are reviewed against
  <span class="mono">catalog.schema.yml</span> before they can be installed.
  Generated from <span class="mono">catalog.d/</span>; do not edit the site by hand.
</div></footer>
{extra}
</body></html>"""


def status_pill(s):
    s = s or "stable"
    return f'<span class="pill {e(s)}">{e(s)}</span>'


def card(kind, cid, entry, base=""):
    st = entry.get("status", "stable")
    desc = " ".join((entry.get("description") or "").split())
    tags = " ".join(entry.get("tags") or [])
    search = f"{cid} {desc} {tags} {kind}".lower()
    extra = ""
    if entry.get("layer") == "L2":
        extra += '<span class="pill l2">L2 base</span>'
    if entry.get("origin") == "community":
        extra += '<span class="pill community">community</span>'
    return f"""<a class="card" href="{base}{e(kind)}-{e(cid)}.html" data-search="{e(search)}">
  <div class="nm">{e(cid)}</div>
  <div class="ds">{e(desc[:130])}{'&hellip;' if len(desc) > 130 else ''}</div>
  <div class="ft"><span class="ver">v{e(entry.get('version'))}</span>
  {status_pill(st)}{extra}</div>
</a>"""


def detail(kind, cid, entry, catalog, out: Path, base=""):
    st = entry.get("status", "stable")
    desc = " ".join((entry.get("description") or "").split())
    install = entry.get("install_url")

    verb = {"bundle": "bundle install", "extension": "extension add",
            "preset": "preset add"}[kind]
    if install:
        cmd = f"specify {verb} {cid} --from {install}"
    else:
        cmd = f"specify {verb} {cid}"

    body = [f'<p class="crumb"><a href="{base}all.html">Browse</a> / {e(kind)}</p>']
    body.append(f"<h1>{e(cid)}</h1>")
    pills = status_pill(st)
    if entry.get("layer"):
        pills += f' <span class="pill">Layer {e(entry["layer"])}</span>'
    if entry.get("origin") == "community":
        pills += ' <span class="pill community">community mirror</span>'
    if entry.get("verified") is True:
        pills += ' <span class="pill stable">verified</span>'
    body.append(f'<p class="lede"><span class="ver">v{e(entry.get("version"))}</span> &middot; {pills}</p>')
    body.append(f"<p>{e(desc)}</p>")

    if entry.get("tags"):
        body.append("<p>" + "".join(f'<span class="tag">#{e(t)}</span>'
                                    for t in entry["tags"]) + "</p>")

    if entry.get("origin") == "community":
        body.append('<div class="note danger"><strong>Mirrored, not authored here.</strong> '
                    'Install from the internal mirror URL below, never from upstream '
                    'directly. The mirror is what was scanned and pinned.</div>')
    if st == "planned":
        body.append('<div class="note"><strong>Not installable yet.</strong> The id is '
                    'reserved and the shape agreed, but no command exists. Installing '
                    'this registers nothing useful.</div>')

    body.append("<h2>Install</h2>")
    body.append(f'<div class="install"><pre>{e(cmd)}</pre></div>')
    if entry.get("release_tag"):
        body.append(f'<p class="lede">Release tag <code>{e(entry["release_tag"])}</code>. '
                    f'For the moving latest, replace the tag with '
                    f'<code>permalink/latest</code>.</p>')

    if kind == "bundle":
        body.append("<h2>Provisions</h2><table><tr><th>Component</th><th>Type</th>"
                    "<th>Pinned at</th><th>Status</th></tr>")
        allent = {**catalog.get("extensions", {}), **catalog.get("presets", {})}
        for c in entry.get("components", []):
            sub = allent.get(c["id"], {})
            link = f'<a href="{base}{c["type"]}-{e(c["id"])}.html">{e(c["id"])}</a>'
            body.append(f'<tr><td>{link}</td><td>{e(c["type"])}</td>'
                        f'<td class="mono">{e(c["version"])}</td>'
                        f'<td>{status_pill(sub.get("status","stable"))}</td></tr>')
        body.append("</table>")
    else:
        inb = [bid for bid, b in catalog.get("bundles", {}).items()
               if any(c["id"] == cid for c in b.get("components", []))]
        body.append("<h2>Bundles that include this</h2>")
        if inb:
            body.append("<p>" + " ".join(
                f'<a href="{base}bundle-{e(b)}.html">{e(b)}</a>' for b in inb) + "</p>")
        else:
            body.append('<p class="lede">None yet. A developer cannot install '
                        'this until it belongs to a bundle.</p>')

    if entry.get("notes"):
        body.append("<h2>Notes</h2><p>" + e(" ".join(entry["notes"].split())) + "</p>")

    # ---- sidebar
    side = ["<h4>Details</h4><ul>"]
    side.append(f"<li>Version <span class='mono'>{e(entry.get('version'))}</span></li>")
    if entry.get("updated"):
        side.append(f"<li>Updated {e(entry['updated'])}</li>")
    if entry.get("owner"):
        side.append(f"<li>Owner <span class='mono'>{e(entry['owner'])}</span></li>")
    if entry.get("license"):
        side.append(f"<li>License {e(entry['license'])}</li>")
    if entry.get("repo"):
        side.append(f"<li>Repo <span class='mono'>{e(entry['repo'])}</span></li>")
    side.append("</ul>")

    links = [("Repository", entry.get("repository")),
             ("Homepage", entry.get("homepage")),
             ("Documentation", entry.get("documentation")),
             ("Changelog", entry.get("changelog")),
             ("Upstream release", entry.get("upstream_release"))]
    links = [(n, u) for n, u in links if u]
    if links:
        side.append("<h4>Links</h4><ul>")
        for n, u in links:
            side.append(f'<li><a href="{e(u)}">{e(n)}</a></li>')
        side.append("</ul>")

    if entry.get("requires"):
        side.append("<h4>Requires</h4><ul>")
        for k, v in entry["requires"].items():
            side.append(f'<li><span class="mono">{e(k)} {e(v)}</span></li>')
        side.append("</ul>")

    html_body = f'<div class="cols"><div>{"".join(body)}</div><aside>{"".join(side)}</aside></div>'
    (out / f"{kind}-{cid}.html").write_text(
        page(f"{cid} | Sketch Catalog", html_body, base), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    here = Path(__file__).resolve().parent.parent
    ap.add_argument("--catalog", default=str(here / "catalog.yml"))
    ap.add_argument("--out", default=str(here / "public"))
    args = ap.parse_args()

    cat_path = Path(args.catalog)
    if not cat_path.is_file():
        print(f"ERROR: catalog not found: {cat_path}. Run build_catalog.py first.",
              file=sys.stderr)
        return 2
    catalog = yaml.safe_load(cat_path.read_text(encoding="utf-8")) or {}

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    exts = catalog.get("extensions") or {}
    pres = catalog.get("presets") or {}
    bundles = catalog.get("bundles") or {}

    everything = ([("bundle", k, v) for k, v in bundles.items()]
                  + [("extension", k, v) for k, v in exts.items()]
                  + [("preset", k, v) for k, v in pres.items()])

    # ---------------------------------------------------------------- index
    installable = [(k, i, v) for k, i, v in everything
                   if v.get("status", "stable") != "planned"]
    highlighted = [t for t in everything if t[2].get("highlighted")]
    if not highlighted:
        highlighted = [t for t in installable if t[0] == "bundle"][:6]

    def upd(t):
        return t[2].get("updated") or "0000-00-00"
    recent = sorted(installable, key=upd, reverse=True)[:8]

    body = ["<h1>Sketch Catalog</h1>",
            '<p class="lede">Everything the organization can install, reviewed '
            'against the catalog schema before it gets here. Install bundles, '
            'not extensions.</p>']
    body.append("<h2>Start here</h2><div class='grid'>")
    body += [card(k, i, v) for k, i, v in highlighted]
    body.append("</div>")
    body.append("<h2>Recently updated</h2><div class='grid'>")
    body += [card(k, i, v) for k, i, v in recent]
    body.append("</div>")

    n_plan = sum(1 for k, i, v in everything if v.get("status") == "planned")
    body.append(f"<h2>At a glance</h2><table>"
                f"<tr><th>Kind</th><th>Installable</th><th>Planned</th></tr>"
                f"<tr><td>Bundles</td><td>{sum(1 for b in bundles.values() if b.get('status','stable')!='planned')}</td>"
                f"<td>{sum(1 for b in bundles.values() if b.get('status')=='planned')}</td></tr>"
                f"<tr><td>Extensions</td><td>{sum(1 for x in exts.values() if x.get('status','stable')!='planned')}</td>"
                f"<td>{sum(1 for x in exts.values() if x.get('status')=='planned')}</td></tr>"
                f"<tr><td>Presets</td><td>{len(pres)}</td><td>0</td></tr></table>"
                f'<p class="lede">{n_plan} entries are <code>planned</code>: the id is '
                f'reserved and the shape agreed, but nothing runs yet.</p>')

    (out / "index.html").write_text(page("Sketch Catalog", "".join(body)), encoding="utf-8")

    # ------------------------------------------------------------------ all
    body = ["<h1>Browse</h1>",
            '<input class="filter" id="filter" placeholder="Filter by name, tag or description...">',
            f'<p class="lede"><span id="count">{len(everything)} entries</span></p>']
    for label, kind in (("Bundles", "bundle"), ("Extensions", "extension"), ("Presets", "preset")):
        items = sorted([t for t in everything if t[0] == kind], key=lambda t: t[1])
        if not items:
            continue
        body.append(f"<h2>{label}</h2><div class='grid'>")
        body += [card(k, i, v) for k, i, v in items]
        body.append("</div>")
    (out / "all.html").write_text(
        page("Browse | Sketch Catalog", "".join(body), extra=FILTER_JS), encoding="utf-8")

    # -------------------------------------------------------------- install
    inst = ["<h1>Installing</h1>",
            '<p class="lede">One command per role. Developers install bundles; '
            'extensions are the unit of authorship, not of installation.</p>',
            "<h2>One-time setup</h2>",
            "<pre>uv tool install specify-cli\n\n"
            "# point the CLI at this catalog rather than the public one\n"
            "export SPECKIT_CATALOG_URL=\"https://&lt;pages-host&gt;/catalog.yml\"</pre>",
            "<h2>Install a bundle</h2>",
            "<pre>cd /path/to/your/project\nspecify init\n"
            "specify bundle install sketch-base</pre>",
            "<h2>Install a specific release directly</h2>",
            '<p class="lede">Bypasses the catalog. Useful for testing a release '
            'candidate, not the supported path for developers.</p>',
            "<pre>specify bundle install sketch-base --from \\\n"
            "  https://&lt;gitlab-host&gt;/platform/sketch-base/-/releases/spec-kit-sketch-v0.3.0/downloads/bundle.zip</pre>",
            "<h2>Always the latest</h2>",
            '<p class="lede">GitLab serves a moving permalink for the most recent '
            'release of a project, so a pinned URL is not required:</p>',
            "<pre>https://&lt;gitlab-host&gt;/platform/sketch-base/-/releases/permalink/latest/downloads/bundle.zip</pre>",
            '<div class="note">Prefer the catalog. A <code>--from</code> URL pins one '
            'artifact and skips every check the catalog performs.</div>']
    (out / "install.html").write_text(
        page("Install | Sketch Catalog", "".join(inst)), encoding="utf-8")

    # ---------------------------------------------------------------- about
    meta = catalog.get("catalog", {})
    about = ["<h1>About this catalog</h1>",
             '<p class="lede">The control plane for Spec Kit in this organization.</p>',
             "<h2>How an entry gets here</h2>",
             "<p>Every installable unit is an entry in one fragment under "
             "<code>catalog.d/</code>, one file per division. A merge request "
             "touching a fragment is routed by CODEOWNERS to that division's "
             "leads, validated against <code>catalog.schema.yml</code>, and only "
             "then aggregated into the catalog this site is built from.</p>",
             "<h2>What the schema enforces</h2>",
             "<ul><li>Ids unique across every fragment</li>"
             "<li>Exact SemVer, no ranges anywhere</li>"
             "<li>Every bundle component resolves at exactly the pinned version</li>"
             "<li>Every bundle includes the <code>sketch</code> base</li>"
             "<li>Ids at most 20 characters</li></ul>",
             "<h2>Status</h2>",
             "<p><code>planned</code> reserves an id with no runnable command. "
             "<code>alpha</code> runs and is in use by the authoring team. "
             "<code>stable</code> is released with SemVer honoured.</p>",
             "<h2>Community mirrors</h2>",
             "<p>Extensions marked <em>community</em> are mirrored from outside the "
             "organization, pinned at a tag and scanned before use. Install them "
             "from the internal mirror URL, never from upstream directly.</p>",
             f'<p class="lede">Built {e(meta.get("updated_at", date.today().isoformat()))} '
             f'from {len(meta.get("source_fragments", []))} fragments.</p>']
    (out / "about.html").write_text(
        page("About | Sketch Catalog", "".join(about)), encoding="utf-8")

    # ------------------------------------------------------------- details
    for kind, cid, entry in everything:
        detail(kind, cid, entry, catalog, out)

    # machine-readable copies, served alongside the site
    (out / "catalog.yml").write_text(cat_path.read_text(encoding="utf-8"), encoding="utf-8")
    (out / "catalog.json").write_text(json.dumps(catalog, indent=2), encoding="utf-8")

    n = len(list(out.glob("*.html")))
    print(f"Wrote {n} pages to {out}")
    print(f"  {len(bundles)} bundle(s), {len(exts)} extension(s), {len(pres)} preset(s)")
    print(f"  plus catalog.yml and catalog.json for the CLI")
    return 0


if __name__ == "__main__":
    sys.exit(main())
