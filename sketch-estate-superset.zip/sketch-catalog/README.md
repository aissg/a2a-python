# sketch-catalog

The control plane. Everything the organization can install is an entry here,
and the CLI only ever sees what CI approved.

This repository does two things: it validates and aggregates the catalog, and
it publishes a browsable site so people can find what exists without reading
YAML.

```
https://<group>.pages.<host>/sketch-catalog/            the site
https://<group>.pages.<host>/sketch-catalog/catalog.yml SPECKIT_CATALOG_URL
```

New to GitLab? [docs/GITLAB-STEP-BY-STEP.md](docs/GITLAB-STEP-BY-STEP.md) goes
from an empty project to a working install.

## Layout

```
sketch-catalog/
├── catalog.schema.yml    the contract
├── catalog.yml           GENERATED aggregate the CLI reads
├── catalog.d/            one fragment per division, plus platform.yml
├── tools/
│   ├── validate_catalog.py   schema + cross-fragment invariants
│   ├── build_catalog.py      fragments -> catalog.yml
│   └── build_site.py         catalog.yml -> browsable site
├── ci/                   reusable pipeline templates other repos include
├── CODEOWNERS            routes each fragment to its division
└── .gitlab-ci.yml        validate -> build -> Pages
```

## Working here

```bash
python3 tools/validate_catalog.py     # schema plus cross-fragment invariants
python3 tools/build_catalog.py        # rebuild catalog.yml from fragments
python3 tools/build_site.py           # rebuild the site into public/
```

Only `pyyaml` is needed. CI runs all three, and additionally fails if
`catalog.yml` does not match its fragments, so the served catalog cannot go
stale.

**Never edit `catalog.yml`.** It is generated. Edit your division's fragment in
`catalog.d/`, then rebuild. An edit to the aggregate is overwritten on the next
build and, worse, passes review while doing nothing.

## The site

Modelled on the public community catalog at
`speckit-community.github.io/extensions`, served from GitLab Pages instead:

- a front page with highlighted and recently-updated entries
- a browse page with client-side filtering
- a detail page per entry carrying the exact `specify ... --from` command
- `catalog.yml` and `catalog.json` served alongside for the CLI

It is a single stdlib Python script with no JavaScript build step, so the CI
job needs nothing but python and pyyaml.

## What the validator enforces

Errors block a merge:

- ids unique across every fragment
- exact SemVer, no ranges anywhere
- every bundle component resolves at exactly the pinned version
- every bundle includes the `sketch` base
- `skt-` only on layer L3 or LX
- ids at most 20 characters

Warnings do not block:

- an installable extension in no bundle. `planned` entries are exempt.

There is also an advisory job that fetches every `install_url` and reports any
that do not resolve. It is deliberately non-blocking, because the release tag
and the catalog merge request are separate steps and the catalog entry often
lands minutes before or after the release.

## Community extensions

Anything from outside the organization is **mirrored**, never referenced live.
See [docs/MIRRORING.md](docs/MIRRORING.md). The short version: mirror at a tag,
scan it, publish it as an internal release, and point the catalog at the
internal URL. Never at upstream.

## Federation

Each division owns one fragment in `catalog.d/`, routed by CODEOWNERS to that
division's leads. A domain publish needs no central approval. The platform team
keeps the schema, the CI templates and the id registry, and nothing else.

This is the only repository where a merge request from one division is visible
to another, which is exactly why each division owns exactly one file in it.
