**GENERIC SOFTWARE REQUIREMENTS SPECIFICATION**

**Portfolio Risk Exposure Reporting: Standard**

*Worked example, production depth, non-regulated framing, GUI drill-down application*

**Document Control**

| **Version** | **Date**   | **Author**                         | **Change Summary**                       |
|-------------|------------|------------------------------------|------------------------------------------|
| 0.1         | 2026-07-08 | R. Okafor, Risk Systems            | Initial draft                            |
| 0.2         | 2026-07-11 | R. Okafor, Risk Systems            | Added reconciliation tolerance, glossary |
| 1.0         | 2026-07-12 | S. Alvarez, Head of Risk Reporting | Approved for build                       |

**How to convert this document to Markdown for Spec Kit:**

> 1. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 2. Save into the Spec Kit feature branch, e.g. specs/risk-exposure-reporting/spec.md.
> 3. Run /speckit.specify against spec.md.

# 0. Depth Selector
|                           |                                                                                                                                                                                                                                                                              |
|---------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **Depth level**           | Standard                                                                                                                                                                                                                                                                     |
| **Rationale**             | Production, internal-only reporting tool consumed by the risk office. Read-only; no trade execution. Not regulated as a standalone system, though its output feeds regulatory risk reports produced elsewhere, which is why reconciliation tolerance is specified precisely. |
| **When to use this tier** | Production work, non-regulated.                                                                                                                                                                                                                                              |

# 1. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

Give risk officers a self-service way to see exposure by portfolio and by position, without waiting on an ad hoc analyst report.

**Success criteria:**

A risk officer can go from the portfolio list to a specific position's risk contribution in 3 clicks or fewer.

**Explicit out of scope:**

- No order execution or trade booking. This is read-only reporting.

- No what-if or scenario simulation in this phase. Deferred to a future phase.

**User roles / personas:**

| **Role**            | **How they differ from other roles**                                            |
|---------------------|---------------------------------------------------------------------------------|
| Risk Officer        | Can view and drill into every portfolio across the firm.                        |
| Portfolio Manager   | Can view and drill into only the portfolios they manage.                        |
| Compliance Reviewer | Read-only across all portfolios, with every drill-down action logged for audit. |

**Functional requirements:**

| **ID** | **Requirement**                                                                                                        | **Priority** |
|--------|------------------------------------------------------------------------------------------------------------------------|--------------|
| FR-1   | System MUST display a filterable list of portfolios, showing name, manager, and total market value.                    | Must         |
| FR-2   | System MUST allow drill-down from a portfolio to its position list, sorted by risk contribution descending by default. | Must         |
| FR-3   | System MUST allow drill-down from a position to its risk factor breakdown, including a historical trend chart.         | Should       |
| FR-4   | System MUST restrict a Portfolio Manager's view to only the portfolios they manage.                                    | Must         |
| FR-5   | System MUST allow export of the current position table to CSV.                                                         | Should       |

# 2. Domain & Data Model
> <strong>What it means:</strong> The nouns of the system: what objects it manages, how they relate, and how big the data gets.
> <strong>Example:</strong> Counterparty, Trade, Settlement Instruction. A Trade has one Counterparty and one or more Settlement Instructions.

**Core entities and key attributes:**

| **Entity**  | **Key attributes**                                                                                      |
|-------------|---------------------------------------------------------------------------------------------------------|
| Portfolio   | id, name, manager, total market value, as-of date                                                       |
| Position    | instrument id, quantity, market value, weight percent of portfolio, sector, asset class, currency       |
| Risk Metric | VaR 95 percent 1-day, beta, volatility, concentration percent; attached to a Portfolio or to a Position |

**Relationships and identity/uniqueness rules:**

A Portfolio has many Positions. Each Position has one current Risk Metric snapshot. A Position is uniquely identified by the combination of portfolio id, instrument id, and as-of date.

**Lifecycle / state transitions:**

Position risk metrics are recalculated nightly at market close. If a night's recalculation fails, the portfolio is marked stale rather than showing blank or last-known figures silently.

**Data volume / scale assumptions:**

Approximately 500 portfolios, averaging 50 positions each. Ten years of daily snapshots retained for trend analysis.

# 3. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Critical user journey:**

Risk officer logs in, sees the portfolio list filterable by manager and by total market value, selects a portfolio, sees its position table sorted by risk contribution descending, selects a position, and sees its risk factor breakdown including a historical VaR trend chart.

**Error / empty / loading states:**

- A portfolio with zero open positions shows “No open positions,” not an empty table.

- If the nightly risk recalculation failed, the portfolio list shows a “Data as of \[last successful date\]” banner rather than blank risk figures.

- While the position table is loading, show a skeleton table, not a blank page.

**Accessibility or localization requirements:**

WCAG 2.1 AA. Every chart element carries a screen-reader label, since risk data is presented visually by default.

# 4. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**                                             | **Target**                                                                                    |
|--------|-------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
| NFR-1  | Portfolio list load time, up to 500 portfolios              | Under 2 seconds                                                                               |
| NFR-2  | Drill-down to position detail                               | Under 1 second                                                                                |
| NFR-3  | Scalability                                                 | Support growth to 2,000 portfolios without redesign                                           |
| NFR-4  | Availability, trading hours (7am to 7pm local)              | 99.5 percent                                                                                  |
| NFR-5  | Reconciliation accuracy vs. official end-of-day risk system | Within 0.1 percent; breach blocks nightly publish and pages the on-call risk systems engineer |

# 5. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Other systems this depends on:**

| **Dependency**                                            | **Failure mode / fallback behaviour**                                                               | **Import/export format** |
|-----------------------------------------------------------|-----------------------------------------------------------------------------------------------------|--------------------------|
| Internal risk engine (nightly VaR, beta, volatility feed) | If late or failed, UI shows yesterday's figures with a stale-data flag rather than blocking access. | Internal REST API        |
| Accounting / custody position feed                        | If unavailable, the affected portfolios are marked stale; no partial position lists are shown.      | Internal REST API        |

**Protocol / versioning assumptions:**

Risk engine data is consumed via a versioned internal REST API. The system must support a dual-read period across the API's next major version, not a hard cutover.

# 6. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**Negative scenarios:**

A portfolio is reassigned to a new manager mid-day. The previous manager loses access immediately, not at their next login.

**Rate limiting / throttling and conflict resolution:**

Bulk export of all 500-plus portfolios is throttled to avoid overloading the reporting database during market hours. No conflict resolution is needed for concurrent viewing, since the system is read-only.

# 7. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

**Technical constraints:**

Must integrate with the existing internal risk engine's REST API. No new risk calculation engine is to be introduced.

**Rejected alternatives:**

| **Alternative considered**              | **Reason rejected**                                                                                                                        |
|-----------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------|
| Real-time (intraday) risk recalculation | Cost and complexity not justified for phase 1; nightly batch matches the current regulatory reporting cadence. Deferred to a future phase. |

# 8. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term**      | **Single definitive meaning**                                                                         |
|---------------|-------------------------------------------------------------------------------------------------------|
| Exposure      | The market value of a position, expressed in base currency.                                           |
| VaR           | Value at Risk at 95 percent confidence, 1-day horizon, unless another horizon is explicitly labelled. |
| Concentration | A single position's percentage share of total portfolio market value.                                 |

**Avoided synonyms:**

“Risk” is never used alone as a field label; it is always qualified (VaR, beta, concentration), since “risk” on its own is ambiguous across teams.

**Cross-team consistency check:**

Finance's general ledger uses “exposure” to mean notional value, not market value. This is a genuine conflict with this system's definition and is called out explicitly on every exported report to avoid a reconciliation dispute.

# 9. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                                                                                                               |
|--------|-----------------------------------------------------------------------------------------------------------------------------|
| AC-1   | Filtering the portfolio list by manager updates the list in under 1 second.                                                 |
| AC-2   | From the portfolio list, a risk officer reaches the top 5 risk-contributing positions in 2 clicks or fewer.                 |
| AC-3   | A Portfolio Manager account cannot view any portfolio outside their assigned list, verified by attempted direct URL access. |

**Definition of Done checklist:**

- Reconciliation report matches the official risk system to within 0.1 percent across a full month of daily snapshots.

- Stale-data banner verified to appear correctly on a simulated feed failure.

**Traceability:**

FR-1 to FR-5 each map to at least one acceptance criterion above or to a Definition of Done item.

# 10. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question**                                                                                         | **Status**                |
|--------|------------------------------------------------------------------------------------------------------|---------------------------|
| 1      | Should Portfolio Managers see other managers' portfolios in aggregate, anonymized, for benchmarking? | Open, deferred to phase 2 |

**Vague terms flagged for quantification:**

| **Vague term**                 | **Where used**            | **Proposed metric**                                           |
|--------------------------------|---------------------------|---------------------------------------------------------------|
| “The dashboard should be fast” | Original business request | Resolved: see the 2-second and 1-second targets in Section 4. |

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown, not a table, so it can be checked off directly in GitHub or by /speckit.clarify.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
