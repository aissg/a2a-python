**GENERIC SOFTWARE REQUIREMENTS SPECIFICATION**

**Portfolio Risk Exposure Reporting: Exhaustive**

*Worked example, mission-critical / firm-wide depth, GUI drill-down application*

**Document Control**

| **Version** | **Date**   | **Author**                         | **Change Summary**                                              |
|-------------|------------|------------------------------------|-----------------------------------------------------------------|
| 0.1         | 2026-05-04 | R. Okafor, Risk Systems            | Initial draft                                                   |
| 0.2         | 2026-05-19 | L. Bergman, Data Governance        | Added glossary governance process, DR requirements              |
| 0.3         | 2026-06-02 | R. Okafor, Risk Systems            | Added dispute workflow, accessibility audit requirement         |
| 1.0         | 2026-06-11 | S. Alvarez, Head of Risk Reporting | Approved for build; Internal Audit sign-off recorded separately |

**How to convert this document to Markdown for Spec Kit:**

> 1. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 2. Save into the Spec Kit feature branch, e.g. specs/risk-exposure-reporting/spec.md.
> 3. Run /speckit.specify against spec.md.

# 0. Depth Selector
|                           |                                                                                                                                                                                                                                                                                                                                                                      |
|---------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **Depth level**           | Exhaustive                                                                                                                                                                                                                                                                                                                                                           |
| **Rationale**             | Firm-wide, mission-critical reporting tool replacing seven legacy divisional spreadsheets, feeding data underlying the firm's regulatory risk disclosures. Multiple business lines, formal governance sign-off, and a full audit trail are required. Exhaustive is the recommended default here even though the tool itself does not directly file with a regulator. |
| **When to use this tier** | Mission-critical, regulated, or multi-team system.                                                                                                                                                                                                                                                                                                                   |

# 1. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

A single firm-wide source of truth for portfolio and position-level risk exposure, replacing seven legacy divisional spreadsheet reports, feeding both internal risk governance committees and the data underlying the firm's regulatory risk disclosures.

**Success criteria:**

100 percent of risk officers across every desk use this tool exclusively. All seven legacy spreadsheet reports are formally decommissioned within two quarters of go-live.

**Explicit out of scope:**

- No trade execution or order booking.

- No portfolio construction or optimization. Owned by a separate system.

- No client-facing access. Internal risk office and audit only.

**User roles / personas:**

| **Role**              | **How they differ from other roles**                                                       |
|-----------------------|--------------------------------------------------------------------------------------------|
| Risk Officer          | Views and drills into every portfolio across the firm.                                     |
| Portfolio Manager     | Views and drills into only the portfolios they manage; can flag a figure as disputed.      |
| Compliance Reviewer   | Read-only across all portfolios; can export audit logs.                                    |
| Data Governance Owner | Owns the glossary in Section 8; arbitrates cross-team term conflicts and disputed figures. |

**Functional requirements:**

| **ID** | **Requirement**                                                                                                         | **Priority** |
|--------|-------------------------------------------------------------------------------------------------------------------------|--------------|
| FR-1   | System MUST display a filterable list of portfolios, showing name, manager, and total market value.                     | Must         |
| FR-2   | System MUST allow drill-down from a portfolio to its position list, sorted by risk contribution descending by default.  | Must         |
| FR-3   | System MUST allow drill-down from a position to its risk factor breakdown, including a historical trend chart.          | Must         |
| FR-4   | System MUST restrict a Portfolio Manager's view to only the portfolios they manage.                                     | Must         |
| FR-5   | System MUST allow export of the current position table to CSV, and export of audit logs for Compliance Reviewers.       | Must         |
| FR-6   | System MUST allow a Portfolio Manager to flag a figure as disputed, routing it to the Data Governance Owner for review. | Must         |
| FR-7   | System MUST enforce the canonical glossary from Section 8 on every field label shown in the UI and in exports.          | Must         |

# 2. Domain & Data Model
> <strong>What it means:</strong> The nouns of the system: what objects it manages, how they relate, and how big the data gets.
> <strong>Example:</strong> Counterparty, Trade, Settlement Instruction. A Trade has one Counterparty and one or more Settlement Instructions.

**Core entities and key attributes:**

| **Entity**      | **Key attributes**                                                                                |
|-----------------|---------------------------------------------------------------------------------------------------|
| Portfolio       | id, name, manager, total market value, as-of date                                                 |
| Position        | instrument id, quantity, market value, weight percent of portfolio, sector, asset class, currency |
| Risk Metric     | VaR 95 percent 1-day, beta, volatility, concentration percent                                     |
| Audit Log Entry | user, portfolio or position viewed, timestamp, action taken                                       |

**Relationships and identity/uniqueness rules:**

A Portfolio has many Positions. Each Position has one current Risk Metric snapshot. A Position is uniquely identified by portfolio id, instrument id, and as-of date. Every view or export action creates one Audit Log Entry.

**Lifecycle / state transitions:**

Position risk metrics are recalculated nightly. A figure moves to “Under Dispute” when flagged by a Portfolio Manager, and only the Data Governance Owner can move it back to “Resolved.” A portfolio is marked “Stale” if a night's recalculation fails.

**Data volume / scale assumptions:**

Approximately 3,000 portfolios firm-wide, averaging 80 positions each. Ten years of daily snapshots retained, replicated across two regions for disaster recovery.

# 3. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Critical user journey:**

Same core journey as the Standard-depth version, extended with the dispute flow: a Portfolio Manager flags a figure, the Data Governance Owner reviews it against source data, and the resolution is recorded against the Audit Log Entry.

**Error / empty / loading states:**

- Same empty and loading states as the Standard-depth version.

- A figure Under Dispute is visually marked in the UI so a Risk Officer does not mistake it for a confirmed number.

**Accessibility or localization requirements:**

WCAG 2.1 AA, certified by an external accessibility audit before go-live. UI available in English and German, since two of the firm's risk desks operate in German-speaking offices.

# 4. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**                                              | **Target**                                                                                                                             |
|--------|--------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------|
| NFR-1  | Portfolio list load time, up to 3,000 portfolios             | Under 2 seconds                                                                                                                        |
| NFR-2  | Drill-down to position detail                                | Under 1 second                                                                                                                         |
| NFR-3  | Scalability                                                  | Support growth to 10,000 portfolios without redesign                                                                                   |
| NFR-4  | Availability, trading hours, with disaster recovery failover | 99.9 percent; failover under 15 minutes                                                                                                |
| NFR-5  | Observability, security & privacy, compliance                | Full audit logging of every view and export; role-based access control; internal-control review for financial reporting data integrity |

# 5. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Other systems this depends on:**

| **Dependency**                                            | **Failure mode / fallback behaviour**                                                                | **Import/export format** |
|-----------------------------------------------------------|------------------------------------------------------------------------------------------------------|--------------------------|
| Internal risk engine (nightly VaR, beta, volatility feed) | If late or failed, UI shows yesterday's figures with a stale-data flag rather than blocking access.  | Internal REST API        |
| Accounting / custody position feed                        | If unavailable, affected portfolios are marked stale; no partial position lists are shown.           | Internal REST API        |
| Data Governance glossary service                          | If unavailable, the UI continues using the last-cached glossary version and flags it as not-current. | Internal REST API        |

**Protocol / versioning assumptions:**

A dual-read period is required across any breaking change to an upstream API. Any upstream system introducing a breaking change must give a 90-day formal deprecation notice.

# 6. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**Negative scenarios:**

A portfolio is reassigned to a new manager mid-day. The previous manager loses access immediately, not at their next login.

**Known edge cases:**

| **ID** | **Description**                                                                               | **Expected behaviour**                                                                                                    |
|--------|-----------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------|
| EC-1   | Disaster recovery failover occurs while a user has an active session.                         | The user's session is preserved and reconnected to the failover region without requiring re-login.                        |
| EC-2   | A glossary term is changed by the Data Governance Owner while a report export is in progress. | The export in progress completes using the glossary version active when it started; the next export uses the new version. |
| EC-3   | A figure is Under Dispute when the nightly recalculation runs.                                | The dispute status is preserved across the recalculation; the new figure does not silently clear the dispute.             |

**Rate limiting / throttling and conflict resolution:**

Bulk export of all portfolios is throttled to avoid overloading the reporting database during market hours. Two Data Governance Owners cannot resolve the same disputed figure simultaneously; the second attempt is rejected with a message to refresh.

# 7. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

**Technical constraints:**

Must integrate with the existing internal risk engine's REST API. Must run across two regions for disaster recovery. No new risk calculation engine is to be introduced.

**Rejected alternatives:**

| **Alternative considered**                   | **Reason rejected**                                                                                                                                |
|----------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| Real-time (intraday) risk recalculation      | Cost and complexity not justified for phase 1; nightly batch matches the current regulatory reporting cadence.                                     |
| Buying a third-party portfolio risk platform | Could not integrate with the firm's proprietary risk engine without a costly custom connector; building in-house was assessed as lower total cost. |

# 8. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term**      | **Single definitive meaning**                                                                                                                 |
|---------------|-----------------------------------------------------------------------------------------------------------------------------------------------|
| Exposure      | The market value of a position, expressed in base currency.                                                                                   |
| VaR           | Value at Risk at 95 percent confidence, 1-day horizon, unless another horizon is explicitly labelled.                                         |
| Concentration | A single position's percentage share of total portfolio market value.                                                                         |
| Stale         | A figure that has not been successfully recalculated in the most recent nightly run, and is being shown from the last successful run instead. |

**Avoided synonyms:**

“Risk” is never used alone as a field label; it is always qualified (VaR, beta, concentration).

**Cross-team consistency check:**

Finance's general ledger uses “exposure” to mean notional value, not market value, a genuine and known conflict. The Data Governance Owner maintains a firm-wide glossary register and reviews new or changed terms quarterly with Finance and Compliance, specifically to catch conflicts like this one before they reach production rather than after.

# 9. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                                                                                                               |
|--------|-----------------------------------------------------------------------------------------------------------------------------|
| AC-1   | Filtering the portfolio list by manager updates the list in under 1 second.                                                 |
| AC-2   | From the portfolio list, a risk officer reaches the top 5 risk-contributing positions in 2 clicks or fewer.                 |
| AC-3   | A Portfolio Manager account cannot view any portfolio outside their assigned list, verified by attempted direct URL access. |
| AC-4   | A simulated regional outage triggers failover within 15 minutes with no data loss.                                          |
| AC-5   | The external accessibility audit reports zero WCAG 2.1 AA critical findings.                                                |

**Definition of Done checklist:**

- Reconciliation report matches the official risk system to within 0.1 percent across a full month of daily snapshots.

- External accessibility audit completed and signed off.

- Internal Audit review of the audit-logging design completed and signed off.

**Traceability:**

Every functional requirement (FR-1 to FR-7) maps to at least one acceptance criterion above, tracked in a traceability matrix maintained outside this document and reviewed at each release.

# 10. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question**                                                                                         | **Status**                                   |
|--------|------------------------------------------------------------------------------------------------------|----------------------------------------------|
| 1      | Should Portfolio Managers see other managers' portfolios in aggregate, anonymized, for benchmarking? | Open, deferred to phase 2                    |
| 2      | Should a Compliance Reviewer see figures that are still Under Dispute, or only Resolved figures?     | Open, pending Data Governance Owner decision |

**Vague terms flagged for quantification:**

| **Vague term**                 | **Where used**            | **Proposed metric**                                   |
|--------------------------------|---------------------------|-------------------------------------------------------|
| “The dashboard should be fast” | Original business request | Resolved: see the response-time targets in Section 4. |

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown, not a table, so it can be checked off directly in GitHub or by /speckit.clarify.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
