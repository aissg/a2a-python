**GENERIC QUESTION CATALOGUE**

**Clarify-Category Interview Questions**

*Domain-agnostic, organized by Spec Kit's own /speckit.clarify taxonomy, graded Lightweight / Standard / Exhaustive*

> This catalogue is deliberately generic: it applies to any software feature, not only AI features. It exists to prepare a coordinated update to /speckit.clarify's own taxonomy as a separate, later task.
> Section numbers and names match the ten categories in Spec Kit's clarify taxonomy exactly, so this catalogue can be diffed directly against the clarify prompt when that update happens.
> Grading key: [L] Lightweight (asked at all depths), [S] Standard (Standard and Exhaustive), [E] Exhaustive only.

## 1. Functional Scope & Behavior
- **\[L\]** What is the core goal of this feature, in one or two sentences?

- **\[L\]** What does success look like, and how would you know it was achieved?

- **\[L\]** What is explicitly out of scope for this piece of work?

- **\[S\]** Who are the distinct user roles or personas, and what does each one actually do differently from the others?

- **\[S\]** Is there a role that should explicitly NOT be able to do something another role can? State the restriction, not just the permission.

- **\[E\]** For each functional requirement, is there a single owner who can approve it as correct?

## 2. Domain & Data Model
- **\[L\]** What are the core objects (entities) this feature manages?

- **\[L\]** For each entity, what are its two or three most important attributes?

- **\[S\]** How do these entities relate to each other? Which relationships are one-to-many, and which are many-to-many?

- **\[S\]** What makes one instance of an entity unique? Is there a natural key, or does the system need to generate one?

- **\[S\]** Does any entity move through distinct states over its lifetime? List the states and what triggers each transition.

- **\[E\]** What is the expected data volume today, and the expected growth rate over the next one to two years?

## 3. Interaction & UX Flow
- **\[L\]** Walk through the single most important user journey, step by step, from the user's first action to the outcome they need.

- **\[S\]** List every distinct usage pattern, not just the main one. A pattern that only appears in a failure, a correction, or an audit still counts as a scenario.

- **\[S\]** For each scenario: who is the actor, what triggers it, and is it primary, secondary, or an edge case?

- **\[E\]** Is there any usage scenario with no functional requirement behind it? That is a pattern someone described in an interview and nobody ever built.

- **\[S\]** What does the user see when there is no data yet (the empty state)?

- **\[S\]** What does the user see while something is loading, and how long is too long to wait without feedback?

- **\[S\]** What does the user see when an action fails? Is the error message specific enough to act on?

- **\[E\]** Are there accessibility standards this must meet (e.g. WCAG level)?

- **\[E\]** Does this need to support more than one language or locale? If so, which, and are there any that read right-to-left?

## 4. Non-Functional Quality Attributes
- **\[L\]** What is an acceptable response time for the main user action, at least approximately?

- **\[S\]** What throughput or concurrent-user load must this handle, at expected peak?

- **\[S\]** What availability is required, and during which hours or windows does that apply?

- **\[S\]** Where must data reside, and are there regions or environments it must never leave?

- **\[E\]** What logging, metrics, or tracing must exist so an incident can be diagnosed after the fact?

- **\[E\]** Are there regulatory or compliance constraints that apply, even indirectly, through downstream consumers of this system's output?

- **\[S\]** SECURITY: What is the data classification of the information this system handles? Public, Internal, Confidential, or Restricted. If more than one, name the highest.

- **\[S\]** SECURITY: Does the system process personal data or client-identifying information? Name the specific fields, not just yes or no.

- **\[S\]** SECURITY: How do users authenticate? Corporate SSO, or something bespoke? A bespoke mechanism needs an explicit justification, not a default.

- **\[S\]** SECURITY: What is the authorization model? Role-based, attribute-based, or record-level? Be specific: “only their own portfolios” is record-level, not role-based, and they are built differently.

- **\[S\]** SECURITY: Who grants and revokes access, and how quickly does a revocation actually take effect? At the next login, or immediately?

- **\[E\]** SECURITY: What are the encryption requirements, at rest and in transit? Are there fields requiring encryption beyond the platform default?

- **\[E\]** SECURITY: How are secrets stored and rotated? API keys, credentials, connection strings. They must never live in code or in a config file in the repository.

- **\[E\]** SECURITY: What is logged for security purposes: who accessed what, when, and from where? How long is that log retained, and who can read it?

- **\[E\]** SECURITY: Is a penetration test, threat model, or security review required before go-live? Who signs it off?

- **\[E\]** SECURITY: Is there a segregation-of-duties constraint? Can the person who builds or operates this system also approve its output, or must those be different people?

## 5. Integration & External Dependencies
- **\[L\]** Does this feature depend on any other system? Name each one, or state "none."

- **\[S\]** For each external dependency, what happens when it is slow, unavailable, or returns an error?

- **\[S\]** What data import or export formats must be supported?

- **\[E\]** What protocol or API version assumptions are being made, and how is a breaking change from an upstream dependency handled?

- **\[E\]** Is there a fallback or degraded mode when a dependency is down, or does the whole feature stop working?

## 6. Edge Cases & Failure Handling
- **\[L\]** What is the single most likely way this feature could fail or be misused?

- **\[S\]** What happens when a required input is missing, malformed, or out of range?

- **\[S\]** What happens under unusually high load, or when a user performs the same action rapidly and repeatedly?

- **\[E\]** What happens when two users act on the same record at the same time? Is there a conflict-resolution rule, or is the second action simply rejected?

- **\[E\]** What are the known edge cases from any existing manual process this feature replaces?

## 7. Constraints & Tradeoffs
- **\[S\]** Are there technical constraints fixed in advance: a mandated language, database, hosting environment, or platform?

- **\[S\]** Are there constraints from outside engineering entirely: budget, timeline, or a vendor contract already in place?

- **\[E\]** What alternative approaches were considered and rejected? State the reason for each rejection, not just the decision.

- **\[E\]** Are there tradeoffs being made knowingly (e.g. simplicity over completeness, speed over cost) that a reader unfamiliar with the project should be told about explicitly?

## 8. Terminology & Consistency
- **\[L\]** What are the two or three terms in this feature most likely to be misunderstood, and what is the single definitive meaning of each?

- **\[L\]** Is there an existing term elsewhere in the organization that sounds like one used here but means something different? Name the conflict explicitly.

- **\[S\]** Are there synonyms that should be deliberately avoided in this project, because they are ambiguous or already mean something else elsewhere?

- **\[S\]** Does this feature's data eventually feed, or get consumed by, another team's system? If so, do they use the same terms the same way?

- **\[E\]** Is there a canonical glossary this project should conform to (a company-wide data dictionary, a regulatory definition, an industry standard)? Does every term here match it, or are the differences documented?

- **\[E\]** If a term's meaning has changed during this project's life, is the old meaning documented as deprecated rather than silently replaced?

## 9. Completion Signals
- **\[L\]** What specific, testable condition must be true for this to be considered done?

- **\[S\]** For each functional requirement, what is the exact pass or fail test?

- **\[S\]** Is there a Definition of Done checklist beyond the individual acceptance criteria (e.g. documentation updated, monitoring in place)?

- **\[E\]** Does every functional requirement trace to at least one acceptance criterion? Is there any requirement with no way to verify it was actually met?

## 10. Misc / Placeholders
- **\[L\]** What decisions are still unresolved that could materially change the design if answered differently?

- **\[S\]** Scan the specification for adjectives like "robust," "intuitive," "fast," or "scalable." For each one found, what is the actual number or test behind it?

- **\[E\]** Are there any remaining TODO markers, bracketed placeholders, or "TBD" notes anywhere in the specification? List them; do not let any reach sign-off unresolved.

## Depth Grading Summary
*Counts are cumulative. Standard includes every Lightweight question. Exhaustive includes every Standard question.*

| **\#** | **Category**                        | **Lightweight** | **Standard** | **Exhaustive** |
|--------|-------------------------------------|-----------------|--------------|----------------|
| 1      | Functional Scope & Behavior         | 3               | 5            | 6              |
| 2      | Domain & Data Model                 | 2               | 5            | 6              |
| 3      | Interaction & UX Flow               | 1               | 6            | 9              |
| 4      | Non-Functional Quality Attributes   | 1               | 9            | 16             |
| 5      | Integration & External Dependencies | 1               | 3            | 5              |
| 6      | Edge Cases & Failure Handling       | 1               | 3            | 5              |
| 7      | Constraints & Tradeoffs             | 0               | 2            | 4              |
| 8      | Terminology & Consistency           | 2               | 4            | 6              |
| 9      | Completion Signals                  | 1               | 3            | 4              |
| 10     | Misc / Placeholders                 | 1               | 2            | 3              |
|        | Total questions asked               | 13              | 42           | 64             |
