**GENERIC SOFTWARE REQUIREMENTS SPECIFICATION**

**\[Project / Feature Name\]: Lightweight**

*PoC / spike depth, reusable template, convert to Markdown for /speckit.specify*

**Document Control**

| **Version** | **Date**       | **Author**      | **Change Summary** |
|-------------|----------------|-----------------|--------------------|
| 0.1         | \[YYYY-MM-DD\] | \[name / role\] | Initial draft      |
|             |                |                 |                    |
|             |                |                 |                    |

**How to convert this document to Markdown for Spec Kit:**

> 1. Complete all sections below, then save this file as .docx (keep the built-in Heading 1/2 styles intact, do not retype section titles as plain text).
> 2. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 3. Save the result into your Spec Kit feature branch, e.g. specs/&lt;feature&gt;/spec.md.
> 4. Run /speckit.specify against spec.md, or paste its contents into the command directly.
> Note: if headings do not convert to # in step 2, re-save the .docx once through Word or LibreOffice first, since this normalizes the file for pandoc.

# 0. Depth Selector
|                                            |                                                                                                                |
|--------------------------------------------|----------------------------------------------------------------------------------------------------------------|
| **Depth level**                            | Lightweight                                                                                                    |
| **Rationale (required if not Exhaustive)** | \[why this depth was chosen instead of Exhaustive\]                                                            |
| **When to use this tier**                  | Internal spike or proof of concept. Single scenario, no production path. Roughly 15 to 20 minutes to complete. |

# 1. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

\[what the system does, in plain language\]

**Success criteria:**

\[what good looks like\]

**Explicit out of scope:**

- \[item\]

**Functional requirements:**

> Every functional requirement must be testable. If a tester cannot write a pass or fail test against it, it is not a requirement yet: it is an intention.
> Keep each one atomic. One requirement, one behaviour. Do not narrate a usage scenario here: scenarios belong in the Usage Scenarios table, and each requirement traces back to the scenarios it serves.
> From Standard depth onward, write them in EARS form: While/When/If &lt;trigger or state&gt;, the &lt;system&gt; shall &lt;response&gt;.

| **ID** | **Requirement** | **Priority** |
|--------|-----------------|--------------|
| FR-1   | \[requirement\] | Must         |

# 2. Domain & Data Model
> <strong>What it means:</strong> The nouns of the system: what objects it manages, how they relate, and how big the data gets.
> <strong>Example:</strong> Counterparty, Trade, Settlement Instruction. A Trade has one Counterparty and one or more Settlement Instructions.

**Core entities and key attributes:**

| **Entity** | **Key attributes** |
|------------|--------------------|
| \[entity\] | \[attributes\]     |

# 3. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Usage scenarios:**

*Capture every distinct way the system is used, not just the main one. A pattern that only appears in a failure, a correction, or an audit still counts. Each functional requirement should trace back to at least one scenario here.*

| **ID** | **Scenario**                           | **Actor** |
|--------|----------------------------------------|-----------|
| US-1   | \[the primary way the system is used\] | \[who\]   |

**Critical user journey (step by step):**

\[walk the primary scenario end to end, from the user's first action to the outcome they need\]

# 4. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**        | **Target**       |
|--------|------------------------|------------------|
| NFR-1  | \[e.g. response time\] | \[target value\] |

**Security & access control:**

*\[Not required at Lightweight depth, unless the spike touches Confidential or Restricted data. If it does, promote to Standard.\]*

# 5. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Other systems this depends on, if any:**

\[list, or "none"\]

# 6. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**The single most likely way this could fail:**

\[failure mode\]

# 7. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

*\[not required at Lightweight depth\]*

# 8. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term** | **Single definitive meaning** |
|----------|-------------------------------|
| \[term\] | \[definition\]                |

# 9. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                     | **Traces to** |
|--------|-----------------------------------|---------------|
| AC-1   | \[testable, pass/fail condition\] | FR-1          |

# 10. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question** | **Status** |
|--------|--------------|------------|
| 1      | \[question\] | Open       |

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown, not a table, so it can be checked off directly in GitHub or by /speckit.clarify.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
