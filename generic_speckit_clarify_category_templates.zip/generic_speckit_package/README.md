# Software Requirements Templates: Clarify-Category Edition

Depth-graded requirements templates and a question catalogue, structured
around the ten ambiguity categories used by GitHub Spec Kit's
/speckit.clarify. Domain-agnostic and vendor-neutral.

## Structure

Ten sections, matching clarify's own taxonomy:

1. Functional Scope & Behavior
2. Domain & Data Model
3. Interaction & UX Flow
4. Non-Functional Quality Attributes
5. Integration & External Dependencies
6. Edge Cases & Failure Handling
7. Constraints & Tradeoffs
8. Terminology & Consistency
9. Completion Signals
10. Misc / Placeholders

Plus a closing Review & Acceptance Checklist, which converts to real GFM
checkboxes in the Markdown export.

## Requirements are traceable, and scenarios are first-class

Usage scenarios (Section 3) are captured in a table with an ID, actor,
trigger, and priority, and every functional requirement (Section 1) carries a
"Traces to" column pointing back at the scenarios it serves.

This exists because a common failure is to narrate usage patterns inside the
functional requirements table. Scenarios and requirements answer different
questions and sit at different levels of granularity. A scenario is a story
told for validation. A requirement is atomic and testable, written for build
and test. One scenario typically produces several requirements.

At Exhaustive depth, Section 9 checks traceability in both directions:

- Every requirement traces to at least one scenario. A requirement serving no
  scenario is a requirement nobody asked for.
- Every scenario has at least one requirement behind it. A scenario with no
  requirements is a usage pattern that was discussed and then quietly never
  built.

The functional requirements table also carries an explicit note: if a tester
cannot write a pass or fail test against a requirement, it is not a
requirement yet, it is an intention.

## Security and access control

Section 4 carries ten security questions, starting at Standard depth, not
Exhaustive: data classification, personal data, authentication, authorization
model, access revocation speed, encryption, secrets handling, security audit
logging, pre-go-live security review, and segregation of duties. The
templates carry a matching SEC-1 to SEC-10 table so every question asked has
somewhere to be answered.

## Depth counts

| | Lightweight | Standard | Exhaustive |
|---|---|---|---|
| Questions | 13 | 42 | 64 |

## Contents

- templates/  Three depth-graded blank templates (.docx + .md)
- example/    Three worked examples: a portfolio risk exposure reporting GUI
- questions/  The depth-graded question catalogue

## Verified before delivery

Heading structure intact, zero em-dashes, no organisation-specific or
vendor-specific references anywhere in the content, security block at the
correct depths, and GFM checkboxes in the closing checklist.

## Worked examples in the templates

The "What it means / Example" box under every section uses financial services
examples: settlement exceptions, counterparties, market data feeds, books and
records reconciliation, KYC field extraction, model validation review. They
are illustrative and organisation-neutral: no firm, vendor, or product is
named anywhere in this package.
