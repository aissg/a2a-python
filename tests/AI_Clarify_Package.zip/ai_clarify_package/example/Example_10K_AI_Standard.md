**AI PROJECT: TECHNICAL REQUIREMENTS SPECIFICATION**

**10-K Financial Field Extraction: Standard**

*Worked example, production batch extraction, US GAAP only, non-regulated*

**Document Control**

| **Version** | **Date**   | **Author**           | **Change Summary**                            |
|-------------|------------|----------------------|-----------------------------------------------|
| 0.1         | 2026-06-20 | J. Chen, AI Champion | Promoted from Lightweight spike               |
| 0.2         | 2026-06-27 | R. Patel, Data Eng   | Added validation rules and confidence routing |
| 1.0         | 2026-07-02 | J. Chen, AI Champion | Signed off for build                          |

**How to convert this document to Markdown for Spec Kit:**

> 1. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 2. Save into the Spec Kit feature branch, e.g. specs/10k-extraction/spec.md.
> 3. Run /speckit.specify against spec.md.

# 0. Depth Selector
|                           |                                                                                                                                                                                                                                                                           |
|---------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **Depth level**           | Standard                                                                                                                                                                                                                                                                  |
| **Rationale**             | Production pipeline feeding an internal analytics store. Single jurisdiction (US GAAP), text and structured tables only, no chart extraction, no regulatory reporting. Exhaustive is not warranted because output is internal analytics, not client-facing or regulatory. |
| **Questions answered**    | 54 (35 generic, 19 AI-specific)                                                                                                                                                                                                                                           |
| **When to use this tier** | Production, non-regulated.                                                                                                                                                                                                                                                |

# 1. AI Use Case Classification
> <strong>What it means:</strong> Which of the six AI archetypes this use case is. Sets its risk profile, platform pattern, and governance path from the outset.
> <strong>Example:</strong> A tool that answers questions about client suitability policy by retrieving from the internal policy library is RAG: retrieval over documents.

**Is this an AI/ML feature?**

Yes.

**Which topic best matches this use case?**

|     | **Topic**                   |
|-----|-----------------------------|
| ☐   | 1\) DMO / Data Agent        |
| ☐   | 2\) Compliance Check        |
| ☐   | 3\) Re/Write Productivity   |
| ☐   | 4\) Agentic AI              |
| ☑   | 5\) RAG Document Extraction |
| ☐   | 6\) RAG and Auto Commentary |

**Deployment target for this iteration:**

|     | **Target**                                 |
|-----|--------------------------------------------|
| ☐   | PoC: throwaway, no production path         |
| ☐   | MVP: user-facing, limited support          |
| ☑   | Production: fully IT-supported, formal SLA |

**Primary topic rationale:**

Squarely Topic 5. The output is discrete structured fields, not generated narrative, so it is not Topic 6 (RAG and Auto Commentary). It is not conversational (Topic 1), not a rules engine (Topic 2), and not an autonomous multi-step agent (Topic 4).

# 2. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

Replace the manual keying of headline financials from roughly 500 US large-cap 10-K filings each quarter, which takes about 40 analyst-hours and introduces transcription errors.

**Success criteria:**

Analyst effort falls to under 4 hours per quarter (review only), with text-source accuracy at or above 98 percent.

**Explicit out of scope:**

- IFRS filers and Form 20-F. Deferred to a future phase, not rejected.

- Chart-sourced or infographic-sourced values.

- Scanned or image-only filings. Rejected at ingest, not OCR'd.

- External distribution of extracted data. Internal analytics only.

**User roles / personas:**

| **Role**          | **How they differ from other roles**                                        |
|-------------------|-----------------------------------------------------------------------------|
| Financial Analyst | Reviews flagged extractions, approves or corrects before load.              |
| Data Engineer     | Owns batch runs and the dead-letter queue. Cannot approve extracted values. |
| Research Lead     | Owns the accuracy target and signs off each quarterly batch.                |

**Why AI rather than deterministic parsing?**

A rules-based parser was built in 2024 and reached about 70 percent field coverage before becoming unmaintainable: every new filer added new label variants. This is evidence, not assertion. Retrieval plus a model handles the label variance that regular expressions could not.

**Where a wrong answer is worse than no answer:**

Every one of the 10 fields. A silently wrong revenue figure loaded into the analytics store is materially worse than an absent one, because nothing downstream re-checks it. The system must abstain rather than guess (FR-5).

**Functional requirements:**

| **ID** | **Requirement**                                                                                                                                                            | **Priority** |
|--------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------|
| FR-1   | When a filing URL is submitted to the batch queue, the system shall retrieve the filing and record its SEC accession number.                                               | Must         |
| FR-2   | When a filing is retrieved, the system shall locate the Consolidated Statements before attempting any extraction.                                                          | Must         |
| FR-3   | When the primary statements are located, the system shall extract the 10 target fields for the most recent fiscal year reported.                                           | Must         |
| FR-4   | Where a filing is a scanned image, the system shall reject it to the manual queue rather than attempt OCR.                                                                 | Must         |
| FR-5   | If a target field cannot be located above its confidence floor, the system shall record it as “not found” and shall not substitute a value from any other field or filing. | Must         |
| FR-6   | If a validation rule in Section 12 is breached, the system shall flag the filing for analyst review and shall not load it.                                                 | Must         |
| FR-7   | When all 10 fields clear their confidence floors and all validation rules pass, the system shall load the record into the analytics store.                                 | Must         |

# 3. Domain & Data Model
> <strong>What it means:</strong> The nouns of the system: what objects it manages, how they relate, and how big the data gets.
> <strong>Example:</strong> Counterparty, Trade, Settlement Instruction. A Trade has one Counterparty and one or more Settlement Instructions.

**Core entities and key attributes:**

| **Entity**      | **Key attributes**                                                 |
|-----------------|--------------------------------------------------------------------|
| Filing          | accession number, filer, fiscal year end, form type, ingest status |
| Extracted Field | name, value, unit, source page, confidence score                   |
| Batch Run       | run id, filings processed, flagged count, completion time          |

**Relationships and identity/uniqueness rules:**

A Filing has exactly 10 Extracted Fields. A Filing is uniquely identified by its SEC accession number: resubmitting the same accession number must not create a duplicate record.

**Largest single input the model must handle:**

The largest 10-K in the current corpus is approximately 400 pages, around 600,000 tokens. Filings exceeding the single-pass context are chunked by statement section, never truncated. A filing that cannot be chunked cleanly is flagged, never silently partially processed.

**Data usage rights:**

Source filings are public regulatory disclosures with no licensing restriction on machine processing. No client data, no personal data.

**Source filings used in validation:**

- Apple Inc. Form 10-K, FY ended 27 Sep 2025: https://www.sec.gov/Archives/edgar/data/0000320193/000032019325000079/aapl-20250927.htm

- Microsoft Corp Form 10-K, FY ended 30 Jun 2025: https://www.sec.gov/Archives/edgar/data/0000789019/000095017025100235/msft-20250630.htm

# 4. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Critical user journey:**

An analyst kicks off the quarterly batch and, the next morning, reviews only the roughly 30 filings the system flagged as uncertain, rather than hand-keying all 500.

**Error / empty / loading states:**

- A filing that fails ingest appears in the dead-letter queue with the reason, not silently absent.

- A field reported as “not found” is visually distinct from a field with a value of zero.

**Disclosure that output is machine-generated:**

Every extracted value in the review UI shows its confidence score and a link to the source page, so an analyst is never presented with a bare number that looks hand-verified when it is not.

**User correction:**

An analyst can correct any flagged value in the review UI. Corrections are written to a corrections table and reviewed monthly by the Research Lead, who owns acting on them.

# 5. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**                            | **Target**                                                                                               |
|--------|--------------------------------------------|----------------------------------------------------------------------------------------------------------|
| NFR-1  | Processing time per filing                 | Under 90 seconds                                                                                         |
| NFR-2  | Batch completion, ~500 filings             | Under 8 hours, overnight window                                                                          |
| NFR-3  | Extraction accuracy, text and table source | 98 percent or higher                                                                                     |
| NFR-4  | Availability                               | Batch window only. No intraday SLA.                                                                      |
| NFR-5  | Data residency                             | EU / Switzerland region.                                                                                 |
| NFR-6  | Running cost                               | Under CHF 0.40 per filing, roughly CHF 200 per quarterly batch. Owned by the Research cost centre.       |
| NFR-7  | Model unavailable                          | Queue and retry for 2 hours, then fail the batch with an alert. No silent degradation to a weaker model. |

# 6. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Dependencies:**

| **Dependency**                    | **Failure mode / fallback behaviour**                                                                   | **Format**      |
|-----------------------------------|---------------------------------------------------------------------------------------------------------|-----------------|
| SEC EDGAR bulk retrieval          | Public, rate-limited, no SLA available to us. If unavailable, the batch is deferred, not partially run. | HTML over HTTPS |
| Model endpoint (hosted API)       | Queue and retry for 2 hours, then hard stop per NFR-7.                                                  | REST            |
| Internal analytics store load API | Owned by Platform, 99.5 percent SLA. If down, records hold in the queue.                                | REST / JSON     |

**Model provider and endpoint:**

Hosted third-party API, region-pinned to EU. Not self-hosted. This is a deliberate tradeoff: lower operational burden, accepted dependency on the provider's deprecation cycle.

# 7. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**Negative scenarios:**

A filer restates the prior year within the same filing, presenting two sets of historical figures. Out of scope at this depth: such filings are flagged and handled manually.

**Relative cost of a false positive versus a false negative:**

A false negative (a wrong value loaded silently) is far worse than a false positive (a correct value needlessly flagged). Nothing downstream re-checks these figures. Every threshold in Section 13 is therefore set to over-flag rather than under-flag.

**Out-of-distribution input:**

A filing in an unexpected format (foreign private issuer, unusual statement structure) must be flagged, not force-fitted into the expected schema.

# 8. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

**Technical constraints:**

Must load into the existing internal analytics store via its published API. Model must be an approved, region-pinned hosted endpoint per the platform's model allowlist.

# 9. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term**  | **Single definitive meaning**                                                                                          |
|-----------|------------------------------------------------------------------------------------------------------------------------|
| Revenue   | Total net sales as reported on the Consolidated Statement of Operations. Never a non-GAAP figure quoted in MD&A.       |
| Not found | The system searched and could not locate the field above its confidence floor. Distinct from a reported value of zero. |

**Avoided synonyms:**

“Top line” is never used as a field label; it is ambiguous across filers.

**Terms the model does not know natively:**

The known label synonyms per canonical field (“Total revenues,” “Revenue, net,” “Net sales” for Revenue; “Cost of revenue,” “Cost of goods sold” for Cost of sales) are supplied to the model in the prompt. It does not reliably infer them unaided.

# 10. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                                                                                                                      |
|--------|------------------------------------------------------------------------------------------------------------------------------------|
| AC-1   | Across the 50-filing labelled sample, at least 98 percent of text-source and table-source fields match the analyst-verified value. |
| AC-2   | Every filing that breaches a validation rule is flagged and not loaded. Zero exceptions across the sample.                         |
| AC-3   | No filing loads with a fabricated value in place of a field the system could not locate.                                           |
| AC-4   | A scanned-image filing is rejected to the manual queue, not partially processed.                                                   |

**Accuracy target, stated per source type:**

Text source: 98 percent or higher. Table source: 98 percent or higher. Chart source: not applicable, out of scope at this depth. A single blended figure is not accepted, because it would hide a weak path.

# 11. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question**                                                                             | **Status**                                         |
|--------|------------------------------------------------------------------------------------------|----------------------------------------------------|
| 1      | How should the system treat a filer that restates the prior year within the same filing? | Open, deferred to Exhaustive tier                  |
| 2      | Do we need per-filer synonym overrides, or is the shared synonym list enough?            | Open. Revisit if any filer falls below 95 percent. |

**Vague terms flagged for quantification:**

| **Vague term**  | **Where used**            | **Resolution**                                              |
|-----------------|---------------------------|-------------------------------------------------------------|
| “High accuracy” | Original business request | Resolved: 98 percent, stated per source type in Section 10. |

# 12. AI Behavior & Validation Rules
> <strong>What it means:</strong> Not a generic business rule: this is specifically about correctness checks on model output, and jurisdiction- or context-conditional rules where an absent value is expected rather than an error.
> <strong>Example:</strong> An AI-generated client summary must never state a risk rating that does not appear in the source client file.

**Validation rules on model output:**

| **ID** | **Rule**                                                                                    | **Tolerance**                   | **Breach action**  |
|--------|---------------------------------------------------------------------------------------------|---------------------------------|--------------------|
| VR-1   | Gross profit = revenue minus cost of sales                                                  | Plus or minus USD 1m (rounding) | Flag for review    |
| VR-2   | Total assets = total liabilities plus total equity                                          | Plus or minus USD 1m            | Flag for review    |
| VR-3   | All 10 fields report the same currency and the same fiscal year end                         | Exact                           | Flag for review    |
| VR-4   | Net income is not greater than operating income unless other income is present and positive | Advisory                        | Warn, do not block |

**Where an absent value is expected rather than an error:**

A filer with no cost of sales line (some financial-sector filers) legitimately has no gross profit. VR-1 must not fire in that case; absence is correct, not a failure.

# 13. Confidence & Human Review Routing
> <strong>What it means:</strong> For AI outputs that carry uncertainty: how sure the system is, and when to trust it automatically versus send it to a human.
> <strong>Example:</strong> A KYC field extracted with high certainty is auto-populated. A low-certainty one is routed to a compliance reviewer before the file can progress.

**Confidence signal:**

Model-reported log-probability, calibrated against the 50-filing labelled set. The floors below were derived from that calibration, not chosen by intuition. An uncalibrated score would be worse than none, because reviewers would trust it.

| **Content type**      | **Auto-approve** | **Flag for review** | **Reject** |
|-----------------------|------------------|---------------------|------------|
| Machine-readable text | 0.95 and above   | 0.80 to 0.94        | Below 0.80 |
| Structured table      | 0.92 and above   | 0.78 to 0.91        | Below 0.78 |

| **Trigger**                               | **Action**              | **Owner**         | **SLA**   |
|-------------------------------------------|-------------------------|-------------------|-----------|
| All 10 fields above floor, all rules pass | Auto-approve and load   | System            | Immediate |
| Any field below floor                     | Flag for analyst review | Financial Analyst | 48 hours  |
| Any validation rule breached              | Flag for analyst review | Financial Analyst | 48 hours  |

# 14. Audit Trail & Provenance
> <strong>What it means:</strong> What must be recorded so any output can be traced back and defended later: its source, method, and how certain it was.
> <strong>Example:</strong> Each extracted figure records the source filing and page, the model and prompt version, and the confidence at the time, so it can be defended in a model validation review.

*\[Not required below Exhaustive depth. Source page references are captured per field (FR-3), which is sufficient for an internal analytics use case, but no formal model-version or prompt-version audit record is maintained at this tier.\]*

# 15. Evaluation & Test Data
> <strong>What it means:</strong> The evidence needed to prove accuracy: what labelled data and verified answers are required, and which cases they must cover.
> <strong>Example:</strong> 200 annual reports with figures independently verified by two analysts, including filings with restatements and figures shown only in charts.

**Labelled examples required:**

50 filings, spread across at least 6 GICS sectors.

**Ground truth source:**

Each filing keyed independently by two analysts; disagreements adjudicated by the Research Lead.

**Must include:**

- At least 5 filings using non-standard line-item labels.

- At least 3 with a missing or non-applicable field, to exercise the “not found” path.

- At least 2 scanned filings, to prove rejection works.

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
- [ ] AI Use Case Classification is completed: Yes/No answered, not left blank
- [ ] If this is an AI feature: all four AI-specific sections (12-15) are completed, not left as placeholder text
