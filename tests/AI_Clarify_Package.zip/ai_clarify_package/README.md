
## Interview Coverage Gaps

A new, unnumbered section now sits between the Depth Selector and Section 1
in every template. It is deliberately not a numbered category: it is a
status check on the interview itself, not a content domain about the
system, and numbering it would have broken the 1:1 alignment with Spec
Kit's own clarify taxonomy that this template exists to preserve.

Paste the Coverage Gaps rollup produced by the Teams Copilot structuring
prompt here (or fill it in manually). "Not Asked" and "Partial" are
colour-coded red and amber respectively in the template, so an unresolved
gap cannot quietly disappear into a document nobody rereads end to end.
