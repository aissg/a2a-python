**AI CLARIFY: COMBINED QUESTION CATALOGUE**

**Generic + AI Interview Questions**

*Distributable as an independent AI Clarify package. Every AI-specific addition is marked and colour-coded against the generic Spec Kit clarify baseline.*

> This catalogue is the union of two sets. The generic set matches Spec Kit's own /speckit.clarify taxonomy exactly and would be asked of any software feature. The AI set is everything added on top, because clarify's taxonomy was written for generic software and has no category for model classification, confidence calibration, review routing, audit provenance, or evaluation data.
> Sections 1 and 12 to 15 are entirely AI-specific: they do not exist in stock clarify at all. Sections 2 to 11 are stock clarify categories, with AI-specific questions added inside them and marked individually.
> Grading key: [L] Lightweight (asked at all depths), [S] Standard (Standard and Exhaustive), [E] Exhaustive only.

**How to read this document**

| **Marker**           | **Meaning**                                                                                   |
|----------------------|-----------------------------------------------------------------------------------------------|
| Black text, no badge | Generic question. Present in stock Spec Kit /speckit.clarify. Ask for any feature.            |
| Blue text, AI badge  | AI-specific addition. Not in stock clarify. Ask only when the feature is classified as AI/ML. |

## 1. AI Use Case Classification
*Entirely AI-specific. This section does not exist in stock clarify. It is the gate: answer No to the first question and Sections 12 to 15 do not apply at all.*

- **[L]** `[AI]` Is this an AI/ML feature at all? If No, skip every AI-marked question in this catalogue.

- **[L]** `[AI]` Which of the six topics best matches it? DMO / Data Agent, Compliance Check, Re/Write Productivity, Agentic AI, RAG Document Extraction, RAG and Auto Commentary.

- **[S]** `[AI]` Does it span more than one topic? If so, which is primary, and why does that one lead?

- **[E]** `[AI]` Has the model risk treatment for this classification been confirmed with the risk owner, and what did they say?

- **[E]** `[AI]` What is the deployment target for this iteration? PoC (throwaway), MVP (user-facing, limited support), or Production (fully IT-supported, formal SLA)?

## 2. Functional Scope & Behavior
*Stock clarify category. AI additions challenge whether a model is needed at all, and define where the system must refuse to answer.*

- **[L]** What is the core goal of this feature, in one or two sentences?

- **[L]** What does success look like, and how would you know it was achieved?

- **[L]** What is explicitly out of scope for this piece of work?

- **[S]** Who are the distinct user roles or personas, and what does each one actually do differently from the others?

- **[S]** Is there a role that should explicitly NOT be able to do something another role can? State the restriction, not just the permission.

- **[E]** For each functional requirement, is there a single owner who can approve it as correct?

- **[S]** `[AI]` Why does this need AI at all? Could deterministic logic, rules, or a lookup table solve it? If so, what justifies a model?

- **[E]** `[AI]` Where is a wrong answer worse than no answer? Name the outputs on which the system must abstain or return “unknown” rather than guess.

- **[E]** `[AI]` Is the model making a decision, or recommending one to a human who decides? These carry very different governance burdens.

## 3. Domain & Data Model
*Stock clarify category. AI additions cover input size against the model's context limit, and the right to send this data to a model at all.*

- **[L]** What are the core objects (entities) this feature manages?

- **[L]** For each entity, what are its two or three most important attributes?

- **[S]** How do these entities relate to each other? Which relationships are one-to-many, and which are many-to-many?

- **[S]** What makes one instance of an entity unique? Is there a natural key, or does the system need to generate one?

- **[S]** Does any entity move through distinct states over its lifetime? List the states and what triggers each transition.

- **[E]** What is the expected data volume today, and the expected growth rate over the next one to two years?

- **[S]** `[AI]` What is the largest single input the model must handle? State it in the unit that actually binds: pages, tokens, records, or conversation turns.

- **[E]** `[AI]` Are there data usage rights constraints on sending this data to a model? Licensing, client consent, or cross-border transfer, as distinct from where the data is stored.

- **[E]** `[AI]` Is any training, fine-tuning, or few-shot example data involved, and where did it come from? Who owns it?

## 4. Interaction & UX Flow
*Stock clarify category. AI additions cover disclosure that the output is machine-generated, and how uncertainty reaches the user.*

- **[L]** Walk through the single most important user journey, step by step, from the user's first action to the outcome they need.

- **[S]** List every distinct usage pattern, not just the main one. A pattern that only appears in a failure, a correction, or an audit still counts as a scenario.

- **[S]** For each scenario: who is the actor, what triggers it, and is it primary, secondary, or an edge case?

- **[E]** Is there any usage scenario with no functional requirement behind it? That is a pattern someone described in an interview and nobody ever built.

- **[S]** What does the user see when there is no data yet (the empty state)?

- **[S]** What does the user see while something is loading, and how long is too long to wait without feedback?

- **[S]** What does the user see when an action fails? Is the error message specific enough to act on?

- **[E]** Are there accessibility standards this must meet (e.g. WCAG level)?

- **[E]** Does this need to support more than one language or locale? If so, which, and are there any that read right-to-left?

- **[S]** `[AI]` How is the user told that an output came from a model rather than a deterministic calculation?

- **[S]** `[AI]` How does the user see uncertainty? Is a confidence signal exposed in the interface at all, and does the user understand what it means?

- **[E]** `[AI]` Can the user correct a model output in the interface? If so, what happens to that correction afterwards?

## 5. Non-Functional Quality Attributes
*Stock clarify category. Security and access control sit here, and for a regulated institution they start at Standard depth, not Exhaustive. AI additions cover running cost, model unavailability, and the ways a model can quietly defeat an access-control model that looks correct on paper.*

- **[L]** What is an acceptable response time for the main user action, at least approximately?

- **[S]** What throughput or concurrent-user load must this handle, at expected peak?

- **[S]** What availability is required, and during which hours or windows does that apply?

- **[S]** Where must data reside, and are there regions or environments it must never leave?

- **[E]** What logging, metrics, or tracing must exist so an incident can be diagnosed after the fact?

- **[E]** Are there regulatory or compliance constraints that apply, even indirectly, through downstream consumers of this system's output?

- **[S]** SECURITY: What is the data classification of the information this system handles? Public, Internal, Confidential, or Restricted. If more than one, name the highest.

- **[S]** SECURITY: Does the system process personal data or client-identifying information? Name the specific fields, not just yes or no.

- **[S]** SECURITY: How do users authenticate? Corporate SSO, or something bespoke? A bespoke mechanism needs an explicit justification, not a default.

- **[S]** SECURITY: What is the authorization model? Role-based, attribute-based, or record-level? Be specific: “only their own portfolios” is record-level, not role-based, and they are built differently.

- **[S]** SECURITY: Who grants and revokes access, and how quickly does a revocation actually take effect? At the next login, or immediately?

- **[E]** SECURITY: What are the encryption requirements, at rest and in transit? Are there fields requiring encryption beyond the platform default?

- **[E]** SECURITY: How are secrets stored and rotated? API keys, credentials, connection strings. They must never live in code or in a config file in the repository.

- **[E]** SECURITY: What is logged for security purposes: who accessed what, when, and from where? How long is that log retained, and who can read it?

- **[E]** SECURITY: Is a penetration test, threat model, or security review required before go-live? Who signs it off?

- **[E]** SECURITY: Is there a segregation-of-duties constraint? Can the person who builds or operates this system also approve its output, or must those be different people?

- **[S]** `[AI]` What is the acceptable running cost? Per query, per batch, or per month, and who owns that budget?

- **[S]** `[AI]` SECURITY: Can a user obtain, through the model, information their own access rights would deny them directly? A retrieval system that indexes documents the asker cannot open has bypassed access control, not implemented it. State how per-user permissions are enforced at retrieval time, not just at the document store.

- **[S]** `[AI]` SECURITY: Does the model provider retain, log, or train on the data you send it? Cite the contractual terms, not the marketing page. For Confidential or Restricted data this is a gating question, not a detail.

- **[E]** `[AI]` What happens when the model or its API is unavailable? A manual fallback, a queue and retry, or a hard stop?

- **[E]** `[AI]` Is silent degradation to a cheaper or weaker model permitted when the primary is unavailable? If not, say so explicitly, since it is a common default.

- **[E]** `[AI]` SECURITY: Are prompts and system instructions treated as secrets, version-controlled outside the application code, and reviewed on change? A prompt containing a business rule is a business rule, wherever it lives.

## 6. Integration & External Dependencies
*Stock clarify category. AI additions treat the model provider as what it is: an external dependency with its own deprecation cycle.*

- **[L]** Does this feature depend on any other system? Name each one, or state “none.”

- **[S]** For each external dependency, what happens when it is slow, unavailable, or returns an error?

- **[S]** What data import or export formats must be supported?

- **[E]** What protocol or API version assumptions are being made, and how is a breaking change from an upstream dependency handled?

- **[E]** Is there a fallback or degraded mode when a dependency is down, or does the whole feature stop working?

- **[S]** `[AI]` Which model provider and endpoint is this using? A hosted third-party API, an internally hosted model, or an open-weights model you run yourself?

- **[E]** `[AI]` What deprecation notice does the model provider give, and what happens when they force a version migration you did not choose?

## 7. Edge Cases & Failure Handling
*Stock clarify category. AI additions cover the error-cost asymmetry that shapes every threshold downstream, and deliberate misuse of the model.*

- **[L]** What is the single most likely way this feature could fail or be misused?

- **[S]** What happens when a required input is missing, malformed, or out of range?

- **[S]** What happens under unusually high load, or when a user performs the same action rapidly and repeatedly?

- **[E]** What happens when two users act on the same record at the same time? Is there a conflict-resolution rule, or is the second action simply rejected?

- **[E]** What are the known edge cases from any existing manual process this feature replaces?

- **[S]** `[AI]` What is the relative cost of a false positive versus a false negative here? This single answer shapes confidence thresholds, review routing, and acceptance criteria everywhere else.

- **[E]** `[AI]` What does the system do with an input unlike anything it has seen before? Does it abstain, or does it confidently produce nonsense?

- **[E]** `[AI]` Could a user deliberately misuse this? Prompt injection, extracting data they should not see, or laundering a decision through the model to avoid personal accountability.

## 8. Constraints & Tradeoffs
*Stock clarify category. AI additions demand evidence, not assertion, that a non-AI approach was genuinely considered.*

- **[S]** Are there technical constraints fixed in advance: a mandated language, database, hosting environment, or platform?

- **[S]** Are there constraints from outside engineering entirely: budget, timeline, or a vendor contract already in place?

- **[E]** What alternative approaches were considered and rejected? State the reason for each rejection, not just the decision.

- **[E]** Are there tradeoffs being made knowingly (e.g. simplicity over completeness, speed over cost) that a reader unfamiliar with the project should be told about explicitly?

- **[E]** `[AI]` Was a non-AI approach actually built or trialled before choosing a model? State the evidence, not just the belief that it would not work.

- **[E]** `[AI]` Are there constraints on model choice? An approved model list, a ban on external APIs, an open-weights-only policy, or a data residency rule that rules out certain providers.

## 9. Terminology & Consistency
*Stock clarify category. AI additions cover terms the model will not know natively, and definitions that must be injected into its context.*

- **[L]** What are the two or three terms in this feature most likely to be misunderstood, and what is the single definitive meaning of each?

- **[L]** Is there an existing term elsewhere in the organization that sounds like one used here but means something different? Name the conflict explicitly.

- **[S]** Are there synonyms that should be deliberately avoided in this project, because they are ambiguous or already mean something else elsewhere?

- **[S]** Does this feature's data eventually feed, or get consumed by, another team's system? If so, do they use the same terms the same way?

- **[E]** Is there a canonical glossary this project should conform to (a company-wide data dictionary, a regulatory definition, an industry standard)? Does every term here match it, or are the differences documented?

- **[E]** If a term's meaning has changed during this project's life, is the old meaning documented as deprecated rather than silently replaced?

- **[S]** `[AI]` Which domain terms will the model not know natively, and therefore must be defined for it in the prompt or retrieved into its context?

- **[E]** `[AI]` Where a term's meaning differs by jurisdiction or standard, how is the correct definition injected into the model's context, and is that injection recorded on the output?

## 10. Completion Signals
*Stock clarify category. AI additions require accuracy stated per output type, since a single blended number hides the weakest path.*

- **[L]** What specific, testable condition must be true for this to be considered done?

- **[S]** For each functional requirement, what is the exact pass or fail test?

- **[S]** Is there a Definition of Done checklist beyond the individual acceptance criteria (e.g. documentation updated, monitoring in place)?

- **[E]** Does every functional requirement trace to at least one acceptance criterion? Is there any requirement with no way to verify it was actually met?

- **[S]** `[AI]` What accuracy target must be met, stated separately per output type or content type? A single blended figure hides the fact that the hardest cases fail most.

- **[E]** `[AI]` What is the go / no-go decision for release, who makes it, and against what evidence?

## 11. Misc / Placeholders
*Stock clarify category. The AI addition catches untested capability claims, which are the AI equivalent of an unquantified adjective.*

- **[L]** What decisions are still unresolved that could materially change the design if answered differently?

- **[S]** Scan the specification for adjectives like “robust,” “intuitive,” “fast,” or “scalable.” For each one found, what is the actual number or test behind it?

- **[E]** Are there any remaining TODO markers, bracketed placeholders, or “TBD” notes anywhere in the specification? List them; do not let any reach sign-off unresolved.

- **[E]** `[AI]` Are there claims in this specification about what the model can do that have not actually been tested? A capability assumed is a capability unproven.

## 12. AI Behavior & Validation Rules
*Entirely AI-specific. Not a generic business rule: these are correctness checks on model output, and context-conditional rules where an absent value is expected rather than an error.*

- **[S]** `[AI]` What business or correctness rules must every model output satisfy before it can be used?

- **[S]** `[AI]` What cross-field or cross-source consistency checks apply to the output? What must reconcile against what?

- **[E]** `[AI]` Which of these rules are regulatory rather than business preference? Cite the rule or standard.

- **[E]** `[AI]` Are any validation rules conditional on jurisdiction, legal entity, product, or context?

- **[E]** `[AI]` Where is an absent value expected rather than an error? A generic validator would flag it as a failure; state where that would be wrong.

- **[E]** `[AI]` On breach of a rule, what happens: reject the output, flag it for review, or accept it with a warning?

## 13. Confidence & Human Review Routing
*Entirely AI-specific. For outputs that carry uncertainty: how sure the system is, and when a human must be in the loop.*

- **[S]** `[AI]` Does the system emit a confidence or uncertainty signal? Is it genuinely calibrated, or only cosmetic? An uncalibrated score is worse than none, because reviewers trust it.

- **[S]** `[AI]` What confidence level is high enough to act on without any human review?

- **[S]** `[AI]` Who reviews low-confidence outputs, and within what SLA?

- **[E]** `[AI]` Should the threshold vary by output type, by input type, or by the materiality of the decision being made?

- **[E]** `[AI]` Are there outputs that always require human sign-off regardless of how confident the model is?

- **[E]** `[AI]` How are human corrections captured, who owns acting on them, and how do they feed back into improving the system? A correction log nobody reads satisfies the question but not the intent.

## 14. Audit Trail & Provenance
*Entirely AI-specific. What must be recorded so any output can be traced back and defended later, long after the model version that produced it has been retired.*

- **[E]** `[AI]` What must be reconstructable after the fact, and for how long must it remain so?

- **[E]** `[AI]` Must each output record its source, method, model version, prompt version, confidence, and timestamp?

- **[E]** `[AI]` Must the original input be retained alongside the output, not just the derived result?

- **[E]** `[AI]` When the model or prompt version changes, whether by choice or by provider deprecation, what re-validation is required before the new version reaches production?

- **[E]** `[AI]` Who is accountable for monitoring model performance once it is live, and what degradation triggers a rollback?

## 15. Evaluation & Test Data
*Entirely AI-specific. The evidence needed to prove the thing actually works, and to keep proving it as the world drifts underneath it.*

- **[S]** `[AI]` What labelled test data is needed, and how much of it?

- **[S]** `[AI]` Where does ground truth come from, and who verifies it is actually correct?

- **[E]** `[AI]` Must the test set include edge cases, adversarial inputs, and deliberate failure paths, not just the happy path?

- **[E]** `[AI]` Is production-like data permitted in test, or must it be synthetic or masked?

- **[E]** `[AI]` Who owns keeping the test set current as real inputs drift over time, and how often is it refreshed? A stale benchmark silently overstates accuracy.

## Depth Grading Summary
*Counts are cumulative. Standard includes every Lightweight question; Exhaustive includes every Standard question.*

| **\#** | **Category**                        | **Generic** | **AI** | **L** | **S** | **E** |
|--------|-------------------------------------|-------------|--------|-------|-------|-------|
| 1      | AI Use Case Classification          | 0           | 5      | 2     | 3     | 5     |
| 2      | Functional Scope & Behavior         | 6           | 3      | 3     | 6     | 9     |
| 3      | Domain & Data Model                 | 6           | 3      | 2     | 6     | 9     |
| 4      | Interaction & UX Flow               | 9           | 3      | 1     | 8     | 12    |
| 5      | Non-Functional Quality Attributes   | 16          | 6      | 1     | 12    | 22    |
| 6      | Integration & External Dependencies | 5           | 2      | 1     | 4     | 7     |
| 7      | Edge Cases & Failure Handling       | 5           | 3      | 1     | 4     | 8     |
| 8      | Constraints & Tradeoffs             | 4           | 2      | 0     | 2     | 6     |
| 9      | Terminology & Consistency           | 6           | 2      | 2     | 5     | 8     |
| 10     | Completion Signals                  | 4           | 2      | 1     | 4     | 6     |
| 11     | Misc / Placeholders                 | 3           | 1      | 1     | 2     | 4     |
| 12     | AI Behavior & Validation Rules      | 0           | 6      | 0     | 2     | 6     |
| 13     | Confidence & Human Review Routing   | 0           | 6      | 0     | 3     | 6     |
| 14     | Audit Trail & Provenance            | 0           | 5      | 0     | 0     | 5     |
| 15     | Evaluation & Test Data              | 0           | 5      | 0     | 2     | 5     |

**Totals by question set:**

| **Question set**                 | **Lightweight** | **Standard** | **Exhaustive** |
|----------------------------------|-----------------|--------------|----------------|
| Generic (stock clarify baseline) | 13              | 42           | 64             |
| AI-specific additions            | 2               | 21           | 54             |
| Combined total                   | 15              | 63           | 118            |

*Of the 118 questions asked at Exhaustive depth, 54 are AI-specific additions that do not exist anywhere in stock Spec Kit clarify. That gap is the reason this package exists.*
