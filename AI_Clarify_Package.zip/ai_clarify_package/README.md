# AI Clarify: A Spec Kit Extension for AI Features

A standalone, distributable package extending GitHub Spec Kit's
/speckit.clarify for AI and machine-learning features.

Stock clarify was written for generic software. Its ambiguity taxonomy has ten
categories, and not one of them covers model classification, confidence
calibration, human review routing, audit provenance, or evaluation data. For a
CRUD form that gap is irrelevant. For a model that can produce a confidently
wrong number, it is the whole problem.

This package closes that gap without replacing anything. Every generic
question is preserved exactly. The AI material is purely additive, and every
AI addition is visually marked.

## The marking convention

In the Word documents: black text = generic, present in stock clarify. Blue
text with an AI badge = AI-specific addition.

In the Markdown exports, the distinction survives as a literal marker:

    - **[L]** What is the core goal of this feature, in one or two sentences?
    - **[S]** `[AI]` Why does this need AI at all? Could deterministic logic solve it?

So `grep '\[AI\]'` returns exactly the 54 AI-specific questions.

## Depth counts

| Question set | Lightweight | Standard | Exhaustive |
|---|---|---|---|
| Generic (stock clarify baseline) | 13 | 42 | 64 |
| AI-specific additions | 2 | 21 | 54 |
| Combined total | 15 | 63 | 118 |

The generic column is identical to the standalone generic catalogue, verified
by direct count. Nothing in the baseline was edited or dropped to make room.

## Structure

Fifteen sections. Sections 2 to 11 are stock clarify categories. Sections 1
and 12 to 15 do not exist in stock clarify at all:

1. AI Use Case Classification (the gate: answer "not an AI feature" and 12 to
   15 do not apply)
12. AI Behavior & Validation Rules
13. Confidence & Human Review Routing
14. Audit Trail & Provenance
15. Evaluation & Test Data

## Requirements are traceable, and scenarios are first-class

Usage scenarios (Section 4) are a table with ID, actor, trigger, and priority.
Every functional requirement (Section 2) carries a "Traces to" column pointing
back at the scenarios it serves, and the requirements table carries an
explicit note that a requirement a tester cannot write a pass or fail test
against is not a requirement, it is an intention.

At Exhaustive depth, Section 10 checks traceability both ways: every
requirement traces to a scenario, and every scenario has at least one
requirement behind it.

## Security and access control

Thirteen security questions, starting at Standard depth. Ten are generic
(classification, authentication, authorization model, revocation speed,
encryption, secrets, audit logging, security review, segregation of duties).
Three are AI-specific, and one of them is the most under-asked question in
enterprise retrieval systems:

> Can a user obtain, through the model, information their own access rights
> would deny them directly? A retrieval system that indexes documents the
> asker cannot open has bypassed access control, not implemented it.

## Contents

- templates/  Three depth-graded blank templates (.docx + .md)
- example/    Three worked examples: financial field extraction from public
              SEC filings (10-K and 20-F)
- questions/  The combined question catalogue, AI colour-coded

## Verified before delivery

Heading structure intact, security and scenario blocks at the correct depths,
54 AI-marked questions counted independently in both .docx and .md, zero
em-dashes, and no organisation-specific or vendor-specific references anywhere
in the content.

## Worked examples in the templates

The "What it means / Example" box under every section uses financial services
examples: settlement exceptions, counterparties, market data feeds, books and
records reconciliation, KYC field extraction, model validation review. They
are illustrative and organisation-neutral: no firm, vendor, or product is
named anywhere in this package.
