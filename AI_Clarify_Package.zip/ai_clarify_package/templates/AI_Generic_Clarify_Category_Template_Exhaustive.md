**AI PROJECT: TECHNICAL REQUIREMENTS SPECIFICATION**

**\[Project / Feature Name\]: Exhaustive**

*Mission-critical / regulated depth, AI-extended, reusable template, convert to Markdown for /speckit.specify*

**Document Control**

| **Version** | **Date**       | **Author**      | **Change Summary** |
|-------------|----------------|-----------------|--------------------|
| 0.1         | \[YYYY-MM-DD\] | \[name / role\] | Initial draft      |
|             |                |                 |                    |
|             |                |                 |                    |

**How to convert this document to Markdown for Spec Kit:**

> 1. Complete all sections below, then save this file as .docx (keep the built-in Heading 1/2 styles intact, do not retype section titles as plain text).
> 2. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 3. Save the result into your Spec Kit feature branch, e.g. specs/&lt;feature&gt;/spec.md.
> 4. Run /speckit.specify against spec.md, or paste its contents into the command directly.
> Note: if headings do not convert to # in step 2, re-save the .docx once through Word or LibreOffice first, since this normalizes the file for pandoc.

# 0. Depth Selector
|                                            |                                                                                                                 |
|--------------------------------------------|-----------------------------------------------------------------------------------------------------------------|
| **Depth level**                            | Exhaustive                                                                                                      |
| **Rationale (required if not Exhaustive)** | N/A: Exhaustive is the recommended default.                                                                     |
| **When to use this tier**                  | Mission-critical, regulated, or multi-team system. Full rigor across all fifteen sections. Recommended default. |

# 1. AI Use Case Classification
> <strong>What it means:</strong> Which of the six AI archetypes this use case is. Sets its risk profile, platform pattern, and governance path from the outset.
> <strong>Example:</strong> A tool that answers questions about client suitability policy by retrieving from the internal policy library is RAG: retrieval over documents.

**Is this an AI/ML feature?**

\[ Yes / No \]

**If yes, which topic best matches this use case?**

|     | **Topic**                   |
|-----|-----------------------------|
| ☐   | 1\) DMO / Data Agent        |
| ☐   | 2\) Compliance Check        |
| ☐   | 3\) Re/Write Productivity   |
| ☐   | 4\) Agentic AI              |
| ☐   | 5\) RAG Document Extraction |
| ☐   | 6\) RAG and Auto Commentary |

**Has the model risk treatment for this classification been confirmed with the risk owner, and what did they say?**

\[confirmation and outcome\]

# 2. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

\[what the system does, in plain language\]

**Success criteria:**

\[what good looks like\]

**Explicit out of scope:**

- \[item\]

**User roles / personas:**

| **Role** | **How they differ from other roles** |
|----------|--------------------------------------|
| \[role\] | \[what makes this role distinct\]    |

**Functional requirements:**

> Every functional requirement must be testable. If a tester cannot write a pass or fail test against it, it is not a requirement yet: it is an intention.
> Keep each one atomic. One requirement, one behaviour. Do not narrate a usage scenario here: scenarios belong in the Usage Scenarios table, and each requirement traces back to the scenarios it serves.
> From Standard depth onward, write them in EARS form: While/When/If &lt;trigger or state&gt;, the &lt;system&gt; shall &lt;response&gt;.

| **ID** | **Requirement (EARS form)**                 | **Priority** | **Traces to** |
|--------|---------------------------------------------|--------------|---------------|
| FR-1   | \[While/When/If ..., the system shall ...\] | Must         | US-1          |

# 3. Domain & Data Model
> <strong>What it means:</strong> The nouns of the system: what objects it manages, how they relate, and how big the data gets.
> <strong>Example:</strong> Counterparty, Trade, Settlement Instruction. A Trade has one Counterparty and one or more Settlement Instructions.

**Core entities and key attributes:**

| **Entity** | **Key attributes** |
|------------|--------------------|
| \[entity\] | \[attributes\]     |

**Relationships and identity/uniqueness rules:**

\[how entities relate; what makes one instance unique\]

**Lifecycle / state transitions:**

\[the states a key entity moves through\]

**Data volume / scale assumptions:**

\[expected record counts, growth rate\]

# 4. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Usage scenarios:**

*Capture every distinct way the system is used, not just the main one. A pattern that only appears in a failure, a correction, or an audit still counts. Each functional requirement should trace back to at least one scenario here.*

| **ID** | **Scenario**                                | **Actor** | **Trigger**        | **Priority** |
|--------|---------------------------------------------|-----------|--------------------|--------------|
| US-1   | \[the primary usage pattern\]               | \[who\]   | \[what starts it\] | Primary      |
| US-2   | \[a secondary pattern\]                     | \[who\]   | \[what starts it\] | Secondary    |
| US-3   | \[a failure, correction, or audit pattern\] | \[who\]   | \[what starts it\] | Edge         |

**Critical user journey (step by step):**

\[walk the primary scenario end to end, from the user's first action to the outcome they need\]

**Error / empty / loading states:**

\[what the user sees when something goes wrong, when there is no data, or while waiting\]

**Accessibility or localization requirements:**

\[standards to meet, languages to support\]

# 5. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**                                      | **Target**       |
|--------|------------------------------------------------------|------------------|
| NFR-1  | \[e.g. response time\]                               | \[target value\] |
| NFR-2  | \[e.g. throughput, availability, or data residency\] | \[target value\] |
| NFR-3  | \[e.g. observability, or regulatory constraint\]     | \[target value\] |

**Security & access control:**

| **ID** | **Control**                         | **Requirement**                                                       |
|--------|-------------------------------------|-----------------------------------------------------------------------|
| SEC-1  | Data classification                 | \[Public / Internal / Confidential / Restricted\]                     |
| SEC-2  | Personal or client-identifying data | \[Yes: name the fields / No\]                                         |
| SEC-3  | Authentication                      | \[Corporate SSO, or bespoke with justification\]                      |
| SEC-4  | Authorization model                 | \[Role-based / attribute-based / record-level\]                       |
| SEC-5  | Access grant and revocation         | \[Who grants, who revokes, how fast revocation takes effect\]         |
| SEC-6  | Encryption at rest and in transit   | \[requirement, and any field needing more than the platform default\] |
| SEC-7  | Secrets handling                    | \[where stored, rotation policy. Never in code or repo config\]       |
| SEC-8  | Security audit logging              | \[what is logged, retention period, who may read it\]                 |
| SEC-9  | Pre-go-live security review         | \[pen test / threat model required? Who signs off?\]                  |
| SEC-10 | Segregation of duties               | \[can the builder or operator also approve output?\]                  |

# 6. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Other systems this depends on, if any:**

\[list, or "none"\]

**External services/APIs and their failure modes:**

| **Dependency** | **Failure mode / fallback behaviour**   | **Import/export format**  |
|----------------|-----------------------------------------|---------------------------|
| \[system\]     | \[what happens when it is unavailable\] | \[format, if applicable\] |

**Protocol / versioning assumptions:**

\[how a breaking change upstream is handled\]

# 7. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**The single most likely way this could fail:**

\[failure mode\]

**Negative scenarios:**

\[behaviour on invalid or unexpected input\]

**Known edge cases:**

| **ID** | **Description**      | **Expected behaviour**        |
|--------|----------------------|-------------------------------|
| EC-1   | \[the unusual case\] | \[what the system should do\] |

**Rate limiting / throttling and conflict resolution:**

\[limits on repeated actions; behaviour when two actors act on the same thing at once\]

# 8. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

**Technical constraints:**

\[language, storage, hosting mandated in advance\]

**Rejected alternatives:**

| **Alternative considered** | **Reason rejected** |
|----------------------------|---------------------|
| \[option\]                 | \[reason\]          |

# 9. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term** | **Single definitive meaning** |
|----------|-------------------------------|
| \[term\] | \[definition\]                |

**Avoided synonyms:**

\[terms not to use for the same concept, and why\]

**Cross-team consistency check:**

\[do other systems or teams use these terms differently? Note any conflict.\]

# 10. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                     | **Traces to** |
|--------|-----------------------------------|---------------|
| AC-1   | \[testable, pass/fail condition\] | FR-1          |

**Definition of Done checklist:**

- \[condition\]

**Traceability check, both directions:**

- Every functional requirement traces to at least one usage scenario. A requirement serving no scenario is a requirement nobody asked for.

- Every usage scenario has at least one functional requirement behind it. A scenario with no requirements is a usage pattern that was discussed and then quietly never built.

- Every functional requirement traces to at least one acceptance criterion. A requirement with no test is a requirement nobody will verify.

# 11. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question** | **Status** |
|--------|--------------|------------|
| 1      | \[question\] | Open       |

**Vague terms flagged for quantification:**

| **Vague term**    | **Where used** | **Proposed metric**       |
|-------------------|----------------|---------------------------|
| \[e.g. “robust”\] | \[section\]    | \[replace with a number\] |

**Final placeholder sweep:**

\[confirm no TODO or bracket placeholder remains before sign-off\]

# 12. AI Behavior & Validation Rules
> <strong>What it means:</strong> Not a generic business rule: this is specifically about correctness checks on model output, and jurisdiction- or context-conditional rules where an absent value is expected rather than an error.
> <strong>Example:</strong> An AI-generated client summary must never state a risk rating that does not appear in the source client file.

**Why AI:**

\[why this needs a model rather than deterministic logic\]

**Validation rules on model output:**

\[cross-field checks, tolerances\]

**Cost of a false positive vs a false negative:**

\[state the asymmetry; this shapes every threshold in Section 13\]

**Conditional / jurisdiction-specific rules:**

\[rules that vary by context, and what “expected absence” looks like, if applicable\]

# 13. Confidence & Human Review Routing
> <strong>What it means:</strong> For AI outputs that carry uncertainty: how sure the system is, and when to trust it automatically versus send it to a human.
> <strong>Example:</strong> A KYC field extracted with high certainty is auto-populated. A low-certainty one is routed to a compliance reviewer before the file can progress.

**Confidence signal:**

\[does the system emit a confidence score? Is it calibrated, or cosmetic?\]

**Auto-approve floor:**

\[threshold, per content/output type if they differ\]

**Flag-for-review floor:**

\[threshold\]

**Reviewer and SLA:**

\[who reviews flagged output, and within what time\]

**Mandatory human sign-off cases:**

\[any output that always requires a human regardless of confidence\]

# 14. Audit Trail & Provenance
> <strong>What it means:</strong> What must be recorded so any output can be traced back and defended later: its source, method, and how certain it was.
> <strong>Example:</strong> Each extracted figure records the source filing and page, the model and prompt version, and the confidence at the time, so it can be defended in a model validation review.

**Per-output record:**

\[what must be captured: source, method, model version, prompt version, confidence, timestamp\]

**Retention:**

\[how long, and where\]

**Re-validation on model change:**

\[what must be re-run before a new model or prompt version goes to production\]

**Regulatory framework(s) in scope:**

\[e.g. SR 11-7, FINMA 08/2024, EU AI Act, or “None”\]

# 15. Evaluation & Test Data
> <strong>What it means:</strong> The evidence needed to prove accuracy: what labelled data and verified answers are required, and which cases they must cover.
> <strong>Example:</strong> 200 annual reports with figures independently verified by two analysts, including filings with restatements and figures shown only in charts.

**Labelled examples required:**

\[count, and what they must cover\]

**Ground truth source:**

\[who verifies correctness\]

**Must include:**

\[edge cases, adversarial inputs, deliberate failure paths\]

**Refresh cadence and owner:**

\[how often the test set is revisited\]

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown, not a table, so it can be checked off directly in GitHub or by /speckit.clarify.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
- [ ] AI Use Case Classification is completed: Yes/No answered, not left blank
- [ ] If this is an AI feature: all four AI-specific sections (12-15) are completed, not left as placeholder text
