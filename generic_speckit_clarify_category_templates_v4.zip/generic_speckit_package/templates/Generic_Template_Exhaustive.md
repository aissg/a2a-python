**GENERIC SOFTWARE REQUIREMENTS SPECIFICATION**

**\[Project / Feature Name\]: Exhaustive**

*Mission-critical / regulated depth, reusable template, convert to Markdown for /speckit.specify*

**Document Control**

| **Version** | **Date**       | **Author**      | **Change Summary** |
|-------------|----------------|-----------------|--------------------|
| 0.1         | \[YYYY-MM-DD\] | \[name / role\] | Initial draft      |
|             |                |                 |                    |
|             |                |                 |                    |

**How to convert this document to Markdown for Spec Kit:**

> 1. Complete all sections below, then save this file as .docx (keep the built-in Heading 1/2 styles intact, do not retype section titles as plain text).
> 2. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 3. Save the result into your Spec Kit feature branch, e.g. specs/&lt;feature&gt;/spec.md.
> 4. Run /speckit.specify against spec.md, or paste its contents into the command directly.
> Note: if headings do not convert to # in step 2, re-save the .docx once through Word or LibreOffice first, since this normalizes the file for pandoc.

# First Interview Key Points
*Use this for the very first conversation, before anyone has agreed to build anything. Do not read the numbered questions in this catalogue aloud: a list intimidates people and turns a conversation into an interrogation. Instead hold a normal discussion that covers the points below, and let the recording or your notes fill in the Lightweight requirement document afterwards. These points are the Lightweight tier expressed as a conversation. Getting through them in about an hour gives a business analyst and a technical architect enough to size the work at a high level. Once the project is prioritised, work the Standard questions one by one; keep the Exhaustive set for full implementation.*

### Part A: The conversation, in the order it usually flows

- **Today's process:** How is this done today? Walk through the current workflow end to end, and what it produces at the end.

- **Pain points:** What goes wrong most often: errors, rework, delays, wasted effort? Ask for a recent concrete example, not a general grumble.

- **The goal, in a sentence:** What is the core goal, in one or two sentences? What would success look like, and how would they know it had been achieved?

- **The data:** What data is involved? Name it their way: documents, spreadsheets, datasets, feeds. Where does it come from, and which system is the source of truth?

- **What comes out, and where it goes:** What is the output, and where does it need to land: a screen, a spreadsheet, a file, another system? If it writes into something like an Excel sheet or a database, name that target and who owns it.

- **Roughly how fast:** About how quickly does a result need to come back for the main action? An approximate answer is fine at this stage.

- **The words that matter:** Which two or three terms here are most likely to be misunderstood, and does any of them already mean something different elsewhere in the firm?

- **What done looks like:** What single, checkable condition has to be true for this to count as done?

- **What's still open:** Which decisions are still genuinely open, the ones that would send the build down a different path depending on the answer?

### Part B: Assumption checks, where first interviews quietly go wrong
*These four are the assumptions clients most often carry into a first meeting unexamined. Each one, left unspoken, has derailed a real project. Surface them gently but explicitly before the conversation ends.*

- **The delivery surface:** How will people actually trigger this and see the result? Clients often assume an existing IT system will host it, or that a screen already exists. Confirm that assumption with the system owner, not just the business user. A GUI nobody agreed to build is a common surprise, and it changes the estimate completely.


# 0. Depth Selector
|                                            |                                                                                                               |
|--------------------------------------------|---------------------------------------------------------------------------------------------------------------|
| **Depth level**                            | Exhaustive                                                                                                    |
| **Rationale (required if not Exhaustive)** | N/A: Exhaustive is the recommended default.                                                                   |
| **When to use this tier**                  | Mission-critical, regulated, or multi-team system. Full rigor across all ten categories. Recommended default. |

## Interview Coverage Gaps
> This is a status check on the interview itself, not a section about the system. It exists so a gap in the answers cannot silently disappear into a 15-section document nobody rereads in full.
> After the interview, paste the Coverage Gaps rollup generated by the structuring prompt here. If every section was fully answered, write: "No coverage gaps. All sections addressed."
> Do not proceed to sign-off with an unresolved Not Asked row still in this table.

**Not Asked** = section not covered. **Partial** = section started but incomplete. Apply these colours to the Status column once populated.

| **Section**                 | **Status**              | **What's Missing**               |
|-----------------------------|-------------------------|----------------------------------|
| \[section number and name\] | \[Not Asked / Partial\] | \[what still needs to be asked\] |

# 1. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

\[what the system does, in plain language\]

**Success criteria:**

\[what good looks like\]

**Explicit out of scope:**

- \[item\]

**User roles / personas:**

| **Role** | **How they differ from other roles** |
|----------|--------------------------------------|
| \[role\] | \[what makes this role distinct\]    |

**Functional requirements:**

> Every functional requirement must be testable. If a tester cannot write a pass or fail test against it, it is not a requirement yet: it is an intention.
> Keep each one atomic. One requirement, one behaviour. Do not narrate a usage scenario here: scenarios belong in the Usage Scenarios table, and each requirement traces back to the scenarios it serves.
> From Standard depth onward, write them in EARS form: While/When/If &lt;trigger or state&gt;, the &lt;system&gt; shall &lt;response&gt;.

| **ID** | **Requirement (EARS form)**                 | **Priority** | **Traces to** |
|--------|---------------------------------------------|--------------|---------------|
| FR-1   | \[While/When/If ..., the system shall ...\] | Must         | US-1          |

# 2. Domain & Data Model
> <strong>What it means:</strong> The data this feature actually touches: what it is, where it lives, and how you reach it. Name it the way your team does, as datasets, tables, files, or feeds, not as abstract entities.
> <strong>Example:</strong> SEC filings dataset in the enterprise data mesh, read via SQL; a local sandbox copy of 50 filings provided for the spike, read from Parquet files with Python.

**Datasets in scope (name, key fields):**

| **Dataset / file / feed**         | **Key fields that matter here** | **Identifies a row by**           |
|-----------------------------------|---------------------------------|-----------------------------------|
| \[name as the team calls it\]     | \[the few fields used\]         | \[unique key or "generated"\]     |

**Location and access method:**

| **Dataset**     | **Location**                                      | **Access method**                                              | **Read / write**                       |
|-----------------|---------------------------------------------------|----------------------------------------------------------------|----------------------------------------|
| \[dataset\]     | \[mesh / warehouse / shared drive / sandbox\]     | \[SQL / Python / REST / company API / file drop / export\]     | \[read-only / writes back to ...\]     |

**Relationships and freshness:**

\[how datasets join and on which key; how fresh the data must be and whether it arrives live, by batch, or as a snapshot\]

**Data volume / scale assumptions:**

\[expected record counts today, growth rate over one to two years\]

# 3. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Usage scenarios:**

*Capture every distinct way the system is used, not just the main one. A pattern that only appears in a failure, a correction, or an audit still counts. Each functional requirement should trace back to at least one scenario here.*

| **ID** | **Scenario**                                | **Actor** | **Trigger**        | **Priority** |
|--------|---------------------------------------------|-----------|--------------------|--------------|
| US-1   | \[the primary usage pattern\]               | \[who\]   | \[what starts it\] | Primary      |
| US-2   | \[a secondary pattern\]                     | \[who\]   | \[what starts it\] | Secondary    |
| US-3   | \[a failure, correction, or audit pattern\] | \[who\]   | \[what starts it\] | Edge         |

**Critical user journey (step by step):**

\[walk the primary scenario end to end, from the user's first action to the outcome they need\]

**Error / empty / loading states:**

\[what the user sees when something goes wrong, when there is no data, or while waiting\]

**Accessibility or localization requirements:**

\[standards to meet, languages to support\]

# 4. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**                                      | **Target**       |
|--------|------------------------------------------------------|------------------|
| NFR-1  | \[e.g. response time\]                               | \[target value\] |
| NFR-2  | \[e.g. throughput, availability, or data residency\] | \[target value\] |
| NFR-3  | \[e.g. observability, or regulatory constraint\]     | \[target value\] |

**Security & access control:**

| **ID** | **Control**                         | **Requirement**                                                       |
|--------|-------------------------------------|-----------------------------------------------------------------------|
| SEC-1  | Data classification                 | \[Public / Internal / Confidential / Restricted\]                     |
| SEC-2  | Personal or client-identifying data | \[Yes: name the fields / No\]                                         |
| SEC-3  | Authentication                      | \[Corporate SSO, or bespoke with justification\]                      |
| SEC-4  | Authorization model                 | \[Role-based / attribute-based / record-level\]                       |
| SEC-5  | Access grant and revocation         | \[Who grants, who revokes, how fast revocation takes effect\]         |
| SEC-6  | Encryption at rest and in transit   | \[requirement, and any field needing more than the platform default\] |
| SEC-7  | Secrets handling                    | \[where stored, rotation policy. Never in code or repo config\]       |
| SEC-8  | Security audit logging              | \[what is logged, retention period, who may read it\]                 |
| SEC-9  | Pre-go-live security review         | \[pen test / threat model required? Who signs off?\]                  |
| SEC-10 | Segregation of duties               | \[can the builder or operator also approve output?\]                  |

# 5. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Other systems this depends on, if any:**

\[list, or "none"\]

**External services/APIs and their failure modes:**

| **Dependency** | **Failure mode / fallback behaviour**   | **Import/export format**  |
|----------------|-----------------------------------------|---------------------------|
| \[system\]     | \[what happens when it is unavailable\] | \[format, if applicable\] |

**Protocol / versioning assumptions:**

\[how a breaking change upstream is handled\]

# 6. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**The single most likely way this could fail:**

\[failure mode\]

**Negative scenarios:**

\[behaviour on invalid or unexpected input\]

**Known edge cases:**

| **ID** | **Description**      | **Expected behaviour**        |
|--------|----------------------|-------------------------------|
| EC-1   | \[the unusual case\] | \[what the system should do\] |

**Rate limiting / throttling and conflict resolution:**

\[limits on repeated actions; behaviour when two actors act on the same thing at once\]

# 7. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

**Technical constraints:**

\[language, storage, hosting mandated in advance\]

**Rejected alternatives:**

| **Alternative considered** | **Reason rejected** |
|----------------------------|---------------------|
| \[option\]                 | \[reason\]          |

# 8. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term** | **Single definitive meaning** |
|----------|-------------------------------|
| \[term\] | \[definition\]                |

**Avoided synonyms:**

\[terms not to use for the same concept, and why\]

**Cross-team consistency check:**

\[do other systems or teams use these terms differently? Note any conflict.\]

# 9. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                     | **Traces to** |
|--------|-----------------------------------|---------------|
| AC-1   | \[testable, pass/fail condition\] | FR-1          |

**Definition of Done checklist:**

- \[condition\]

**Traceability check, both directions:**

- Every functional requirement traces to at least one usage scenario. A requirement serving no scenario is a requirement nobody asked for.

- Every usage scenario has at least one functional requirement behind it. A scenario with no requirements is a usage pattern that was discussed and then quietly never built.

- Every functional requirement traces to at least one acceptance criterion. A requirement with no test is a requirement nobody will verify.

# 10. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question** | **Status** |
|--------|--------------|------------|
| 1      | \[question\] | Open       |

**Vague terms flagged for quantification:**

| **Vague term**    | **Where used** | **Proposed metric**       |
|-------------------|----------------|---------------------------|
| \[e.g. “robust”\] | \[section\]    | \[replace with a number\] |

**Final placeholder sweep:**

\[confirm no TODO or bracket placeholder remains before sign-off\]

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown, not a table, so it can be checked off directly in GitHub or by /speckit.clarify.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
