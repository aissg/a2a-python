**GENERIC QUESTION CATALOGUE**

**Clarify-Category Interview Questions**

*Domain-agnostic, organized by Spec Kit's own /speckit.clarify taxonomy, graded Lightweight / Standard / Exhaustive*

> This catalogue is deliberately generic: it applies to any software feature, not only AI features. It exists to prepare a coordinated update to /speckit.clarify's own taxonomy as a separate, later task.
> Section numbers and names match the ten categories in Spec Kit's clarify taxonomy exactly, so this catalogue can be diffed directly against the clarify prompt when that update happens.
> Grading key: [L] Lightweight (asked at all depths), [S] Standard (Standard and Exhaustive), [E] Exhaustive only.

## First Interview Key Points
*Use this for the very first conversation, before anyone has agreed to build anything. Do not read the numbered questions in this catalogue aloud: a list intimidates people and turns a conversation into an interrogation. Instead hold a normal discussion that covers the points below, and let the recording or your notes fill in the Lightweight requirement document afterwards. These points are the Lightweight tier expressed as a conversation. Getting through them in about an hour gives a business analyst and a technical architect enough to size the work at a high level. Once the project is prioritised, work the Standard questions one by one; keep the Exhaustive set for full implementation.*

### Part A: The conversation, in the order it usually flows

- **Today's process:** How is this done today? Walk through the current workflow end to end, and what it produces at the end.

- **Pain points:** What goes wrong most often: errors, rework, delays, wasted effort? Ask for a recent concrete example, not a general grumble.

- **The goal, in a sentence:** What is the core goal, in one or two sentences? What would success look like, and how would they know it had been achieved?

- **The data:** What data is involved? Name it their way: documents, spreadsheets, datasets, feeds. Where does it come from, and which system is the source of truth?

- **What comes out, and where it goes:** What is the output, and where does it need to land: a screen, a spreadsheet, a file, another system? If it writes into something like an Excel sheet or a database, name that target and who owns it.

- **Roughly how fast:** About how quickly does a result need to come back for the main action? An approximate answer is fine at this stage.

- **The words that matter:** Which two or three terms here are most likely to be misunderstood, and does any of them already mean something different elsewhere in the firm?

- **What done looks like:** What single, checkable condition has to be true for this to count as done?

- **What's still open:** Which decisions are still genuinely open, the ones that would send the build down a different path depending on the answer?

### Part B: Assumption checks, where first interviews quietly go wrong
*These four are the assumptions clients most often carry into a first meeting unexamined. Each one, left unspoken, has derailed a real project. Surface them gently but explicitly before the conversation ends.*

- **The delivery surface:** How will people actually trigger this and see the result? Clients often assume an existing IT system will host it, or that a screen already exists. Confirm that assumption with the system owner, not just the business user. A GUI nobody agreed to build is a common surprise, and it changes the estimate completely.

## First Interview Key Points
*Use this for the very first conversation, before anyone has agreed to build anything. Do not read the numbered questions in this catalogue aloud: a list intimidates people and turns a conversation into an interrogation. Instead hold a normal discussion that covers the points below, and let the recording or your notes fill in the Lightweight requirement document afterwards. These points are the Lightweight tier expressed as a conversation. Getting through them in about an hour gives a business analyst and a technical architect enough to size the work at a high level. Once the project is prioritised, work the Standard questions one by one; keep the Exhaustive set for full implementation.*

### Part A: The conversation, in the order it usually flows

- **Today's process:** How is this done today? Walk through the current workflow end to end, and what it produces at the end.

- **Pain points:** What goes wrong most often: errors, rework, delays, wasted effort? Ask for a recent concrete example, not a general grumble.

- **The goal, in a sentence:** What is the core goal, in one or two sentences? What would success look like, and how would they know it had been achieved?

- **The data:** What data is involved? Name it their way: documents, spreadsheets, datasets, feeds. Where does it come from, and which system is the source of truth?

- **What comes out, and where it goes:** What is the output, and where does it need to land: a screen, a spreadsheet, a file, another system? If it writes into something like an Excel sheet or a database, name that target and who owns it.

- **Roughly how fast:** About how quickly does a result need to come back for the main action? An approximate answer is fine at this stage.

- **The words that matter:** Which two or three terms here are most likely to be misunderstood, and does any of them already mean something different elsewhere in the firm?

- **What done looks like:** What single, checkable condition has to be true for this to count as done?

- **What's still open:** Which decisions are still genuinely open, the ones that would send the build down a different path depending on the answer?

### Part B: Assumption checks, where first interviews quietly go wrong
*These four are the assumptions clients most often carry into a first meeting unexamined. Each one, left unspoken, has derailed a real project. Surface them gently but explicitly before the conversation ends.*

- **The delivery surface:** How will people actually trigger this and see the result? Clients often assume an existing IT system will host it, or that a screen already exists. Confirm that assumption with the system owner, not just the business user. A GUI nobody agreed to build is a common surprise, and it changes the estimate completely.

## 1. Functional Scope & Behavior
- **\[L\]** What is the core goal of this feature, in one or two sentences?

- **\[L\]** What does success look like, and how would you know it was achieved?

- **\[L\]** What is explicitly out of scope for this piece of work?

- **\[L\]** Before we talk about the change: how is this done today? Walk me through the current process and what it produces.

- **\[L\]** What goes wrong most often today: errors, rework, misunderstandings, wasted effort? Can you give me a recent example?

- **\[S\]** If this replaces something that already exists: which parts of the current version do people really use and value, and which are rarely looked at? What could we drop without anyone missing it?

- **\[S\]** Who are the different types of users, and what does each of them do differently?

- **\[S\]** Is there anything one type of user must not be able to do that another can?

- **\[S\]** If we had to shrink the output to a fraction of its size, what absolutely must stay, and what is nice-to-have?

- **\[E\]** For each requirement, who is the one person who can confirm it is correct?

## 2. Domain & Data Model

- **\[L\]** What data does this read or produce? Name it the way your team does: datasets, tables, files, or feeds.

- **\[L\]** For each dataset, which few fields actually matter here, and which field tells one record apart from another?

- **\[S\]** Where does each dataset live? Enterprise data mesh, a governed warehouse, a shared drive, or a local sandbox copy provided for this work?

- **\[S\]** Is the same data available in more than one system? Which one is the source of truth, and why that one?

- **\[S\]** Is the data coming from an approved, official source? And is it used as-is, or changed in some way before this feature uses it?

- **\[S\]** How is each dataset accessed? SQL query, Python read, a REST or company-specific API, a file drop, or a manual export. Name the interface.

- **\[S\]** Is the access read-only, or does the feature write back? If it writes, to where, and who owns that target?

- **\[S\]** Does the feature just pass data through, or does it keep a copy somewhere: a folder, a database, or an object store?

- **\[S\]** How do the datasets connect? Which field links them, and can one record on one side match many on the other, like one filing with many line items?

- **\[S\]** How fresh does the data need to be, and how does it arrive: live query, scheduled batch, or a one-off snapshot?

- **\[S\]** What data quality problems exist in the source today: missing fields, stale values, duplicates, or systems contradicting each other? Which do we have to live with, and which must be fixed?

- **\[S\]** Does the data include client-identifying details or other restricted information? If so, which fields?

- **\[E\]** What is the expected data volume today, and the expected growth rate over the next one to two years?

## 3. Interaction & UX Flow
- **\[L\]** Walk through the single most important user journey, step by step, from the user's first action to the outcome they need.

- **\[S\]** Beyond the main flow, how else is this used? Things that only happen during a failure, a correction, or an audit count too.

- **\[S\]** For each of those: who does it, what sets it off, and is it everyday use or a rare case?

- **\[E\]** Did anyone describe a way of using this that never made it into a requirement? Something mentioned in an interview that nobody ever built.

- **\[S\]** What should the user see the very first time, before there is any data to show?

- **\[S\]** Can users move to other screens while they wait for the action to finish, or must they stay put?

- **\[S\]** Does this need its own screen, or would another channel do: Teams, a Copilot agent, a chatbot, a downloaded file, or output dropped in a folder?

- **\[S\]** What does the user see while something is loading, and how long is too long to wait without feedback?

- **\[S\]** What does the user see when an action fails? Is the error message specific enough to act on?

- **\[E\]** Are there accessibility standards this must meet (e.g. WCAG level)?

- **\[E\]** Does this need to support more than one language or locale? If so, which, and are there any that read right-to-left?

## 4. Non-Functional Quality Attributes
- **\[L\]** What is an acceptable response time for the main user action, at least approximately?

- **\[S\]** How many people will use this at the same time at peak, and how much work must it get through?

- **\[S\]** What availability is required, and during which hours or windows does that apply?

- **\[S\]** Where must data reside, and are there regions or environments it must never leave?

- **\[E\]** What logging, metrics, or tracing must exist so an incident can be diagnosed after the fact?

- **\[E\]** Are there regulatory or compliance constraints that apply, even indirectly, through downstream consumers of this system's output?

- **\[S\]** SECURITY: What is the data classification of the information this system handles? Public, Internal, Confidential, or Restricted. If more than one, name the highest.

- **\[S\]** SECURITY: Does the system process personal data or client-identifying information? Name the specific fields, not just yes or no.

- **\[S\]** SECURITY: How do users authenticate? Corporate SSO, or something bespoke? A bespoke mechanism needs an explicit justification, not a default.

- **\[S\]** SECURITY: What is the authorization model? Role-based, attribute-based, or record-level? Be specific: “only their own portfolios” is record-level, not role-based, and they are built differently.

- **\[S\]** SECURITY: Who grants and revokes access, and how quickly does a revocation actually take effect? At the next login, or immediately?

- **\[E\]** SECURITY: What are the encryption requirements, at rest and in transit? Are there fields requiring encryption beyond the platform default?

- **\[E\]** SECURITY: How are secrets stored and rotated? API keys, credentials, connection strings. They must never live in code or in a config file in the repository.

- **\[E\]** SECURITY: What is logged for security purposes: who accessed what, when, and from where? How long is that log retained, and who can read it?

- **\[E\]** SECURITY: Is a penetration test, threat model, or security review required before go-live? Who signs it off?

- **\[E\]** SECURITY: Is there a segregation-of-duties constraint? Can the person who builds or operates this system also approve its output, or must those be different people?

## 5. Integration & External Dependencies
- **\[L\]** Does this feature depend on any other system, upstream or downstream? Name each one, or state “none.”

- **\[S\]** For each external dependency, what happens when it is slow, unavailable, or returns an error?

- **\[S\]** Is any system this depends on due to be changed, migrated, or switched off in the near future? Building on a platform that is already being retired is something we need to know now.

- **\[S\]** What data import or export formats must be supported?

- **\[E\]** What protocol or API version assumptions are being made, and how is a breaking change from an upstream dependency handled?

- **\[E\]** Is there a fallback or degraded mode when a dependency is down, or does the whole feature stop working?

## 6. Edge Cases & Failure Handling
- **\[L\]** What is the single most likely way this feature could fail or be misused?

- **\[S\]** What should happen when a required input is missing, wrong, or out of range?

- **\[S\]** What happens at unusually busy times, or when someone repeats the same action rapidly?

- **\[E\]** What happens when two users act on the same record at the same time? Is there a conflict-resolution rule, or is the second action simply rejected?

- **\[E\]** What are the known edge cases from any existing manual process this feature replaces?

## 7. Constraints & Tradeoffs
- **\[S\]** Are there technical constraints fixed in advance: a mandated language, database, hosting environment, or platform?

- **\[S\]** Are there constraints from outside engineering entirely: budget, timeline, or a vendor contract already in place?

- **\[E\]** What other approaches were considered and rejected, and why?

- **\[E\]** Are there tradeoffs being made on purpose, like simple over complete or fast over cheap, that we should write down for future readers?

## 8. Terminology & Consistency
- **\[L\]** Which two or three terms here are most likely to be misunderstood, and what exactly does each one mean?

- **\[L\]** Is there a term used elsewhere in the organization that sounds like one used here but means something different?

- **\[S\]** Are there synonyms that should be deliberately avoided in this project, because they are ambiguous or already mean something else elsewhere?

- **\[S\]** Does this feature's data eventually feed, or get consumed by, another team's system? If so, do they use the same terms the same way?

- **\[E\]** Is there an official glossary or data dictionary this must follow, whether company-wide, regulatory, or industry? Do our terms match it, and if not, is the difference written down?

- **\[E\]** If a term's meaning changed during the project, did we keep a note of the old meaning rather than silently replacing it?

## 9. Completion Signals
- **\[L\]** What specific, testable condition must be true for this to be considered done?

- **\[S\]** For each functional requirement, what is the exact pass or fail test?

- **\[S\]** Is there a Definition of Done checklist beyond the individual acceptance criteria (e.g. documentation updated, monitoring in place)?

- **\[E\]** Does every requirement have at least one test that proves it was met? Is there any requirement we could not verify?

## 10. Misc / Placeholders
- **\[L\]** Which open questions, if answered one way versus another, would send the build down a different path? List the decisions still outstanding that the design genuinely hinges on.

- **\[E\]** Once the requirements are signed off, how are later changes handled, and who can approve a change to scope, controls, data use, or model behaviour?

- **\[S\]** Wherever the spec says “robust,” “intuitive,” “fast,” or “scalable”: what is the actual number or test behind each one?

- **\[E\]** Are there any remaining TODO markers, bracketed placeholders, or "TBD" notes anywhere in the specification? List them; do not let any reach sign-off unresolved.

## Depth Grading Summary
*Counts are cumulative. Standard includes every Lightweight question. Exhaustive includes every Standard question.*

| **\#** | **Category**                        | **Lightweight** | **Standard** | **Exhaustive** |
|--------|-------------------------------------|-----------------|--------------|----------------|
| 1      | Functional Scope & Behavior         | 5               | 9            | 10             |
| 2      | Domain & Data Model                 | 2               | 12           | 13             |
| 3      | Interaction & UX Flow               | 1               | 8            | 11             |
| 4      | Non-Functional Quality Attributes   | 1               | 9            | 16             |
| 5      | Integration & External Dependencies | 1               | 4            | 6              |
| 6      | Edge Cases & Failure Handling       | 1               | 3            | 5              |
| 7      | Constraints & Tradeoffs             | 0               | 2            | 4              |
| 8      | Terminology & Consistency           | 2               | 4            | 6              |
| 9      | Completion Signals                  | 1               | 3            | 4              |
| 10     | Misc / Placeholders                 | 1               | 2            | 4              |
|        | Total questions asked               | 15              | 56           | 79             |
