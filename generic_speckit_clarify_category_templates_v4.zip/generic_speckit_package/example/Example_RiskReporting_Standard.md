**GENERIC SOFTWARE REQUIREMENTS SPECIFICATION**

**Portfolio Risk Exposure Reporting: Standard**

*Worked example, production depth, non-regulated framing, GUI drill-down application*

**Document Control**

| **Version** | **Date**   | **Author**                         | **Change Summary**                       |
|-------------|------------|------------------------------------|------------------------------------------|
| 0.1         | 2026-07-08 | R. Okafor, Risk Systems            | Initial draft                            |
| 0.2         | 2026-07-11 | R. Okafor, Risk Systems            | Added reconciliation tolerance, glossary |
| 1.0         | 2026-07-12 | S. Alvarez, Head of Risk Reporting | Approved for build                       |

**How to convert this document to Markdown for Spec Kit:**

> 1. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 2. Save into the Spec Kit feature branch, e.g. specs/risk-exposure-reporting/spec.md.
> 3. Run /speckit.specify against spec.md.

# 0. Depth Selector
|                           |                                                                                                                                                                                                                                                                              |
|---------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **Depth level**           | Standard                                                                                                                                                                                                                                                                     |
| **Rationale**             | Production, internal-only reporting tool consumed by the risk office. Read-only; no trade execution. Not regulated as a standalone system, though its output feeds regulatory risk reports produced elsewhere, which is why reconciliation tolerance is specified precisely. |
| **When to use this tier** | Production work, non-regulated.                                                                                                                                                                                                                                              |

## Interview Coverage Gaps
> Status check on the interview itself, not a section about the system. Both gaps below are non-blocking for this release and are tracked as open questions in Section 10.

**Not Asked** = section not covered. **Partial** = section started but incomplete.

| **Section**                      | **Status** | **What's Missing**                                                                                                                          |
|----------------------------------|------------|---------------------------------------------------------------------------------------------------------------------------------------------|
| 1. Functional Scope & Behavior   | Partial    | Whether Portfolio Managers get an anonymized cross-manager benchmarking view is undecided (open question 1). Does not affect current scope. |
| 6. Edge Cases & Failure Handling | Partial    | Concurrent-edit behaviour not discussed. The release is read-only, so no conflict path exists yet. Revisit when a write path is added.      |

# 1. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

Give risk officers a self-service way to see exposure by portfolio and by position, without waiting on an ad hoc analyst report.

**Success criteria:**

A risk officer can go from the portfolio list to a specific position's risk contribution in 3 clicks or fewer.

**Explicit out of scope:**

- No order execution or trade booking. This is read-only reporting.

- No what-if or scenario simulation in this phase. Deferred to a future phase.

**User roles / personas:**

| **Role**            | **How they differ from other roles**                                            |
|---------------------|---------------------------------------------------------------------------------|
| Risk Officer        | Can view and drill into every portfolio across the firm.                        |
| Portfolio Manager   | Can view and drill into only the portfolios they manage.                        |
| Compliance Reviewer | Read-only across all portfolios, with every drill-down action logged for audit. |

**Functional requirements:**

| **ID** | **Requirement (EARS form)**                                                                                                                                 | **Priority** | **Traces to**    |
|--------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------|------------------|
| FR-1   | When a user opens the portfolio view, the system shall display a filterable list of portfolios showing name, manager, and total market value.               | Must         | US-1, US-2, US-4 |
| FR-2   | When a user selects a portfolio, the system shall display its position list sorted by risk contribution descending.                                         | Must         | US-1, US-2       |
| FR-3   | When a user selects a position, the system shall display its risk factor breakdown including a historical trend chart.                                      | Should       | US-1             |
| FR-4   | Where the signed-in user holds the Portfolio Manager role, the system shall restrict the portfolio list and every drill-down to the portfolios they manage. | Must         | US-2             |
| FR-5   | When a user requests an export of the current position table, the system shall produce a CSV file of the rows currently displayed.                          | Should       | US-3             |

# 2. Domain & Data Model
> <strong>What it means:</strong> The data this feature actually touches: what it is, where it lives, and how you reach it.
> <strong>Example:</strong> Positions and risk factors from the risk warehouse, read via SQL; reference data for legal entities from a shared service.

**Datasets in scope (name, key fields):**

| **Dataset / file / feed** | **Key fields that matter here**                      | **Identifies a row by**       |
|---------------------------|------------------------------------------------------|-------------------------------|
| Positions dataset         | portfolio, instrument, market value, risk factor     | portfolio + instrument id     |
| Risk factor breakdown     | risk factor, contribution, as-of date                | position + risk factor        |
| Portfolio reference       | portfolio id, name, manager                          | portfolio id                  |

**Location and access method:**

| **Dataset**               | **Location**                       | **Access method** | **Read / write** |
|---------------------------|------------------------------------|-------------------|------------------|
| Positions dataset         | Risk data warehouse (governed)     | SQL query         | Read-only        |
| Risk factor breakdown     | Risk data warehouse (governed)     | SQL query         | Read-only        |
| Portfolio reference       | Reference data service             | REST API          | Read-only        |

**Source of truth:**

The risk warehouse is the authoritative source for positions and risk factors; the front-office book is not read directly, to avoid two systems disagreeing on the same figure.

**Relationships and freshness:**

One portfolio holds many positions, and one position decomposes into many risk factors, both one-to-many joined on portfolio and position ids. Data is refreshed by the overnight risk batch; the report reads the most recent completed run, never a partial one.

**Data quality issues in the source:**

Known issues: positions can arrive before their reference data on the first day of a new portfolio, showing a blank manager; stale risk factors from a failed overnight run must be visibly marked, not shown as current.

# 3. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Usage scenarios:**

*Capture every distinct way the system is used, not just the main one. A pattern that only appears in a failure, a correction, or an audit still counts. Each functional requirement should trace back to at least one scenario here.*

| **ID** | **Scenario**                                                                                        | **Actor**         | **Trigger**                              | **Priority** |
|--------|-----------------------------------------------------------------------------------------------------|-------------------|------------------------------------------|--------------|
| US-1   | Review firm-wide exposure by drilling from the portfolio list to a position's risk factor breakdown | Risk Officer      | Start-of-day risk review                 | Primary      |
| US-2   | Review exposure for own portfolios only, before a trade decision                                    | Portfolio Manager | Ad hoc check during the trading day      | Secondary    |
| US-3   | Export the current position table for analysis outside the tool                                     | Risk Officer      | Figures needed for a report or a meeting | Secondary    |
| US-4   | Open the portfolio list after the overnight risk recalculation failed                               | Risk Officer      | Nightly batch did not complete           | Edge         |

**Critical user journey:**

Risk officer logs in, sees the portfolio list filterable by manager and by total market value, selects a portfolio, sees its position table sorted by risk contribution descending, selects a position, and sees its risk factor breakdown including a historical VaR trend chart.

**Error / empty / loading states:**

- A portfolio with zero open positions shows “No open positions,” not an empty table.

- If the nightly risk recalculation failed, the portfolio list shows a “Data as of \[last successful date\]” banner rather than blank risk figures.

- While the position table is loading, show a skeleton table, not a blank page.

**Accessibility or localization requirements:**

WCAG 2.1 AA. Every chart element carries a screen-reader label, since risk data is presented visually by default.

**Delivery surface:**

A dedicated read-only web view for risk officers and portfolio managers, reached through the existing risk portal's navigation rather than a standalone application.

# 4. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**                                             | **Target**                                                                                    |
|--------|-------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
| NFR-1  | Portfolio list load time, up to 500 portfolios              | Under 2 seconds                                                                               |
| NFR-2  | Drill-down to position detail                               | Under 1 second                                                                                |
| NFR-3  | Scalability                                                 | Support growth to 2,000 portfolios without redesign                                           |
| NFR-4  | Availability, trading hours (7am to 7pm local)              | 99.5 percent                                                                                  |
| NFR-5  | Reconciliation accuracy vs. official end-of-day risk system | Within 0.1 percent; breach blocks nightly publish and pages the on-call risk systems engineer |

# 5. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Other systems this depends on:**

| **Dependency**                                            | **Failure mode / fallback behaviour**                                                               | **Import/export format** |
|-----------------------------------------------------------|-----------------------------------------------------------------------------------------------------|--------------------------|
| Internal risk engine (nightly VaR, beta, volatility feed) | If late or failed, UI shows yesterday's figures with a stale-data flag rather than blocking access. | Internal REST API        |
| Accounting / custody position feed                        | If unavailable, the affected portfolios are marked stale; no partial position lists are shown.      | Internal REST API        |

**Protocol / versioning assumptions:**

Risk engine data is consumed via a versioned internal REST API. The system must support a dual-read period across the API's next major version, not a hard cutover.

# 6. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**Negative scenarios:**

A portfolio is reassigned to a new manager mid-day. The previous manager loses access immediately, not at their next login.

**Rate limiting / throttling and conflict resolution:**

Bulk export of all 500-plus portfolios is throttled to avoid overloading the reporting database during market hours. No conflict resolution is needed for concurrent viewing, since the system is read-only.

# 7. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

**Technical constraints:**

Must integrate with the existing internal risk engine's REST API. No new risk calculation engine is to be introduced.

**Rejected alternatives:**

| **Alternative considered**              | **Reason rejected**                                                                                                                        |
|-----------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------|
| Real-time (intraday) risk recalculation | Cost and complexity not justified for phase 1; nightly batch matches the current regulatory reporting cadence. Deferred to a future phase. |

# 8. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term**      | **Single definitive meaning**                                                                         |
|---------------|-------------------------------------------------------------------------------------------------------|
| Exposure      | The market value of a position, expressed in base currency.                                           |
| VaR           | Value at Risk at 95 percent confidence, 1-day horizon, unless another horizon is explicitly labelled. |
| Concentration | A single position's percentage share of total portfolio market value.                                 |

**Avoided synonyms:**

“Risk” is never used alone as a field label; it is always qualified (VaR, beta, concentration), since “risk” on its own is ambiguous across teams.

**Cross-team consistency check:**

Finance's general ledger uses “exposure” to mean notional value, not market value. This is a genuine conflict with this system's definition and is called out explicitly on every exported report to avoid a reconciliation dispute.

# 9. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                                                                                                               | **Traces to** |
|--------|-----------------------------------------------------------------------------------------------------------------------------|---------------|
| AC-1   | Filtering the portfolio list by manager updates the list in under 1 second.                                                 | FR-1          |
| AC-2   | From the portfolio list, a risk officer reaches the top 5 risk-contributing positions in 2 clicks or fewer.                 | FR-2          |
| AC-3   | A Portfolio Manager account cannot view any portfolio outside their assigned list, verified by attempted direct URL access. | FR-4          |

**Definition of Done checklist:**

- Reconciliation report matches the official risk system to within 0.1 percent across a full month of daily snapshots.

- Stale-data banner verified to appear correctly on a simulated feed failure.

**Traceability:**

FR-1 to FR-5 each map to at least one acceptance criterion above or to a Definition of Done item.

# 10. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question**                                                                                         | **Status**                |
|--------|------------------------------------------------------------------------------------------------------|---------------------------|
| 1      | Should Portfolio Managers see other managers' portfolios in aggregate, anonymized, for benchmarking? | Open, deferred to phase 2 |

**Vague terms flagged for quantification:**

| **Vague term**                 | **Where used**            | **Proposed metric**                                           |
|--------------------------------|---------------------------|---------------------------------------------------------------|
| “The dashboard should be fast” | Original business request | Resolved: see the 2-second and 1-second targets in Section 4. |

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown, not a table, so it can be checked off directly in GitHub or by /speckit.clarify.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
