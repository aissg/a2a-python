**GENERIC SOFTWARE REQUIREMENTS SPECIFICATION**

**Portfolio Risk Exposure Reporting: Lightweight**

*Worked example, PoC / spike depth, GUI drill-down application*

**Document Control**

| **Version** | **Date**   | **Author**              | **Change Summary**         |
|-------------|------------|-------------------------|----------------------------|
| 0.1         | 2026-06-20 | R. Okafor, Risk Systems | Initial draft, spike scope |

**How to convert this document to Markdown for Spec Kit:**

> 1. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 2. Save into the Spec Kit feature branch, e.g. specs/risk-exposure-reporting/spec.md.
> 3. Run /speckit.specify against spec.md.

# 0. Depth Selector
|                           |                                                                                                                                                       |
|---------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|
| **Depth level**           | Lightweight                                                                                                                                           |
| **Rationale**             | Prove the portfolio-to-position drill-down concept is usable before committing to a full production build with live data feeds and role-based access. |
| **When to use this tier** | Internal spike or proof of concept.                                                                                                                   |

## Interview Coverage Gaps
> Status check on the interview itself, not a section about the system. The gaps below are acceptable at Lightweight depth and must be closed before any production build.

**Not Asked** = section not covered. **Partial** = section started but incomplete.

| **Section**                            | **Status** | **What's Missing**                                                                                                                          |
|----------------------------------------|------------|---------------------------------------------------------------------------------------------------------------------------------------------|
| 4. Non-Functional Quality Attributes   | Partial    | Response time agreed. Concurrent-user load and availability were not discussed. Acceptable for a spike, required before a production build. |
| 5. Integration & External Dependencies | Partial    | Confirmed as none for the spike. The live position feed this would eventually read has not been identified.                                 |
| 7. Constraints & Tradeoffs             | Not Asked  | Out of scope at Lightweight depth. To be covered if the spike is promoted to Standard.                                                      |

# 1. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

Test whether a simple drill-down UI lets a risk officer find a portfolio's largest position without training.

**Success criteria:**

A first-time user finds the top position in a sample portfolio within 30 seconds, unassisted.

**Explicit out of scope:**

- No live data feed. Uses a static sample data file.

- No export.

- No multi-user login or access control.

**Functional requirements:**

| **ID** | **Requirement**                                                                                        | **Priority** |
|--------|--------------------------------------------------------------------------------------------------------|--------------|
| FR-1   | System MUST display a list of 5 sample portfolios with name and total market value.                    | Must         |
| FR-2   | System MUST allow drill-down from a portfolio to its position list, sorted by market value descending. | Must         |

# 2. Domain & Data Model
> <strong>What it means:</strong> The data this feature actually touches: what it is, where it lives, and how you reach it.
> <strong>Example:</strong> Positions and risk factors from the risk warehouse, read via SQL; reference data for legal entities from a shared service.

**Datasets in scope (name, key fields):**

| **Dataset / file / feed** | **Key fields that matter here**                      | **Identifies a row by**       |
|---------------------------|------------------------------------------------------|-------------------------------|
| Positions dataset         | portfolio, instrument, market value, risk factor     | portfolio + instrument id     |
| Risk factor breakdown     | risk factor, contribution, as-of date                | position + risk factor        |
| Portfolio reference       | portfolio id, name, manager                          | portfolio id                  |

# 3. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Usage scenarios:**

*Capture every distinct way the system is used, not just the main one. A pattern that only appears in a failure, a correction, or an audit still counts. Each functional requirement should trace back to at least one scenario here.*

| **ID** | **Scenario**                                                                 | **Actor**                       |
|--------|------------------------------------------------------------------------------|---------------------------------|
| US-1   | Find a portfolio's largest position by drilling down from the portfolio list | Risk officer (test participant) |
| US-2   | Open a portfolio that has no positions                                       | Risk officer (test participant) |

**Critical user journey:**

User opens the app, sees the 5 sample portfolios, clicks one, and sees its positions sorted with the largest market value first.

**Delivery surface:**

A dedicated read-only web view for risk officers and portfolio managers, reached through the existing risk portal's navigation rather than a standalone application.

# 4. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**              | **Target**      |
|--------|------------------------------|-----------------|
| NFR-1  | Response time for any screen | Under 3 seconds |

# 5. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Other systems this depends on:**

None at this stage. Sample data is loaded from a static local file, not a live feed.

# 6. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**The single most likely way this could fail:**

A portfolio with zero positions is selected and the position view breaks, instead of showing an empty state.

# 7. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

*\[Not required at Lightweight depth.\]*

# 8. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term** | **Single definitive meaning**                               |
|----------|-------------------------------------------------------------|
| Exposure | The market value of a position, expressed in base currency. |

# 9. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                                                                                                                        | **Traces to** |
|--------|--------------------------------------------------------------------------------------------------------------------------------------|---------------|
| AC-1   | In an informal test with 3 people unfamiliar with the tool, each finds the largest position in a sample portfolio within 30 seconds. | FR-1, FR-2    |

# 10. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question**                                                                | **Status** |
|--------|-----------------------------------------------------------------------------|------------|
| 1      | Should the spike use real archived portfolio data, or fully synthetic data? | Open       |

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown, not a table, so it can be checked off directly in GitHub or by /speckit.clarify.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
