**BANKING TECHNICAL REQUIREMENTS SPECIFICATION**

**Counterparty Exposure Weekly Report: Standard**

*Production planning depth. A working session with stakeholders, about a day. Sufficient for production architecture planning.*

**Document Control**

| **Version** | **Date**         | **Author**       | **Change Summary** |
|-------------|------------------|------------------|--------------------|
| 0.1 | 2026-06-15 | J. Brunner, Business Analyst | First draft from interview notes |
| 0.2 | 2026-07-06 | J. Brunner, Business Analyst | Reworked after the prototype readout; MVP scope agreed |
| 1.0 | 2026-07-20 | J. Brunner, Business Analyst | Sign-off version for the requirements gate |

**Approvals and Gate Sign-off**

| **Gate**             | **Role**             | **Name**   | **Date**         | **Decision**                            |
|----------------------|----------------------|------------|------------------|-----------------------------------------|
| Requirements review | Head of Counterparty Risk Reporting | C. Weber | 2026-07-20 | Approved |
| Portal delivery commitment | Risk Portal Product Owner | P. Gasser | 2026-07-21 | Approved |

**Depth and Applicability**

| **Field**       | **Value**    |
|-----------------|--------------|
| Depth level     | Standard     |
| Track                | Generic |
| AI / ML feature      | No |
| Rationale            | Internal report, single legal entity, and the analysts still review before anything is published. Exhaustive becomes mandatory when the report is published to the committee without a full manual rebuild as backstop. |
| Questions answered   | 87 of 92 Standard questions resolved; 5 recorded as gaps |
| When to use this tier| Production, non-regulated, once the project is prioritised. |

**How to convert this document to Markdown for Spec Kit:**

> 1\) Convert with pandoc: pandoc -t markdown "<this-file>.docx" -o spec.md
> 2\) Save into the Spec Kit feature branch, e.g. specs/<feature>/spec.md.
> 3\) Run /speckit.clarify against it before /speckit.plan.

## Interview Coverage Gaps
> Status check on the interview itself, not a section about the system. Complete this before the document is treated as finished.

**Not Asked** = section not covered. **Partial** = section started but incomplete.

| **Section**                   | **Status**                | **What's Missing**            |
|-------------------------------|---------------------------|-------------------------------|
| 11. Failure & Edge Cases | Partial | Rerun-during-review behaviour agreed verbally; wording to be confirmed by the lead analyst |

**Not relevant to this use case**

| **#** | **Question or area**                   | **Why not relevant**                                                 |
|-------|----------------------------------------|----------------------------------------------------------------------|
| 1 | Cross-border transfer and residency exceptions | All processing stays in the bank's risk environment |
| 2 | Localisation of the interface | The reporting team and the committee work in English |

**Review findings**

| **Finding**                                                        | **Where**     | **Resolution**                            |
|--------------------------------------------------------------------|---------------|-------------------------------------------|
| “Early enough on Monday” in the interview | 1 | Drafted report ready by 06:00, review complete for the 12:00 committee deadline |
| “Matches the manual report” without a tolerance | 13 | Every figure equal after rounding to the reporting unit; any difference listed |

# Part A: Context

## 1. Purpose & Current State
> <strong>What it means:</strong> Why this piece of work exists at all: how the job is done today, what goes wrong with it, and what is meant to change.
> <strong>Example:</strong> Credit officers key approval authority by hand from a report, taking about three hours a week and producing occasional transcription errors. The aim is to calculate it automatically and leave the officer to check.

**Problem statement:**

Three risk analysts spend most of every Monday assembling the weekly counterparty exposure report by hand from a warehouse extract. The work exists to generate the report automatically and leave the analysts to review it, so Monday is spent on analysis rather than assembly.

**How it is done today:**

The warehouse extract lands at 02:00 Monday. Each analyst copies their portfolios into the master spreadsheet, applies netting and collateral adjustments, reconciles totals against the previous week, and pastes the tables into the report document. The report covers about 1,900 counterparties and is due to the credit risk committee by 12:00 Monday. Assembly takes each analyst around six hours.

**What goes wrong today:**

Manual assembly produces copy and formula errors under time pressure. In April a netting set was double-counted during a paste, overstating one counterparty's exposure; the figure reached the committee, triggered a limit breach investigation, and took two days to unwind. Reconciliation breaks delay the report roughly one Monday in four.

**What changes:**

The report is generated from the extract without manual assembly. Analysts open a drafted report, review the movements and exceptions, and publish. Target: analyst time falls from six hours of assembly to under one hour of review, and the 12:00 deadline is met every week the extract arrives on time.

**Terms that must not be misread:**

Exposure means net exposure after netting and collateral, not gross. Counterparty means the legal entity group under the master agreement, not the individual trading entity. Breach means an exposure above the approved limit, not merely close to it.

## 2. Scope & Stakeholders
> <strong>What it means:</strong> What is being built and for whom, where the line around this work is drawn, and who may and may not do what.
> <strong>Example:</strong> Calculate and display approval authority for corporate credit requests. Out of scope: changing the authority policy itself. A credit officer may view and submit; only a delegated approver may override.

**Core goal:**

Generate the weekly counterparty exposure report from the warehouse extract, faithful to the agreed netting and collateral rules, in time for analyst review before the 12:00 Monday committee deadline.

**In scope:**

Automated generation of the full report for all portfolios, a review screen in the risk portal showing week-on-week movements and exceptions, and publication of the reviewed report to the committee folder.

**Explicitly out of scope:**

The exception workflow for reconciliation breaks is deferred to the production iteration: at MVP a break holds the report for manual handling. Changing the netting rules is rejected. Intraday or daily reporting is rejected: the committee cycle is weekly.

**Deployment target for this iteration:**

|       | **Target**                                     |
|-------|------------------------------------------------|
| ☐     | PoC: throwaway, no production path             |
| ☒     | MVP: user-facing, limited support              |
| ☐     | Production: fully IT-supported, formal SLA     |

**Roles:**

| **Role**   | **What they do**        | **What they must NOT be able to do**     |
|------------|-------------------------|------------------------------------------|
| Risk analyst | Reviews their portfolio sections; corrects and marks reviewed | Must not publish the report |
| Lead analyst | Publishes when all sections are reviewed; sees all corrections | Must not mark another analyst's section reviewed |
| Portal administrator | Manages entitlements through the standard process | Must not hold an analyst or lead role at the same time |

**Requirement owners:**

Report content and netting rules: head of counterparty risk reporting. Data and warehouse: the risk data warehouse owner. Portal delivery: the risk portal product owner.

# Part B: Behaviour

## 3. User Scenarios
> <strong>What it means:</strong> The distinct ways someone actually uses this, ordered by value. Each scenario must stand on its own: if only the first were built, there should still be something worth using. Every functional requirement traces back to one of these. Describe the journey here; the surface it runs on belongs in Section 6.
> <strong>Example:</strong> A credit officer checks approval authority for a single request before submitting it. Separately, a team lead reviews every request breaching authority at end of day.

**Usage scenarios:**

| **ID**   | **Scenario**                                                                                                     | **Actor**         | **Priority**                               |
|----------|------------------------------------------------------------------------------------------------------------------|-------------------|--------------------------------------------|
| US-1 | Review the drafted report: work the movements and exceptions, correct, mark reviewed, publish | Risk analyst / lead analyst | P1 |
| US-2 | Work the exception list: ungrouped counterparties and reconciliation flags, source open alongside | Risk analyst | P2 |
| US-3 | Handle a held run: see the reason, decide fallback or wait, record the decision | Lead analyst | P3 |

**Scenario detail:**

**US-1: Review and publish the drafted report  (Priority: P1)**

On Monday morning I open the drafted report in the portal. The movements against last week are highlighted and the exceptions are listed. I work through my portfolios, check anything flagged, correct where needed, and mark my section reviewed. When all sections are reviewed, the lead analyst publishes.

*Why this priority:* It replaces the six hours of assembly that produce the errors and the delays. Every other scenario supports or audits this one.

*Independent test:* Generate and review one portfolio's section for one week: the drafted tables, the movement highlights, and a reviewed section matching the source extract. That alone removes that analyst's assembly work.

*Acceptance scenarios:* Given a complete extract, When generation runs, Then every portfolio section is drafted with movements and exceptions listed. Given a drafted section the analyst corrects, When they mark it reviewed, Then the correction and reviewer are recorded. Given an incomplete extract, When generation runs, Then the report is held with a stated reason and nothing is published.

*Detail is shown for US-1, the priority scenario. The remaining scenarios follow the same pattern; their acceptance paths are carried in Section 13.*

## 4. Functional Requirements
> <strong>What it means:</strong> What the system must do, written so each statement can be tested pass or fail, and traced back to a way someone actually uses the system.
> <strong>Example:</strong> When a credit request is submitted, the system shall calculate the approval authority from legal entity, rating, exposure, and limit type.

> *Write each requirement in EARS form: When / While / Where / If <trigger or state>, the <system> shall <response>. One behaviour per requirement, each one testable pass or fail. No implementation detail: no languages, frameworks, or product names.*

**Functional requirements:**

| **ID**   | **Requirement (EARS form)**                       | **Priority**                | **Traces to** |
|----------|---------------------------------------------------|-----------------------------|---------------|
| FR-1 | When the Monday extract is complete, the system shall generate every portfolio section under the agreed netting and collateral rules | Must | US-1 |
| FR-2 | When the extract is incomplete or fails the layout version check, the system shall hold the run with a stated reason and publish nothing | Must | US-3 |
| FR-3 | When a section is generated, the system shall list week-on-week movements above the agreed threshold and all exceptions | Must | US-2 |
| FR-4 | When an analyst corrects a figure, the system shall record the generated value, the correction, the reason, and the analyst | Must | US-1 |
| FR-5 | When all sections are marked reviewed, the system shall allow the lead analyst to publish to the committee folder | Must | US-1 |
| FR-6 | When the report is published, the system shall write-protect it and record the publication with a content hash | Must | US-1 |
| FR-7 | When generation has not completed by 06:00 Monday, the system shall alert the operating team and the lead analyst | Must | US-3 |
| FR-8 | While a section is open for review, the system shall prevent a second analyst from editing it | Should | US-1 |

## 5. Data & Information
> <strong>What it means:</strong> The data this work actually touches: what it is, where it comes from, how it is reached, and whether it can be trusted. Named the way the team names it, not as abstract entities.
> <strong>Example:</strong> Exposure positions from the credit data warehouse, read by SQL. A governed extract of 5,000 rows was provided for the spike, read from CSV.

**Datasets in scope:**

| **Dataset / file / feed**       | **Key fields that matter here** | **Identifies a row by**          |
|---------------------------------|---------------------------------|----------------------------------|
| Monday warehouse extract | Positions, collateral values, limits, counterparty groups | Counterparty group identifier |
| Counterparty group mapping | Trading entity to legal entity group | Trading entity identifier |
| Weekly report | Net exposure, limit, utilisation, breach flag per group | Counterparty group identifier plus report date |

**Data classification:**

Confidential: counterparty legal entity names, exposure amounts, limits, and breach status identify the bank's counterparties and positions. No personal data is involved.

**Location and access:**

| **Dataset**   | **Location**                                    | **Access method**                                             | **Read / write**                  |
|---------------|-------------------------------------------------|---------------------------------------------------------------|-----------------------------------|
| Monday warehouse extract | Risk data warehouse | SQL | Read-only |
| Counterparty group mapping | Risk data warehouse | SQL | Read-only |
| Weekly report | Report store in the risk environment | Internal API | Writes drafted and published reports |
| Committee folder | Collaboration platform | File drop | Writes the published report only |

**Source of truth:**

Positions appear in the trading systems and the risk data warehouse; the warehouse is authoritative for this report because the netting and collateral adjustments are applied there under risk ownership. Limits are authoritative in the limit system and read from its warehouse copy.

**Relationships and freshness:**

Positions, collateral, and limits join on the counterparty group identifier. The report runs on the Monday 02:00 snapshot: a scheduled batch, not a live query, so the committee sees one consistent picture.

**Data quality issues in the source:**

A late collateral feed leaves collateral values stale: that must stop the run, not be tolerated, because it distorts net exposure unpredictably. Counterparties missing a group mapping appear ungrouped: tolerated, listed as an exception for the analyst. Duplicate position records from one upstream system are a known warehouse defect: fixed upstream, and guarded by a duplicate check here until then.

## 6. Delivery & Presentation
> <strong>What it means:</strong> The surface this is delivered through, and how it behaves away from the happy path. The journeys themselves belong in Section 3: this section covers where they run and what the user sees when there is nothing to show or something failed.
> <strong>Example:</strong> A read-only view inside the existing credit portal. If no requests are pending, show “Nothing awaiting authority calculation”, not an empty grid.

**Delivery surface:**

A review screen hosted in the existing risk portal, confirmed with the portal product owner on 2026-06-30: this was an unexamined assumption in the first interview and is now recorded as confirmed. The published report lands in the committee folder as today.

**Error, empty, and first-use states:**

Before the extract arrives the report shows Awaiting Monday extract with the expected time. During generation it shows In progress. On failure it shows Held with the stated reason and the manual fallback instruction: never a blank or partially filled report.

**Accessibility requirements:**

The portal's existing accessibility standard applies (WCAG 2.1 AA). Movement and breach highlighting must not rely on colour alone, because the review decision hangs on those flags.

**Language and localisation:**

English only: interface, report, and committee pack.

# Part C: Quality & Constraints

## 7. Quality Attributes
> <strong>What it means:</strong> How well this must perform, scale, stay available, and be observed. The quality bar, not the behaviour.
> <strong>Example:</strong> The authority figure returns within two seconds. Available 99.5 percent during business hours. Every calculation is logged with its inputs.

**Quality requirements:**

| **ID**    | **Requirement**                                    | **Target**                |
|-----------|----------------------------------------------------|---------------------------|
| NFR-1 | Drafted report ready after a complete 02:00 extract | By 06:00 Monday |
| NFR-2 | Analyst review time at steady state | Under one hour per analyst |
| NFR-3 | Availability of the review screen Monday 06:00 to 13:00 | 99 percent |
| NFR-4 | Reconciliation of report totals to the snapshot | Exact after rounding to the reporting unit |

**Processing volume and rhythm:**

One batch a week: roughly 310,000 position records aggregated to about 1,900 counterparty groups after the Monday 02:00 extract. No intraday load.

**Observability:**

Per run: extract arrival time, generation duration, record counts in and out, reconciliation result, and exception count. An alert fires if generation has not completed by 06:00 Monday.

**Capacity reservation:**

Shared capacity is acceptable, provided the 06:00 completion holds. If Monday contention breaks it, reservation is revisited.

## 8. Security, Privacy & Compliance
> <strong>What it means:</strong> Who may reach this and the data behind it, how that data is protected, and which external obligations constrain it.
> <strong>Example:</strong> Only entitled credit officers may view a client's exposure. Data stays in Switzerland. Access is granted through the existing entitlement process, not a local user list.

**Who may access this, and how access is granted:**

Entitlement follows the existing risk portal roles through the standard process: no local user list. Analysts see their portfolios; the lead analyst sees all sections and the publish action; the committee folder is read-only for its existing audience.

**Personal and client-identifying data:**

No personal data. Counterparty data is corporate legal entity information.

**Authentication:**

Users authenticate through corporate single sign-on. The generation job runs under its own service identity with read access to the warehouse and write access only to the report store.

**Data residency:**

All data stays within the bank's risk environment in the approved processing regions. Nothing leaves the bank: no external service receives counterparty or position data.

**Encryption:**

Bank-standard encryption at rest for the report store and in transit for every hop, matching the warehouse's existing controls.

**Secrets and credentials:**

The service identity's credentials live in the bank's secrets vault with standard rotation. No credentials in configuration or code.

**Applicable regulations and internal policy:**

The bank's SDLC control framework, the data classification policy, and the records policy for committee inputs. Mapped in Appendix B.

## 9. Audit, Logging & Retention
> <strong>What it means:</strong> What must be recorded so that any action or output can be reconstructed and defended later, and how long those records are kept. Separate from operational logging.
> <strong>Example:</strong> Every authority calculation records the inputs used, the policy version applied, the result, and who saw it. Records are kept for ten years and cannot be altered.

**What must be recorded:**

Every generation run (snapshot used, rule version, totals), every correction (generated value, corrected value, reason, analyst), every section review, and every publication (who published, when, report hash). Each published figure is traceable to the snapshot and rule version that produced it.

**Retention periods:**

Published reports and their audit trail kept ten years, from the records policy on committee inputs. Operational logs kept one year.

**Tamper evidence:**

Published reports are write-protected with a recorded hash; corrections and reviews are append-only. A restatement is a new publication that references the one it supersedes, never an edit in place.

## 10. Integrations & Dependencies
> <strong>What it means:</strong> The other systems this one must talk to, what happens when they are unavailable, and whether any of them is about to change underneath you.
> <strong>Example:</strong> Positions come from the credit warehouse overnight. If the load has not completed, show the previous day's figures and mark every one of them as stale.

**Dependencies:**

| **Dependency**          | **Failure mode / fallback behaviour**                                | **Format**                      |
|-------------------------|----------------------------------------------------------------------|---------------------------------|
| Risk data warehouse extract | Run holds; alert states the revised timeline; fallback decision by 08:00 | SQL, versioned extract layout |
| Risk portal | Review pauses; generation continues and the draft waits | Portal component interface |
| Committee folder | Publication retries; lead alerted if still failing after 30 minutes | Fixed committee document format |

**Change, migration, and decommission risk:**

The risk data warehouse has no retirement plan. The limit system migrates to a new platform next year: the limit fields used here are confirmed stable across that migration by the limit system owner.

**Import and export formats:**

Inbound: the weekly warehouse extract (positions, collateral, limits, counterparty groups) in the agreed extract layout. Outbound: the published report in the committee's fixed document format, and the breach list to the limit monitoring team in their agreed file layout.

**Ownership and service levels:**

Warehouse extract: the risk data warehouse team, delivery by 02:00 Monday with a 99 percent on-time commitment. Portal: the risk portal team under its existing service level. Committee folder: the committee secretariat, availability under the collaboration platform's standard level.

## 11. Failure & Edge Cases
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once. The cases nobody thinks of until they happen in production.
> <strong>Example:</strong> Two officers open the same request at once. The second submission is refused with a message to refresh, rather than silently overwriting the first.

**Negative scenarios:**

A missing or incomplete extract holds the run with a stated reason. A counterparty without a group mapping is listed as an exception, not silently dropped. A negative or impossible exposure value fails reconciliation and holds the report.

**Conflicting or concurrent action:**

Sections are locked to their analyst while open. If the lead publishes while a correction is unsaved, the publish is refused until the section is re-reviewed. A rerun of generation while review is open voids the open review and notifies the analysts.

**Load and throttling:**

The load is one weekly batch, so busy-time behaviour is about the window, not concurrency: a late extract compresses review time and the alert states the revised timeline. A repeated publish click is idempotent: one publication record.

## 12. Constraints & Decisions
> <strong>What it means:</strong> What was fixed before the work started, and what was considered and deliberately rejected, with the reason. The record a future reader needs to understand why this looks the way it does.
> <strong>Example:</strong> Must read positions from the existing warehouse. A parallel position store was considered and rejected: it would create a reconciliation break.

**Fixed constraints:**

The risk data warehouse is the only permitted source. The review surface must live in the existing risk portal. The committee document format is fixed by the secretariat and is not this work's to change.

**Alternatives considered and rejected:**

Building the report in the warehouse's own reporting tool was rejected: it cannot carry the review and correction workflow, and the committee format cannot be produced faithfully there. Reading positions directly from the trading systems was rejected: it would bypass the governed netting and collateral adjustments and create a reconciliation break with every other risk report.

**Deliberate tradeoffs:**

Consistency over freshness: the report runs on the 02:00 snapshot even though positions move afterwards, because one consistent picture beats a fresher inconsistent one. Held over partial: a run that cannot reconcile publishes nothing rather than most of a report.

# Part E: Closure

## 13. Acceptance Criteria
> <strong>What it means:</strong> The definition of done: specific, measurable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an officer reaches the underlying request from the authority figure in two clicks, and the daily total ties to the source system within 0.1 percent.

**Acceptance criteria:**

| **ID**   | **Criterion**                  | **Traces to**       |
|----------|--------------------------------|---------------------|
| AC-1 | Over a four-week parallel run, the generated report matches the hand-built one after rounding, with every difference listed and attributed | FR-1 |
| AC-2 | The drafted report is ready by 06:00 on each parallel-run Monday with a complete extract | NFR-1 |
| AC-3 | A deliberately incomplete extract holds the run and publishes nothing | FR-2 |
| AC-4 | Every correction made in review appears in the correction record with its reason | FR-4 |
| AC-5 | Publication is refused while any section is unreviewed, verified by test | FR-5 |

**Acceptance scenarios:**

Given a complete Monday extract, When generation runs, Then the drafted report reconciles to the snapshot and every section is ready for review. Given all sections reviewed, When the lead publishes, Then the report lands write-protected in the committee folder with a publication record. Given an incomplete extract, When generation runs, Then the report is held with a stated reason and nothing reaches the folder.

## 14. Open Items & Risks
> <strong>What it means:</strong> What is still undecided, and what could go wrong with the work itself. Kept visible rather than buried, so nothing is quietly forgotten.
> <strong>Example:</strong> Whether restated prior-year figures are handled automatically or manually is still open, owned by the data lead, and would change the design if answered either way.

**Open questions:**

| **#** | **Question**                                                             | **Owner**          | **Status**                      |
|-------|--------------------------------------------------------------------------|--------------------|---------------------------------|
| 1 | Whether the movement threshold is a fixed amount, a percentage, or both | C. Weber | Decided: both, whichever is breached first |
| 2 | Whether a held run past 08:00 always triggers the manual fallback or the lead may wait | Lead analyst | Open |

**Risks:**

| **#** | **Risk**                                       | **Impact**               | **Mitigation**        |
|-------|------------------------------------------------|--------------------------|-----------------------|
| 1 | Netting rule differences surface only after cutover | Wrong figures reach the committee | Four-week parallel run with every difference attributed before cutover |
| 2 | The extract layout changes without notice | A misread report or a missed Monday | Version check holds the run; layout changes agreed with the warehouse team |
| 3 | The portal release slot slips | The review screen has no host | Hosting is committed in the portal release plan |

# Appendix A: Glossary
> <strong>What it means:</strong> Defined once here and used consistently everywhere. A term whose meaning differs elsewhere in the bank is the most expensive kind of ambiguity, so record the conflict rather than hoping nobody notices.

**Canonical terms:**

| **Term**   | **Single definitive meaning**                     | **Conflicting use elsewhere**                                   |
|------------|---------------------------------------------------|-----------------------------------------------------------------|
| Exposure | Net exposure after netting and collateral | Gross exposure in some trading system screens |
| Counterparty | The legal entity group under the master agreement | Individual trading entities in the source systems |
| Breach | Exposure above the approved limit | Sometimes used loosely for utilisation above 90 percent; not here |
| Reviewed | An analyst has worked their section and marked it complete | None known |
| Published | The lead analyst has released the report to the committee folder | None known |

**Terms deliberately avoided:**

Exposure unqualified is not used: the document states net or gross each time. Real-time is not used: the commitment is the Monday snapshot cycle. Sign-off is not used for the analyst step: the document distinguishes reviewed (analyst) from published (lead).

**Official glossary this must follow:**

Terms follow the bank's credit risk glossary. No differences: where the interview used looser wording, this document adopts the glossary term and records the mapping in Appendix A.

# Appendix B: Compliance Mapping
> <strong>What it means:</strong> How this specification satisfies the bank's SDLC control obligations. The controls themselves live in the control catalogue and are not restated here: this table is the traceability an auditor or reviewer needs, nothing more.

**Control mapping:**

| **Control reference**               | **How this specification satisfies it**           | **Section**          |
|-------------------------------------|---------------------------------------------------|----------------------|
| SDLC requirements control | This document at the agreed depth, signed at the requirements gate | All |
| Access control standard | Entitlement through the existing portal process; role restrictions stated | 2, 8 |
| Record-keeping control | Ten-year retention of published reports and audit trail | 9 |
| Data classification control | Confidential handling of counterparty data throughout | 5, 8 |

**Controls not applicable:**

Client-facing disclosure controls: no client sees this output. Agreed with the divisional control officer at requirements review.

## Review & Acceptance Checklist
*Confirm each of these before the document is signed off at its gate.*

- [x] No implementation detail (languages, frameworks, product names) appears in this specification
- [x] Every functional requirement is testable and unambiguous
- [x] Every acceptance criterion is measurable
- [x] Every requirement traces to a usage scenario, and every scenario to a requirement
- [x] Each scenario states its own independent test, so it can be delivered on its own
- [x] Roles state what each may not do, not only what they may
- [x] The delivery surface has been confirmed with the system that will host it
- [x] Retention periods state the obligation each derives from
- [x] Edge cases and failure modes are identified
- [x] Terminology is defined once in Appendix A and used consistently
- [x] No placeholder text or unresolved TODO remains
- [x] Compliance mapping in Appendix B is complete for every applicable control
