**BANKING TECHNICAL REQUIREMENTS SPECIFICATION**

**Counterparty Exposure Weekly Report: Exhaustive**

*Full implementation depth. Several sessions with the business, about a week. Produces the detailed estimate and the evidence a regulated build stands on.*

**Document Control**

| **Version** | **Date**         | **Author**       | **Change Summary** |
|-------------|------------------|------------------|--------------------|
| 0.1 | 2026-07-27 | J. Brunner, Business Analyst | Production draft built on the approved MVP document |
| 0.2 | 2026-08-10 | M. Odermatt, Solution Architect | Controls and audit sections reworked after control review |
| 1.0 | 2026-08-24 | J. Brunner, Business Analyst | Sign-off version for the production requirements gate |

**Approvals and Gate Sign-off**

| **Gate**             | **Role**             | **Name**   | **Date**         | **Decision**                            |
|----------------------|----------------------|------------|------------------|-----------------------------------------|
| Requirements review | Head of Counterparty Risk Reporting | C. Weber | 2026-08-24 | Approved |
| Control review | Divisional Control Officer | N. Steiner | 2026-08-27 | Approved |
| Production readiness | Head of Risk Reporting Operations | E. Vogel | 2026-09-28 | Conditional: fallback drill evidence before go-live |

**Depth and Applicability**

| **Field**       | **Value**      |
|-----------------|----------------|
| Depth level     | Exhaustive     |
| Track                | Generic |
| AI / ML feature      | No |
| Rationale            | The report is a formal input to the weekly credit risk committee and is producible on request for the regulator. A misstated exposure figure reaching the committee carries real consequence, so the specification must carry the evidence a production build stands on. |
| Questions answered   | 117 of 122 Exhaustive questions resolved; 5 recorded as gaps or not relevant |
| When to use this tier| Regulated work, client-facing output, or where a defensible detailed estimate is required. |

**How to convert this document to Markdown for Spec Kit:**

> 1\) Convert with pandoc: pandoc -t markdown "<this-file>.docx" -o spec.md
> 2\) Save into the Spec Kit feature branch, e.g. specs/<feature>/spec.md.
> 3\) Run /speckit.clarify against it before /speckit.plan.

## Interview Coverage Gaps
> Status check on the interview itself, not a section about the system. Complete this before the document is treated as finished.

**Not Asked** = section not covered. **Partial** = section started but incomplete.

| **Section**                   | **Status**                | **What's Missing**            |
|-------------------------------|---------------------------|-------------------------------|
| 6. Delivery & Presentation | Partial | Colour-independent highlighting agreed; the accessibility walkthrough with the portal team is still to run |

**Not relevant to this use case**

| **#** | **Question or area**                   | **Why not relevant**                                                 |
|-------|----------------------------------------|----------------------------------------------------------------------|
| 1 | Cross-border transfer and residency exceptions | All processing stays in the bank's risk environment |
| 2 | Localisation of the interface | The reporting team and the committee work in English |
| 3 | Vendor and contractual position | Every system in the chain is bank-internal |

**Review findings**

| **Finding**                                                        | **Where**     | **Resolution**                            |
|--------------------------------------------------------------------|---------------|-------------------------------------------|
| “Early enough on Monday” in the interview | 1 | Drafted report ready by 06:00, review complete for the 12:00 committee deadline |
| “Matches the manual report” without a tolerance | 13 | Every figure equal after rounding to the reporting unit; any difference listed |
| “Exposure” used for gross and net in one meeting | 1 | Net exposure after netting and collateral, stated as such throughout |

# Part A: Context

## 1. Purpose & Current State
> <strong>What it means:</strong> Why this piece of work exists at all: how the job is done today, what goes wrong with it, and what is meant to change.
> <strong>Example:</strong> Credit officers key approval authority by hand from a report, taking about three hours a week and producing occasional transcription errors. The aim is to calculate it automatically and leave the officer to check.

**Problem statement:**

Three risk analysts spend most of every Monday assembling the weekly counterparty exposure report by hand from a warehouse extract. The work exists to generate the report automatically and leave the analysts to review it, so Monday is spent on analysis rather than assembly.

**How it is done today:**

The warehouse extract lands at 02:00 Monday. Each analyst copies their portfolios into the master spreadsheet, applies netting and collateral adjustments, reconciles totals against the previous week, and pastes the tables into the report document. The report covers about 1,900 counterparties and is due to the credit risk committee by 12:00 Monday. Assembly takes each analyst around six hours.

**What goes wrong today:**

Manual assembly produces copy and formula errors under time pressure. In April a netting set was double-counted during a paste, overstating one counterparty's exposure; the figure reached the committee, triggered a limit breach investigation, and took two days to unwind. Reconciliation breaks delay the report roughly one Monday in four.

**What changes:**

The report is generated from the extract without manual assembly. Analysts open a drafted report, review the movements and exceptions, and publish. Target: analyst time falls from six hours of assembly to under one hour of review, and the 12:00 deadline is met every week the extract arrives on time.

**Terms that must not be misread:**

Exposure means net exposure after netting and collateral, not gross. Counterparty means the legal entity group under the master agreement, not the individual trading entity. Breach means an exposure above the approved limit, not merely close to it.

**Business case reference:**

Business case BC-2026-058, approved June 2026 and revised at the production gate: about 850 analyst hours a year returned to analysis, delays removed, and assembly errors eliminated from the committee input.

## 2. Scope & Stakeholders
> <strong>What it means:</strong> What is being built and for whom, where the line around this work is drawn, and who may and may not do what.
> <strong>Example:</strong> Calculate and display approval authority for corporate credit requests. Out of scope: changing the authority policy itself. A credit officer may view and submit; only a delegated approver may override.

**Core goal:**

Generate the weekly counterparty exposure report from the warehouse extract, faithful to the agreed netting and collateral rules, in time for analyst review before the 12:00 Monday committee deadline.

**In scope:**

Automated generation of the full report under a formal service level, the review and publication flow in the risk portal, the exception workflow for reconciliation breaks, and the audit record covering every published figure.

**Explicitly out of scope:**

Changing the netting or collateral rules is rejected: this work reproduces the agreed rules. Intraday reporting is rejected: the cycle is weekly. Extending the report to other legal entities is deferred, pending a decision by the group risk function.

**Deployment target for this iteration:**

|       | **Target**                                     |
|-------|------------------------------------------------|
| ☐     | PoC: throwaway, no production path             |
| ☐     | MVP: user-facing, limited support              |
| ☒     | Production: fully IT-supported, formal SLA     |

**Roles:**

| **Role**   | **What they do**        | **What they must NOT be able to do**     |
|------------|-------------------------|------------------------------------------|
| Risk analyst | Reviews their portfolio sections; corrects and marks reviewed | Must not publish the report |
| Lead analyst | Publishes when all sections are reviewed; sees all corrections | Must not mark another analyst's section reviewed, and needs a second reviewer on any section where they corrected a figure |
| Divisional control officer | Reads the audit record; owns the control attestation | Must not correct or publish report content |
| Portal administrator | Manages entitlements through the standard process | Must not hold an analyst or lead role at the same time |

**Requirement owners:**

Report content and netting rules: head of counterparty risk reporting. Data and warehouse: the risk data warehouse owner. Portal delivery: the risk portal product owner. Controls and audit record: the divisional control officer.

**Impacted processes and downstream consumers:**

The weekly credit risk committee consumes the report as a formal input. The limit monitoring team consumes the breach list. The committee secretariat pulls the published report into the committee pack; the format and folder are stable for that handover.

# Part B: Behaviour

## 3. User Scenarios
> <strong>What it means:</strong> The distinct ways someone actually uses this, ordered by value. Each scenario must stand on its own: if only the first were built, there should still be something worth using. Every functional requirement traces back to one of these. Describe the journey here; the surface it runs on belongs in Section 6.
> <strong>Example:</strong> A credit officer checks approval authority for a single request before submitting it. Separately, a team lead reviews every request breaching authority at end of day.

**Usage scenarios:**

| **ID**   | **Scenario**                                                                                                     | **Actor**         | **Priority**                               |
|----------|------------------------------------------------------------------------------------------------------------------|-------------------|--------------------------------------------|
| US-1 | Review the drafted report: work the movements and exceptions, correct, mark reviewed, publish | Risk analyst / lead analyst | P1 |
| US-2 | Work the exception list: ungrouped counterparties and reconciliation flags, source open alongside | Risk analyst | P2 |
| US-3 | Handle a held run: see the reason, decide fallback or wait, record the decision | Lead analyst | P3 |
| US-4 | Reconstruct a published figure for audit or the regulator from the run and correction records | Control officer / internal audit | P3 |

**Scenario detail:**

**US-1: Review and publish the drafted report  (Priority: P1)**

On Monday morning I open the drafted report in the portal. The movements against last week are highlighted and the exceptions are listed. I work through my portfolios, check anything flagged, correct where needed, and mark my section reviewed. When all sections are reviewed, the lead analyst publishes to the committee folder and the publication is recorded.

*Why this priority:* It replaces the six hours of assembly that produce the errors and the delays. Every other scenario supports or audits this one.

*Independent test:* Generate and review one portfolio's section for one week: the drafted tables, the movement highlights, and a reviewed section matching the source extract. That alone removes that analyst's assembly work.

*Acceptance scenarios:* Given a complete extract, When generation runs, Then every portfolio section is drafted with movements and exceptions listed. Given a drafted section the analyst corrects, When they mark it reviewed, Then the correction and reviewer are recorded. Given an unreviewed section, When the lead attempts publication, Then publication is refused. Given an incomplete extract, When generation runs, Then the report is held with a stated reason and nothing is published.

*Detail is shown for US-1, the priority scenario. The remaining scenarios follow the same pattern; their acceptance paths are carried in Section 13.*

**Trigger and frequency:**

US-1 weekly on the Monday extract. US-2 weekly during review. US-3 on exception only, expected a few times a quarter. US-4 on request from audit or the regulator, rare but time-bound when it comes.

**Coverage check:**

Checked at review: every scenario has at least one requirement and every requirement traces to a scenario. No orphans remain.

## 4. Functional Requirements
> <strong>What it means:</strong> What the system must do, written so each statement can be tested pass or fail, and traced back to a way someone actually uses the system.
> <strong>Example:</strong> When a credit request is submitted, the system shall calculate the approval authority from legal entity, rating, exposure, and limit type.

> *Write each requirement in EARS form: When / While / Where / If <trigger or state>, the <system> shall <response>. One behaviour per requirement, each one testable pass or fail. No implementation detail: no languages, frameworks, or product names.*

**Functional requirements:**

| **ID**   | **Requirement (EARS form)**                       | **Priority**                | **Traces to** |
|----------|---------------------------------------------------|-----------------------------|---------------|
| FR-1 | When the Monday extract is complete, the system shall generate every portfolio section under the agreed netting and collateral rules | Must | US-1 |
| FR-2 | When the extract is incomplete or fails the layout version check, the system shall hold the run with a stated reason and publish nothing | Must | US-3 |
| FR-3 | When a section is generated, the system shall list week-on-week movements above the agreed threshold and all exceptions | Must | US-2 |
| FR-4 | When an analyst corrects a figure, the system shall record the generated value, the correction, the reason, and the analyst | Must | US-1 |
| FR-5 | When all sections are marked reviewed, the system shall allow the lead analyst to publish to the committee folder | Must | US-1 |
| FR-6 | When the report is published, the system shall write-protect it and record the publication with a content hash | Must | US-1 |
| FR-7 | When generation has not completed by 06:00 Monday, the system shall alert the operating team and the lead analyst | Must | US-3 |
| FR-8 | While a section is open for review, the system shall prevent a second analyst from editing it | Must | US-1 |
| FR-9 | When a published report is restated, the system shall publish a new version referencing the one it supersedes, never edit in place | Must | US-4 |
| FR-10 | When an audit report is requested for a published figure, the system shall produce the full trace within one working day | Must | US-4 |
| FR-11 | Where the lead analyst corrected a figure, the system shall require a second reviewer on that section before publication | Must | US-1 |

## 5. Data & Information
> <strong>What it means:</strong> The data this work actually touches: what it is, where it comes from, how it is reached, and whether it can be trusted. Named the way the team names it, not as abstract entities.
> <strong>Example:</strong> Exposure positions from the credit data warehouse, read by SQL. A governed extract of 5,000 rows was provided for the spike, read from CSV.

**Datasets in scope:**

| **Dataset / file / feed**       | **Key fields that matter here** | **Identifies a row by**          |
|---------------------------------|---------------------------------|----------------------------------|
| Monday warehouse extract | Positions, collateral values, limits, counterparty groups | Counterparty group identifier |
| Counterparty group mapping | Trading entity to legal entity group | Trading entity identifier |
| Weekly report | Net exposure, limit, utilisation, breach flag per group | Counterparty group identifier plus report date |
| Run and publication record | Snapshot reference, rule version, corrections, publication hash | Generated run identifier |

**Data classification:**

Confidential: counterparty legal entity names, exposure amounts, limits, and breach status identify the bank's counterparties and positions. No personal data is involved.

**Location and access:**

| **Dataset**   | **Location**                                    | **Access method**                                             | **Read / write**                  |
|---------------|-------------------------------------------------|---------------------------------------------------------------|-----------------------------------|
| Monday warehouse extract | Risk data warehouse | SQL | Read-only |
| Counterparty group mapping | Risk data warehouse | SQL | Read-only |
| Weekly report | Report store in the risk environment | Internal API | Writes drafted and published reports |
| Committee folder | Collaboration platform | File drop | Writes the published report only |
| Run and publication record | Report store in the risk environment | Internal API | Append-only writes |

**Source of truth:**

Positions appear in the trading systems and the risk data warehouse; the warehouse is authoritative for this report because the netting and collateral adjustments are applied there under risk ownership. Limits are authoritative in the limit system and read from its warehouse copy.

**Relationships and freshness:**

Positions, collateral, and limits join on the counterparty group identifier. The report runs on the Monday 02:00 snapshot: a scheduled batch, not a live query, so the committee sees one consistent picture.

**Data quality issues in the source:**

A late collateral feed leaves collateral values stale: that must stop the run, not be tolerated, because it distorts net exposure unpredictably. Counterparties missing a group mapping appear ungrouped: tolerated, listed as an exception for the analyst. Duplicate position records from one upstream system are a known warehouse defect: fixed upstream, and guarded by a duplicate check here until then.

**Volume and growth:**

About 1,900 counterparty groups and roughly 310,000 position records per weekly snapshot, growing under 10 percent a year. Published reports accumulate at 52 a year, retained ten years.

**Non-production data handling:**

Production extracts may be used in test within the risk environment, which already holds this data. Any test outside that boundary uses the masked extract the warehouse team maintains.

## 6. Delivery & Presentation
> <strong>What it means:</strong> The surface this is delivered through, and how it behaves away from the happy path. The journeys themselves belong in Section 3: this section covers where they run and what the user sees when there is nothing to show or something failed.
> <strong>Example:</strong> A read-only view inside the existing credit portal. If no requests are pending, show “Nothing awaiting authority calculation”, not an empty grid.

**Delivery surface:**

A review screen hosted in the existing risk portal, confirmed with the portal product owner on 2026-06-30 and committed in the portal release plan. Publication writes the report to the committee folder and records the publication event.

**Error, empty, and first-use states:**

Before the extract arrives the report shows Awaiting Monday extract with the expected time. During generation it shows In progress. On failure it shows Held with the stated reason and the manual fallback instruction: never a blank or partially filled report.

**Accessibility requirements:**

The portal's existing accessibility standard applies (WCAG 2.1 AA). Movement and breach highlighting must not rely on colour alone, because the review decision hangs on those flags.

**Language and localisation:**

English only: interface, report, and committee pack.

**User correction and override:**

The analyst corrects a figure in their section before marking it reviewed; the correction is recorded with the generated value, the corrected value, the reason, and the analyst identity. The lead analyst sees all corrections before publishing, and recurring corrections feed back to the warehouse team as data defects.

# Part C: Quality & Constraints

## 7. Quality Attributes
> <strong>What it means:</strong> How well this must perform, scale, stay available, and be observed. The quality bar, not the behaviour.
> <strong>Example:</strong> The authority figure returns within two seconds. Available 99.5 percent during business hours. Every calculation is logged with its inputs.

**Quality requirements:**

| **ID**    | **Requirement**                                    | **Target**                |
|-----------|----------------------------------------------------|---------------------------|
| NFR-1 | Drafted report ready after a complete 02:00 extract | By 06:00 Monday |
| NFR-2 | Analyst review time at steady state | Under one hour per analyst |
| NFR-3 | Availability of the review screen Monday 06:00 to 13:00 | 99.5 percent under the formal service level |
| NFR-4 | Reconciliation of report totals to the snapshot | Exact after rounding to the reporting unit |
| NFR-5 | Recovery after a Monday morning failure | Report available by 10:00 |
| NFR-6 | Audit trace for any published figure | Produced within one working day of request |

**Processing volume and rhythm:**

One batch a week: roughly 310,000 position records aggregated to about 1,900 counterparty groups after the Monday 02:00 extract. No intraday load.

**Observability:**

Per run: extract arrival time, generation duration, record counts in and out, reconciliation result, and exception count. An alert fires if generation has not completed by 06:00 Monday.

**Capacity reservation:**

Reserved batch capacity in the Monday 02:00 to 06:00 window; shared capacity otherwise.

**Scalability limits and degradation:**

The ceiling is the Monday batch window. If the extract is late, generation still runs and the operating alert states the revised completion estimate; the system never publishes a partial report to hit the clock.

**Recovery expectations:**

Recovery time: by 10:00 Monday, because review needs two hours before the 12:00 committee deadline. Recovery point: the last complete extract; a generated report is always reproducible from its snapshot, so nothing beyond the snapshot needs preserving mid-run.

## 8. Security, Privacy & Compliance
> <strong>What it means:</strong> Who may reach this and the data behind it, how that data is protected, and which external obligations constrain it.
> <strong>Example:</strong> Only entitled credit officers may view a client's exposure. Data stays in Switzerland. Access is granted through the existing entitlement process, not a local user list.

**Who may access this, and how access is granted:**

Entitlement follows the existing risk portal roles through the standard process: no local user list. Analysts see their portfolios; the lead analyst sees all sections and the publish action; the committee folder is read-only for its existing audience.

**Personal and client-identifying data:**

No personal data. Counterparty data is corporate legal entity information.

**Authentication:**

Users authenticate through corporate single sign-on. The generation job runs under its own service identity with read access to the warehouse and write access only to the report store.

**Data residency:**

All data stays within the bank's risk environment in the approved processing regions. Nothing leaves the bank: no external service receives counterparty or position data.

**Encryption:**

Bank-standard encryption at rest for the report store and in transit for every hop, matching the warehouse's existing controls.

**Secrets and credentials:**

The service identity's credentials live in the bank's secrets vault with standard rotation. No credentials in configuration or code.

**Applicable regulations and internal policy:**

The bank's SDLC control framework, the data classification policy, the records policy for committee inputs, and the reporting obligations that make the published report producible for the regulator. Mapped in Appendix B.

**Segregation of duties:**

The analyst who corrects a figure must not be the one who publishes the report: publication is restricted to the lead analyst role, and the portal blocks publishing by anyone who corrected a figure in that week's report without a second reviewer on that section.

**Threat assumptions and abuse cases:**

An analyst could mark a section reviewed without looking: the movement and exception flags are recorded as seen or unseen, and the lead's publication view shows unopened flags. Someone outside risk could try to read exposures: portal entitlement scoping stops it. A user could edit the published file in the folder: the published report is write-protected and its hash recorded.

**Third-party and cross-border transfer:**

None. All processing and storage stay inside the bank's environment.

## 9. Audit, Logging & Retention
> <strong>What it means:</strong> What must be recorded so that any action or output can be reconstructed and defended later, and how long those records are kept. Separate from operational logging.
> <strong>Example:</strong> Every authority calculation records the inputs used, the policy version applied, the result, and who saw it. Records are kept for ten years and cannot be altered.

**What must be recorded:**

Every generation run (snapshot used, rule version, totals), every correction (generated value, corrected value, reason, analyst), every section review, and every publication (who published, when, report hash). Each published figure is traceable to the snapshot and rule version that produced it.

**Retention periods:**

Published reports, corrections, and run records kept ten years, from the records policy on committee inputs and the regulator's producibility expectation. Operational logs kept one year under the standard logging policy.

**Tamper evidence:**

Published reports are write-protected with a recorded hash; corrections and reviews are append-only. A restatement is a new publication that references the one it supersedes, never an edit in place.

**Who may read the audit record:**

The lead analyst, the divisional control officer, and internal audit may read the audit record; access is itself logged. Analysts see their own corrections only.

**Evidence for examination:**

For any published figure: the snapshot it came from, the rule version applied, any correction with its reason, the reviewer, and the publication record, retrievable as a single report within one working day.

## 10. Integrations & Dependencies
> <strong>What it means:</strong> The other systems this one must talk to, what happens when they are unavailable, and whether any of them is about to change underneath you.
> <strong>Example:</strong> Positions come from the credit warehouse overnight. If the load has not completed, show the previous day's figures and mark every one of them as stale.

**Dependencies:**

| **Dependency**          | **Failure mode / fallback behaviour**                                | **Format**                      |
|-------------------------|----------------------------------------------------------------------|---------------------------------|
| Risk data warehouse extract | Run holds; alert states the revised timeline; fallback decision by 08:00 | SQL, versioned extract layout |
| Risk portal | Review pauses; generation continues and the draft waits | Portal component interface |
| Committee folder | Publication retries; lead alerted if still failing after 30 minutes | Fixed committee document format |
| Limit monitoring handover | Breach list resends on failure; the monitoring team is alerted after one hour | Agreed breach list file layout |

**Change, migration, and decommission risk:**

The risk data warehouse has no retirement plan. The limit system migrates next year: the limit interface is specified against the target platform and confirmed with the migration owner. The committee folder platform is stable.

**Import and export formats:**

Inbound: the weekly warehouse extract (positions, collateral, limits, counterparty groups) in the agreed extract layout. Outbound: the published report in the committee's fixed document format, and the breach list to the limit monitoring team in their agreed file layout.

**Ownership and service levels:**

Warehouse extract: the risk data warehouse team, delivery by 02:00 Monday with a 99 percent on-time commitment. Portal: the risk portal team under its existing service level. Committee folder: the committee secretariat, availability under the collaboration platform's standard level.

**Protocol and version assumptions:**

The extract layout is versioned; generation checks the version stamp and holds the run if the layout changes rather than misreading columns. The committee document format is fixed by the secretariat and changes only at quarter boundaries with notice.

**Vendor and contractual position:**

No external dependency: every system in the chain is bank-internal. The collaboration platform hosting the committee folder is covered by the bank's existing enterprise agreement.

## 11. Failure & Edge Cases
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once. The cases nobody thinks of until they happen in production.
> <strong>Example:</strong> Two officers open the same request at once. The second submission is refused with a message to refresh, rather than silently overwriting the first.

**Negative scenarios:**

A missing or incomplete extract holds the run with a stated reason. A counterparty without a group mapping is listed as an exception, not silently dropped. A negative or impossible exposure value fails reconciliation and holds the report.

**Conflicting or concurrent action:**

Sections are locked to their analyst while open. If the lead publishes while a correction is unsaved, the publish is refused until the section is re-reviewed. A rerun of generation while review is open voids the open review and notifies the analysts.

**Load and throttling:**

The load is one weekly batch, so busy-time behaviour is about the window, not concurrency: a late extract compresses review time and the alert states the revised timeline. A repeated publish click is idempotent: one publication record.

**Unexpected input:**

An extract with unexpected columns, duplicate position records, or a counterparty group appearing twice is held and flagged. The run never coerces a malformed extract into a plausible report.

**Disaster and unavailability:**

The manual process remains the documented fallback: analysts rebuild the report from the extract as they do today, and the outage is recorded against the run history. An outage discovered Monday morning triggers the fallback decision by 08:00.

## 12. Constraints & Decisions
> <strong>What it means:</strong> What was fixed before the work started, and what was considered and deliberately rejected, with the reason. The record a future reader needs to understand why this looks the way it does.
> <strong>Example:</strong> Must read positions from the existing warehouse. A parallel position store was considered and rejected: it would create a reconciliation break.

**Fixed constraints:**

The risk data warehouse is the only permitted source. The review surface must live in the existing risk portal. The committee document format is fixed by the secretariat and is not this work's to change.

**Alternatives considered and rejected:**

Building the report in the warehouse's own reporting tool was rejected: it cannot carry the review and correction workflow, and the committee format cannot be produced faithfully there. Reading positions directly from the trading systems was rejected: it would bypass the governed netting and collateral adjustments and create a reconciliation break with every other risk report.

**Deliberate tradeoffs:**

Consistency over freshness: the report runs on the 02:00 snapshot even though positions move afterwards, because one consistent picture beats a fresher inconsistent one. Held over partial: a run that cannot reconcile publishes nothing rather than most of a report.

**Decision records:**

ADR-201 (warehouse as sole source), ADR-204 (snapshot consistency over freshness), ADR-209 (hold over partial publication), ADR-212 (publication immutability and restatement chain).

# Part E: Closure

## 13. Acceptance Criteria
> <strong>What it means:</strong> The definition of done: specific, measurable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an officer reaches the underlying request from the authority figure in two clicks, and the daily total ties to the source system within 0.1 percent.

**Acceptance criteria:**

| **ID**   | **Criterion**                  | **Traces to**       |
|----------|--------------------------------|---------------------|
| AC-1 | Over a four-week parallel run, the generated report matches the hand-built one after rounding, with every difference listed and attributed | FR-1 |
| AC-2 | The drafted report is ready by 06:00 on each parallel-run Monday with a complete extract | NFR-1 |
| AC-3 | A deliberately incomplete extract holds the run and publishes nothing | FR-2 |
| AC-4 | Publication is refused while any section is unreviewed, and where the lead corrected a figure without a second reviewer | FR-11 |
| AC-5 | A published report cannot be altered; a restatement produces a new version referencing the old | FR-9 |
| AC-6 | The audit trace for a sampled published figure is produced within one working day and is complete | FR-10 |
| AC-7 | The fallback drill produces the manual report from the same snapshot within the documented time | NFR-5 |

**Acceptance scenarios:**

Given a complete Monday extract, When generation runs, Then the drafted report reconciles to the snapshot and every section is ready for review. Given all sections reviewed, When the lead publishes, Then the report lands write-protected in the committee folder with a publication record. Given an incomplete extract, When generation runs, Then the report is held with a stated reason and nothing reaches the folder.

**Evidence required at acceptance:**

The parallel run report, the reconciliation test evidence, the segregation-of-duties test, the control attestation for Appendix B, and the operating runbook including the fallback drill, accepted by the head of counterparty risk reporting and the divisional control officer.

## 14. Open Items & Risks
> <strong>What it means:</strong> What is still undecided, and what could go wrong with the work itself. Kept visible rather than buried, so nothing is quietly forgotten.
> <strong>Example:</strong> Whether restated prior-year figures are handled automatically or manually is still open, owned by the data lead, and would change the design if answered either way.

**Open questions:**

| **#** | **Question**                                                             | **Owner**          | **Status**                      |
|-------|--------------------------------------------------------------------------|--------------------|---------------------------------|
| 1 | Whether the breach list handover to limit monitoring moves inside this system or stays a file | E. Vogel | Open |
| 2 | Whether quarter-end weeks need an extended review window | C. Weber | Deferred to the first live quarter-end |

**Risks:**

| **#** | **Risk**                                       | **Impact**               | **Mitigation**        |
|-------|------------------------------------------------|--------------------------|-----------------------|
| 1 | Netting rule differences surface only after cutover | Wrong figures reach the committee | Parallel run plus the reconciliation gate on every weekly run |
| 2 | The limit system migration changes the limit fields | Breach flags become unreliable | Interface specified against the target platform with the migration owner |
| 3 | The fallback skill decays once assembly is automated | A Monday outage with nobody able to rebuild by hand | A documented fallback runbook and an annual fallback drill |
| 4 | Corrections quietly patch recurring data defects | Warehouse defects persist unfixed | Correction reasons reviewed monthly and fed back to the warehouse team |

**Deferred items:**

Extension to other legal entities is deferred pending the group risk decision. A self-service movement drill-down for committee members was considered and deferred indefinitely: it changes the audience and the entitlement model.

# Appendix A: Glossary
> <strong>What it means:</strong> Defined once here and used consistently everywhere. A term whose meaning differs elsewhere in the bank is the most expensive kind of ambiguity, so record the conflict rather than hoping nobody notices.

**Canonical terms:**

| **Term**   | **Single definitive meaning**                     | **Conflicting use elsewhere**                                   |
|------------|---------------------------------------------------|-----------------------------------------------------------------|
| Exposure | Net exposure after netting and collateral | Gross exposure in some trading system screens |
| Counterparty | The legal entity group under the master agreement | Individual trading entities in the source systems |
| Breach | Exposure above the approved limit | Sometimes used loosely for utilisation above 90 percent; not here |
| Reviewed | An analyst has worked their section and marked it complete | None known |
| Published | The lead analyst has released the report to the committee folder | None known |
| Restatement | A new published version referencing the report it supersedes | None known |

**Terms deliberately avoided:**

Exposure unqualified is not used: the document states net or gross each time. Real-time is not used: the commitment is the Monday snapshot cycle. Sign-off is not used for the analyst step: the document distinguishes reviewed (analyst) from published (lead).

**Official glossary this must follow:**

Terms follow the bank's credit risk glossary. No differences: where the interview used looser wording, this document adopts the glossary term and records the mapping in Appendix A.

# Appendix B: Compliance Mapping
> <strong>What it means:</strong> How this specification satisfies the bank's SDLC control obligations. The controls themselves live in the control catalogue and are not restated here: this table is the traceability an auditor or reviewer needs, nothing more.

**Control mapping:**

| **Control reference**               | **How this specification satisfies it**           | **Section**          |
|-------------------------------------|---------------------------------------------------|----------------------|
| SDLC requirements control | This document at Exhaustive depth, signed at the requirements gate | All |
| Access control standard | Entitlement through the portal process; segregation of duties stated and tested | 2, 8 |
| Record-keeping control | Ten-year retention of published reports, corrections, and run records | 9 |
| Data classification control | Confidential handling of counterparty data throughout | 5, 8 |
| Committee input integrity control | Write-protected publication with hash and restatement chain | 9, 11 |

**Controls not applicable:**

Client-facing disclosure controls: no client sees this output. Personal data controls: none is processed. Both agreed with the divisional control officer at the requirements gate.

**Controls satisfied outside this document:**

The warehouse's own data quality controls are met by the warehouse team's process; evidence lives with that team. Committee record retention beyond the report itself is met by the secretariat's records process.

## Review & Acceptance Checklist
*Confirm each of these before the document is signed off at its gate.*

- [x] No implementation detail (languages, frameworks, product names) appears in this specification
- [x] Every functional requirement is testable and unambiguous
- [x] Every acceptance criterion is measurable
- [x] Every requirement traces to a usage scenario, and every scenario to a requirement
- [x] Each scenario states its own independent test, so it can be delivered on its own
- [x] Roles state what each may not do, not only what they may
- [x] The delivery surface has been confirmed with the system that will host it
- [x] Retention periods state the obligation each derives from
- [x] Edge cases and failure modes are identified
- [x] Terminology is defined once in Appendix A and used consistently
- [x] No placeholder text or unresolved TODO remains
- [x] Compliance mapping in Appendix B is complete for every applicable control
