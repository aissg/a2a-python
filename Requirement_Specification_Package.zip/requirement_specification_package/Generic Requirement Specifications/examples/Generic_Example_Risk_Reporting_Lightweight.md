**BANKING TECHNICAL REQUIREMENTS SPECIFICATION**

**Counterparty Exposure Weekly Report: Lightweight**

*Core requirements any project needs. One interview, about an hour. Sufficient for a high-level estimate or a proof-of-concept decision.*

**Document Control**

| **Version** | **Date**         | **Author**       | **Change Summary** |
|-------------|------------------|------------------|--------------------|
| 0.1 | 2026-06-15 | J. Brunner, Business Analyst | First draft from the interview of 2026-06-11 |
| 0.2 | 2026-06-22 | J. Brunner, Business Analyst | Gaps closed after follow-up with the reporting team |

**Approvals and Gate Sign-off**

| **Gate**             | **Role**             | **Name**   | **Date**         | **Decision**                            |
|----------------------|----------------------|------------|------------------|-----------------------------------------|
| PoC decision | Head of Counterparty Risk Reporting | C. Weber | 2026-06-26 | Approved |

**Depth and Applicability**

| **Field**       | **Value**       |
|-----------------|-----------------|
| Depth level     | Lightweight     |
| Track                | Generic |
| AI / ML feature      | No |
| Rationale            | One interview is enough to decide whether an automated draft of the report matches what the analysts assemble by hand. A decision to roll out beyond one portfolio triggers the move to Standard. |
| Questions answered   | 31 of 34 Lightweight questions resolved; 3 recorded as gaps |
| When to use this tier| First interview. Estimate or PoC decision, before the project is prioritised. |

**How to convert this document to Markdown for Spec Kit:**

> 1\) Convert with pandoc: pandoc -t markdown "<this-file>.docx" -o spec.md
> 2\) Save into the Spec Kit feature branch, e.g. specs/<feature>/spec.md.
> 3\) Run /speckit.clarify against it before /speckit.plan.

## Interview Coverage Gaps
> Status check on the interview itself, not a section about the system. Complete this before the document is treated as finished.

**Not Asked** = section not covered. **Partial** = section started but incomplete.

| **Section**                   | **Status**                | **What's Missing**            |
|-------------------------------|---------------------------|-------------------------------|
| 7. Quality Attributes | Partial | Only the Monday deadline was discussed; availability and recovery were not |
| 10. Integrations & Dependencies | Not Asked | The limit system migration was not checked in the first interview |

**Not relevant to this use case**

| **#** | **Question or area**                   | **Why not relevant**                                                 |
|-------|----------------------------------------|----------------------------------------------------------------------|
| 1 | Cross-border transfer and residency exceptions | All processing stays in the bank's risk environment |

**Review findings**

| **Finding**                                                        | **Where**     | **Resolution**                            |
|--------------------------------------------------------------------|---------------|-------------------------------------------|
| “Early enough on Monday” in the interview | 1 | Drafted report ready by 06:00, review complete for the 12:00 committee deadline |

# Part A: Context

## 1. Purpose & Current State
> <strong>What it means:</strong> Why this piece of work exists at all: how the job is done today, what goes wrong with it, and what is meant to change.
> <strong>Example:</strong> Credit officers key approval authority by hand from a report, taking about three hours a week and producing occasional transcription errors. The aim is to calculate it automatically and leave the officer to check.

**Problem statement:**

Three risk analysts spend most of every Monday assembling the weekly counterparty exposure report by hand from a warehouse extract. The work exists to generate the report automatically and leave the analysts to review it, so Monday is spent on analysis rather than assembly.

**How it is done today:**

The warehouse extract lands at 02:00 Monday. Each analyst copies their portfolios into the master spreadsheet, applies netting and collateral adjustments, reconciles totals against the previous week, and pastes the tables into the report document. The report covers about 1,900 counterparties and is due to the credit risk committee by 12:00 Monday. Assembly takes each analyst around six hours.

**What goes wrong today:**

Manual assembly produces copy and formula errors under time pressure. In April a netting set was double-counted during a paste, overstating one counterparty's exposure; the figure reached the committee, triggered a limit breach investigation, and took two days to unwind. Reconciliation breaks delay the report roughly one Monday in four.

**What changes:**

The report is generated from the extract without manual assembly. Analysts open a drafted report, review the movements and exceptions, and publish. Target: analyst time falls from six hours of assembly to under one hour of review, and the 12:00 deadline is met every week the extract arrives on time.

## 2. Scope & Stakeholders
> <strong>What it means:</strong> What is being built and for whom, where the line around this work is drawn, and who may and may not do what.
> <strong>Example:</strong> Calculate and display approval authority for corporate credit requests. Out of scope: changing the authority policy itself. A credit officer may view and submit; only a delegated approver may override.

**Core goal:**

Generate the weekly counterparty exposure report from the warehouse extract, faithful to the agreed netting and collateral rules, in time for analyst review before the 12:00 Monday committee deadline.

**In scope:**

A prototype that generates the report tables for one portfolio from a real weekly extract, compared line by line against the hand-built version for four consecutive weeks.

**Explicitly out of scope:**

No portal screen, no publication flow, no exception workflow: all deferred to a build decision. Changing the netting rules themselves is rejected: this work reproduces the agreed rules, it does not redesign them.

**Deployment target for this iteration:**

|       | **Target**                                     |
|-------|------------------------------------------------|
| ☒     | PoC: throwaway, no production path             |
| ☐     | MVP: user-facing, limited support              |
| ☐     | Production: fully IT-supported, formal SLA     |

**Roles:**

| **Role**   | **What they do**        | **What they must NOT be able to do**     |
|------------|-------------------------|------------------------------------------|
| Risk analyst (prototype) | Builds the manual tables and records line-by-line differences | Must not use prototype output in the committee report |
| Prototype lead | Owns the comparison method and the readout | Must not alter recorded differences |

# Part B: Behaviour

## 3. User Scenarios
> <strong>What it means:</strong> The distinct ways someone actually uses this, ordered by value. Each scenario must stand on its own: if only the first were built, there should still be something worth using. Every functional requirement traces back to one of these. Describe the journey here; the surface it runs on belongs in Section 6.
> <strong>Example:</strong> A credit officer checks approval authority for a single request before submitting it. Separately, a team lead reviews every request breaching authority at end of day.

**Usage scenarios:**

| **ID**   | **Scenario**                                                                                                     | **Actor**         | **Priority**                               |
|----------|------------------------------------------------------------------------------------------------------------------|-------------------|--------------------------------------------|
| US-1 | Generate one portfolio's tables from the Monday extract and compare against the hand-built version | Risk analyst (prototype) | P1 |
| US-2 | An incomplete extract holds the run with a stated reason instead of producing tables | Prototype lead | P2 |

## 4. Functional Requirements
> <strong>What it means:</strong> What the system must do, written so each statement can be tested pass or fail, and traced back to a way someone actually uses the system.
> <strong>Example:</strong> When a credit request is submitted, the system shall calculate the approval authority from legal entity, rating, exposure, and limit type.

> *Write each requirement in EARS form: When / While / Where / If <trigger or state>, the <system> shall <response>. One behaviour per requirement, each one testable pass or fail. No implementation detail: no languages, frameworks, or product names.*

**Functional requirements:**

| **ID**   | **Requirement (EARS form)**                       | **Priority**                |
|----------|---------------------------------------------------|-----------------------------|
| FR-1 | When the Monday extract is complete, the system shall generate the portfolio's report tables under the agreed netting and collateral rules | Must |
| FR-2 | When the extract is missing a required feed, the system shall hold the run with a stated reason and generate nothing | Must |
| FR-3 | When generation completes, the system shall write the tables beside the hand-built version for comparison | Must |
| FR-4 | When generated and hand-built figures differ, the system shall list every difference with both values | Must |

## 5. Data & Information
> <strong>What it means:</strong> The data this work actually touches: what it is, where it comes from, how it is reached, and whether it can be trusted. Named the way the team names it, not as abstract entities.
> <strong>Example:</strong> Exposure positions from the credit data warehouse, read by SQL. A governed extract of 5,000 rows was provided for the spike, read from CSV.

**Datasets in scope:**

| **Dataset / file / feed**       | **Key fields that matter here** | **Identifies a row by**          |
|---------------------------------|---------------------------------|----------------------------------|
| Monday warehouse extract | Positions, collateral, limits for one portfolio | Counterparty group identifier |
| Hand-built report tables | The same tables assembled manually | Counterparty group identifier |

**Data classification:**

Confidential: counterparty legal entity names, exposure amounts, limits, and breach status identify the bank's counterparties and positions. No personal data is involved.

## 6. Delivery & Presentation
> <strong>What it means:</strong> The surface this is delivered through, and how it behaves away from the happy path. The journeys themselves belong in Section 3: this section covers where they run and what the user sees when there is nothing to show or something failed.
> <strong>Example:</strong> A read-only view inside the existing credit portal. If no requests are pending, show “Nothing awaiting authority calculation”, not an empty grid.

**Delivery surface:**

No user surface in the prototype: generated tables land in a spreadsheet beside the hand-built version for comparison. The build decision includes choosing the surface.

# Part C: Quality & Constraints

## 7. Quality Attributes
> <strong>What it means:</strong> How well this must perform, scale, stay available, and be observed. The quality bar, not the behaviour.
> <strong>Example:</strong> The authority figure returns within two seconds. Available 99.5 percent during business hours. Every calculation is logged with its inputs.

**Quality requirements:**

| **ID**    | **Requirement**                                    | **Target**                |
|-----------|----------------------------------------------------|---------------------------|
| NFR-1 | Generation time for one portfolio from the extract | Under 30 minutes |
| NFR-2 | Comparison coverage | Four consecutive weekly extracts |

**Processing volume and rhythm:**

One batch a week: roughly 310,000 position records aggregated to about 1,900 counterparty groups after the Monday 02:00 extract. No intraday load.

## 8. Security, Privacy & Compliance
> <strong>What it means:</strong> Who may reach this and the data behind it, how that data is protected, and which external obligations constrain it.
> <strong>Example:</strong> Only entitled credit officers may view a client's exposure. Data stays in Switzerland. Access is granted through the existing entitlement process, not a local user list.

**Who may access this, and how access is granted:**

Entitlement follows the existing risk portal roles through the standard process: no local user list. Analysts see their portfolios; the lead analyst sees all sections and the publish action; the committee folder is read-only for its existing audience.

**Personal and client-identifying data:**

No personal data. Counterparty data is corporate legal entity information.

## 9. Audit, Logging & Retention
> <strong>What it means:</strong> What must be recorded so that any action or output can be reconstructed and defended later, and how long those records are kept. Separate from operational logging.
> <strong>Example:</strong> Every authority calculation records the inputs used, the policy version applied, the result, and who saw it. Records are kept for ten years and cannot be altered.

**What must be recorded:**

Every generation run (snapshot used, rule version, totals), every correction (generated value, corrected value, reason, analyst), every section review, and every publication (who published, when, report hash). Each published figure is traceable to the snapshot and rule version that produced it.

## 10. Integrations & Dependencies
> <strong>What it means:</strong> The other systems this one must talk to, what happens when they are unavailable, and whether any of them is about to change underneath you.
> <strong>Example:</strong> Positions come from the credit warehouse overnight. If the load has not completed, show the previous day's figures and mark every one of them as stale.

**Dependencies:**

| **Dependency**          | **Failure mode / fallback behaviour**                                | **Format**                      |
|-------------------------|----------------------------------------------------------------------|---------------------------------|
| Risk data warehouse | The prototype week is skipped and recorded; no substitute source | SQL over the extract tables |

**Change, migration, and decommission risk:**

None checked yet: recorded as an open item for the build decision.

## 11. Failure & Edge Cases
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once. The cases nobody thinks of until they happen in production.
> <strong>Example:</strong> Two officers open the same request at once. The second submission is refused with a message to refresh, rather than silently overwriting the first.

**Negative scenarios:**

A missing or incomplete extract holds the run with a stated reason. A counterparty without a group mapping is listed as an exception, not silently dropped. A negative or impossible exposure value fails reconciliation and holds the report.

## 12. Constraints & Decisions
> <strong>What it means:</strong> What was fixed before the work started, and what was considered and deliberately rejected, with the reason. The record a future reader needs to understand why this looks the way it does.
> <strong>Example:</strong> Must read positions from the existing warehouse. A parallel position store was considered and rejected: it would create a reconciliation break.

**Fixed constraints:**

The risk data warehouse is the only permitted source. The review surface must live in the existing risk portal. The committee document format is fixed by the secretariat and is not this work's to change.

# Part E: Closure

## 13. Acceptance Criteria
> <strong>What it means:</strong> The definition of done: specific, measurable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an officer reaches the underlying request from the authority figure in two clicks, and the daily total ties to the source system within 0.1 percent.

**Acceptance criteria:**

| **ID**   | **Criterion**                  | **Traces to**       |
|----------|--------------------------------|---------------------|
| AC-1 | Across four weekly runs, every generated figure matches the hand-built report or the difference is attributed to a manual error | FR-4 |
| AC-2 | The held-run path fires on a deliberately incomplete extract and generates nothing | FR-2 |
| AC-3 | Generation completes within 30 minutes on each weekly extract | NFR-1 |

## 14. Open Items & Risks
> <strong>What it means:</strong> What is still undecided, and what could go wrong with the work itself. Kept visible rather than buried, so nothing is quietly forgotten.
> <strong>Example:</strong> Whether restated prior-year figures are handled automatically or manually is still open, owned by the data lead, and would change the design if answered either way.

**Open questions:**

| **#** | **Question**                                                             | **Owner**          | **Status**                      |
|-------|--------------------------------------------------------------------------|--------------------|---------------------------------|
| 1 | Whether the movement threshold for highlighting is a fixed amount or a percentage | C. Weber | Open |
| 2 | Whether the prototype's four weeks are consecutive or sampled across a quarter-end | Prototype lead | Open |

# Appendix A: Glossary
> <strong>What it means:</strong> Defined once here and used consistently everywhere. A term whose meaning differs elsewhere in the bank is the most expensive kind of ambiguity, so record the conflict rather than hoping nobody notices.

**Canonical terms:**

| **Term**   | **Single definitive meaning**                     | **Conflicting use elsewhere**                                   |
|------------|---------------------------------------------------|-----------------------------------------------------------------|
| Exposure | Net exposure after netting and collateral | Gross exposure in some trading system screens |
| Counterparty | The legal entity group under the master agreement | Individual trading entities in the source systems |
| Held | A run stopped before publication with a stated reason | None known |

# Appendix B: Compliance Mapping
> <strong>What it means:</strong> How this specification satisfies the bank's SDLC control obligations. The controls themselves live in the control catalogue and are not restated here: this table is the traceability an auditor or reviewer needs, nothing more.

**Control mapping:**

| **Control reference**               | **How this specification satisfies it**           | **Section**          |
|-------------------------------------|---------------------------------------------------|----------------------|
| Risk environment usage rules | Prototype runs inside the risk environment on data it already holds | 5 |

## Review & Acceptance Checklist
*Confirm each of these before the document is signed off at its gate.*

- [x] No implementation detail (languages, frameworks, product names) appears in this specification
- [x] Every functional requirement is testable and unambiguous
- [x] Every acceptance criterion is measurable
- [x] Every requirement traces to a usage scenario, and every scenario to a requirement
- [x] Each scenario states its own independent test, so it can be delivered on its own
- [x] Roles state what each may not do, not only what they may
- [x] The delivery surface has been confirmed with the system that will host it
- [x] Retention periods state the obligation each derives from
- [x] Edge cases and failure modes are identified
- [x] Terminology is defined once in Appendix A and used consistently
- [x] No placeholder text or unresolved TODO remains
- [x] Compliance mapping in Appendix B is complete for every applicable control
