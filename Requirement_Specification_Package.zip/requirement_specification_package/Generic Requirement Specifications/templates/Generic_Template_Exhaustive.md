**BANKING TECHNICAL REQUIREMENTS SPECIFICATION**

**[Project / Feature Name]: Exhaustive**

*Full implementation depth. Several sessions with the business, about a week. Produces the detailed estimate and the evidence a regulated build stands on.*

**Document Control**

| **Version** | **Date**         | **Author**       | **Change Summary** |
|-------------|------------------|------------------|--------------------|
| 0.1         | [YYYY-MM-DD]     | [name, role]     | [what changed]     |

**Approvals and Gate Sign-off**

| **Gate**             | **Role**             | **Name**   | **Date**         | **Decision**                            |
|----------------------|----------------------|------------|------------------|-----------------------------------------|
| [lifecycle gate]     | [approving role]     | [name]     | [YYYY-MM-DD]     | [Approved / Rejected / Conditional]     |

**Depth and Applicability**

| **Field**       | **Value**      |
|-----------------|----------------|
| Depth level     | Exhaustive     |
| Track                | Generic |
| AI / ML feature      | No |
| Rationale            | [the regulatory, client, or model-risk driver that requires this tier] |
| Questions answered   | [count resolved, generic and AI-specific] |
| When to use this tier| Regulated work, client-facing output, or where a defensible detailed estimate is required. |

**How to convert this document to Markdown for Spec Kit:**

> 1\) Convert with pandoc: pandoc -t markdown "<this-file>.docx" -o spec.md
> 2\) Save into the Spec Kit feature branch, e.g. specs/<feature>/spec.md.
> 3\) Run /speckit.clarify against it before /speckit.plan.

## Interview Coverage Gaps
> Status check on the interview itself, not a section about the system. Complete this before the document is treated as finished.

**Not Asked** = section not covered. **Partial** = section started but incomplete.

| **Section**                   | **Status**                | **What's Missing**            |
|-------------------------------|---------------------------|-------------------------------|
| [section number and name]     | [Not Asked / Partial]     | [what remains unanswered]     |

**Not relevant to this use case**

| **#** | **Question or area**                   | **Why not relevant**                                                 |
|-------|----------------------------------------|----------------------------------------------------------------------|
| 1     | [the question judged inapplicable]     | [one line. "Nobody discussed it" is not a reason: that is a gap]     |

**Review findings**

| **Finding**                                                        | **Where**     | **Resolution**                            |
|--------------------------------------------------------------------|---------------|-------------------------------------------|
| [a vague term needing a number, or a term used inconsistently]     | [section]     | [the agreed figure or canonical term]     |

# Part A: Context

## 1. Purpose & Current State
> <strong>What it means:</strong> Why this piece of work exists at all: how the job is done today, what goes wrong with it, and what is meant to change.
> <strong>Example:</strong> Credit officers key approval authority by hand from a report, taking about three hours a week and producing occasional transcription errors. The aim is to calculate it automatically and leave the officer to check.

**Problem statement:**

\[why this work exists, in two or three sentences\]

**How it is done today:**

\[the current process end to end, and what it produces\]

**What goes wrong today:**

\[errors, rework, delays, misinterpretation, wasted effort, with a recent concrete example rather than a general complaint\]

**What changes:**

\[the intended outcome, stated as a difference from today\]

**Terms that must not be misread:**

\[the two or three terms whose misreading would cause real damage, defined here so the reader has them before the requirements. The full glossary is Appendix A\]

**Business case reference:**

\[link or reference to the approved business case, and the quantified benefit it claims\]

## 2. Scope & Stakeholders
> <strong>What it means:</strong> What is being built and for whom, where the line around this work is drawn, and who may and may not do what.
> <strong>Example:</strong> Calculate and display approval authority for corporate credit requests. Out of scope: changing the authority policy itself. A credit officer may view and submit; only a delegated approver may override.

**Core goal:**

\[what this must achieve, in one or two sentences\]

**In scope:**

\[what this piece of work delivers\]

**Explicitly out of scope:**

\[what it deliberately does not deliver, and whether each item is deferred or rejected\]

**Deployment target for this iteration:**

|       | **Target**                                     |
|-------|------------------------------------------------|
| ☐     | PoC: throwaway, no production path             |
| ☐     | MVP: user-facing, limited support              |
| ☐     | Production: fully IT-supported, formal SLA     |

**Roles:**

| **Role**   | **What they do**        | **What they must NOT be able to do**     |
|------------|-------------------------|------------------------------------------|
| [role]     | [what they do here]     | [the restriction, stated explicitly]     |

**Requirement owners:**

\[for each area of this document, the single person who can confirm it is correct\]

**Impacted processes and downstream consumers:**

\[business processes affected, and any system or team that consumes the output\]

# Part B: Behaviour

## 3. User Scenarios
> <strong>What it means:</strong> The distinct ways someone actually uses this, ordered by value. Each scenario must stand on its own: if only the first were built, there should still be something worth using. Every functional requirement traces back to one of these. Describe the journey here; the surface it runs on belongs in Section 6.
> <strong>Example:</strong> A credit officer checks approval authority for a single request before submitting it. Separately, a team lead reviews every request breaching authority at end of day.

**Usage scenarios:**

| **ID**   | **Scenario**                                                                                                     | **Actor**         | **Priority**                               |
|----------|------------------------------------------------------------------------------------------------------------------|-------------------|--------------------------------------------|
| US-1     | [a distinct way the system is used, in the user's own words. Failure, correction, and audit paths count too]     | [who does it]     | [P1 / P2 / P3, P1 being most valuable]     |

**Scenario detail:**

**US-n: [short title]  (Priority: [P1 / P2 / P3])**

\[the journey in plain language, as the user would describe it, start to finish\]

*Why this priority:* \[the value it delivers, and why it ranks above or below the others\]

*Independent test:* \[how this scenario alone can be verified and deliver value, without the rest being finished\]

*Acceptance scenarios:* \[Given <starting state>, When <action>, Then <expected outcome>. One line per path, including at least one failure path\]

*Repeat this block for each scenario, ordered by priority. Building US-1 alone should still deliver something usable.*

**Trigger and frequency:**

\[for each scenario, what sets it off and how often it happens: many times a day, monthly, or only on exception\]

**Coverage check:**

\[any scenario with no functional requirement behind it, and any requirement that traces to no scenario. Both are defects: add the missing one, or remove the orphan\]

## 4. Functional Requirements
> <strong>What it means:</strong> What the system must do, written so each statement can be tested pass or fail, and traced back to a way someone actually uses the system.
> <strong>Example:</strong> When a credit request is submitted, the system shall calculate the approval authority from legal entity, rating, exposure, and limit type.

> *Write each requirement in EARS form: When / While / Where / If <trigger or state>, the <system> shall <response>. One behaviour per requirement, each one testable pass or fail. No implementation detail: no languages, frameworks, or product names.*

**Functional requirements:**

| **ID**   | **Requirement (EARS form)**                       | **Priority**                | **Traces to** |
|----------|---------------------------------------------------|-----------------------------|---------------|
| FR-1     | [When <trigger>, the system shall <response>]     | [Must / Should / Could]     | [US-n]        |

## 5. Data & Information
> <strong>What it means:</strong> The data this work actually touches: what it is, where it comes from, how it is reached, and whether it can be trusted. Named the way the team names it, not as abstract entities.
> <strong>Example:</strong> Exposure positions from the credit data warehouse, read by SQL. A governed extract of 5,000 rows was provided for the spike, read from CSV.

**Datasets in scope:**

| **Dataset / file / feed**       | **Key fields that matter here** | **Identifies a row by**          |
|---------------------------------|---------------------------------|----------------------------------|
| [name as the team calls it]     | [the few fields used here]      | [unique key, or "generated"]     |

**Data classification:**

\[the bank classification of the most sensitive data involved, and whether client-identifying fields are present. Name the fields if so\]

**Location and access:**

| **Dataset**   | **Location**                                    | **Access method**                                             | **Read / write**                  |
|---------------|-------------------------------------------------|---------------------------------------------------------------|-----------------------------------|
| [dataset]     | [mesh / warehouse / shared drive / sandbox]     | [SQL / Python / REST / internal API / file drop / export]     | [read-only, or writes to ...]     |

**Source of truth:**

\[where the same data appears in more than one system, which is authoritative and why that one\]

**Relationships and freshness:**

\[how datasets join and on which key; how fresh the data must be; live query, scheduled batch, or snapshot\]

**Data quality issues in the source:**

\[missing fields, stale values, duplicates, or systems contradicting each other. State which must be tolerated and which fixed\]

**Volume and growth:**

\[record counts today, and expected growth over one to two years\]

**Non-production data handling:**

\[whether production data may be used in test, and if not, whether masked or synthetic data is required\]

## 6. Delivery & Presentation
> <strong>What it means:</strong> The surface this is delivered through, and how it behaves away from the happy path. The journeys themselves belong in Section 3: this section covers where they run and what the user sees when there is nothing to show or something failed.
> <strong>Example:</strong> A read-only view inside the existing credit portal. If no requests are pending, show “Nothing awaiting authority calculation”, not an empty grid.

**Delivery surface:**

\[how users trigger this and see the result: a dedicated screen, an existing system, Teams, a Copilot agent, a file, or output written to a folder. If it depends on an existing system hosting it, record that the system owner has confirmed\]

**Error, empty, and first-use states:**

\[what the user sees on failure, with no data yet, and while waiting\]

**Accessibility requirements:**

\[the accessibility standard that applies, and any specific obligation\]

**Language and localisation:**

\[which languages the interface and output must support, and whether any content is jurisdiction-specific\]

**User correction and override:**

\[how a user corrects or overrides an output, where the correction is recorded, and who reviews corrections\]

# Part C: Quality & Constraints

## 7. Quality Attributes
> <strong>What it means:</strong> How well this must perform, scale, stay available, and be observed. The quality bar, not the behaviour.
> <strong>Example:</strong> The authority figure returns within two seconds. Available 99.5 percent during business hours. Every calculation is logged with its inputs.

**Quality requirements:**

| **ID**    | **Requirement**                                    | **Target**                |
|-----------|----------------------------------------------------|---------------------------|
| NFR-1     | [response time, volume, availability, or cost]     | [the measured number]     |

**Processing volume and rhythm:**

\[roughly how much is processed and how often, and whether it arrives as a batch, as individual requests through the day, or a mix. This is the figure that sizes capacity\]

**Observability:**

\[what must be logged, measured, or traced for the operating team to know this is working, distinct from the audit record in Section 9\]

**Capacity reservation:**

\[whether guaranteed reserved capacity is required or shared best-effort capacity is acceptable, and during which windows\]

**Scalability limits and degradation:**

\[the known ceiling, and how the system behaves as it approaches it: queue, shed load, or refuse\]

**Recovery expectations:**

\[recovery time and recovery point objectives, and the business justification for each\]

## 8. Security, Privacy & Compliance
> <strong>What it means:</strong> Who may reach this and the data behind it, how that data is protected, and which external obligations constrain it.
> <strong>Example:</strong> Only entitled credit officers may view a client's exposure. Data stays in Switzerland. Access is granted through the existing entitlement process, not a local user list.

**Who may access this, and how access is granted:**

\[the authorisation model, and whether entitlement is managed through an existing process or something new\]

**Personal and client-identifying data:**

\[whether any is processed, and which specific fields\]

**Authentication:**

\[how users and systems prove identity; single sign-on, service account, certificate, or other\]

**Data residency:**

\[where data may be stored and processed, and where it must not leave\]

**Encryption:**

\[requirements at rest and in transit\]

**Secrets and credentials:**

\[how keys, tokens, and credentials are stored and rotated. Never in configuration files or prompts\]

**Applicable regulations and internal policy:**

\[the specific obligations that constrain this work. Mapped in Appendix B\]

**Segregation of duties:**

\[which combinations of actions one person must never be able to perform, and how the system enforces that\]

**Threat assumptions and abuse cases:**

\[who might misuse this, how, and what stops them\]

**Third-party and cross-border transfer:**

\[any transfer of data outside the bank or across a border, and the basis on which it is permitted\]

## 9. Audit, Logging & Retention
> <strong>What it means:</strong> What must be recorded so that any action or output can be reconstructed and defended later, and how long those records are kept. Separate from operational logging.
> <strong>Example:</strong> Every authority calculation records the inputs used, the policy version applied, the result, and who saw it. Records are kept for ten years and cannot be altered.

**What must be recorded:**

\[the actions and outputs that must leave a record, and what each record contains: who, what, when, and on what basis\]

**Retention periods:**

\[how long audit records must be kept, and how long the business records themselves must be kept. State the obligation each period comes from\]

**Tamper evidence:**

\[whether records must be immutable or tamper-evident, and how that is achieved\]

**Who may read the audit record:**

\[which roles may access audit data, and whether that access is itself recorded\]

**Evidence for examination:**

\[what must be producible on request for internal audit, model validation, or a regulator, and in what form\]

## 10. Integrations & Dependencies
> <strong>What it means:</strong> The other systems this one must talk to, what happens when they are unavailable, and whether any of them is about to change underneath you.
> <strong>Example:</strong> Positions come from the credit warehouse overnight. If the load has not completed, show the previous day's figures and mark every one of them as stale.

**Dependencies:**

| **Dependency**          | **Failure mode / fallback behaviour**                                | **Format**                      |
|-------------------------|----------------------------------------------------------------------|---------------------------------|
| [system or service]     | [what happens when it is slow, unavailable, or returns an error]     | [interface and data format]     |

**Change, migration, and decommission risk:**

\[whether any system depended on is scheduled to be changed, migrated, or switched off. Building on a platform already being retired must be known now, not after build\]

**Import and export formats:**

\[data crossing the boundary in either direction, and the agreed format\]

**Ownership and service levels:**

\[who owns each dependency and what service level is committed\]

**Protocol and version assumptions:**

\[assumed interface versions, and behaviour when a dependency changes version\]

**Vendor and contractual position:**

\[for external dependencies, the contractual basis, exit position, and concentration risk\]

## 11. Failure & Edge Cases
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once. The cases nobody thinks of until they happen in production.
> <strong>Example:</strong> Two officers open the same request at once. The second submission is refused with a message to refresh, rather than silently overwriting the first.

**Negative scenarios:**

\[what happens when a required input is missing, wrong, or out of range\]

**Conflicting or concurrent action:**

\[what happens when two people or processes act on the same item at the same time\]

**Load and throttling:**

\[behaviour at unusually busy times, or when one caller repeats the same action rapidly\]

**Unexpected input:**

\[input outside the anticipated shape. It must be flagged, not forced into the expected structure\]

**Disaster and unavailability:**

\[behaviour if this system, or the platform beneath it, is unavailable for an extended period\]

## 12. Constraints & Decisions
> <strong>What it means:</strong> What was fixed before the work started, and what was considered and deliberately rejected, with the reason. The record a future reader needs to understand why this looks the way it does.
> <strong>Example:</strong> Must read positions from the existing warehouse. A parallel position store was considered and rejected: it would create a reconciliation break.

**Fixed constraints:**

\[what was decided before this work began and is not open for discussion: platform, hosting, interface, standard\]

**Alternatives considered and rejected:**

\[each option considered, and the reason it was rejected. State the reason, not just the decision\]

**Deliberate tradeoffs:**

\[choices made knowingly against another quality: simple over complete, fast over cheap, coverage over precision\]

**Decision records:**

\[references to any architecture decision records that carry the full reasoning\]

# Part E: Closure

## 13. Acceptance Criteria
> <strong>What it means:</strong> The definition of done: specific, measurable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an officer reaches the underlying request from the authority figure in two clicks, and the daily total ties to the source system within 0.1 percent.

**Acceptance criteria:**

| **ID**   | **Criterion**                  | **Traces to**       |
|----------|--------------------------------|---------------------|
| AC-1     | [the measurable condition]     | [FR-n or NFR-n]     |

**Acceptance scenarios:**

\[for the main paths, stated as: Given <starting state>, When <action>, Then <expected outcome>. One per path\]

**Evidence required at acceptance:**

\[what must be produced and by whom before sign-off: test results, evaluation report, control attestation\]

## 14. Open Items & Risks
> <strong>What it means:</strong> What is still undecided, and what could go wrong with the work itself. Kept visible rather than buried, so nothing is quietly forgotten.
> <strong>Example:</strong> Whether restated prior-year figures are handled automatically or manually is still open, owned by the data lead, and would change the design if answered either way.

**Open questions:**

| **#** | **Question**                                                             | **Owner**          | **Status**                      |
|-------|--------------------------------------------------------------------------|--------------------|---------------------------------|
| 1     | [the decision still outstanding that the design genuinely hinges on]     | [named person]     | [Open / Decided / Deferred]     |

**Risks:**

| **#** | **Risk**                                       | **Impact**               | **Mitigation**        |
|-------|------------------------------------------------|--------------------------|-----------------------|
| 1     | [what could go wrong with delivering this]     | [what it would cost]     | [what reduces it]     |

**Deferred items:**

\[anything consciously postponed, the tier or phase it is deferred to, and the reason\]

# Appendix A: Glossary
> <strong>What it means:</strong> Defined once here and used consistently everywhere. A term whose meaning differs elsewhere in the bank is the most expensive kind of ambiguity, so record the conflict rather than hoping nobody notices.

**Canonical terms:**

| **Term**   | **Single definitive meaning**                     | **Conflicting use elsewhere**                                   |
|------------|---------------------------------------------------|-----------------------------------------------------------------|
| [term]     | [the one meaning it carries in this document]     | [where the same word means something else, or "none known"]     |

**Terms deliberately avoided:**

\[words not used here because they are ambiguous, and what is used instead\]

**Official glossary this must follow:**

\[any bank-wide, regulatory, or industry glossary that governs these terms, and any difference from it\]

# Appendix B: Compliance Mapping
> <strong>What it means:</strong> How this specification satisfies the bank's SDLC control obligations. The controls themselves live in the control catalogue and are not restated here: this table is the traceability an auditor or reviewer needs, nothing more.

**Control mapping:**

| **Control reference**               | **How this specification satisfies it**           | **Section**          |
|-------------------------------------|---------------------------------------------------|----------------------|
| [control id from the catalogue]     | [the requirement or record that satisfies it]     | [section number]     |

**Controls not applicable:**

\[any control judged not applicable to this work, with the reason and who agreed it\]

**Controls satisfied outside this document:**

\[obligations met by process rather than by requirements, and where that evidence lives\]

## Review & Acceptance Checklist
*Confirm each of these before the document is signed off at its gate.*

- [ ] No implementation detail (languages, frameworks, product names) appears in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Every requirement traces to a usage scenario, and every scenario to a requirement
- [ ] Each scenario states its own independent test, so it can be delivered on its own
- [ ] Roles state what each may not do, not only what they may
- [ ] The delivery surface has been confirmed with the system that will host it
- [ ] Retention periods state the obligation each derives from
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once in Appendix A and used consistently
- [ ] No placeholder text or unresolved TODO remains
- [ ] Compliance mapping in Appendix B is complete for every applicable control
