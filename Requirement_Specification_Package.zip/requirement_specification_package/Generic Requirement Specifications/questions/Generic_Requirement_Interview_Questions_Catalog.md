**GENERIC REQUIREMENT INTERVIEW QUESTIONS CATALOG**

**Generic Track**

*Mirrors the requirements template section for section. Ask questions from the section they belong to; the answers land in the matching section of the document.*

**How to read this document**

> Each question carries a depth marker. **[L]** Lightweight, **[S]** Standard, **[E]** Exhaustive. The tiers are cumulative: Standard asks every [L] and every [S]; Exhaustive asks all three.

## First Interview Key Points
*Use this for the very first conversation, before anyone has agreed to build anything. Do not read the numbered questions in this catalogue aloud: a list intimidates people and turns a conversation into an interrogation. Hold a normal discussion covering the points below, and let the recording or your notes fill in the Lightweight document afterwards. These points are the Lightweight tier expressed as a conversation. Getting through them in about an hour gives a business analyst and a technical architect enough to size the work at a high level.*

### Part A: The conversation, in the order it usually flows

- **Today's process:** How is this done today? Walk through the current workflow end to end, and what it produces.

- **Pain points:** What goes wrong most often: errors, rework, delays, wasted effort? Ask for a recent concrete example, not a general grumble.

- **The goal, in a sentence:** What is the core goal? What would success look like, and how would they know it had been achieved?

- **How far this time:** Is this a throwaway proof of concept, a limited-support MVP, or fully supported production? This one answer changes the availability, audit, and security expectations for everything else.

- **Who is involved:** Which types of user, what does each do differently, and is there anything one of them must not be able to do?

- **The data:** What data is involved? Name it their way: documents, spreadsheets, datasets, feeds. Where does it come from, and which system is the source of truth?

- **Volume and rhythm:** Roughly how much has to be processed, and how often: a number like 500 documents a quarter or 200 a day. And does it arrive as one big batch, or steadily through the day? This sizes everything.

- **What comes out, and where it goes:** What is the output, and where does it need to land: a screen, a spreadsheet, a file, another system?

- **Roughly how fast:** About how quickly must a result come back for the main action? An approximate answer is fine at this stage.

- **The words that matter:** Which two or three terms are most likely to be misunderstood, and does any of them already mean something different elsewhere in the firm?

- **What done looks like:** What single, checkable condition has to be true for this to count as done?

- **What's still open:** Which decisions are still genuinely open, the ones that would send the build down a different path depending on the answer?

### Part B: Assumption checks, where first interviews quietly go wrong
*These four are the assumptions clients most often carry into a first meeting unexamined. Each one, left unspoken, has derailed a real project. Surface them gently but explicitly before the conversation ends.*

- **The delivery surface:** How will people actually trigger this and see the result? Clients often assume an existing IT system will host it, or that a screen already exists. Confirm that assumption with the system owner, not just the business user. A screen nobody agreed to build changes the estimate completely.

# Part A: Context

## 1. Purpose & Current State
*Why the work exists, and what is wrong with how it is done today. Ask this first: a specification that cannot state its own justification is missing its foundation.*

- **[L]** Why does this work exist? What problem is being solved?

- **[L]** Before we talk about the change: how is this done today? Walk me through the current process and what it produces.

- **[L]** What goes wrong most often today: errors, rework, misunderstandings, wasted effort? Can you give me a recent example?

- **[L]** What changes? What does this look like once it is built?

- **[S]** If this replaces something that already exists: which parts of the current version do people really use and value, and which are rarely looked at? What could we drop without anyone missing it?

- **[S]** Which two or three terms here are most likely to be misunderstood, and what exactly does each one mean? The full glossary comes later; these are the ones that would cause real damage if misread.

- **[E]** Is there an approved business case, and what benefit does it claim?

## 2. Scope & Stakeholders
*The boundary around the work, how far it is being taken this time, and who may and may not do what.*

- **[L]** What is the core goal of this feature, in one or two sentences?

- **[L]** What does success look like, and how would you know it was achieved?

- **[L]** What is explicitly out of scope for this piece of work? For each item, is it deferred or rejected?

- **[L]** What is the deployment target for this iteration? PoC (throwaway, no production path), MVP (user-facing, limited support), or Production (fully IT-supported, formal SLA)? This shapes availability, audit, and security depth for everything that follows.

- **[L]** Who are the different types of users, and what does each of them do differently?

- **[S]** Is there anything one type of user must not be able to do that another can?

- **[S]** For each area of this document, who is the one person who can confirm it is correct?

- **[E]** Which business processes and which downstream teams are affected by this?

# Part B: Behaviour

## 3. User Scenarios
*The distinct ways someone uses this, ordered by value. The traceability anchor: every requirement traces back to one of these. Describe journeys here, not surfaces.*

- **[L]** Walk through the single most important user journey, step by step, from the user's first action to the outcome they need.

- **[L]** Beyond that main flow, how else is this used? Things that only happen during a failure, a correction, or an audit count too.

- **[L]** Of those, which is most valuable? If we could only build one, which would it be?

- **[S]** For each of those: who does it, and what sets it off?

- **[S]** For each scenario, how could it be tested on its own and still deliver something useful, without the rest being finished?

- **[S]** If we had to shrink the output to a fraction of its size, what absolutely must stay, and what is nice-to-have?

- **[E]** How often does each scenario happen: many times a day, monthly, or only on exception?

- **[E]** Did anyone describe a way of using this that never made it into a requirement? Or is there a requirement that serves no scenario? Both are defects.

## 4. Functional Requirements
*What the system must do, each behaviour testable pass or fail.*

- **[L]** What must the system do? State each behaviour so that someone could test it and get a clear pass or fail.

- **[S]** For each requirement, which scenario does it serve?

- **[S]** Which requirements are genuinely Must-have, and which could ship in a later release?

- **[S]** Is any single requirement bundling two behaviours that should be stated separately?

- **[E]** Is there any requirement nobody could actually verify?

## 5. Data & Information
*What data is touched, where it comes from, how it is reached, and whether it can be trusted.*

- **[L]** What data does this read or produce? Name it the way your team does: datasets, tables, files, or feeds.

- **[L]** For each dataset, which few fields actually matter here, and which field tells one record apart from another?

- **[L]** What is the data classification of the information handled: Public, Internal, Confidential, or Restricted? If more than one, name the highest.

- **[L]** Does the data include client-identifying details or other restricted information? If so, which fields?

- **[S]** Where does each dataset live? Enterprise data mesh, a governed warehouse, a shared drive, or a local sandbox copy provided for this work?

- **[S]** How is each dataset accessed? SQL query, Python read, a REST or company-specific API, a file drop, or a manual export. Name the interface.

- **[S]** Is the access read-only, or does the feature write back? If it writes, to where, and who owns that target?

- **[S]** Does the feature just pass data through, or does it keep a copy somewhere: a folder, a database, or an object store?

- **[S]** Is the same data available in more than one system? Which one is the source of truth, and why that one?

- **[S]** Is the data coming from an approved, official source? And is it used as-is, or changed in some way before this feature uses it?

- **[S]** How do the datasets connect? Which field links them, and can one record on one side match many on the other?

- **[S]** How fresh does the data need to be, and how does it arrive: live query, scheduled batch, or a one-off snapshot?

- **[S]** What data quality problems exist in the source today: missing fields, stale values, duplicates, or systems contradicting each other? Which must we live with, and which must be fixed?

- **[E]** What is the expected data volume today, and the expected growth over the next one to two years?

- **[E]** May production data be used in test? If not, is masked or synthetic data required, and who approves its use?

## 6. Delivery & Presentation
*The surface it is delivered through and how it behaves away from the happy path. Where the journeys run, not the journeys themselves.*

- **[L]** How will people trigger this and see the result: a dedicated screen, an existing system, Teams, a Copilot agent, a downloaded file, or output written to a folder?

- **[L]** If this depends on an existing system hosting it, has that system's owner confirmed they will actually do it? Confirm with the owner, not just the business user.

- **[S]** What should the user see the very first time, before there is any data to show?

- **[S]** What does the user see while something is loading, and how long is too long to wait without feedback?

- **[S]** What does the user see when an action fails? Is the message specific enough to act on?

- **[S]** Can users move to other screens while they wait for the action to finish, or must they stay put?

- **[S]** Are there accessibility standards this must meet?

- **[S]** Does this need to support more than one language or locale? If so, which, and are any of them read right-to-left?

- **[E]** Can the user correct or override an output? If so, where is that correction recorded, and who reviews it?

# Part C: Quality & Constraints

## 7. Quality Attributes
*How well it must perform, scale, stay available, and be observed.*

- **[L]** What is an acceptable response time for the main action, at least approximately?

- **[L]** Roughly how much needs to be processed, and how often: for example 500 documents a quarter, or 200 requests a day? This is the number that sizes everything else.

- **[S]** Do requests arrive as one big batch, like overnight or end of quarter, or as individual requests spread through the day, or a mix of both?

- **[S]** Does this need guaranteed, reserved capacity, or is shared best-effort capacity acceptable? Reserved capacity costs more but protects against slow responses when demand spikes elsewhere.

- **[S]** How many people will use this at the same time at peak?

- **[S]** What availability is required, and during which hours or windows does that apply?

- **[S]** What logging, metrics, or tracing must exist so an incident can be diagnosed after the fact?

- **[E]** What is the known ceiling, and how does the system behave as it approaches it: queue, shed load, or refuse?

- **[E]** What recovery time and recovery point objectives apply, and what is the business justification for each?

## 8. Security, Privacy & Compliance
*Who may reach this and the data behind it, how that data is protected, and which external obligations constrain it. Ask these with an engineer or risk officer present: precision earns its keep here.*

- **[L]** Who may access this, and how is access granted? Through an existing entitlement process, or something new?

- **[L]** Does the system process personal data or client-identifying information? Name the specific fields, not just yes or no.

- **[S]** How do users authenticate? Corporate single sign-on, or something bespoke? A bespoke mechanism needs an explicit justification, not a default.

- **[S]** What is the authorisation model: role-based, attribute-based, or record-level? Be specific, because “only their own portfolios” is record-level, not role-based, and they are built differently.

- **[S]** Who grants and revokes access, and how quickly does a revocation actually take effect? At the next login, or immediately?

- **[S]** Where must data reside, and are there regions or environments it must never leave?

- **[S]** What are the encryption requirements, at rest and in transit? Are there fields requiring encryption beyond the platform default?

- **[S]** How are secrets stored and rotated: API keys, credentials, connection strings? They must never live in code or in a config file in the repository.

- **[S]** Which regulations or internal policies apply, including indirectly through downstream consumers of this system's output?

- **[E]** Is there a segregation-of-duties constraint? Can the person who builds or operates this system also approve its output, or must those be different people?

- **[E]** Is a penetration test, threat model, or security review required before go-live? Who signs it off?

- **[E]** Who might misuse this, how, and what stops them?

- **[E]** Does any data leave the bank or cross a border? On what basis is that permitted?

## 9. Audit, Logging & Retention
*What must be recorded so an action or output can be reconstructed and defended later, and for how long. Distinct from operational logging in Section 7.*

- **[L]** What actions or outputs must leave a record, and what does each record contain: who, what, when, and on what basis?

- **[S]** How long must audit records be kept, and how long must the business records themselves be kept? State the obligation each period comes from.

- **[S]** Must records be immutable or tamper-evident? How is that achieved?

- **[S]** What is logged for security purposes: who accessed what, when, and from where?

- **[E]** Who may read the audit record, and is that access itself recorded?

- **[E]** What must be producible on request for internal audit, model validation, or a regulator, and in what form?

- **[E]** What must be reconstructable after the fact, and for how long must it remain so?

## 10. Integrations & Dependencies
*What this must talk to, what happens when those are unavailable, and whether any of them is about to change underneath you.*

- **[L]** Does this depend on any other system, upstream or downstream? Name each one, or state “none.”

- **[L]** Is any system this depends on due to be changed, migrated, or switched off in the near future? Building on a platform already being retired is something we need to know now, not after build.

- **[S]** For each dependency, what happens when it is slow, unavailable, or returns an error?

- **[S]** What data import or export formats must be supported?

- **[S]** Who owns each dependency, and what service level is committed?

- **[E]** What protocol or API version assumptions are being made, and how is a breaking change from upstream handled?

- **[E]** Is there a fallback or degraded mode when a dependency is down, or does the whole feature stop working?

- **[E]** For external dependencies: what is the contractual basis, the exit position, and the concentration risk?

## 11. Failure & Edge Cases
*The negative and unusual paths. What the system does with bad input, overload, and two people acting at once.*

- **[L]** What is the single most likely way this could fail or be misused?

- **[L]** What should happen when a required input is missing, wrong, or out of range?

- **[S]** What happens at unusually busy times, or when someone repeats the same action rapidly?

- **[S]** What happens when two people or processes act on the same item at the same time? Is there a conflict rule, or is the second action simply refused?

- **[E]** What are the known edge cases from any existing manual process this replaces?

- **[E]** What happens if this system, or the platform beneath it, is unavailable for an extended period?

## 12. Constraints & Decisions
*What was fixed before the work started, and what was considered and rejected, with the reason.*

- **[L]** Are there technical constraints fixed in advance: a mandated language, database, hosting environment, or platform?

- **[S]** Are there constraints from outside engineering entirely: budget, timeline, or a vendor contract already in place?

- **[S]** What other approaches were considered and rejected, and why? State the reason, not just the decision.

- **[S]** Are there tradeoffs being made on purpose, like simple over complete or fast over cheap, that we should write down for future readers?

- **[E]** Are there architecture decision records that carry the full reasoning?

# Part E: Closure

## 13. Acceptance Criteria
*The definition of done, stated so it can be checked rather than felt.*

- **[L]** What specific, testable condition must be true for this to be considered done?

- **[S]** For each functional requirement, what is the exact pass or fail test?

- **[S]** For the main paths, state it this way: given a starting state, when an action happens, then what must be true?

- **[S]** Is there a Definition of Done beyond the individual criteria: documentation updated, monitoring in place, runbook written?

- **[E]** Does every requirement have at least one test that proves it was met? Is there any requirement we could not verify?

- **[E]** What evidence must be produced, and by whom, before sign-off?

## 14. Open Items & Risks
*What is still undecided, and what could go wrong with the work itself.*

- **[L]** Which open questions, if answered one way versus another, would send the build down a different path? List the decisions still outstanding that the design genuinely hinges on.

- **[S]** What could go wrong with delivering this, how bad would it be, and what reduces it?

- **[S]** Wherever the spec says “robust,” “intuitive,” “fast,” or “scalable”: what is the actual number or test behind each one?

- **[E]** Once the requirements are signed off, how are later changes handled, and who can approve a change to scope, controls, data use, or model behaviour?

- **[E]** Are there any remaining TODO markers, bracketed placeholders, or “TBD” notes anywhere in the specification? List them; none should reach sign-off unresolved.

- **[E]** What has been consciously deferred, to which phase or tier, and why?

# Appendix A: Glossary
*Defined once and used consistently. A term whose meaning differs elsewhere in the bank is the most expensive kind of ambiguity, so record the conflict rather than hoping nobody notices.*

- **[L]** Which terms need defining once, so that everyone uses them the same way?

- **[L]** Is there a term used elsewhere in the organisation that sounds like one used here but means something different?

- **[S]** Are there synonyms that should be deliberately avoided in this project, because they are ambiguous or already mean something else?

- **[S]** Does this feature's data eventually feed, or get consumed by, another team's system? If so, do they use the same terms the same way?

- **[S]** Is there an official glossary or data dictionary this must follow, whether company-wide, regulatory, or industry? Do our terms match it, and if not, is the difference written down?

- **[E]** If a term's meaning changed during the project, did we keep a note of the old meaning rather than silently replacing it?

# Appendix B: Compliance Mapping
*The traceability an auditor needs, and nothing more. Control text lives in the control catalogue and is not restated here.*

- **[L]** Which control obligations apply to this piece of work?

- **[S]** For each applicable control, which section of this document satisfies it, and how?

- **[S]** Which controls are judged not applicable, for what reason, and who agreed it?

- **[E]** Which obligations are met by process rather than by requirements, and where does that evidence live?

## Depth Grading Summary
*Counts are cumulative. Standard includes every Lightweight question; Exhaustive includes every Standard question.*

| **#**  | **Section**                        | **L**  | **S**  | **E**   |
|--------|------------------------------------|--------|--------|---------|
| 1      | Purpose & Current State            | 4      | 6      | 7       |
| 2      | Scope & Stakeholders               | 5      | 7      | 8       |
| 3      | User Scenarios                     | 3      | 6      | 8       |
| 4      | Functional Requirements            | 1      | 4      | 5       |
| 5      | Data & Information                 | 4      | 13     | 15      |
| 6      | Delivery & Presentation            | 2      | 8      | 9       |
| 7      | Quality Attributes                 | 2      | 7      | 9       |
| 8      | Security, Privacy & Compliance     | 2      | 9      | 13      |
| 9      | Audit, Logging & Retention         | 1      | 4      | 7       |
| 10     | Integrations & Dependencies        | 2      | 5      | 8       |
| 11     | Failure & Edge Cases               | 2      | 4      | 6       |
| 12     | Constraints & Decisions            | 1      | 4      | 5       |
| 13     | Acceptance Criteria                | 1      | 4      | 6       |
| 14     | Open Items & Risks                 | 1      | 3      | 6       |
| A      | Appendix A: Glossary               | 2      | 5      | 6       |
| B      | Appendix B: Compliance Mapping     | 1      | 3      | 4       |
|        | Total questions asked              | 34     | 92     | 122     |
