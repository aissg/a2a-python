# Requirement Specification Package

Requirement specification templates, interview question catalogs, and worked
examples for regulated banking work, in three depths and two tracks.

## Depths

| Depth | Timebox | Purpose |
|---|---|---|
| Lightweight | About 1 hour, one interview | Core requirements any project needs. High-level estimate or PoC decision |
| Standard | About 1 day, working session with stakeholders | Production architecture planning, once prioritised |
| Exhaustive | About 1 week, several sessions | Detailed estimate and the evidence a regulated build stands on |

Every section exists at every depth. What changes is how much of each section is
interrogated. A section not interrogated at a given depth carries an explicit
italic note saying so, rather than being silently absent.

## Tracks

- **Generic**: 14 sections in Parts A, B, C, E. Use for any non-AI feature.
- **AI-Extended**: 20 sections, adding Part D (AI Governance). Sections 1 to 12
  are identical to the generic track, so moving between them is safe.

## Structure

```
Part A  Context              1 Purpose & Current State
                             2 Scope & Stakeholders        (incl. deployment target)
Part B  Behaviour            3 User Scenarios
                             4 Functional Requirements
                             5 Data & Information
                             6 Delivery & Presentation
Part C  Quality &            7 Quality Attributes
        Constraints          8 Security, Privacy & Compliance
                             9 Audit, Logging & Retention
                            10 Integrations & Dependencies
                            11 Failure & Edge Cases
                            12 Constraints & Decisions
Part D  AI Governance       13 AI Classification & Justification   (AI track only)
                            14 AI Behaviour & Output Validation
                            15 Confidence & Human Review
                            16 Provenance & Lineage
                            17 Evaluation & Test Evidence
                            18 Model Lifecycle & Monitoring
Part E  Closure          19/13 Acceptance Criteria
                         20/14 Open Items & Risks
Appendix A  Glossary
Appendix B  Compliance Mapping
```

Preceded by an unnumbered Interview Coverage Gaps block, and closed by a Review
& Acceptance Checklist.

## Sections, not categories

There is no category layer in this package. Content is addressed one way only:
by part letter and section number, so Section 8 in a template, Section 8 in a
catalog, and Section 8 in a worked example are the same thing.

This is worth stating because two other numbering schemes are easy to confuse
with it. Spec Kit's `clarify.md` carries a 10-category ambiguity taxonomy, and
an earlier draft of this work was a flat 15-section list. Neither survives here:
the taxonomy belongs to Spec Kit's command, not to this document, and the flat
list became the five parts above. Any reference to categories, or to a
15-section or 19-section template, predates the restructure.

The two halves of the package share that one addressing scheme:

- **Templates** are the document. Each section holds the fields that section is
  responsible for, and every section exists at all three depths.
- **Catalogs** are the interview instrument. Each question is tagged `[L]`,
  `[S]`, or `[E]` and filed under the section its answer belongs to, so a
  question asked from Section 8 produces an answer that lands in Section 8.
  Tags are cumulative: Standard asks every `[L]` and `[S]` question, Exhaustive
  asks all three.

Question counts per depth, from each catalog's own Depth Grading Summary:

| Catalog | Sections | Lightweight | Standard | Exhaustive |
|---|---|---|---|---|
| Generic | 14 + 2 appendices | 34 | 92 | 122 |
| AI-Extended | 20 + 2 appendices | 45 | 125 | 186 |

## What is deliberately not in the body

SDLC process controls (gate approvals, code review, test phase evidence, change
control after baseline, deployment approval) are not restated as requirements.
They are handled in two places instead:

- **Approvals and Gate Sign-off** table in the header, for the requirements-stage
  approval record.
- **Appendix B, Compliance Mapping**, for traceability from each applicable
  control to the section that satisfies it.

Restating control text in a requirements document creates a second copy that
drifts out of date. The mapping gives an auditor the traceability without the
duplication.

## Files

Both formats are generated from a single source, so they do not drift:

- `templates/Generic_Template_{Lightweight,Standard,Exhaustive}.docx` / `.md`
- `templates/AI_Template_{Lightweight,Standard,Exhaustive}.docx` / `.md`
- `questions/Generic_Requirement_Interview_Questions_Catalog.docx` / `.md`
- `questions/AI_Requirement_Interview_Questions_Catalog.docx` / `.md`
- `examples/Generic_Example_Risk_Reporting_{Lightweight,Standard,Exhaustive}.docx` / `.md`
- `examples/AI_Example_10K_Extraction_{Lightweight,Standard,Exhaustive}.docx` / `.md`

The `templates/`, `questions/`, and `examples/` folders sit under a `Generic
Requirement Specifications` and an `AI Requirement Specifications` master folder,
so either track can be handed over on its own. Section numbering and question
tagging work as described in Sections, not categories above.

## Worked examples

The `examples/` folder contains one completed document per depth per track,
filled on the current templates so every section, table, and field carries
worked content instead of placeholder text.

- **AI-Extended: 10-K Financial Field Extraction.** One use case maturing
  through the depths: a Lightweight PoC spike over 20 filings, a Standard MVP
  with a review screen and confidence bands, and an Exhaustive regulated
  production build feeding the counterparty credit model, with Part D completed
  at each depth.
- **Generic: Counterparty Exposure Reporting.** The weekly exposure report:
  a Lightweight prototype comparison against the manual report, a Standard MVP
  running in parallel with it, and an Exhaustive production build where the
  automated report becomes the committee record.

Each example is compatible with both halves of the package: it follows the
template of its depth field for field, and its content reads as the answers the
matching question catalog would have produced at that depth, including the
Interview Coverage Gaps block, the depth-gated sections, and the deployment
target moving from PoC to MVP to Production.

## Converting for Spec Kit

```
pandoc -t markdown "<template>.docx" -o spec.md
```

Stock Spec Kit's own `spec-template.md` is 131 lines and four top-level
sections:

| Stock section | Contents | Where it lands here |
|---|---|---|
| User Scenarios & Testing | User stories at P1 to P3, plain-language journey, independent test, Given/When/Then, plus Edge Cases as two prompt questions | Section 3, near field for field |
| Requirements | `FR-001: System MUST ...` as prose, plus Key Entities | Section 4 (as EARS, not prose) and part of Section 5 |
| Success Criteria | `SC-001` measurable outcomes | Section 19/13, and by default everything non-functional |
| Assumptions | One list holding assumptions, scope boundaries and dependencies | Parts of Sections 10 and 12 |

Counting the AI track's 20 sections plus 2 appendices, 3 blocks land cleanly,
5 arrive flattened, and 14 have no destination at all. The flattening is
structural rather than accidental: stock has no non-functional requirements
section, so an availability target or a retention period can only be recorded
as a success metric, which strips it of an owner and a test. The 14 with no
destination are Purpose & Current State, Scope & Stakeholders, Delivery &
Presentation, Security, Privacy & Compliance, Audit, Logging & Retention, all
six Part D sections, Open Items & Risks, and both appendices.

A straight `pandoc` conversion into stock Spec Kit therefore loses the
governance record. Install this template as a Spec Kit preset instead: Spec Kit
resolves templates at runtime and a preset overrides the stock
`spec-template.md`, so every `/speckit.specify` run in the repository produces
this structure by default, with no overwrite step and nothing depending on
someone remembering.

## On User Scenarios

Section 3 is deliberately first in Part B and separate from Functional
Requirements. Each scenario is a first-class object, not a table row: at Standard
and above it carries its own priority, plain-language journey, value
justification, independent test, and Given/When/Then acceptance scenarios.

The independent test matters most. If a scenario cannot be verified and deliver
value on its own, it is not a slice, and the delivery sequence built on it will
not work. Ordering by priority means building US-1 alone should still leave
something usable.

## On deployment target

PoC, MVP, or Production sits in Section 2 for both tracks, not in the AI part.
It is a delivery-maturity question with nothing AI-specific about it, and it
drives availability targets, audit obligations, security depth, and recovery
expectations for any system.

## On the Section 3 / Section 6 boundary

A scenario describes a journey. Section 6 describes the surface that journey runs
on and how it behaves off the happy path. The two callouts cross-reference each
other so whoever fills them in knows which is which.

- Section 3: who wants what, in what order of value. The traceability anchor:
  every functional requirement traces to a US-n.
- Section 6: where the output lands, what the user sees with no data or after a
  failure, accessibility, and language.

Section 6 also sits close to Section 11, Failure & Edge Cases, without
duplicating it. Section 11 is what the system does with bad input. Section 6 is
what the user sees. A missing field produces both, and both need stating.

## On the AI archetype question

The six-archetype classification sits fourth in Section 13, not first, and it is
explicitly labelled as being for routing and governance rather than for
specifying behaviour. Three questions come before it: is this AI at all, why is a
model needed rather than ordinary rules, and is the AI deciding or recommending.
Those three shape the specification; the archetype shapes which governance path
the work inherits.

The question also carries an escape hatch. If no archetype fits cleanly, the
interviewee is asked to say so and describe the use case in their own words. A
recorded mismatch is safer than a forced fit, because the wrong archetype means
inheriting the wrong governance path, and the distinction between some of the
archetypes is thinning as models improve.
