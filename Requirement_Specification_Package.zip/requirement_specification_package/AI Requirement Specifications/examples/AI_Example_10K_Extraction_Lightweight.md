**BANKING TECHNICAL REQUIREMENTS SPECIFICATION**

**10-K Financial Field Extraction: Lightweight**

*Core requirements any project needs. One interview, about an hour. Sufficient for a high-level estimate or a proof-of-concept decision.*

**Document Control**

| **Version** | **Date**         | **Author**       | **Change Summary** |
|-------------|------------------|------------------|--------------------|
| 0.1 | 2026-06-12 | A. Meier, Business Analyst | First draft from the interview of 2026-06-10 |
| 0.2 | 2026-06-19 | A. Meier, Business Analyst | Gaps closed after follow-up with the analyst team |

**Approvals and Gate Sign-off**

| **Gate**             | **Role**             | **Name**   | **Date**         | **Decision**                            |
|----------------------|----------------------|------------|------------------|-----------------------------------------|
| PoC decision | Head of Counterparty Credit Analysis | L. Fontana | 2026-06-24 | Approved |

**Depth and Applicability**

| **Field**       | **Value**       |
|-----------------|-----------------|
| Depth level     | Lightweight     |
| Track                | AI-Extended |
| AI / ML feature      | Yes |
| Rationale            | One interview is enough to decide whether extraction accuracy on real filings justifies further investment. A decision to build a user-facing MVP triggers the move to Standard. |
| Questions answered   | 41 of 45 Lightweight questions resolved; 4 recorded as gaps |
| When to use this tier| First interview. Estimate or PoC decision, before the project is prioritised. |

**How to convert this document to Markdown for Spec Kit:**

> 1\) Convert with pandoc: pandoc -t markdown "<this-file>.docx" -o spec.md
> 2\) Save into the Spec Kit feature branch, e.g. specs/<feature>/spec.md.
> 3\) Run /speckit.clarify against it before /speckit.plan.

## Interview Coverage Gaps
> Status check on the interview itself, not a section about the system. Complete this before the document is treated as finished.

**Not Asked** = section not covered. **Partial** = section started but incomplete.

| **Section**                   | **Status**                | **What's Missing**            |
|-------------------------------|---------------------------|-------------------------------|
| 7. Quality Attributes | Partial | Only the two-working-day figure was discussed; availability was not |
| 10. Integrations & Dependencies | Not Asked | Platform change and migration risk not checked in the first interview |

**Not relevant to this use case**

| **#** | **Question or area**                   | **Why not relevant**                                                 |
|-------|----------------------------------------|----------------------------------------------------------------------|
| 1 | Cross-border transfer of personal data | No personal data is processed anywhere in this work |

**Review findings**

| **Finding**                                                        | **Where**     | **Resolution**                            |
|--------------------------------------------------------------------|---------------|-------------------------------------------|
| “Fast enough” in the interview | 1 | Two working days from filing arrival to figures available |

# Part A: Context

## 1. Purpose & Current State
> <strong>What it means:</strong> Why this piece of work exists at all: how the job is done today, what goes wrong with it, and what is meant to change.
> <strong>Example:</strong> Credit officers key approval authority by hand from a report, taking about three hours a week and producing occasional transcription errors. The aim is to calculate it automatically and leave the officer to check.

**Problem statement:**

Credit analysts key roughly 32 financial figures by hand from each annual filing into the counterparty spreadsheet that feeds the credit assessment. The work exists to have a model extract those figures automatically, with the analyst checking rather than typing.

**How it is done today:**

An analyst downloads the filing from the regulator's site, opens the financial statements section, and keys about 32 figures per counterparty into the assessment spreadsheet: income statement, balance sheet, and cash flow lines. Keying and self-checking takes about 45 minutes per filing, across roughly 420 filings a year, clustered in filing season.

**What goes wrong today:**

About 2 percent of keyed fields contain a transcription error found later in review. In March an analyst keyed total revenue instead of net revenue for one filer; the assessment was rerun and the review meeting repeated a week later. During filing season the backlog reaches three weeks, so assessments run on stale figures.

**What changes:**

The system drafts all 32 fields with a source reference; the analyst confirms or corrects instead of keying. Target: under 10 minutes of analyst time per filing, and no assessment waiting more than two working days for figures during filing season.

## 2. Scope & Stakeholders
> <strong>What it means:</strong> What is being built and for whom, where the line around this work is drawn, and who may and may not do what.
> <strong>Example:</strong> Calculate and display approval authority for corporate credit requests. Out of scope: changing the authority policy itself. A credit officer may view and submit; only a delegated approver may override.

**Core goal:**

Extract the agreed set of 32 financial fields from annual filings accurately enough that the analyst checks rather than keys, with every figure traceable to its source page.

**In scope:**

A spike over 20 recent 10-K filings: extraction of the 32 agreed fields, an accuracy measurement against hand-keyed answers, and a recommendation.

**Explicitly out of scope:**

No user interface, no integration, no non-US filings: all deferred to a build decision. Quarterly filings rejected for now: the assessment cycle is annual.

**Deployment target for this iteration:**

|       | **Target**                                     |
|-------|------------------------------------------------|
| ☒     | PoC: throwaway, no production path             |
| ☐     | MVP: user-facing, limited support              |
| ☐     | Production: fully IT-supported, formal SLA     |

**Roles:**

| **Role**   | **What they do**        | **What they must NOT be able to do**     |
|------------|-------------------------|------------------------------------------|
| Credit analyst (spike team) | Runs extractions on the spike set and records mismatches | Must not use spike output in a live assessment |
| Spike lead | Owns the comparison method and the readout | Must not alter recorded mismatch results |

# Part B: Behaviour

## 3. User Scenarios
> <strong>What it means:</strong> The distinct ways someone actually uses this, ordered by value. Each scenario must stand on its own: if only the first were built, there should still be something worth using. Every functional requirement traces back to one of these. Describe the journey here; the surface it runs on belongs in Section 6.
> <strong>Example:</strong> A credit officer checks approval authority for a single request before submitting it. Separately, a team lead reviews every request breaching authority at end of day.

**Usage scenarios:**

| **ID**   | **Scenario**                                                                                                     | **Actor**         | **Priority**                               |
|----------|------------------------------------------------------------------------------------------------------------------|-------------------|--------------------------------------------|
| US-1 | Run extraction on a spike filing and compare against hand-keyed figures | Credit analyst (spike team) | P1 |
| US-2 | A filing the system cannot read fails cleanly with a stated reason | Spike lead | P2 |

## 4. Functional Requirements
> <strong>What it means:</strong> What the system must do, written so each statement can be tested pass or fail, and traced back to a way someone actually uses the system.
> <strong>Example:</strong> When a credit request is submitted, the system shall calculate the approval authority from legal entity, rating, exposure, and limit type.

> *Write each requirement in EARS form: When / While / Where / If <trigger or state>, the <system> shall <response>. One behaviour per requirement, each one testable pass or fail. No implementation detail: no languages, frameworks, or product names.*

**Functional requirements:**

| **ID**   | **Requirement (EARS form)**                       | **Priority**                |
|----------|---------------------------------------------------|-----------------------------|
| FR-1 | When a filing from the spike set is submitted, the system shall draft the 32 agreed fields, each with a source reference or marked Not found | Must |
| FR-2 | When a field cannot be located with a source reference, the system shall mark it Not found rather than produce a value | Must |
| FR-3 | When a filing cannot be read, the system shall fail it with a stated reason and produce no figures | Must |
| FR-4 | When extraction completes, the system shall write the drafted fields to the comparison spreadsheet | Must |

## 5. Data & Information
> <strong>What it means:</strong> The data this work actually touches: what it is, where it comes from, how it is reached, and whether it can be trusted. Named the way the team names it, not as abstract entities.
> <strong>Example:</strong> Exposure positions from the credit data warehouse, read by SQL. A governed extract of 5,000 rows was provided for the spike, read from CSV.

**Datasets in scope:**

| **Dataset / file / feed**       | **Key fields that matter here** | **Identifies a row by**          |
|---------------------------------|---------------------------------|----------------------------------|
| Spike filing set (20 10-Ks) | The 32 agreed financial fields | Filing accession number |
| Hand-keyed answer sheet | The same 32 fields, keyed twice | Filing accession number |

**Data classification:**

The filings are public documents. The counterparty list and the assessment spreadsheet are classified Confidential: they reveal which entities the bank assesses and the counterparty identifier. No personal data is involved.

## 6. Delivery & Presentation
> <strong>What it means:</strong> The surface this is delivered through, and how it behaves away from the happy path. The journeys themselves belong in Section 3: this section covers where they run and what the user sees when there is nothing to show or something failed.
> <strong>Example:</strong> A read-only view inside the existing credit portal. If no requests are pending, show “Nothing awaiting authority calculation”, not an empty grid.

**Delivery surface:**

No user surface in the spike: results land in a comparison spreadsheet the analysts already use. The build decision includes choosing the surface.

# Part C: Quality & Constraints

## 7. Quality Attributes
> <strong>What it means:</strong> How well this must perform, scale, stay available, and be observed. The quality bar, not the behaviour.
> <strong>Example:</strong> The authority figure returns within two seconds. Available 99.5 percent during business hours. Every calculation is logged with its inputs.

**Quality requirements:**

| **ID**    | **Requirement**                                    | **Target**                |
|-----------|----------------------------------------------------|---------------------------|
| NFR-1 | Extraction time per filing on the spike set | Under 10 minutes per filing |
| NFR-2 | Cost per filing, measured for the readout | Recorded, no target set for the spike |

**Processing volume and rhythm:**

About 420 filings a year arriving individually, but heavily clustered: peak weeks bring 40 filings. Capacity is sized for the peak week, not the average.

## 8. Security, Privacy & Compliance
> <strong>What it means:</strong> Who may reach this and the data behind it, how that data is protected, and which external obligations constrain it.
> <strong>Example:</strong> Only entitled credit officers may view a client's exposure. Data stays in Switzerland. Access is granted through the existing entitlement process, not a local user list.

**Who may access this, and how access is granted:**

Entitlement follows the existing credit analysis portal roles through the standard entitlement process: no local user list. Analysts see their own coverage; team leads see the team's queue.

**Personal and client-identifying data:**

No personal data. The signing officers named in filings are public-record information and are not extracted.

## 9. Audit, Logging & Retention
> <strong>What it means:</strong> What must be recorded so that any action or output can be reconstructed and defended later, and how long those records are kept. Separate from operational logging.
> <strong>Example:</strong> Every authority calculation records the inputs used, the policy version applied, the result, and who saw it. Records are kept for ten years and cannot be altered.

**What must be recorded:**

Every extraction (filing, field set, drafted values, confidence), every analyst confirmation or correction (who, when, original and final value), and every export to the assessment spreadsheet. Each record carries the source reference it was based on.

## 10. Integrations & Dependencies
> <strong>What it means:</strong> The other systems this one must talk to, what happens when they are unavailable, and whether any of them is about to change underneath you.
> <strong>Example:</strong> Positions come from the credit warehouse overnight. If the load has not completed, show the previous day's figures and mark every one of them as stale.

**Dependencies:**

| **Dependency**          | **Failure mode / fallback behaviour**                                | **Format**                      |
|-------------------------|----------------------------------------------------------------------|---------------------------------|
| Model gateway | Retry once, then the spike run pauses; no fallback model | Gateway API, document text in, structured fields out |

**Change, migration, and decommission risk:**

None checked yet: recorded as an open item for the build decision.

## 11. Failure & Edge Cases
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once. The cases nobody thinks of until they happen in production.
> <strong>Example:</strong> Two officers open the same request at once. The second submission is refused with a message to refresh, rather than silently overwriting the first.

**Negative scenarios:**

A filing missing its financial statements section fails extraction with a stated reason and routes to manual handling. A field the model cannot locate is drafted as Not found, never as a guessed value.

## 12. Constraints & Decisions
> <strong>What it means:</strong> What was fixed before the work started, and what was considered and deliberately rejected, with the reason. The record a future reader needs to understand why this looks the way it does.
> <strong>Example:</strong> Must read positions from the existing warehouse. A parallel position store was considered and rejected: it would create a reconciliation break.

**Fixed constraints:**

Model access only through the bank's approved model gateway. Hosting on the bank's standard analytics platform. The review surface must live in the existing credit analysis portal, not a new application.

# Part D: AI Governance
*Complete this part only where the Depth and Applicability block records this as an AI/ML feature.*

## 13. AI Classification & Justification
> <strong>What it means:</strong> Which kind of AI use case this is, how far it is being taken this time, and why a model is needed at all rather than ordinary logic.
> <strong>Example:</strong> Extracting named fields from filed documents is retrieval over documents, not a conversational assistant and not an autonomous agent.

**Which topic best matches this use case?**

|       | **Topic**                      |
|-------|--------------------------------|
| ☐     | 1) DMO / Data Agent            |
| ☐     | 2) Compliance Check            |
| ☐     | 3) Re/Write Productivity       |
| ☐     | 4) Agentic AI                  |
| ☒     | 5) RAG Document Extraction     |
| ☐     | 6) RAG and Auto Commentary     |

**Why AI rather than ordinary logic:**

A deterministic parser was tried on last year's filings: it held on standardised data tags but broke on the statement layouts that vary by filer, covering 14 of 32 fields reliably. The failing fields are exactly the ones analysts spend the time on. Layout variety across 420 filers is what defeats rules.

**Is the AI deciding, or recommending to a person who decides?**

Recommending. Every drafted figure is confirmed or corrected by an analyst before it becomes the business record. Nothing the model produces takes effect on its own.

## 14. AI Behaviour & Output Validation
> <strong>What it means:</strong> Correctness checks on what the AI produces, whether that is one model call or an agent taking several steps, and the places where an absent answer is the right answer.
> <strong>Example:</strong> An extracted gross profit must equal revenue minus cost of sales within a rounding tolerance. A filer with no cost of sales legitimately has neither: absence is correct, not a failure.

**Where a wrong answer is worse than no answer:**

Every extracted figure. A field the model cannot locate with a source reference is returned as Not found. A guessed financial figure entering a credit assessment is the single worst outcome this system can produce.

**Validation rules on output:**

| **ID**   | **Rule**                                  | **Tolerance**                      | **Breach action**                          |
|----------|-------------------------------------------|------------------------------------|--------------------------------------------|
| VR-1 | Gross profit equals revenue minus cost of sales where both are present | Rounding tolerance of one reporting unit | Flag for review |
| VR-2 | Every drafted value carries a locatable source reference | Exact | Reject the field: mark Not found |

## 15. Confidence & Human Review
> <strong>What it means:</strong> How sure the system is, how the user knows, and when a human must look before anything proceeds.
> <strong>Example:</strong> Fields extracted with high certainty load automatically. Anything less certain goes to a named reviewer within two working days.

**How the user knows how sure the system is:**

Each drafted field shows one of three bands: Confident, Check, or Not found. Bands were chosen over raw scores because analysts read a percentage as precision it does not have. The band definitions are printed on the review screen.

**Who reviews what the system is unsure about:**

The covering credit analyst reviews every filing and may confirm, correct, or reject any field. The team lead handles rejected filings and samples confirmed ones.

**How the user knows an answer came from AI:**

Drafted values are marked Drafted by extraction until confirmed; the export carries a confirmation status per field. Derived ratios computed by the spreadsheet are not marked, because they are fixed calculations on confirmed inputs.

## 16. Provenance & Lineage
> <strong>What it means:</strong> What is recorded about how each AI output was produced, so it can be traced back and defended. Distinct from the general audit record in Section 9.
> <strong>Example:</strong> Each extracted figure records the source document and page, the model and prompt version, and the confidence at the time it was produced.

*Not interrogated at Lightweight depth. A first-pass spike is verified by hand end to end, so no formal provenance record is maintained yet.*

## 17. Evaluation & Test Evidence
> <strong>What it means:</strong> The evidence that this actually works: how much test data with known-correct answers exists, where the correct answers come from, and which hard cases the set must cover.
> <strong>Example:</strong> Fifty documents, each keyed independently by two analysts, disagreements adjudicated by the team lead, including several with unusual layouts.

**How much test data with known answers can be provided:**

20 filings hand-keyed by the analyst team for the spike. Below the 30-to-50 rule of thumb, and recorded as such: the spike result is directional, not proof.

## 18. Model Lifecycle & Monitoring
> <strong>What it means:</strong> What happens to this after it goes live: how the model is kept fit, what is watched, and what happens when the model or the world underneath it changes.
> <strong>Example:</strong> Accuracy is sampled monthly against a refreshed set. If it falls below the agreed floor, the owner is alerted and the model is re-validated before further use.

**Model and hosting:**

A hosted frontier model reached only through the bank's model gateway. The AI platform team owns the provider relationship; the accountable model owner owns this use of it.

# Part E: Closure

## 19. Acceptance Criteria
> <strong>What it means:</strong> The definition of done: specific, measurable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an officer reaches the underlying request from the authority figure in two clicks, and the daily total ties to the source system within 0.1 percent.

**Acceptance criteria:**

| **ID**   | **Criterion**                  | **Traces to**       |
|----------|--------------------------------|---------------------|
| AC-1 | On the 20-filing spike set, at least 95 percent of text and table fields match the hand-keyed answers | FR-1 |
| AC-2 | Every mismatch is listed with its source reference in the readout | FR-1 |
| AC-3 | The scanned-image filing fails with a stated reason and produces no figures | FR-3 |

## 20. Open Items & Risks
> <strong>What it means:</strong> What is still undecided, and what could go wrong with the work itself. Kept visible rather than buried, so nothing is quietly forgotten.
> <strong>Example:</strong> Whether restated prior-year figures are handled automatically or manually is still open, owned by the data lead, and would change the design if answered either way.

**Open questions:**

| **#** | **Question**                                                             | **Owner**          | **Status**                      |
|-------|--------------------------------------------------------------------------|--------------------|---------------------------------|
| 1 | Whether restated prior-year figures are compared against the original or the restated value | L. Fontana | Open |
| 2 | Whether the spike cost per filing supports the business case | Spike lead | Open |

# Appendix A: Glossary
> <strong>What it means:</strong> Defined once here and used consistently everywhere. A term whose meaning differs elsewhere in the bank is the most expensive kind of ambiguity, so record the conflict rather than hoping nobody notices.

**Canonical terms:**

| **Term**   | **Single definitive meaning**                     | **Conflicting use elsewhere**                                   |
|------------|---------------------------------------------------|-----------------------------------------------------------------|
| Field | One of the 32 agreed financial figures | None known |
| Not found | The model could not locate the field with a source reference | None known |
| Filing | An annual report filed with the regulator (10-K in this spike) | Elsewhere used for internal regulatory submissions |

# Appendix B: Compliance Mapping
> <strong>What it means:</strong> How this specification satisfies the bank's SDLC control obligations. The controls themselves live in the control catalogue and are not restated here: this table is the traceability an auditor or reviewer needs, nothing more.

**Control mapping:**

| **Control reference**               | **How this specification satisfies it**           | **Section**          |
|-------------------------------------|---------------------------------------------------|----------------------|
| Sandbox usage control (AI policy) | Spike runs in the approved sandbox on public filings with a synthetic entity list | 5 |

## Review & Acceptance Checklist
*Confirm each of these before the document is signed off at its gate.*

- [x] No implementation detail (languages, frameworks, product names) appears in this specification
- [x] Every functional requirement is testable and unambiguous
- [x] Every acceptance criterion is measurable
- [x] Every requirement traces to a usage scenario, and every scenario to a requirement
- [x] Each scenario states its own independent test, so it can be delivered on its own
- [x] Roles state what each may not do, not only what they may
- [x] The delivery surface has been confirmed with the system that will host it
- [x] Retention periods state the obligation each derives from
- [x] Edge cases and failure modes are identified
- [x] Terminology is defined once in Appendix A and used consistently
- [x] No placeholder text or unresolved TODO remains
- [x] Compliance mapping in Appendix B is complete for every applicable control
- [x] If this is an AI feature: Part D is completed, not left as placeholder text
