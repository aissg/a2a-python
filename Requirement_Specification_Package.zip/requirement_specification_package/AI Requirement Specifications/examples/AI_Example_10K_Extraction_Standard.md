**BANKING TECHNICAL REQUIREMENTS SPECIFICATION**

**10-K Financial Field Extraction: Standard**

*Production planning depth. A working session with stakeholders, about a day. Sufficient for production architecture planning.*

**Document Control**

| **Version** | **Date**         | **Author**       | **Change Summary** |
|-------------|------------------|------------------|--------------------|
| 0.1 | 2026-06-12 | A. Meier, Business Analyst | First draft from interview notes |
| 0.2 | 2026-07-01 | A. Meier, Business Analyst | Reworked after the PoC readout; MVP scope agreed |
| 1.0 | 2026-07-15 | A. Meier, Business Analyst | Sign-off version for the requirements gate |

**Approvals and Gate Sign-off**

| **Gate**             | **Role**             | **Name**   | **Date**         | **Decision**                            |
|----------------------|----------------------|------------|------------------|-----------------------------------------|
| Requirements review | Head of Counterparty Credit Analysis | L. Fontana | 2026-07-15 | Approved |
| Pre-build governance check | Accountable Model Owner | D. Keller | 2026-07-16 | Conditional: calibration report due before release |

**Depth and Applicability**

| **Field**       | **Value**    |
|-----------------|--------------|
| Depth level     | Standard     |
| Track                | AI-Extended |
| AI / ML feature      | Yes |
| Rationale            | Single jurisdiction (US filings only), internal users only, and the output feeds an analyst spreadsheet rather than the credit model directly. Exhaustive becomes mandatory when the feed to the counterparty credit model is switched on. |
| Questions answered   | 118 of 125 Standard questions resolved; 7 recorded as gaps |
| When to use this tier| Production, non-regulated, once the project is prioritised. |

**How to convert this document to Markdown for Spec Kit:**

> 1\) Convert with pandoc: pandoc -t markdown "<this-file>.docx" -o spec.md
> 2\) Save into the Spec Kit feature branch, e.g. specs/<feature>/spec.md.
> 3\) Run /speckit.clarify against it before /speckit.plan.

## Interview Coverage Gaps
> Status check on the interview itself, not a section about the system. Complete this before the document is treated as finished.

**Not Asked** = section not covered. **Partial** = section started but incomplete.

| **Section**                   | **Status**                | **What's Missing**            |
|-------------------------------|---------------------------|-------------------------------|
| 11. Failure & Edge Cases | Partial | Concurrent amended-filing behaviour agreed verbally; wording to be confirmed by the team lead |

**Not relevant to this use case**

| **#** | **Question or area**                   | **Why not relevant**                                                 |
|-------|----------------------------------------|----------------------------------------------------------------------|
| 1 | Cross-border transfer of personal data | No personal data is processed anywhere in this work |
| 2 | Localisation of the interface | Analyst team works in English; filings in scope are English |

**Review findings**

| **Finding**                                                        | **Where**     | **Resolution**                            |
|--------------------------------------------------------------------|---------------|-------------------------------------------|
| “Fast enough” in the interview | 1 | Two working days from filing arrival to figures available |
| “Accurate” used without a figure | 17 | Per-source-type targets: 99 / 98 / 95 percent |

# Part A: Context

## 1. Purpose & Current State
> <strong>What it means:</strong> Why this piece of work exists at all: how the job is done today, what goes wrong with it, and what is meant to change.
> <strong>Example:</strong> Credit officers key approval authority by hand from a report, taking about three hours a week and producing occasional transcription errors. The aim is to calculate it automatically and leave the officer to check.

**Problem statement:**

Credit analysts key roughly 32 financial figures by hand from each annual filing into the counterparty spreadsheet that feeds the credit assessment. The work exists to have a model extract those figures automatically, with the analyst checking rather than typing.

**How it is done today:**

An analyst downloads the filing from the regulator's site, opens the financial statements section, and keys about 32 figures per counterparty into the assessment spreadsheet: income statement, balance sheet, and cash flow lines. Keying and self-checking takes about 45 minutes per filing, across roughly 420 filings a year, clustered in filing season.

**What goes wrong today:**

About 2 percent of keyed fields contain a transcription error found later in review. In March an analyst keyed total revenue instead of net revenue for one filer; the assessment was rerun and the review meeting repeated a week later. During filing season the backlog reaches three weeks, so assessments run on stale figures.

**What changes:**

The system drafts all 32 fields with a source reference; the analyst confirms or corrects instead of keying. Target: under 10 minutes of analyst time per filing, and no assessment waiting more than two working days for figures during filing season.

**Terms that must not be misread:**

Revenue means net revenue as presented on the face of the income statement, not gross or segment revenue. Fiscal year means the filer's own reporting year, which for many filers does not match the calendar year. Restated means a prior-year figure changed in a later filing; the restated value governs.

## 2. Scope & Stakeholders
> <strong>What it means:</strong> What is being built and for whom, where the line around this work is drawn, and who may and may not do what.
> <strong>Example:</strong> Calculate and display approval authority for corporate credit requests. Out of scope: changing the authority policy itself. A credit officer may view and submit; only a delegated approver may override.

**Core goal:**

Extract the agreed set of 32 financial fields from annual filings accurately enough that the analyst checks rather than keys, with every figure traceable to its source page.

**In scope:**

Extraction of the 32 agreed fields from 10-K filings, a review screen for the analyst, and export to the assessment spreadsheet. US filers only in this iteration.

**Explicitly out of scope:**

20-F and other non-US filings deferred to the production iteration. Quarterly filings rejected: the assessment cycle is annual. Direct feed into the credit model deferred until the production gate.

**Deployment target for this iteration:**

|       | **Target**                                     |
|-------|------------------------------------------------|
| ☐     | PoC: throwaway, no production path             |
| ☒     | MVP: user-facing, limited support              |
| ☐     | Production: fully IT-supported, formal SLA     |

**Roles:**

| **Role**   | **What they do**        | **What they must NOT be able to do**     |
|------------|-------------------------|------------------------------------------|
| Credit analyst | Reviews drafted fields; confirms, corrects, or rejects | Must not export a filing they have not opened field by field |
| Team lead | Handles rejected filings; samples confirmations weekly | Must not review filings they confirmed themselves |
| Portal administrator | Manages entitlements through the standard process | Must not hold an analyst role at the same time |

**Requirement owners:**

Business process and field definitions: head of counterparty credit analysis. Data and systems: credit data warehouse owner. AI governance sections: the accountable model owner named in the model inventory.

# Part B: Behaviour

## 3. User Scenarios
> <strong>What it means:</strong> The distinct ways someone actually uses this, ordered by value. Each scenario must stand on its own: if only the first were built, there should still be something worth using. Every functional requirement traces back to one of these. Describe the journey here; the surface it runs on belongs in Section 6.
> <strong>Example:</strong> A credit officer checks approval authority for a single request before submitting it. Separately, a team lead reviews every request breaching authority at end of day.

**Usage scenarios:**

| **ID**   | **Scenario**                                                                                                     | **Actor**         | **Priority**                               |
|----------|------------------------------------------------------------------------------------------------------------------|-------------------|--------------------------------------------|
| US-1 | Confirm a drafted extraction: check each field against its source, correct, submit | Credit analyst | P1 |
| US-2 | Work the Check queue: fields the system is unsure about, source open alongside | Credit analyst | P2 |
| US-3 | Handle a rejected or failed filing manually and record why it failed | Team lead | P3 |

**Scenario detail:**

**US-1: Confirm a drafted extraction  (Priority: P1)**

A new filing arrives for one of my counterparties. I open it in the review screen: the 32 fields are already drafted, each with a link to the page it came from. I go down the list, confirm the ones that match the source, correct the ones that do not, and submit. The confirmed set lands in the assessment spreadsheet without me keying anything.

*Why this priority:* This is the whole point of the work: it replaces the 45 minutes of keying that produces the errors and the backlog. Every other scenario supports or audits this one.

*Independent test:* Run one real filing end to end: drafted fields, analyst confirmation, corrected export matching the source document. Even with review routing and monitoring unfinished, this alone removes the keying.

*Acceptance scenarios:* Given a supported filing, When extraction completes, Then all 32 fields are drafted with source references. Given a drafted field the analyst corrects, When they submit, Then the corrected value exports and the correction is recorded. Given a filing the system cannot read, When extraction fails, Then the filing is flagged for manual handling and no partial figures are exported.

*Detail is shown for US-1, the priority scenario. The remaining scenarios follow the same pattern; their acceptance paths are carried in Section 19.*

## 4. Functional Requirements
> <strong>What it means:</strong> What the system must do, written so each statement can be tested pass or fail, and traced back to a way someone actually uses the system.
> <strong>Example:</strong> When a credit request is submitted, the system shall calculate the approval authority from legal entity, rating, exposure, and limit type.

> *Write each requirement in EARS form: When / While / Where / If <trigger or state>, the <system> shall <response>. One behaviour per requirement, each one testable pass or fail. No implementation detail: no languages, frameworks, or product names.*

**Functional requirements:**

| **ID**   | **Requirement (EARS form)**                       | **Priority**                | **Traces to** |
|----------|---------------------------------------------------|-----------------------------|---------------|
| FR-1 | When a supported filing arrives, the system shall draft the 32 agreed fields, each with a source reference or marked Not found | Must | US-1 |
| FR-2 | When a field cannot be located with a source reference, the system shall mark it Not found rather than produce a value | Must | US-1 |
| FR-3 | When drafting completes, the system shall assign each field a band of Confident, Check, or Not found | Must | US-2 |
| FR-4 | When an analyst corrects a drafted value, the system shall record the original value, the correction, and the analyst identity | Must | US-1 |
| FR-5 | When an analyst submits a filing, the system shall export the confirmed field set to the assessment spreadsheet in the agreed layout | Must | US-1 |
| FR-6 | When a filing cannot be read, the system shall route it to manual handling with a stated reason and export nothing | Must | US-3 |
| FR-7 | When an amended filing arrives for a counterparty, the system shall supersede the original and void any open draft | Must | US-3 |
| FR-8 | While a filing is open for review, the system shall prevent a second analyst from reviewing it | Should | US-1 |

## 5. Data & Information
> <strong>What it means:</strong> The data this work actually touches: what it is, where it comes from, how it is reached, and whether it can be trusted. Named the way the team names it, not as abstract entities.
> <strong>Example:</strong> Exposure positions from the credit data warehouse, read by SQL. A governed extract of 5,000 rows was provided for the spike, read from CSV.

**Datasets in scope:**

| **Dataset / file / feed**       | **Key fields that matter here** | **Identifies a row by**          |
|---------------------------------|---------------------------------|----------------------------------|
| Filing feed | Filing document, filer identity, filing date, amendment flag | Filing accession number |
| Counterparty master | Counterparty identifier, legal entity name, industry code | Counterparty identifier |
| Assessment spreadsheet | The 32 confirmed fields per counterparty and year | Counterparty identifier plus fiscal year |

**Data classification:**

The filings are public documents. The counterparty list and the assessment spreadsheet are classified Confidential: they reveal which entities the bank assesses and the counterparty identifier. No personal data is involved.

**Location and access:**

| **Dataset**   | **Location**                                    | **Access method**                                             | **Read / write**                  |
|---------------|-------------------------------------------------|---------------------------------------------------------------|-----------------------------------|
| Filing feed | Document store | Internal API | Read-only |
| Counterparty master | Data warehouse | SQL | Read-only |
| Assessment spreadsheet | Shared analysis drive | Export | Writes confirmed field sets |

**Source of truth:**

The filing itself is the source of truth for every extracted figure. Where the data vendor feed disagrees with the filing, the filing governs, because the vendor applies its own adjustments. The counterparty master is authoritative for entity identity.

**Relationships and freshness:**

Filings join to counterparties on the counterparty identifier held in the master. Freshness: figures must be available within two working days of filing arrival. Processing is a scheduled batch on arrival, not a live query.

**Data quality issues in the source:**

Some filers legitimately omit fields: a filer with no cost of sales has no gross profit, and that absence must be tolerated as correct. Amended filings (10-K/A) duplicate the original and must supersede it: that must be handled, not tolerated. Vendor feed disagreements are tolerated and resolved in favour of the filing.

## 6. Delivery & Presentation
> <strong>What it means:</strong> The surface this is delivered through, and how it behaves away from the happy path. The journeys themselves belong in Section 3: this section covers where they run and what the user sees when there is nothing to show or something failed.
> <strong>Example:</strong> A read-only view inside the existing credit portal. If no requests are pending, show “Nothing awaiting authority calculation”, not an empty grid.

**Delivery surface:**

A review screen hosted inside the existing credit analysis portal. The portal owner confirmed hosting on 2026-05-19; this was an unexamined assumption in the first interview and is now recorded as confirmed.

**Error, empty, and first-use states:**

While extraction runs the filing shows as In progress with the arrival time. On failure the filing shows Failed with the reason and a manual-handling link: never a blank grid. A counterparty with no filing yet shows Awaiting filing, not an empty screen.

**Accessibility requirements:**

The portal's existing accessibility standard applies (WCAG 2.1 AA). The review screen must be fully keyboard-operable, because analysts confirm long field lists and a mouse-only flow would be slower than the keying it replaces.

**Language and localisation:**

English only: interface, filings, and output.

# Part C: Quality & Constraints

## 7. Quality Attributes
> <strong>What it means:</strong> How well this must perform, scale, stay available, and be observed. The quality bar, not the behaviour.
> <strong>Example:</strong> The authority figure returns within two seconds. Available 99.5 percent during business hours. Every calculation is logged with its inputs.

**Quality requirements:**

| **ID**    | **Requirement**                                    | **Target**                |
|-----------|----------------------------------------------------|---------------------------|
| NFR-1 | Figures available after filing arrival | Within two working days, including peak weeks |
| NFR-2 | Analyst time per confirmed filing | Under 10 minutes at steady state |
| NFR-3 | Availability during business hours | 99 percent, aligned to the portal's level |
| NFR-4 | Peak week throughput | 40 filings processed within the two-day figure |

**Processing volume and rhythm:**

About 420 filings a year arriving individually, but heavily clustered: peak weeks bring 40 filings. Capacity is sized for the peak week, not the average.

**Observability:**

Per filing: arrival time, extraction duration, field completion count, confidence distribution, and failure reason. Daily: queue depth and oldest unprocessed filing. These are operating signals; the defensible record is Section 9.

**Capacity reservation:**

Shared capacity is acceptable, provided the two-working-day figure holds in peak weeks. If it does not, reservation is revisited.

## 8. Security, Privacy & Compliance
> <strong>What it means:</strong> Who may reach this and the data behind it, how that data is protected, and which external obligations constrain it.
> <strong>Example:</strong> Only entitled credit officers may view a client's exposure. Data stays in Switzerland. Access is granted through the existing entitlement process, not a local user list.

**Who may access this, and how access is granted:**

Entitlement follows the existing credit analysis portal roles through the standard entitlement process: no local user list. Analysts see their own coverage; team leads see the team's queue.

**Personal and client-identifying data:**

No personal data. The signing officers named in filings are public-record information and are not extracted.

**Authentication:**

Users authenticate through corporate single sign-on. The extraction service calls the model gateway with its own service identity; no shared accounts.

**Data residency:**

Filings and extracted figures stay within the bank's approved processing regions. The Confidential counterparty list does not leave the bank.

**Encryption:**

Bank-standard encryption at rest for the document store and extraction database, and encryption in transit for every hop including calls to the model gateway.

**Secrets and credentials:**

Model gateway credentials live in the bank's secrets vault with standard rotation. Prompts are treated as controlled artefacts and contain no credentials, no counterparty names, and no internal identifiers.

**Applicable regulations and internal policy:**

The bank's SDLC control framework, the AI usage policy, and the data classification policy. Mapped in Appendix B.

## 9. Audit, Logging & Retention
> <strong>What it means:</strong> What must be recorded so that any action or output can be reconstructed and defended later, and how long those records are kept. Separate from operational logging.
> <strong>Example:</strong> Every authority calculation records the inputs used, the policy version applied, the result, and who saw it. Records are kept for ten years and cannot be altered.

**What must be recorded:**

Every extraction (filing, field set, drafted values, confidence), every analyst confirmation or correction (who, when, original and final value), and every export to the assessment spreadsheet. Each record carries the source reference it was based on.

**Retention periods:**

Confirmed figures and their audit trail kept ten years, from the record-keeping obligation on credit assessment inputs. Operational logs kept one year.

**Tamper evidence:**

Confirmation and correction records are append-only: a correction adds a record, never rewrites one. The audit store enforces write-once retention.

## 10. Integrations & Dependencies
> <strong>What it means:</strong> The other systems this one must talk to, what happens when they are unavailable, and whether any of them is about to change underneath you.
> <strong>Example:</strong> Positions come from the credit warehouse overnight. If the load has not completed, show the previous day's figures and mark every one of them as stale.

**Dependencies:**

| **Dependency**          | **Failure mode / fallback behaviour**                                | **Format**                      |
|-------------------------|----------------------------------------------------------------------|---------------------------------|
| Filing feed | Filings queue; the two-day clock starts at actual arrival | Internal API, PDF and HTML documents |
| Model gateway | Retry once, then fail the filing to manual handling; no fallback model | Gateway API, document text in, structured fields out |
| Credit analysis portal | Review pauses; extraction continues and queues results | Portal component interface |
| Shared analysis drive | Export queues and retries; analysts alerted if still failing after one hour | Versioned spreadsheet layout |

**Change, migration, and decommission risk:**

The credit analysis portal has no retirement plan. The shared analysis drive is scheduled for migration next year: the export path must survive that move.

**Import and export formats:**

Inbound: filing documents (PDF and HTML) from the filing feed. Outbound: the confirmed field set per counterparty in the agreed spreadsheet layout, one row per field with value, source reference, and confirmation status.

**Ownership and service levels:**

Filing feed: market data operations, next-working-day delivery. Model gateway: the AI platform team, business-hours support. Portal: the credit portal team under its existing service level.

## 11. Failure & Edge Cases
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once. The cases nobody thinks of until they happen in production.
> <strong>Example:</strong> Two officers open the same request at once. The second submission is refused with a message to refresh, rather than silently overwriting the first.

**Negative scenarios:**

A filing missing its financial statements section fails extraction with a stated reason and routes to manual handling. A field the model cannot locate is drafted as Not found, never as a guessed value.

**Conflicting or concurrent action:**

One filing, one reviewer: the review screen locks a filing while an analyst has it open. A second analyst sees who holds it. An amended filing arriving during review voids the open draft and requeues the amended version.

**Load and throttling:**

Peak weeks queue in arrival order. A repeated submission of the same confirmation is idempotent: one record, no duplicate export.

## 12. Constraints & Decisions
> <strong>What it means:</strong> What was fixed before the work started, and what was considered and deliberately rejected, with the reason. The record a future reader needs to understand why this looks the way it does.
> <strong>Example:</strong> Must read positions from the existing warehouse. A parallel position store was considered and rejected: it would create a reconciliation break.

**Fixed constraints:**

Model access only through the bank's approved model gateway. Hosting on the bank's standard analytics platform. The review surface must live in the existing credit analysis portal, not a new application.

**Alternatives considered and rejected:**

Buying the data vendor's extracted fundamentals was rejected: the vendor applies its own adjustments, so figures do not tie back to the filing, which the assessment requires. A rules-based PDF parser was rejected after trial: it broke on each new statement layout and covered under half the field set.

**Deliberate tradeoffs:**

Precision over coverage: a field is drafted only when it can carry a source reference; otherwise it is Not found and the analyst keys that one field. Fewer drafted fields beat plausible unverifiable ones.

# Part D: AI Governance
*Complete this part only where the Depth and Applicability block records this as an AI/ML feature.*

## 13. AI Classification & Justification
> <strong>What it means:</strong> Which kind of AI use case this is, how far it is being taken this time, and why a model is needed at all rather than ordinary logic.
> <strong>Example:</strong> Extracting named fields from filed documents is retrieval over documents, not a conversational assistant and not an autonomous agent.

**Which topic best matches this use case?**

|       | **Topic**                      |
|-------|--------------------------------|
| ☐     | 1) DMO / Data Agent            |
| ☐     | 2) Compliance Check            |
| ☐     | 3) Re/Write Productivity       |
| ☐     | 4) Agentic AI                  |
| ☒     | 5) RAG Document Extraction     |
| ☐     | 6) RAG and Auto Commentary     |

**Why AI rather than ordinary logic:**

A deterministic parser was tried on last year's filings: it held on standardised data tags but broke on the statement layouts that vary by filer, covering 14 of 32 fields reliably. The failing fields are exactly the ones analysts spend the time on. Layout variety across 420 filers is what defeats rules.

**Is the AI deciding, or recommending to a person who decides?**

Recommending. Every drafted figure is confirmed or corrected by an analyst before it becomes the business record. Nothing the model produces takes effect on its own.

**Primary topic rationale:**

RAG Document Extraction leads. There is a secondary compliance-check flavour in the validation rules, but they exist to check the extraction, not as a use case of their own.

## 14. AI Behaviour & Output Validation
> <strong>What it means:</strong> Correctness checks on what the AI produces, whether that is one model call or an agent taking several steps, and the places where an absent answer is the right answer.
> <strong>Example:</strong> An extracted gross profit must equal revenue minus cost of sales within a rounding tolerance. A filer with no cost of sales legitimately has neither: absence is correct, not a failure.

**Where a wrong answer is worse than no answer:**

Every extracted figure. A field the model cannot locate with a source reference is returned as Not found. A guessed financial figure entering a credit assessment is the single worst outcome this system can produce.

**Validation rules on output:**

| **ID**   | **Rule**                                  | **Tolerance**                      | **Breach action**                          |
|----------|-------------------------------------------|------------------------------------|--------------------------------------------|
| VR-1 | Gross profit equals revenue minus cost of sales where both are present | Rounding tolerance of one reporting unit | Flag for review |
| VR-2 | Total assets equal total liabilities plus equity | Rounding tolerance of one reporting unit | Flag for review |
| VR-3 | Every drafted value carries a locatable source reference | Exact | Reject the field: mark Not found |
| VR-4 | Sign conventions match the field definition (costs negative, revenue positive) | Exact | Flag for review |

**Where an absent value is expected rather than an error:**

A filer with no cost of sales legitimately has no gross profit: absence is correct there, not a failure. Banks and insurers structurally lack several of the 32 fields. The field list carries a per-industry applicability flag so the completeness check does not flag expected blanks.

## 15. Confidence & Human Review
> <strong>What it means:</strong> How sure the system is, how the user knows, and when a human must look before anything proceeds.
> <strong>Example:</strong> Fields extracted with high certainty load automatically. Anything less certain goes to a named reviewer within two working days.

**How the user knows how sure the system is:**

Each drafted field shows one of three bands: Confident, Check, or Not found. Bands were chosen over raw scores because analysts read a percentage as precision it does not have. The band definitions are printed on the review screen.

**Who reviews what the system is unsure about:**

The covering credit analyst reviews every filing and may confirm, correct, or reject any field. The team lead handles rejected filings and samples confirmed ones.

**How the user knows an answer came from AI:**

Drafted values are marked Drafted by extraction until confirmed; the export carries a confirmation status per field. Derived ratios computed by the spreadsheet are not marked, because they are fixed calculations on confirmed inputs.

**Confidence thresholds:**

| **Content type**   | **Auto-approve** | **Flag for review** | **Reject**      |
|--------------------|------------------|---------------------|-----------------|
| Text-stated figure | 0.97 and above | 0.80 to 0.97 | Below 0.80: Not found |
| Table-read figure | 0.95 and above | 0.75 to 0.95 | Below 0.75: Not found |

**Review routing:**

| **Trigger**                | **Action**         | **Owner**        | **SLA**          |
|----------------------------|--------------------|------------------|------------------|
| Any field banded Check | Filing routes to the covering analyst's Check queue | Credit analyst | Two working days |
| Any validation rule breach | Filing held; breach shown alongside the source | Credit analyst | Two working days |
| Filing rejected by an analyst | Routes to the team lead with the rejection reason | Team lead | Two working days |

**How the confidence signal was calibrated:**

Calibrated against the 50-filing evaluation set: Confident fields were correct 99.2 percent of the time, Check fields 91 percent. Recalibrated when the model or prompt changes.

## 16. Provenance & Lineage
> <strong>What it means:</strong> What is recorded about how each AI output was produced, so it can be traced back and defended. Distinct from the general audit record in Section 9.
> <strong>Example:</strong> Each extracted figure records the source document and page, the model and prompt version, and the confidence at the time it was produced.

**What each output records:**

Each drafted figure records the source filing identifier, the page and statement it was read from, the retrieved passages supplied to the model, and the prompt version.

**Traceability back to source:**

The review screen and the export both carry the source reference; one click opens the filing at the cited page. The audit report reproduces the same reference.

## 17. Evaluation & Test Evidence
> <strong>What it means:</strong> The evidence that this actually works: how much test data with known-correct answers exists, where the correct answers come from, and which hard cases the set must cover.
> <strong>Example:</strong> Fifty documents, each keyed independently by two analysts, disagreements adjudicated by the team lead, including several with unusual layouts.

**How much test data with known answers can be provided:**

50 filings, each keyed independently by two analysts with disagreements adjudicated by the team lead.

**Where the correct answers come from:**

Two analysts key each evaluation filing independently; the team lead adjudicates disagreements against the filing. The adjudicated set is the ground truth.

**Accuracy target, per source type:**

Text-stated figures: 99 percent. Table-read figures: 98 percent. Figures requiring derivation or unusual layouts: 95 percent, and always banded Check. A blended target was rejected because it would hide the weak path.

## 18. Model Lifecycle & Monitoring
> <strong>What it means:</strong> What happens to this after it goes live: how the model is kept fit, what is watched, and what happens when the model or the world underneath it changes.
> <strong>Example:</strong> Accuracy is sampled monthly against a refreshed set. If it falls below the agreed floor, the owner is alerted and the model is re-validated before further use.

**Model and hosting:**

A hosted frontier model reached only through the bank's model gateway. The AI platform team owns the provider relationship; the accountable model owner owns this use of it.

**Behaviour when the model is unavailable:**

Queue and retry once, then fail to manual handling. Silent fallback to a different or cheaper model is explicitly unacceptable: extraction accuracy was evidenced on one model, and a substitution invalidates that evidence.

**What is monitored after go-live:**

Monthly: correction rate per field, band calibration, Not found rate, and failure rate, reviewed by the accountable model owner. A rising correction rate on a field is the early drift signal.

# Part E: Closure

## 19. Acceptance Criteria
> <strong>What it means:</strong> The definition of done: specific, measurable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an officer reaches the underlying request from the authority figure in two clicks, and the daily total ties to the source system within 0.1 percent.

**Acceptance criteria:**

| **ID**   | **Criterion**                  | **Traces to**       |
|----------|--------------------------------|---------------------|
| AC-1 | On the 50-filing evaluation set, accuracy meets the per-source-type targets | FR-1 |
| AC-2 | Analyst time per confirmed filing is under 10 minutes, measured over one week of live use | NFR-2 |
| AC-3 | Every confirmed figure opens its source page in one click | FR-1 |
| AC-4 | A filing with a Check field cannot be exported until the field is confirmed or corrected | FR-3 |
| AC-5 | An amended filing supersedes the original and voids any open draft, verified by test | FR-7 |

**Acceptance scenarios:**

Given a supported filing, When extraction completes, Then every applicable field is drafted with a source reference or marked Not found. Given a drafted filing, When the analyst confirms, Then the export matches the confirmed values and the audit record is written. Given an unreadable filing, When extraction fails, Then the filing routes to manual handling and nothing is exported.

## 20. Open Items & Risks
> <strong>What it means:</strong> What is still undecided, and what could go wrong with the work itself. Kept visible rather than buried, so nothing is quietly forgotten.
> <strong>Example:</strong> Whether restated prior-year figures are handled automatically or manually is still open, owned by the data lead, and would change the design if answered either way.

**Open questions:**

| **#** | **Question**                                                             | **Owner**          | **Status**                      |
|-------|--------------------------------------------------------------------------|--------------------|---------------------------------|
| 1 | Whether restated prior-year figures replace the stored prior year automatically or on analyst confirmation | L. Fontana | Decided: on confirmation |
| 2 | Whether the Check queue is per analyst or pooled for the team | Team lead | Open |

**Risks:**

| **#** | **Risk**                                       | **Impact**               | **Mitigation**        |
|-------|------------------------------------------------|--------------------------|-----------------------|
| 1 | Accuracy in live use falls below the evaluation result | Analyst trust lost; re-keying returns | Monthly correction-rate monitoring with an escalation threshold |
| 2 | Peak week volume exceeds capacity | The two-day promise breaks in filing season | Peak sizing in NFR-4 and the queue alert at three days |
| 3 | The portal release slot slips | The review screen has no host | Hosting is committed in the portal release plan |

# Appendix A: Glossary
> <strong>What it means:</strong> Defined once here and used consistently everywhere. A term whose meaning differs elsewhere in the bank is the most expensive kind of ambiguity, so record the conflict rather than hoping nobody notices.

**Canonical terms:**

| **Term**   | **Single definitive meaning**                     | **Conflicting use elsewhere**                                   |
|------------|---------------------------------------------------|-----------------------------------------------------------------|
| Field | One of the 32 agreed financial figures | None known |
| Revenue | Net revenue as presented on the face of the income statement | The vendor feed's revenue includes vendor adjustments |
| Confirmed | An analyst has checked the field against its source and submitted it | None known |
| Filing | An annual report filed with the regulator (10-K in this iteration) | Elsewhere used for internal regulatory submissions |
| Restated | A prior-year figure changed in a later filing; the restated value governs | None known |

**Terms deliberately avoided:**

Accuracy unqualified is not used: the document states field-level accuracy per source type. Real-time is not used: the commitment is two working days. Sales is not used: the field is net revenue.

**Official glossary this must follow:**

Field definitions follow the bank's financial spreading standard. One difference: the standard's operating income aligns to the filer's own presentation here, recorded because the credit model expects the filer view.

# Appendix B: Compliance Mapping
> <strong>What it means:</strong> How this specification satisfies the bank's SDLC control obligations. The controls themselves live in the control catalogue and are not restated here: this table is the traceability an auditor or reviewer needs, nothing more.

**Control mapping:**

| **Control reference**               | **How this specification satisfies it**           | **Section**          |
|-------------------------------------|---------------------------------------------------|----------------------|
| SDLC requirements control | This document at the agreed depth, signed at the requirements gate | All |
| Access control standard | Entitlement through the existing portal process; role restrictions stated | 2, 8 |
| Record-keeping control | Ten-year retention of confirmed figures and audit trail | 9 |
| AI usage policy | Gateway-only model access; no retention by the provider | 8, 18 |

**Controls not applicable:**

Client-facing disclosure controls: no client sees this output. Agreed with the control office at requirements review.

## Review & Acceptance Checklist
*Confirm each of these before the document is signed off at its gate.*

- [x] No implementation detail (languages, frameworks, product names) appears in this specification
- [x] Every functional requirement is testable and unambiguous
- [x] Every acceptance criterion is measurable
- [x] Every requirement traces to a usage scenario, and every scenario to a requirement
- [x] Each scenario states its own independent test, so it can be delivered on its own
- [x] Roles state what each may not do, not only what they may
- [x] The delivery surface has been confirmed with the system that will host it
- [x] Retention periods state the obligation each derives from
- [x] Edge cases and failure modes are identified
- [x] Terminology is defined once in Appendix A and used consistently
- [x] No placeholder text or unresolved TODO remains
- [x] Compliance mapping in Appendix B is complete for every applicable control
- [x] If this is an AI feature: Part D is completed, not left as placeholder text
