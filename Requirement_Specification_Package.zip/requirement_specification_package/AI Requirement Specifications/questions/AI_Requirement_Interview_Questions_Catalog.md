**AI REQUIREMENT INTERVIEW QUESTIONS CATALOG**

**AI-Extended Track**

*Mirrors the requirements template section for section. Ask questions from the section they belong to; the answers land in the matching section of the document.*

**How to read this document**

> Each question carries a depth marker. **[L]** Lightweight, **[S]** Standard, **[E]** Exhaustive. The tiers are cumulative: Standard asks every [L] and every [S]; Exhaustive asks all three.
> Questions marked `[AI]` apply only where the feature is AI or machine learning. Answer No to the first question in Section 13 and every one of them is skipped.

## First Interview Key Points
*Use this for the very first conversation, before anyone has agreed to build anything. Do not read the numbered questions in this catalogue aloud: a list intimidates people and turns a conversation into an interrogation. Hold a normal discussion covering the points below, and let the recording or your notes fill in the Lightweight document afterwards. These points are the Lightweight tier expressed as a conversation. Getting through them in about an hour gives a business analyst and a technical architect enough to size the work at a high level.*

### Part A: The conversation, in the order it usually flows

- **Today's process:** How is this done today? Walk through the current workflow end to end, and what it produces.

- **Pain points:** What goes wrong most often: errors, rework, delays, wasted effort? Ask for a recent concrete example, not a general grumble.

- **Where AI would help:** `[AI]` Where in that workflow would AI actually save time? And could plain rules or a lookup do it instead? Knowing why a model is needed matters as much as knowing that it is.

- **The goal, in a sentence:** What is the core goal? What would success look like, and how would they know it had been achieved?

- **How far this time:** Is this a throwaway proof of concept, a limited-support MVP, or fully supported production? This one answer changes the availability, audit, and security expectations for everything else.

- **Who is involved:** Which types of user, what does each do differently, and is there anything one of them must not be able to do?

- **The data:** What data is involved? Name it their way: documents, spreadsheets, datasets, feeds. Where does it come from, and which system is the source of truth?

- **Input complexity:** `[AI]` If documents or inputs are involved, are they simple, medium, or complex, and roughly what mix? A model that handles clean one-pagers may fail on the messy ones, and the hard cases decide feasibility.

- **Volume and rhythm:** Roughly how much has to be processed, and how often: a number like 500 documents a quarter or 200 a day. And does it arrive as one big batch, or steadily through the day? This sizes everything.

- **What comes out, and where it goes:** What is the output, and where does it need to land: a screen, a spreadsheet, a file, another system?

- **Roughly how fast:** About how quickly must a result come back for the main action? An approximate answer is fine at this stage.

- **The words that matter:** Which two or three terms are most likely to be misunderstood, and does any of them already mean something different elsewhere in the firm?

- **What done looks like:** What single, checkable condition has to be true for this to count as done?

- **What's still open:** Which decisions are still genuinely open, the ones that would send the build down a different path depending on the answer?

### Part B: Assumption checks, where first interviews quietly go wrong
*These four are the assumptions clients most often carry into a first meeting unexamined. Each one, left unspoken, has derailed a real project. Surface them gently but explicitly before the conversation ends.*

- **The delivery surface:** How will people actually trigger this and see the result? Clients often assume an existing IT system will host it, or that a screen already exists. Confirm that assumption with the system owner, not just the business user. A screen nobody agreed to build changes the estimate completely.

- **The accuracy expectation:** `[AI]` What accuracy do they expect? Many say 100 percent. Explain early, and kindly, that no AI extraction is perfect, and that the practical answer is a human in the loop: the model does the heavy lifting, a person checks and corrects. Agreeing this in the first hour prevents a broken promise later.

- **The human review path:** `[AI]` Given that, who checks the uncertain cases, and how? Even a light answer now, one reviewer and a simple queue, tells the architect whether review is an afterthought or a core part of the flow.

- **The test data:** `[AI]` How many real examples with known-correct answers can they give you? Thirty to fifty is the minimum to tell whether the approach works at all. If they cannot supply any, that itself is a finding worth knowing on day one.

# Part A: Context

## 1. Purpose & Current State
*Why the work exists, and what is wrong with how it is done today. Ask this first: a specification that cannot state its own justification is missing its foundation.*

- **[L]** Why does this work exist? What problem is being solved?

- **[L]** Before we talk about the change: how is this done today? Walk me through the current process and what it produces.

- **[L]** What goes wrong most often today: errors, rework, misunderstandings, wasted effort? Can you give me a recent example?

- **[L]** What changes? What does this look like once it is built?

- **[S]** If this replaces something that already exists: which parts of the current version do people really use and value, and which are rarely looked at? What could we drop without anyone missing it?

- **[S]** Which two or three terms here are most likely to be misunderstood, and what exactly does each one mean? The full glossary comes later; these are the ones that would cause real damage if misread.

- **[E]** Is there an approved business case, and what benefit does it claim?

## 2. Scope & Stakeholders
*The boundary around the work, how far it is being taken this time, and who may and may not do what.*

- **[L]** What is the core goal of this feature, in one or two sentences?

- **[L]** What does success look like, and how would you know it was achieved?

- **[L]** What is explicitly out of scope for this piece of work? For each item, is it deferred or rejected?

- **[L]** What is the deployment target for this iteration? PoC (throwaway, no production path), MVP (user-facing, limited support), or Production (fully IT-supported, formal SLA)? This shapes availability, audit, and security depth for everything that follows.

- **[L]** Who are the different types of users, and what does each of them do differently?

- **[S]** Is there anything one type of user must not be able to do that another can?

- **[S]** For each area of this document, who is the one person who can confirm it is correct?

- **[E]** Which business processes and which downstream teams are affected by this?

# Part B: Behaviour

## 3. User Scenarios
*The distinct ways someone uses this, ordered by value. The traceability anchor: every requirement traces back to one of these. Describe journeys here, not surfaces.*

- **[L]** Walk through the single most important user journey, step by step, from the user's first action to the outcome they need.

- **[L]** Beyond that main flow, how else is this used? Things that only happen during a failure, a correction, or an audit count too.

- **[L]** Of those, which is most valuable? If we could only build one, which would it be?

- **[S]** For each of those: who does it, and what sets it off?

- **[S]** For each scenario, how could it be tested on its own and still deliver something useful, without the rest being finished?

- **[S]** If we had to shrink the output to a fraction of its size, what absolutely must stay, and what is nice-to-have?

- **[E]** How often does each scenario happen: many times a day, monthly, or only on exception?

- **[E]** Did anyone describe a way of using this that never made it into a requirement? Or is there a requirement that serves no scenario? Both are defects.

## 4. Functional Requirements
*What the system must do, each behaviour testable pass or fail.*

- **[L]** What must the system do? State each behaviour so that someone could test it and get a clear pass or fail.

- **[S]** For each requirement, which scenario does it serve?

- **[S]** Which requirements are genuinely Must-have, and which could ship in a later release?

- **[S]** Is any single requirement bundling two behaviours that should be stated separately?

- **[E]** Is there any requirement nobody could actually verify?

## 5. Data & Information
*What data is touched, where it comes from, how it is reached, and whether it can be trusted.*

- **[L]** What data does this read or produce? Name it the way your team does: datasets, tables, files, or feeds.

- **[L]** For each dataset, which few fields actually matter here, and which field tells one record apart from another?

- **[L]** What is the data classification of the information handled: Public, Internal, Confidential, or Restricted? If more than one, name the highest.

- **[L]** Does the data include client-identifying details or other restricted information? If so, which fields?

- **[L]** `[AI]` What is the largest single input the model must handle? State it in the unit that actually binds: pages, tokens, records, or conversation turns.

- **[S]** Where does each dataset live? Enterprise data mesh, a governed warehouse, a shared drive, or a local sandbox copy provided for this work?

- **[S]** How is each dataset accessed? SQL query, Python read, a REST or company-specific API, a file drop, or a manual export. Name the interface.

- **[S]** Is the access read-only, or does the feature write back? If it writes, to where, and who owns that target?

- **[S]** Does the feature just pass data through, or does it keep a copy somewhere: a folder, a database, or an object store?

- **[S]** Is the same data available in more than one system? Which one is the source of truth, and why that one?

- **[S]** Is the data coming from an approved, official source? And is it used as-is, or changed in some way before this feature uses it?

- **[S]** How do the datasets connect? Which field links them, and can one record on one side match many on the other?

- **[S]** How fresh does the data need to be, and how does it arrive: live query, scheduled batch, or a one-off snapshot?

- **[S]** What data quality problems exist in the source today: missing fields, stale values, duplicates, or systems contradicting each other? Which must we live with, and which must be fixed?

- **[S]** `[AI]` Is the source data reachable by the model's runtime at all, or does it sit behind an API, VPN, or entitlement the model host cannot call directly?

- **[E]** What is the expected data volume today, and the expected growth over the next one to two years?

- **[E]** May production data be used in test? If not, is masked or synthetic data required, and who approves its use?

- **[E]** `[AI]` Are there data usage rights constraints on sending this data to a model? Licensing, client consent, or cross-border transfer, as distinct from where the data is stored.

- **[E]** `[AI]` Is any training, fine-tuning, or few-shot example data involved, and where did it come from? Who owns it?

## 6. Delivery & Presentation
*The surface it is delivered through and how it behaves away from the happy path. Where the journeys run, not the journeys themselves.*

- **[L]** How will people trigger this and see the result: a dedicated screen, an existing system, Teams, a Copilot agent, a downloaded file, or output written to a folder?

- **[L]** If this depends on an existing system hosting it, has that system's owner confirmed they will actually do it? Confirm with the owner, not just the business user.

- **[S]** What should the user see the very first time, before there is any data to show?

- **[S]** What does the user see while something is loading, and how long is too long to wait without feedback?

- **[S]** What does the user see when an action fails? Is the message specific enough to act on?

- **[S]** Can users move to other screens while they wait for the action to finish, or must they stay put?

- **[S]** Are there accessibility standards this must meet?

- **[S]** Does this need to support more than one language or locale? If so, which, and are any of them read right-to-left?

- **[S]** `[AI]` How does the user know an answer came from AI rather than a fixed calculation?

- **[S]** `[AI]` How does the user see how confident the system is, and would they understand what that signal means?

- **[E]** Can the user correct or override an output? If so, where is that correction recorded, and who reviews it?

- **[E]** `[AI]` Will users deal only with this one AI feature, or will the flow pass through other agents, AI tools, or handoffs between tools?

- **[E]** `[AI]` Does the user need to see the reasoning, evidence, or sources behind the AI's answer, right there on screen?

- **[E]** `[AI]` Should users be able to look back at earlier AI interactions and reopen or reuse them later?

# Part C: Quality & Constraints

## 7. Quality Attributes
*How well it must perform, scale, stay available, and be observed.*

- **[L]** What is an acceptable response time for the main action, at least approximately?

- **[L]** Roughly how much needs to be processed, and how often: for example 500 documents a quarter, or 200 requests a day? This is the number that sizes everything else.

- **[S]** Do requests arrive as one big batch, like overnight or end of quarter, or as individual requests spread through the day, or a mix of both?

- **[S]** Does this need guaranteed, reserved capacity, or is shared best-effort capacity acceptable? Reserved capacity costs more but protects against slow responses when demand spikes elsewhere.

- **[S]** How many people will use this at the same time at peak?

- **[S]** What availability is required, and during which hours or windows does that apply?

- **[S]** What logging, metrics, or tracing must exist so an incident can be diagnosed after the fact?

- **[S]** `[AI]` What is the acceptable running cost? Per query, per batch, or per month, and who owns that budget?

- **[E]** What is the known ceiling, and how does the system behave as it approaches it: queue, shed load, or refuse?

- **[E]** What recovery time and recovery point objectives apply, and what is the business justification for each?

## 8. Security, Privacy & Compliance
*Who may reach this and the data behind it, how that data is protected, and which external obligations constrain it. Ask these with an engineer or risk officer present: precision earns its keep here.*

- **[L]** Who may access this, and how is access granted? Through an existing entitlement process, or something new?

- **[L]** Does the system process personal data or client-identifying information? Name the specific fields, not just yes or no.

- **[S]** How do users authenticate? Corporate single sign-on, or something bespoke? A bespoke mechanism needs an explicit justification, not a default.

- **[S]** What is the authorisation model: role-based, attribute-based, or record-level? Be specific, because “only their own portfolios” is record-level, not role-based, and they are built differently.

- **[S]** Who grants and revokes access, and how quickly does a revocation actually take effect? At the next login, or immediately?

- **[S]** Where must data reside, and are there regions or environments it must never leave?

- **[S]** What are the encryption requirements, at rest and in transit? Are there fields requiring encryption beyond the platform default?

- **[S]** How are secrets stored and rotated: API keys, credentials, connection strings? They must never live in code or in a config file in the repository.

- **[S]** Which regulations or internal policies apply, including indirectly through downstream consumers of this system's output?

- **[S]** `[AI]` Can a user obtain, through the model, information their own access rights would deny them directly? A retrieval system that indexes documents the asker cannot open has bypassed access control, not implemented it. State how per-user permissions are enforced at retrieval time, not just at the document store.

- **[S]** `[AI]` Does the model provider retain, log, or train on the data you send it? Cite the contractual terms, not the marketing page. For Confidential or Restricted data this is a gating question, not a detail.

- **[E]** Is there a segregation-of-duties constraint? Can the person who builds or operates this system also approve its output, or must those be different people?

- **[E]** Is a penetration test, threat model, or security review required before go-live? Who signs it off?

- **[E]** Who might misuse this, how, and what stops them?

- **[E]** Does any data leave the bank or cross a border? On what basis is that permitted?

- **[E]** `[AI]` Are prompts and system instructions treated as secrets, version-controlled outside the application code, and reviewed on change? A prompt containing a business rule is a business rule, wherever it lives.

## 9. Audit, Logging & Retention
*What must be recorded so an action or output can be reconstructed and defended later, and for how long. Distinct from operational logging in Section 7.*

- **[L]** What actions or outputs must leave a record, and what does each record contain: who, what, when, and on what basis?

- **[S]** How long must audit records be kept, and how long must the business records themselves be kept? State the obligation each period comes from.

- **[S]** Must records be immutable or tamper-evident? How is that achieved?

- **[S]** What is logged for security purposes: who accessed what, when, and from where?

- **[E]** Who may read the audit record, and is that access itself recorded?

- **[E]** What must be producible on request for internal audit, model validation, or a regulator, and in what form?

- **[E]** What must be reconstructable after the fact, and for how long must it remain so?

## 10. Integrations & Dependencies
*What this must talk to, what happens when those are unavailable, and whether any of them is about to change underneath you.*

- **[L]** Does this depend on any other system, upstream or downstream? Name each one, or state “none.”

- **[L]** Is any system this depends on due to be changed, migrated, or switched off in the near future? Building on a platform already being retired is something we need to know now, not after build.

- **[S]** For each dependency, what happens when it is slow, unavailable, or returns an error?

- **[S]** What data import or export formats must be supported?

- **[S]** Who owns each dependency, and what service level is committed?

- **[S]** `[AI]` Which model provider and endpoint is this using: a hosted third-party API, an internally hosted model, or an open-weights model you run yourself?

- **[E]** What protocol or API version assumptions are being made, and how is a breaking change from upstream handled?

- **[E]** Is there a fallback or degraded mode when a dependency is down, or does the whole feature stop working?

- **[E]** For external dependencies: what is the contractual basis, the exit position, and the concentration risk?

- **[E]** `[AI]` What deprecation notice does the model provider give, and what happens when they force a version migration you did not choose?

## 11. Failure & Edge Cases
*The negative and unusual paths. What the system does with bad input, overload, and two people acting at once.*

- **[L]** What is the single most likely way this could fail or be misused?

- **[L]** What should happen when a required input is missing, wrong, or out of range?

- **[S]** What happens at unusually busy times, or when someone repeats the same action rapidly?

- **[S]** What happens when two people or processes act on the same item at the same time? Is there a conflict rule, or is the second action simply refused?

- **[S]** `[AI]` Which is worse here: flagging something that is actually fine, or missing something that should have been caught? This one answer shapes thresholds and review routing everywhere else.

- **[E]** What are the known edge cases from any existing manual process this replaces?

- **[E]** What happens if this system, or the platform beneath it, is unavailable for an extended period?

- **[E]** `[AI]` What does the system do with an input unlike anything it has seen before? Does it abstain, or confidently produce nonsense?

- **[E]** `[AI]` Could a user deliberately misuse this? Prompt injection, extracting data they should not see, or laundering a decision through the model to avoid personal accountability.

## 12. Constraints & Decisions
*What was fixed before the work started, and what was considered and rejected, with the reason.*

- **[L]** Are there technical constraints fixed in advance: a mandated language, database, hosting environment, or platform?

- **[S]** Are there constraints from outside engineering entirely: budget, timeline, or a vendor contract already in place?

- **[S]** What other approaches were considered and rejected, and why? State the reason, not just the decision.

- **[S]** Are there tradeoffs being made on purpose, like simple over complete or fast over cheap, that we should write down for future readers?

- **[E]** Are there architecture decision records that carry the full reasoning?

- **[E]** `[AI]` Are there constraints on model choice? An approved model list, a ban on external APIs, an open-weights-only policy, or a data residency rule that rules out certain providers.

# Part D: AI Governance

## 13. AI Classification & Justification
*The gate for everything that follows. Answer the first question No and Part D does not apply at all. The archetype is for routing and governance, not for specifying behaviour, so it comes after the justification questions.*

- **[L]** `[AI]` Is this an AI or machine-learning feature at all? If No, skip every AI-marked question and mark Part D not applicable.

- **[L]** `[AI]` Why does this need AI at all? Could ordinary rules or a lookup table do the job? If so, why use a model?

- **[L]** `[AI]` Is the AI making the decision, or recommending one for a person to decide? The two carry very different governance.

- **[L]** `[AI]` Which of the bank's current AI archetypes best matches this: DMO / Data Agent, Compliance Check, Re/Write Productivity, Agentic AI, RAG Document Extraction, or RAG and Auto Commentary? This is for routing and governance, not for specifying behaviour. If none fits cleanly, say so and describe it in your own words rather than forcing a fit: a recorded mismatch is safer than inheriting the wrong governance path.

- **[S]** `[AI]` Does it span more than one archetype? If so, which leads, and why does that one lead?

- **[E]** `[AI]` Was a non-AI approach actually built or trialled before choosing a model? State the evidence, not just the belief that it would not work.

- **[E]** `[AI]` Has the model risk treatment for this classification been confirmed with the risk owner, and what did they say?

## 14. AI Behaviour & Output Validation
*Correctness checks on what the AI produces, and the places where no answer is the right answer.*

- **[L]** `[AI]` Where would a wrong answer be worse than no answer? Where should the system say “unknown” instead of guessing?

- **[L]** `[AI]` What business or correctness rules must every output satisfy before it can be used? This applies whether the output comes from a single model call or an agent taking several steps.

- **[S]** `[AI]` What cross-field or cross-source consistency checks apply to the output? What must reconcile against what?

- **[S]** `[AI]` Where is a blank value normal rather than a mistake? Tell us where an automatic check would wrongly flag it as an error.

- **[E]** `[AI]` Which of these rules are regulatory rather than business preference? Cite the rule or standard.

- **[E]** `[AI]` Are any validation rules conditional on jurisdiction, legal entity, product, or context?

- **[E]** `[AI]` On breach of a rule, what happens: reject the output, flag it for review, or accept it with a warning? For an agentic system, does it stop, retry, or escalate?

- **[E]** `[AI]` What prevents fabrication, prompt injection, instruction leakage, or data exposure through the prompt?

## 15. Confidence & Human Review
*How sure the system is, how the user knows, and when a human must look before anything proceeds.*

- **[L]** `[AI]` When the system gives an answer, does it also tell you how sure it is? And has that been checked, so that answers it calls “high confidence” really are right more often than “low confidence” ones? A number that looks certain but has never been checked is dangerous, because people trust it.

- **[L]** `[AI]` Who reviews what the system is unsure about, and what can they do: approve, correct, or reject?

- **[S]** `[AI]` What confidence level is high enough to act on without any human review?

- **[S]** `[AI]` Within what time limit must a flagged item be reviewed?

- **[S]** `[AI]` Should the threshold vary by output type, by input type, or by the materiality of the decision being made?

- **[E]** `[AI]` Are there outputs that always require human sign-off regardless of how confident the model is?

- **[E]** `[AI]` How are human corrections captured, who owns acting on them, and how do they feed back into improving the system? A correction log nobody reads satisfies the question but not the intent.

- **[E]** `[AI]` What must a reviewer know, or be trained in, to review this meaningfully?

- **[E]** `[AI]` At which lifecycle points must a human sign off before things move on: before design, before planning, before build, before release, or before the evidence is approved?

## 16. Provenance & Lineage
*What is recorded about how each output was produced, so it can be traced and defended.*

- **[S]** `[AI]` Must each output record what it was based on: the data, documents, records, prompts, or sources used to produce it?

- **[S]** `[AI]` How does a reader of an output reach the exact source it came from?

- **[E]** `[AI]` Must each output record its source, method, model version, prompt version, confidence, and timestamp?

- **[E]** `[AI]` Must the original input be retained alongside the output, not just the derived result?

- **[E]** `[AI]` Must a past output be reproducible? If so, what is retained to make that possible?

## 17. Evaluation & Test Evidence
*The evidence that this works: labelled data, ground truth, and the hard cases the set must cover.*

- **[L]** `[AI]` How much test data, with known correct answers, can you provide? As a rule of thumb we ask for a minimum of 30 to 50 examples so the results are statistically meaningful; more is better, because a small set makes the system look more accurate than it is.

- **[S]** `[AI]` Where does ground truth come from, and who verifies it is actually correct?

- **[S]** `[AI]` What accuracy target must be met, stated separately per output or content type? A single blended figure hides the fact that the hardest cases fail most.

- **[E]** `[AI]` Must the test set include edge cases, adversarial inputs, and deliberate failure paths, not just the happy path?

- **[E]** `[AI]` Is production-like data permitted in test, or must it be synthetic or masked?

- **[E]** `[AI]` Are there claims in this specification about what the model can do that have not actually been tested? A capability assumed is a capability unproven.

## 18. Model Lifecycle & Monitoring
*What happens after go-live: keeping the model fit, watching for drift, and handling change forced from outside.*

- **[L]** `[AI]` Which model is this using, hosted or self-hosted, and who owns that relationship?

- **[S]** `[AI]` What happens when the model or its API is unavailable? A manual fallback, a queue and retry, or a hard stop?

- **[S]** `[AI]` If the main model is down, is it acceptable to quietly switch to a cheaper or weaker one? If not, say so explicitly, because many systems do it by default.

- **[S]** `[AI]` What is monitored after go-live for drift or degradation, by whom, and how often?

- **[E]** `[AI]` When the model or prompt version changes, whether by choice or by provider deprecation, what re-validation is required before the new version reaches production?

- **[E]** `[AI]` Who is accountable for monitoring model performance once it is live, and what degradation triggers a rollback?

- **[E]** `[AI]` Who keeps the evaluation set current as real inputs drift over time, and how often is it refreshed? A stale benchmark silently overstates accuracy.

# Part E: Closure

## 19. Acceptance Criteria
*The definition of done, stated so it can be checked rather than felt.*

- **[L]** What specific, testable condition must be true for this to be considered done?

- **[S]** For each functional requirement, what is the exact pass or fail test?

- **[S]** For the main paths, state it this way: given a starting state, when an action happens, then what must be true?

- **[S]** Is there a Definition of Done beyond the individual criteria: documentation updated, monitoring in place, runbook written?

- **[E]** Does every requirement have at least one test that proves it was met? Is there any requirement we could not verify?

- **[E]** What evidence must be produced, and by whom, before sign-off?

- **[E]** `[AI]` What is the go or no-go decision for release, who makes it, and against what evidence?

## 20. Open Items & Risks
*What is still undecided, and what could go wrong with the work itself.*

- **[L]** Which open questions, if answered one way versus another, would send the build down a different path? List the decisions still outstanding that the design genuinely hinges on.

- **[S]** What could go wrong with delivering this, how bad would it be, and what reduces it?

- **[S]** Wherever the spec says “robust,” “intuitive,” “fast,” or “scalable”: what is the actual number or test behind each one?

- **[E]** Once the requirements are signed off, how are later changes handled, and who can approve a change to scope, controls, data use, or model behaviour?

- **[E]** Are there any remaining TODO markers, bracketed placeholders, or “TBD” notes anywhere in the specification? List them; none should reach sign-off unresolved.

- **[E]** What has been consciously deferred, to which phase or tier, and why?

# Appendix A: Glossary
*Defined once and used consistently. A term whose meaning differs elsewhere in the bank is the most expensive kind of ambiguity, so record the conflict rather than hoping nobody notices.*

- **[L]** Which terms need defining once, so that everyone uses them the same way?

- **[L]** Is there a term used elsewhere in the organisation that sounds like one used here but means something different?

- **[S]** Are there synonyms that should be deliberately avoided in this project, because they are ambiguous or already mean something else?

- **[S]** Does this feature's data eventually feed, or get consumed by, another team's system? If so, do they use the same terms the same way?

- **[S]** Is there an official glossary or data dictionary this must follow, whether company-wide, regulatory, or industry? Do our terms match it, and if not, is the difference written down?

- **[S]** `[AI]` Which domain terms will the model not know natively, and therefore must be defined for it in the prompt or retrieved into its context?

- **[E]** If a term's meaning changed during the project, did we keep a note of the old meaning rather than silently replacing it?

- **[E]** `[AI]` Where a term's meaning differs by jurisdiction or standard, how is the correct definition injected into the model's context, and is that injection recorded on the output?

# Appendix B: Compliance Mapping
*The traceability an auditor needs, and nothing more. Control text lives in the control catalogue and is not restated here.*

- **[L]** Which control obligations apply to this piece of work?

- **[S]** For each applicable control, which section of this document satisfies it, and how?

- **[S]** Which controls are judged not applicable, for what reason, and who agreed it?

- **[E]** Which obligations are met by process rather than by requirements, and where does that evidence live?

## Depth Grading Summary
*Counts are cumulative. Standard includes every Lightweight question; Exhaustive includes every Standard question.*

| **#**  | **Section**                           | **Generic** | **AI** | **L**  | **S**   | **E**   |
|--------|---------------------------------------|-------------|--------|--------|---------|---------|
| 1      | Purpose & Current State               | 7           | 0      | 4      | 6       | 7       |
| 2      | Scope & Stakeholders                  | 8           | 0      | 5      | 7       | 8       |
| 3      | User Scenarios                        | 8           | 0      | 3      | 6       | 8       |
| 4      | Functional Requirements               | 5           | 0      | 1      | 4       | 5       |
| 5      | Data & Information                    | 15          | 4      | 5      | 15      | 19      |
| 6      | Delivery & Presentation               | 9           | 5      | 2      | 10      | 14      |
| 7      | Quality Attributes                    | 9           | 1      | 2      | 8       | 10      |
| 8      | Security, Privacy & Compliance        | 13          | 3      | 2      | 11      | 16      |
| 9      | Audit, Logging & Retention            | 7           | 0      | 1      | 4       | 7       |
| 10     | Integrations & Dependencies           | 8           | 2      | 2      | 6       | 10      |
| 11     | Failure & Edge Cases                  | 6           | 3      | 2      | 5       | 9       |
| 12     | Constraints & Decisions               | 5           | 1      | 1      | 4       | 6       |
| 13     | AI Classification & Justification     | 0           | 7      | 4      | 5       | 7       |
| 14     | AI Behaviour & Output Validation      | 0           | 8      | 2      | 4       | 8       |
| 15     | Confidence & Human Review             | 0           | 9      | 2      | 5       | 9       |
| 16     | Provenance & Lineage                  | 0           | 5      | 0      | 2       | 5       |
| 17     | Evaluation & Test Evidence            | 0           | 6      | 1      | 3       | 6       |
| 18     | Model Lifecycle & Monitoring          | 0           | 7      | 1      | 4       | 7       |
| 19     | Acceptance Criteria                   | 6           | 1      | 1      | 4       | 7       |
| 20     | Open Items & Risks                    | 6           | 0      | 1      | 3       | 6       |
| A      | Appendix A: Glossary                  | 6           | 2      | 2      | 6       | 8       |
| B      | Appendix B: Compliance Mapping        | 4           | 0      | 1      | 3       | 4       |
|        | Total questions asked                 | 122         | 64     | 45     | 125     | 186     |
