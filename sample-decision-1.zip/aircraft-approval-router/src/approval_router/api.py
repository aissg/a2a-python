"""REST API.

    POST /route     {"memo": "...", "case_id": "optional"}  -> RoutingResult
    GET  /rules     current rule set with version and hash
    GET  /health

Configuration (environment):
    RULES_PATH        default config/rules.json
    ROUTER_EXTRACTOR  openai | azure        default openai
    AUDIT_LOG         JSONL path            default audit/audit.jsonl (set empty to disable)

Run with: uvicorn approval_router.api:create_app --factory
"""

from __future__ import annotations

import os

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from .audit import AuditLogger
from .extractors import FactExtractor, make_extractor
from .router import RoutingResult, route
from .rules import RuleSet, load_ruleset


class RouteRequest(BaseModel):
    memo: str = Field(min_length=1)
    case_id: str | None = None


def create_app(
    ruleset: RuleSet | None = None,
    extractor: FactExtractor | None = None,
    audit: AuditLogger | None = None,
) -> FastAPI:
    ruleset = ruleset or load_ruleset(os.getenv("RULES_PATH", "config/rules.json"))
    state: dict = {"extractor": extractor, "audit": audit}

    def get_extractor() -> FactExtractor:
        if state["extractor"] is None:
            state["extractor"] = make_extractor(
                os.getenv("ROUTER_EXTRACTOR", "openai"), ruleset.policy.min_confidence
            )
        return state["extractor"]

    if state["audit"] is None and os.getenv("AUDIT_LOG", "audit/audit.jsonl"):
        state["audit"] = AuditLogger(os.getenv("AUDIT_LOG", "audit/audit.jsonl"))

    app = FastAPI(title="Aircraft Approval Router", version="0.1.0")

    @app.get("/health")
    def health() -> dict:
        return {"status": "ok", "ruleset_version": ruleset.version, "ruleset_sha": ruleset.sha}

    @app.get("/rules")
    def rules() -> dict:
        return {"sha": ruleset.sha, **ruleset.model_dump(mode="json")}

    @app.post("/route", response_model=RoutingResult)
    def route_memo(req: RouteRequest) -> RoutingResult:
        try:
            result = route(req.memo, ruleset, get_extractor())
        except Exception as exc:  # provider or network failure: never guess an approver
            raise HTTPException(status_code=502, detail=f"Fact extraction failed: {exc}") from exc
        if state["audit"]:
            state["audit"].write(result, memo=req.memo, case_id=req.case_id)
        return result

    return app
