"""Aircraft-financing approval router.

The decision model only answers atomic fact questions about a credit memo.
A deterministic rule engine maps those facts to the approving risk officer.
"""

from .logic import Tri
from .rules import RuleSet, load_ruleset
from .router import RoutingResult, decide, route

__all__ = ["Tri", "RuleSet", "load_ruleset", "RoutingResult", "decide", "route"]
__version__ = "0.1.0"
