"""Microsoft-Decision-1 adapter for Microsoft Foundry.

Status: Microsoft-Decision-1 is in public preview, text only, 32K context.

Request format: Microsoft has not fully documented the Foundry wire format.
This adapter uses the "System One" schema (model, state, questions with
type/instructions/criteria; answers with choice/probabilities/confidence),
which third-party gateways use for Decision-1. Before production use, confirm
the path and body against the "View code" sample in your Foundry deployment,
and adjust AZURE_DECISION_PATH if needed.

Environment:
    AZURE_DECISION_ENDPOINT     https://<resource>.services.ai.azure.com
    AZURE_DECISION_DEPLOYMENT   your deployment name (must not contain "Microsoft")
    AZURE_DECISION_PATH         default /providers/microsoft/v1/systemone
    AZURE_DECISION_API_KEY      key auth; if unset, Entra ID (azure-identity) is used
"""

from __future__ import annotations

import os
from typing import Any, Callable, Mapping

import httpx

from ..rules import FactDef
from .base import CHOICES, FactExtractor, RawAnswer, build_instructions

ENTRA_SCOPE = "https://cognitiveservices.azure.com/.default"


class AzureDecision1Extractor(FactExtractor):
    name = "azure"

    def __init__(
        self,
        endpoint: str | None = None,
        deployment: str | None = None,
        api_key: str | None = None,
        path: str | None = None,
        min_confidence: float = 0.9,
        timeout: float = 30.0,
        http_client: httpx.Client | None = None,
        token_provider: Callable[[], str] | None = None,
    ) -> None:
        super().__init__(min_confidence)
        self.endpoint = (endpoint or os.getenv("AZURE_DECISION_ENDPOINT", "")).rstrip("/")
        self.deployment = deployment or os.getenv("AZURE_DECISION_DEPLOYMENT", "decision-1")
        self.path = path or os.getenv("AZURE_DECISION_PATH", "/providers/microsoft/v1/systemone")
        self.api_key = api_key or os.getenv("AZURE_DECISION_API_KEY")
        if not self.endpoint:
            raise ValueError("Set AZURE_DECISION_ENDPOINT or pass endpoint=")
        self.http = http_client or httpx.Client(timeout=timeout)
        self._token_provider = token_provider

    def _headers(self) -> dict[str, str]:
        if self.api_key:
            return {"api-key": self.api_key, "Content-Type": "application/json"}
        if self._token_provider is None:
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider

            self._token_provider = get_bearer_token_provider(DefaultAzureCredential(), ENTRA_SCOPE)
        return {"Authorization": f"Bearer {self._token_provider()}", "Content-Type": "application/json"}

    def build_request(self, memo: str, facts: Mapping[str, FactDef]) -> dict[str, Any]:
        return {
            "model": self.deployment,
            "state": memo,
            "questions": {
                name: {"type": "choice", "instructions": build_instructions(fact), "criteria": CHOICES}
                for name, fact in facts.items()
            },
        }

    def _extract_batch(
        self, memo: str, facts: Mapping[str, FactDef]
    ) -> tuple[dict[str, RawAnswer], dict[str, Any]]:
        resp = self.http.post(
            f"{self.endpoint}{self.path}", headers=self._headers(), json=self.build_request(memo, facts)
        )
        resp.raise_for_status()
        body = resp.json()

        raw: dict[str, RawAnswer] = {}
        for name, ans in (body.get("answers") or {}).items():
            if name not in facts or not isinstance(ans, dict):
                continue
            if ans.get("type") == "refusal" or "choice" not in ans:
                raw[name] = RawAnswer(refused=True)
                continue
            raw[name] = RawAnswer(
                choice=str(ans["choice"]),
                confidence=ans.get("confidence"),
                probabilities={str(k): float(v) for k, v in (ans.get("probabilities") or {}).items()},
            )

        meta = {
            "provider": "azure",
            "model": body.get("model", self.deployment),
            "request_id": resp.headers.get("apim-request-id") or resp.headers.get("x-request-id"),
            "usage": body.get("usage"),
        }
        return raw, meta
