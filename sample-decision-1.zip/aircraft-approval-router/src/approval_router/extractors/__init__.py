from __future__ import annotations

from typing import Any

from .base import CHOICES, ExtractionResult, FactAnswer, FactExtractor, RawAnswer
from .fixture import FixtureExtractor

__all__ = [
    "CHOICES",
    "ExtractionResult",
    "FactAnswer",
    "FactExtractor",
    "RawAnswer",
    "FixtureExtractor",
    "make_extractor",
]


def make_extractor(kind: str, min_confidence: float = 0.9, **kwargs: Any) -> FactExtractor:
    """Build an extractor by name: openai, azure or fixture (needs answers=... or answers_path=...)."""
    kind = kind.lower()
    if kind == "openai":
        from .openai_decisions import OpenAIDecisionsExtractor

        return OpenAIDecisionsExtractor(min_confidence=min_confidence, **kwargs)
    if kind == "azure":
        from .azure_decision1 import AzureDecision1Extractor

        return AzureDecision1Extractor(min_confidence=min_confidence, **kwargs)
    if kind == "fixture":
        if "answers_path" in kwargs:
            return FixtureExtractor.from_file(kwargs["answers_path"], min_confidence)
        return FixtureExtractor(kwargs.get("answers", {}), min_confidence)
    raise ValueError(f"Unknown extractor '{kind}' (use openai, azure or fixture)")
