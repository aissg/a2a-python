# Authoring an extension

An extension adds new commands. If you want to change how existing commands
behave, you want a preset instead: see [ARCHITECTURE.md](ARCHITECTURE.md).

The worked reference is [`platform/base/sketch`](../platform/base/sketch/).
Read it before writing anything: it is a complete extension with three
commands, resolver scripts, an 87-assertion selftest and full documentation,
and it is the bar the estate expects.

---

## 1. Start in incubation

```bash
# your team's sandbox: no schema, no catalog, no review
incubation/<your-team>/skt-yourthing/
```

Nothing in `incubation/` reaches a catalog channel, so iterate freely. Ids are
not reserved here; reservation happens at promotion.

Do not start in `domains/`. Governed space is for things that work.

## 2. Choose an id

The id is typed in every command, so it is the one naming decision that keeps
costing you.

| Rule | Why |
|------|-----|
| Lowercase kebab-case | Enforced by the schema |
| `skt-` prefix for L3 and LX | Reserved for Sketch; marks the family |
| At most 20 characters | Validator rejects longer; commands get unusable |
| Names the capability, not the audience | `skt-kyc`, never `skt-wm-kyc-team` |

`speckit.skt-kyc.screen` is 26 characters. `speckit.sketch-wealth-kyc.screen`
is 38 and nobody types it twice.

**The id answers "what does this do", never "who is it for".** Roles and
divisions live in bundles, where they are invisible to the person typing.

## 3. Layout

```
skt-yourthing/
├── extension.yml            manifest: the contract
├── README.md                what it does, what state it is in
├── .gitlab-ci.yml           three lines, includes the shared template
├── commands/
│   └── yourcmd.md           the command body the agent reads
└── scripts/
    ├── bash/
    │   ├── resolver.sh      validates arguments, emits JSON
    │   └── selftest.sh      your tests
    └── lib/                 anything shared
```

## 4. The manifest

```yaml
schema_version: "1.0"

extension:
  id: "skt-yourthing"
  name: "Sketch Your Thing"
  version: "0.0.1"
  description: >
    One or two lines. What it does, not who asked for it.
  author: "sketch"
  license: "MIT"

requires:
  speckit_version: ">=0.6.0"
  extensions:
    sketch: ">=0.3.0"

provides:
  commands:
    - name: "speckit.skt-yourthing.yourcmd"
      file: "commands/yourcmd.md"
      description: "[Sketch L3] What this command does"

hooks: {}

tags: ["sketch", "l3", "process"]
```

**Command names must be `speckit.{ext-id}.{cmd}`.** Spec Kit validates this at
install and rejects anything else, and CI catches it before you get that far.

## 5. Write the command

The command file is what the agent reads. Conventions this estate expects,
taken from the base extension:

**A resolver script validates every argument.** The command body never derives
paths itself. It runs the resolver, stops on non-zero, and uses the JSON that
comes back.

```bash
SK=".specify/extensions/skt-yourthing"
[ -d "$SK" ] || { echo "not installed"; exit 1; }
"$SK/scripts/bash/resolver.sh" $ARGUMENTS --json
```

This matters because an agent that derives its own paths will eventually derive
a wrong one, and the failure will be silent. A resolver that exits 3 with a
hint is a failure you can act on.

**Exit codes are a contract.** The base extension uses: 1 usage, 2 mutually
exclusive options, 3 required input missing or unresolvable, 4 optional input
unresolvable, 5 wrong format, 6 missing asset, 7 missing tool. Reuse the shape.

**Facts come from sources.** If your command produces content, it does not
invent values. An absent number is a visible gap, not a plausible default. This
is the single strongest convention in the base extension and the reason its
output survives review.

**Preserve the hook protocol exactly.** `before_*` and `after_*`, the `enabled`
and `condition` handling, the dot-to-hyphen command naming, `EXECUTE_COMMAND`
emission. Copy it from `commands/specify.md` rather than paraphrasing.

## 6. Write a selftest

`scripts/bash/selftest.sh`, exiting non-zero on any failure. CI requires it
once the extension is past `planned`.

Test the resolver's contract, not the agent's behaviour: every exit code, every
flag combination, every path form (absolute, relative, `~`). The base
extension's selftest is 87 assertions and is the model.

```bash
#!/usr/bin/env bash
set -uo pipefail
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); printf '  ok    %s\n' "$1"; }
bad(){ FAIL=$((FAIL+1)); printf '  FAIL  %s\n' "$1"; }
# ... your assertions ...
printf '\n%d passed, %d failed\n' "$PASS" "$FAIL"
[[ "$FAIL" -eq 0 ]]
```

## 7. Wire up CI

```yaml
include:
  - project: 'AI Augmented Development Community/SketchKitExtensions'
    ref: main
    file: '/ci/extension-release.yml'
    inputs:
      ext_id: skt-yourthing
      require_selftest: true
```

That gives you manifest validation, command-name checking, your selftest, and
on a `v*` tag, a published archive that CI verifies is downloadable.

## 8. Promote

1. Transfer the GitLab project into `domains/<division>/extensions/`, or
   `platform/extensions/` if it is genuinely cross-cutting. A transfer, not a
   copy, so history follows.
2. Add it to your division's catalog fragment,
   `platform/catalog/catalog.d/<division>.yml`, with `status: alpha`.
3. Add it to at least one bundle. An extension in no bundle cannot be installed
   by anyone, and the validator warns about it.
4. Open the merge request. CODEOWNERS routes it to your division's leads.

Validate before you push:

```bash
cd platform/catalog
python3 tools/validate_catalog.py
python3 tools/build_catalog.py
```

## Status, honestly

| Status | Means |
|--------|-------|
| `planned` | Id reserved, shape agreed, nothing runs |
| `alpha` | Runs, your team uses it, interface may change |
| `stable` | Released, SemVer honoured, any division can install it |

Use `planned` freely while you are still building. It is better than an empty
repository that looks abandoned or an `0.0.1` that looks shipped.

## The checklist

- [ ] Id is short, kebab-case, names the capability not the audience
- [ ] Every command name is `speckit.{ext-id}.{cmd}`
- [ ] Every command file referenced in the manifest exists
- [ ] A resolver validates arguments and emits JSON; the command uses only that
- [ ] Exit codes follow the estate's shape
- [ ] `selftest.sh` exists, is executable, and exits non-zero on failure
- [ ] README says what state it is in, plainly
- [ ] `.gitlab-ci.yml` includes the shared template
- [ ] Catalog entry added, with an accurate `status`
- [ ] Member of at least one bundle
