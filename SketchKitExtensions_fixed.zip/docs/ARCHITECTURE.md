# Architecture

Why this is layered the way it is, and which mechanism to reach for.

---

## Three mechanisms, three jobs

Getting this wrong is the most common mistake, so it comes first.

| | Extension | Preset | Bundle |
|---|-----------|--------|--------|
| **Adds** | New commands | Nothing | Nothing |
| **Changes** | Nothing existing | How existing commands behave | Nothing |
| **Is** | The unit of authorship | An override layer | The unit of installation |
| **Contains** | Commands, scripts, templates | Templates, constitution | A pinned component list |

**The test:** does your change alter what a developer *types*, or only what
happens *behind* an existing command?

New command → extension. Same command, different behaviour → preset. A curated
set someone installs in one go → bundle.

A worked case: adding `-l`/`-s`/`-e` flags and a transcript input to spec
authoring is a new calling convention, so `sketch` is an extension with its own
command names. Overriding `speckit.specify` as a preset would have technically
worked, but on uninstall the fallback silently reinterprets flags as a feature
description, and any other preset touching the same command wins or loses
invisibly.

---

## The layers

Layers describe **provenance**, not template-resolution priority.

```
Layer 4    review overlays              sketch-reviewer, red-team
Layer X    cross-cutting utilities      skt-pdfx, skt-graph, skt-llmcost
Layer 3    workload and domain          skt-fullstack, skt-kyc, skt-riskrep
Layer 2    Sketch bank base             sketch: specify, independent-read, clarify
Layer 1    Spec Kit core (mirrored)     speckit.specify, plan, tasks, implement
```

**Layer 1** is Microsoft's, mirrored unmodified and tag-tracked.

**Layer 2** is `sketch`: things that apply to all software development in the
bank, regardless of division, workload or role. It is in every bundle, which is
a schema rule rather than a habit.

**Layer 3** is where most work lives. Workload extensions sit in
`platform/extensions/`; domain extensions sit in `domains/<division>/`.

**Layer X** utilities join any bundle at any layer. A PDF extractor is not more
or less foundational than a KYC screener; it is orthogonal to both.

**Layer 4** overlays are added per engagement rather than by default, because
raising the evidence bar on everything raises it on nothing.

---

## Why bundles install and extensions author

The upstream community catalog is the counter-example: 144 extensions, 23%
shipping exactly one command, nothing grouping them.

Three consequences follow, and all three are avoided here.

**Install order and completeness become tribal knowledge.** Which ten
extensions make a working full-stack setup lives in chat threads. Here it is a
bundle manifest the CLI can verify.

**No version coherence.** Extension A at 2.1 and B at 0.4 may never have been
tested together. A bundle pins exact versions, so two projects provisioned six
months apart get provably the same commands.

**Fragmentation feels productive.** Every capability its own repo, version and
install step. Keeping extensions small is correct; making developers assemble
them by hand is not. Bundles let both be true.

---

## Naming

Ids are typed in every command, so length is a recurring cost, not a one-off
aesthetic choice.

| Layer | Pattern | Example command |
|-------|---------|-----------------|
| L2 | `sketch` | `/speckit.sketch.specify` (26 chars) |
| L3, LX | `skt-<capability>` | `/speckit.skt-kyc.screen` (23 chars) |

Two rules that save arguments later:

**The id names the capability, never the audience.** `skt-kyc`, not
`skt-wm-kyc`. Roles and divisions live in bundles, invisible to the person
typing. Encoding a role in an id gives you
`/speckit-sketch-business-analyst-specify`, which nobody types twice.

**Bare `sketch` is reserved for the base.** A second cross-cutting capability
does not become a second bare id, because ids are unique. Either it is a new
command inside `sketch` (same job, new verb) or a new suffixed extension
(different job). That test does not run out of room; "is it cross-cutting" does.

---

## The catalog is the control plane

Every installable unit is a catalog entry with a repo, an exact version and a
layer. `catalog.schema.yml` validates every merge request, so the CLI only ever
sees what CI approved.

`SPECKIT_CATALOG_URL` points at the bank's catalog rather than the public one,
which means a mirrored-and-approved entry cannot be silently overridden by
upstream.

---

## Federation

A single catalog file would put the platform team on the merge path of every
publish in the bank. That does not scale past the first division, and central
review of domain content adds latency rather than safety: whether a KYC
questionnaire rule is correct is a Compliance judgement.

So the catalog is fragmented. Each division owns one file under `catalog.d/`,
CODEOWNERS routes merge requests to that division's leads, and CI aggregates
the fragments into the served catalog.

Central control shrinks to a contract: the schema, the CI gates, the shared
layers, and the id registry. Everything else is delegated, and the delegation
is enforced by subgroup membership and CODEOWNERS rather than by asking people
to only touch their own folders.

---

## Three channels

```
incubation  →  domain  →  org
```

**Incubation** is per-team, in no channel, no rules. **Domain** is a division's
own catalog fragment. **Org** is the aggregated catalog developers read.

Promotion between them is a GitLab project transfer plus a catalog merge
request. Nothing enters the org channel unreviewed, and nothing has to be
reviewed before it is worth reviewing.
