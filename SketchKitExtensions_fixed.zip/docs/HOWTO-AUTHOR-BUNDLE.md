# Authoring a bundle

A bundle is a manifest that pins exact versions of extensions and presets. It
adds no commands of its own. It is the only thing a developer installs.

The worked reference is
[`platform/bundles/sketch-requirements`](../platform/bundles/sketch-requirements/):
every component in it is stable, so it is installable today.

---

## When you need one

When a role or a workload needs a known-good combination of capabilities.
"What does a business analyst install on day one" is a bundle question. "What
does this capability do" is an extension question.

Do not create a bundle for a single extension unless you want the version pin
and the stable install command, which are legitimate reasons on their own.

## Layout

```
sketch-yourbundle/
├── bundle.yml       the manifest
├── README.md        what it provisions and for whom
└── .gitlab-ci.yml   includes the shared template
```

Three files. There is no code in a bundle.

## The manifest

```yaml
schema_version: "1.0"

bundle:
  id: "sketch-yourbundle"
  name: "Sketch Your Bundle"
  version: "0.1.0"
  description: >
    The workload this provisions, in one or two lines.
  author: "sketch"
  license: "MIT"

# Omit 'integration' unless you are deliberately pinning one agent. A bundle
# with no integration inherits whichever the project was initialised with.

components:
  - type: "extension"
    id: "sketch"
    version: "0.3.0"
  - type: "extension"
    id: "skt-yourthing"
    version: "0.0.1"
  - type: "preset"
    id: "sketch-constitution"
    version: "0.1.0"
```

## Rules the validator enforces

**Every bundle includes the `sketch` base.** Not a convention: the schema fails
a bundle without it. Layer 2 applies to all software development in the bank,
so a bundle that omits it is either a mistake or needs a documented exemption.

**Pins are exact.** `"0.3.0"`, never `">=0.3.0"` or `"^0.3"`. A range lets two
projects provisioned months apart diverge, and the first symptom is a bug that
reproduces on one machine and not another.

**Every pin resolves.** The component must exist in the catalog at exactly that
version. CI fetches the catalog and checks, so a bundle cannot ship a promise
the catalog will not keep.

**No component listed twice.**

## Composition, not forking

If two bundles need the same capability, both list it. Neither copies it.

A fix to `skt-pdfx` ships once, and every bundle picks it up on its next
version bump. That is the whole reason extensions stay small and separate: the
alternative is the same fix applied in four places, three of them eventually
wrong.

## CI

```yaml
include:
  - project: 'AI Augmented Development Community/SketchKitExtensions'
    ref: main
    file: '/ci/bundle-release.yml'
    inputs:
      bundle_id: sketch-yourbundle
```

The job that matters is `pins-resolve`. It fetches the org catalog and proves
every pinned component exists at that exact version. It also notes any
component still `status: planned`, so you know your bundle installs commands
that do nothing yet.

## Releasing

```bash
# 1. edit bundle.yml: bump bundle.version, and any component pins
# 2. commit, then tag
git tag v0.2.0 && git push origin v0.2.0
# 3. open a merge request bumping this bundle in your catalog fragment
```

CI refuses a tag whose version disagrees with the manifest, and prints a
reminder that publishing the archive does not make the bundle discoverable:
the catalog fragment has to move too, in a separate reviewed merge request.

Full detail in [RELEASING.md](RELEASING.md).

## Bumping a component

When `skt-yourthing` releases 0.0.2, every bundle pinning 0.0.1 keeps working
on 0.0.1. That is the point of pinning. To adopt it:

1. Edit the pin in `bundle.yml`.
2. Bump `bundle.version`: the combination changed, so the bundle changed.
3. Tag, and open the catalog merge request.

A bundle version therefore identifies a tested combination, not a date.

## The checklist

- [ ] `id` matches the directory name and the catalog entry
- [ ] Includes the `sketch` base
- [ ] Every pin is exact, no ranges
- [ ] Every pin resolves in the catalog at that version
- [ ] README lists the components and says plainly if any are `planned`
- [ ] `.gitlab-ci.yml` includes the shared template
- [ ] Catalog fragment updated in the same change
