# Releasing

A release is a tag on a reviewed commit. Nothing is released from a laptop.

**Extensions are not PyPI packages.** Only the `specify` CLI is. An extension
release is an archive at a stable URL, which is what these pipelines produce.

---

## The short version

```bash
# 1. bump the version in the manifest (extension.yml or bundle.yml)
# 2. commit through a merge request, reviewed as normal
# 3. tag the merged commit
git tag v0.2.0
git push origin v0.2.0
# 4. open a merge request bumping the version in the catalog fragment
```

Step 4 is the one people forget. Publishing the archive makes it *fetchable*.
The catalog makes it *discoverable*. Until the fragment moves,
`specify bundle install` still resolves to the previous version.

---

## What the pipeline does

Both templates live in [`../ci/`](../ci/) and are included by each repo's own
three-line `.gitlab-ci.yml`.

### Extensions: `ci/extension-release.yml`

| Stage | Job | Runs on | What it does |
|-------|-----|---------|-------------|
| validate | `manifest` | every push | Manifest is well-formed; every command is `speckit.{ext-id}.{cmd}`; every referenced command file exists |
| validate | `tag-matches-manifest` | tags | The tag and `extension.version` agree |
| test | `selftest` | every push | Runs the extension's own tests |
| test | `house-style` | every push | Advisory, never blocks |
| release | `publish` | `v*` tags | Builds the archive, uploads to the Package Registry |
| verify | `verify-published` | `v*` tags | Downloads it back, confirms it is a readable archive containing `extension.yml` |

`verify-published` exists because a release nobody can download is not a
release, and the failure is otherwise discovered by the first person who tries
to install it.

### Bundles: `ci/bundle-release.yml`

| Stage | Job | Runs on | What it does |
|-------|-----|---------|-------------|
| validate | `manifest` | every push | Exact pins, no duplicates, base included |
| validate | `pins-resolve` | every push | Fetches the org catalog, proves every pin exists at that exact version |
| validate | `tag-matches-manifest` | tags | Tag and `bundle.version` agree |
| release | `publish` | `v*` tags | Builds and uploads the archive |
| verify | `remind-catalog-bump` | `v*` tags | Prints the reminder that the catalog fragment still needs a merge request |

`pins-resolve` is the important one. Without it a bundle can pin a version that
was never released, and nobody finds out until an install fails.

---

## Versioning

SemVer, exact, no ranges anywhere in the estate.

| Change | Bump |
|--------|------|
| A command is removed or its arguments change incompatibly | major |
| A command is added, or behaviour extended compatibly | minor |
| Fix with no interface change | patch |

For a bundle, **any** component pin moving is at least a minor bump: the
combination changed, so the thing you are shipping changed. A bundle version
identifies a tested combination, not a date.

While below `1.0.0`, treat minor as the breaking bump. That is the convention
in use: `sketch` went `0.1.0` to `0.3.0` across two interface changes.

---

## Where releases land

```
${CI_API_V4_URL}/projects/${CI_PROJECT_ID}/packages/generic/<id>/<tag>/<id>.zip
```

Installable directly, bypassing the catalog:

```bash
specify extension add sketch --from https://gitlab.example.com/api/v4/projects/42/packages/generic/sketch/v0.3.0/sketch.zip
```

Useful for testing a release candidate. Not the supported path for developers:
they install bundles by name from the catalog.

GitLab also generates a tag archive automatically at
`/-/archive/v0.3.0/<repo>-v0.3.0.zip`. It works, but prefer the Package
Registry URL: it is an intentional release artifact rather than a git feature
that happens to serve zips.

> **Verify once before relying on this.** Every documented `--from` example
> upstream uses a `github.com/.../archive/refs/tags/...` URL. It is almost
> certainly agnostic, since it is fetching a zip over HTTP, but GitLab-shaped
> URLs are not shown in the upstream docs. Test
> `specify extension add <id> --from <your-gitlab-url>` once and confirm.

---

## Releasing the catalog itself

The catalog has no tags. Its default branch is the release: merging to `main`
rebuilds `catalog.yml` and publishes it to GitLab Pages, which is what
`SPECKIT_CATALOG_URL` points at.

CI refuses a merge where `catalog.yml` does not match its fragments, so the
served catalog cannot silently go stale. If you edited a fragment, run:

```bash
cd platform/catalog
python3 tools/build_catalog.py
```

and commit the result alongside your fragment change.

---

## Checklist

**Extension**

- [ ] `extension.version` bumped
- [ ] `CHANGELOG.md` entry written
- [ ] Selftest passes locally
- [ ] Merge request reviewed and merged
- [ ] Tag pushed, matching the manifest exactly
- [ ] Pipeline green, including `verify-published`
- [ ] Catalog fragment bumped, with `status` still accurate
- [ ] Every bundle pinning it updated, if they should adopt this version

**Bundle**

- [ ] `bundle.version` bumped
- [ ] Component pins updated and each one exists at that version
- [ ] `pins-resolve` green
- [ ] Tag pushed, matching the manifest
- [ ] Catalog fragment bumped

---

## Troubleshooting

**`tag-matches-manifest` fails.** The tag and the manifest disagree. Delete the
tag, fix the manifest, tag again:
`git tag -d v0.2.0 && git push origin :refs/tags/v0.2.0`.

**`pins-resolve` says a component is not in the catalog.** Either the id is
wrong, or the extension has not been added to a fragment yet. An extension must
be in the catalog before a bundle can pin it.

**`pins-resolve` says the version differs.** The extension released but the
catalog fragment was not bumped, or was bumped past what you pinned. Fix
whichever is stale.

**`catalog-is-current` fails.** You changed a fragment without rebuilding.
`python3 tools/build_catalog.py` and commit.

**`publish` gets 401 or 403.** `CI_JOB_TOKEN` lacks Package Registry write, or
the registry is disabled for the project. Check Settings, then General, then
Visibility.
