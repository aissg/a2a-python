# GitLab setup

Turning this skeleton into the real group structure. Written for whoever
administers the GitLab group.

> **Tier matters.** CODEOWNERS with *enforced* approval requires GitLab
> Premium. On Free, a CODEOWNERS file assigns reviewers but does not block a
> merge, so the federation is advisory rather than structural. Check your tier
> before designing governance around it: on Free you need protected branches
> plus a manual review convention instead, and you should expect it to leak.

---

## Target structure

```
AI Augmented Development Community/
└── SketchKitExtensions/                    group
    ├── platform/                           subgroup, platform team
    │   ├── catalog                         project
    │   ├── base/sketch                     project
    │   ├── presets/<preset>                one project each
    │   ├── extensions/<ext>                one project each
    │   ├── mirrors/spec-kit                project
    │   └── bundles/<bundle>                one project each
    ├── domains/                            subgroup
    │   └── <division>/                     subgroup, division leads
    │       ├── extensions/<ext>            one project each
    │       └── bundles/<bundle>            one project each
    └── incubation/                         subgroup
        └── <team-slug>/                    subgroup, team
```

One project per extension and per bundle. Never loose projects: repositories
always live under a typed subgroup, so inheritance can do the permission work.

## Membership, set once

The point of this table is that almost nothing is set per repository.
Inheritance covers the rest, which is what makes it survive contact with an
urgent fix at 6pm.

| Level | Who | Role | How often |
|-------|-----|------|-----------|
| `SketchKitExtensions/` | Platform team | Owner | once |
| `platform/` | Platform team | Maintainer | once |
| `domains/<division>/` | That division's leads group | Maintainer | once per division |
| `incubation/<team>/` | That team's group | Maintainer | once per team |
| Each extension project | Its owner group | Maintainer | once per extension |
| `platform/catalog` | Every division's leads group | Developer, **direct invite** | once per division |
| Everything below | nobody | pure inheritance | never |

**The direct-invite gotcha.** `@group` approval rules count *direct* members
only. A user who is a member of a nested subgroup does not satisfy a rule
naming the parent. This is why division leads are invited directly to the
catalog project rather than relying on inheritance: without it, their approvals
do not count and every catalog merge request stalls.

## Groups to create

One leads group per division, plus the platform team:

```
@sketch/platform-team
@sketch/ai-security
@sketch/domains/ib-leads
@sketch/domains/gwm-leads
@sketch/domains/wmpc-leads
@sketch/domains/wma-leads
@sketch/domains/am-leads
@sketch/domains/risk-leads
@sketch/domains/finance-leads
@sketch/domains/gcore-leads
@sketch/domains/hr-leads
@sketch/domains/legal-leads
@sketch/domains/gia-leads
@sketch/domains/gic-leads
@sketch/domains/ceda-leads
@sketch/domains/gcto-leads
@sketch/domains/caio-leads
```

These names appear in [`../CODEOWNERS`](../CODEOWNERS) and
[`../platform/catalog/CODEOWNERS`](../platform/catalog/CODEOWNERS). If you name
them differently, update both files.

## CODEOWNERS

Two files, already written.

[`platform/catalog/CODEOWNERS`](../platform/catalog/CODEOWNERS) is the whole
federation mechanism:

```
catalog.schema.yml       @sketch/platform-team
tools/                   @sketch/platform-team
catalog.d/platform.yml   @sketch/platform-team
catalog.d/ib.yml         @sketch/domains/ib-leads
catalog.d/gwm.yml        @sketch/domains/gwm-leads
...
```

Each division owns exactly one fragment. A division's merge request touches
only its own file and is approved by its own leads. The platform team is not in
the path for a routine domain publish, which is the entire point.

The schema and the tooling stay central because changing them changes the rules
for everyone.

## Protected branches

On every project:

| Setting | Value |
|---------|-------|
| Protected branch | `main` |
| Allowed to merge | Maintainers |
| Allowed to push | No one |
| Require approval from Code Owners | On (Premium) |
| Protected tag | `v*`, Maintainers only |

Protecting `v*` matters more than it looks: the tag *is* the release trigger.
An unprotected tag pattern means anyone who can push can publish.

## Pipeline setup

The reusable templates in [`../ci/`](../ci/) are included by project path:

```yaml
include:
  - project: 'AI Augmented Development Community/SketchKitExtensions'
    ref: main
    file: '/ci/extension-release.yml'
```

If you split the skeleton into separate projects, the templates need a home.
Either keep a project at the group root holding `ci/`, or move them into
`platform/catalog` and update the `project:` path in every including repo.
Decide before the split; changing it afterwards touches every repository.

Each project also needs the Package Registry enabled, under Settings, then
General, then Visibility. Without it `publish` fails with a 403.

## Catalog hosting

The catalog has to be served over HTTP for `SPECKIT_CATALOG_URL` to point at
it. GitLab Pages on the catalog project is the natural choice; the
`publish-catalog` job already writes to `public/`.

```bash
export SPECKIT_CATALOG_URL="https://<group>.pages.<gitlab-host>/catalog.yml"
```

Set it org-wide through whatever provisions developer environments: an
onboarding script, the corporate image's shell profile, or an `.envrc`.

Alternatives if Pages is unavailable: the raw file URL on the default branch,
or a generic package published on each merge to `main`. Both work; Pages is
just tidier.

## Splitting the skeleton

This repository is one tree. Production is many projects. Suggested order:

1. Create the group and subgroups, and the leads groups.
2. Create `platform/catalog` first: everything else references it.
3. Move `ci/` to its final home and fix the `include:` paths.
4. Create `platform/base/sketch` and release `v0.3.0`.
5. Create `platform/bundles/sketch-requirements` and release `v0.1.0`.
6. Point `SPECKIT_CATALOG_URL` at the published catalog and verify one real
   install end to end before creating anything else.
7. Create the remaining projects as they are actually needed. Empty projects
   for planned work are optional; the catalog already reserves the ids.

Step 6 before step 7, deliberately. Proving one bundle installs from the
catalog is worth more than thirty repositories nobody has tested.

## Verifying

```bash
# the catalog is reachable and parses
curl -s "$SPECKIT_CATALOG_URL" | head -20

# the CLI can see it
specify bundle list

# a real install works end to end
cd /tmp && mkdir t && cd t && specify init
specify bundle install sketch-requirements
specify extension list
```

If `specify bundle list` is empty, `SPECKIT_CATALOG_URL` is unset or
unreachable, and the CLI has quietly fallen back to the public catalog.
