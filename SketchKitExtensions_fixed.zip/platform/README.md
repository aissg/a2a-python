# Platform

The central tier. Owned by the platform team; read-only to divisions.

```
platform/
├── catalog/        the control plane: schema, tooling, fragments, CODEOWNERS
├── base/sketch/    Layer 2: the base every bundle includes
├── presets/        bank-wide presets
├── extensions/     workload (L3) and cross-cutting (LX) capabilities
├── mirrors/        upstream intake, scanned and pinned
└── bundles/        workload bundles: what developers actually install
```

## What the platform team owns, and what it does not

It owns what only it can judge: the catalog schema, the CI gates, the shared
layers every division depends on, and the id registry that stops two divisions
claiming one name.

It does not own domain content. Whether a KYC questionnaire rule is correct is
a Compliance judgement, not a platform judgement, and central review of domain
content adds latency without adding safety. Divisions publish through their own
catalog fragment with their own leads approving.

## The one thing to read first

[`base/sketch`](base/sketch/) is the reference implementation: a complete,
tested extension with three commands, resolver scripts, an 87-assertion
selftest, and full documentation. Every other extension in the estate is
expected to meet the bar it sets.

[`bundles/sketch-requirements`](bundles/sketch-requirements/) is the reference
bundle: every component in it is stable and installable today.

Most other entries under `extensions/` and `bundles/` are `status: planned`.
Their ids are reserved and their shapes agreed, but they have no runnable
commands. The catalog says so, and so do their READMEs.
