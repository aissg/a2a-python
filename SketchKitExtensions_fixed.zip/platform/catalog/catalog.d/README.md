# Catalog fragments

One fragment per division, plus `platform.yml` for the central tier. CI
aggregates them into `../catalog.yml`, which is what the CLI reads.

## Why fragments rather than one file

A single catalog file puts the platform team on the merge path of every
publish in the bank. That does not scale past the first division and makes the
central team the slowest part of every release.

Fragments make ownership structural. Each division owns one file, CODEOWNERS
routes merge requests to that division's leads, and a domain publish needs no
central approval. The platform team keeps only what it alone can judge: the
schema, the CI gates, and the shared layers.

## Working on a fragment

```bash
cd platform/catalog

# validate your changes against the schema and the cross-fragment invariants
python3 tools/validate_catalog.py

# rebuild the aggregate; CI fails if you commit a fragment change without this
python3 tools/build_catalog.py
```

Both commands need only `pyyaml`.

## Rules the validator enforces

Errors, which block a merge:

- ids unique across every fragment, so two divisions cannot claim one name
- exact SemVer versions, no ranges anywhere
- every bundle component resolves to a real entry at exactly the pinned version
- every bundle includes the `sketch` base
- `skt-` prefix only on layer L3 or LX
- ids at most 20 characters, because they are typed in every command

Warnings, which do not block:

- an installable extension that belongs to no bundle, since a bundle is the
  only route a developer has to install anything. Entries still marked
  `planned` are exempt.

## status

`planned` reserves an id and an agreed shape with no runnable command.
`alpha` runs and is in use by the authoring team. `stable` is released with
SemVer honoured.

Use `planned` freely. A catalog that cannot say "not built yet" forces authors
to either hide roadmap or make it look shipped, and both are worse than saying
so plainly.
