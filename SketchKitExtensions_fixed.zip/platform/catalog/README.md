# Catalog

The control plane. Every installable unit in the bank is an entry here, and the
CLI only ever sees what CI approved.

```
catalog/
├── catalog.schema.yml    the contract
├── catalog.yml           GENERATED: the aggregate the CLI reads
├── catalog.d/            one fragment per division, plus platform.yml
├── tools/
│   ├── validate_catalog.py
│   └── build_catalog.py
├── CODEOWNERS            routes each fragment to its division
└── .gitlab-ci.yml
```

## Working here

```bash
python3 tools/validate_catalog.py    # schema plus cross-fragment invariants
python3 tools/build_catalog.py       # rebuild catalog.yml from the fragments
```

Both need only `pyyaml`. CI runs both, and additionally fails if `catalog.yml`
does not match its fragments, so the served catalog cannot go stale.

## Never edit catalog.yml

It is generated. Edit your division's fragment in `catalog.d/`, then rebuild.
An edit to the aggregate is overwritten on the next build and, worse, passes
review while doing nothing.

## What the validator enforces

Errors block a merge:

- ids unique across every fragment
- exact SemVer, no ranges anywhere
- every bundle component resolves at exactly the pinned version
- every bundle includes the `sketch` base
- `skt-` only on layer L3 or LX
- ids at most 20 characters

Warnings do not block:

- an installable extension in no bundle, since a bundle is the only route a
  developer has to install anything. `planned` entries are exempt.

## Serving it

`SPECKIT_CATALOG_URL` points at the published `catalog.yml`. The
`publish-catalog` job writes it to `public/` for GitLab Pages on every merge to
the default branch. See [../../docs/GITLAB-SETUP.md](../../docs/GITLAB-SETUP.md).
