# Reviewer overlay

An assurance overlay added per engagement, not by default. It raises the
evidence bar on specifications and plans for work under heightened scrutiny:
regulated change, client-facing output, or anything a supervisor may examine.

This is a **preset**: it changes how existing commands behave, and adds no
commands of its own. It composes with `sketch-constitution` rather than
replacing it.

> `status: planned`. The shape below is agreed; the wording is not final and
> the platform team has not committed it. Do not add this to a bundle yet.

## I. An independent reader, not the author

Review findings come from someone who did not write the document. Where that
is an agent, it paraphrases in isolation and diffs, rather than reading and
agreeing. The failure this catches is the confident misread: text that is clear
to two readers and means different things to each.

## II. Evidence is produced, not asserted

"The model was validated" is not evidence. The validation report, its date, its
author and its scope are. A claim in a specification that cannot be traced to
an artifact is a finding.

## III. Findings close explicitly

A finding is resolved when the resolving text exists and has been re-read, not
when the file changed. Re-verification is a separate pass over the flagged
items only.

## IV. Silence is a finding

Where a reviewer expects a section and finds none, that absence is recorded.
Under this overlay the burden is on the author to show a topic was considered,
not on the reviewer to prove it was missed.
