# sketch-reviewer

**Sketch Reviewer** · Layer L4 · `status: planned` · v0.1.0

Review and assurance overlay, added per engagement rather than by default. Raises evidence expectations on specs and plans.

A preset changes how existing commands behave and adds no commands of its own. It is installed as part of a bundle, never directly.

The content is in [`memory/constitution.md`](memory/constitution.md), which the agent reads before planning.
