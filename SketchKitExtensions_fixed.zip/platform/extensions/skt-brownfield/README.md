# skt-brownfield

**Sketch Brownfield** · Layer L3 · `status: planned`

Adopting spec-driven development in an existing estate.

## Nothing here runs yet

This repository is a reserved id and an agreed shape. There is no working
command. It exists so that:

- the id is taken and no other division can collide with it,
- bundles can pin it and catalog validation passes,
- the roadmap is visible in the catalog rather than in a slide deck.

`status: planned` in the catalog says this out loud. Developers browsing the
catalog see it and know not to expect a working command.

## To make it real

1. Write the command in `commands/run.md`. Use
   [`platform/base/sketch`](../../base/sketch) as the reference: it is a complete,
   tested extension with resolver scripts, its own selftest and full docs.
2. Add `scripts/bash/selftest.sh`. CI requires it once `require_selftest` is
   true, which is the default for anything past planned.
3. Set `require_selftest: true` in `.gitlab-ci.yml`.
4. Move `status` to `alpha` in `platform/catalog/catalog.d/platform.yml`.
5. Tag `v0.1.0`. CI publishes the archive and verifies it downloads.

## Guides

- [Authoring an extension](../../../docs/HOWTO-AUTHOR-EXTENSION.md)
- [Releasing](../../../docs/RELEASING.md)
- [Architecture](../../../docs/ARCHITECTURE.md)
