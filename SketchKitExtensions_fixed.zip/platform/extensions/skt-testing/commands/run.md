---
name: "speckit.skt-testing.run"
description: "Test engineering, acceptance criteria and coverage tracing."
argument-hint: "[options]"
---

## User Input

```text
$ARGUMENTS
```

# /speckit.skt-testing.run

> **PLACEHOLDER.** This command is not implemented. The extension is
> `status: planned` in the catalog: the id is reserved and the shape is
> agreed, but there is nothing to run yet.
>
> Installing this extension registers a command that does nothing useful.
> That is why planned extensions are not advertised to developers.

## What this command is intended to do

Test engineering, acceptance criteria and coverage tracing.

## When implementing

Read `platform/base/sketch/commands/specify.md` first. It is the reference
implementation and shows the conventions this estate expects:

- A resolver script validates every argument and emits a JSON resolution.
  The command body never derives paths itself.
- Non-zero exit from the resolver stops the command; the error and hint are
  reported verbatim rather than worked around.
- Facts come from sources, never from inference. An absent value is a
  visible gap, not a plausible guess.
- The extension hook protocol is preserved exactly: `before_*` and `after_*`,
  `enabled` and `condition` handling, `EXECUTE_COMMAND` emission.
