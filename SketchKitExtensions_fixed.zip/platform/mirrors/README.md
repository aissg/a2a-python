# Mirrors

Upstream code the bank uses but does not author: the Spec Kit core, and any
community extension approved for use here.

```
mirrors/
└── spec-kit/           upstream github/spec-kit, tag-tracked
```

## Why mirror rather than depend directly

Three reasons, in order of how much they matter.

**Nothing upstream is reviewed.** The community catalog carries an explicit
no-review, no-endorsement disclaimer. Mirroring puts a scan and an approval
between upstream and a developer's machine.

**Pinning has to be real.** A dependency fetched live from upstream can change
under a project between two installs. A mirror pinned to a tag cannot.

**Availability.** Upstream going away, or a repository being renamed, should
not stop the bank from provisioning a project.

## Intake

1. Mirror the repository at a specific tag. Never track a branch.
2. Run the security scan. Community extensions execute in a developer's
   environment with their credentials, so treat the code as untrusted input.
3. Diff-review the change on every version bump. A mirror that auto-updates is
   not a mirror, it is a live dependency with extra steps.
4. Add it to `platform/catalog/catalog.d/platform.yml` with `verified: false`
   until a human has reviewed it.

## Cadence

Upstream Spec Kit is reviewed on each minor release. Community mirrors are
reviewed when a bundle needs a newer version, not on a schedule: a mirror
nobody depends on does not need to be current.
