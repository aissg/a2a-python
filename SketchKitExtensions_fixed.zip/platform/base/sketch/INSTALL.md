# Installing sketch

Four routes, in order of how much setup they need. All install the same thing:
the extension at `.specify/extensions/sketch/`, with all three commands registered
with your AI agent.

| Route | Best for | Setup cost |
|-------|----------|------------|
| [1. Local directory](#1-local-directory) | Trying it, developing it | None |
| [2. GitLab clone](#2-gitlab-clone) | A team sharing one version | A repo |
| [3. GitLab submodule](#3-gitlab-submodule) | Pinning a version per project | A repo, plus submodule discipline |
| [4. GitLab catalog](#4-gitlab-catalog) | Company-wide, install by short name | A repo, a hosted catalog, an env var |

## Prerequisites

Every route needs these.

| Requirement | Why | Check |
|-------------|-----|-------|
| A Spec Kit project | The extension installs into `.specify/` | `ls .specify` |
| `specify` CLI | Installs and registers the commands | `specify check` |
| `python3` | Catalog parsing, Markdown companion fix | `python3 --version` |
| `pandoc` | Only for invocations that write a `.docx` | `pandoc --version` |

If the project is not initialised yet:

```bash
specify init          # in an existing repo, or: specify init <project-name>
```

`pandoc` is optional in the sense that the resolver checks for it and fails
cleanly with exit 7 rather than part way through authoring. Without it you can
still work Markdown-only by always passing `-spec <file>.md`.

---

## 1. Local directory

The development route, and the fastest way to try it.

```bash
unzip sketch.zip -d ~/tools          # anywhere outside the project
cd /path/to/your/spec-kit/project
specify extension add --dev ~/tools/sketch
```

`--dev <path>` installs from a local directory rather than a catalog. Both
commands are registered with your agent at install time.

### Verify

```bash
specify extension list                  # sketch, enabled, 3 commands
specify extension info sketch
.specify/extensions/sketch/scripts/bash/selftest.sh
```

The self-test runs 59 assertions on any machine and should end
`59 passed, 0 failed, 14 skipped`. The 14 skips are resolver assertions that
need pandoc; with pandoc installed they run too, and the converter suite adds
its own set. It needs no project state and is safe to run at any time.

### Update

```bash
specify extension remove sketch
specify extension add --dev ~/tools/sketch
```

Removing unregisters the commands from your agent, so a stale copy is never left
behind.

---

## 2. GitLab clone

The simplest shared route. One repo holds the extension; everyone clones it and
installs from their clone.

### Set up the repo, once

```bash
cd /path/to/sketch                   # the unzipped directory
git init
git add .
git commit -m "sketch 2.0.0"
git remote add origin git@gitlab.example.com:platform/sketch.git
git push -u origin main
git tag -a v2.0.0 -m "sketch 2.0.0"
git push origin v2.0.0
```

Tag every release. The tag is what makes "which version is this project on?"
answerable later.

### Install, per developer

```bash
git clone git@gitlab.example.com:platform/sketch.git ~/tools/sketch
cd ~/tools/sketch && git checkout v2.0.0

cd /path/to/your/spec-kit/project
specify extension add --dev ~/tools/sketch
```

### Update

```bash
cd ~/tools/sketch && git fetch --tags && git checkout v2.1.0
cd /path/to/your/spec-kit/project
specify extension remove sketch
specify extension add --dev ~/tools/sketch
```

### For private repos in CI

Use a deploy token or `CI_JOB_TOKEN` rather than SSH keys:

```bash
git clone https://gitlab-ci-token:${CI_JOB_TOKEN}@gitlab.example.com/platform/sketch.git
```

---

## 3. GitLab submodule

Pins an exact commit per project, and the pin is visible in the project's own
git history. Good when different projects must sit on different versions.

```bash
cd /path/to/your/spec-kit/project
git submodule add git@gitlab.example.com:platform/sketch.git .specify/vendor/sketch
cd .specify/vendor/sketch && git checkout v2.0.0 && cd -
git add .gitmodules .specify/vendor/sketch
git commit -m "Pin sketch v2.0.0"

specify extension add --dev .specify/vendor/sketch
```

Anyone cloning the project afterwards runs:

```bash
git submodule update --init --recursive
specify extension add --dev .specify/vendor/sketch
```

Bumping the version becomes a reviewable commit:

```bash
cd .specify/vendor/sketch && git fetch --tags && git checkout v2.1.0 && cd -
git add .specify/vendor/sketch
git commit -m "Bump sketch to v2.1.0"
```

Install into `.specify/vendor/` rather than `.specify/extensions/` so the
submodule and the installed copy do not fight over the same path.

---

## 4. GitLab catalog

The company-wide route. Developers install by short name, with no path and no
clone.

```bash
specify extension add sketch
```

### How it works

`SPECKIT_CATALOG_URL` points the CLI at your organisation's catalog instead of
the upstream default. Set it once, org-wide, through whatever provisions your
developer environments: an onboarding script, a shell profile in the corporate
image, Ansible, an `.envrc`.

### Set it up

**a. Build and host the artifact.** GitLab CI can produce the zip on tag and
publish it to the project's package registry:

```yaml
# .gitlab-ci.yml  (a release job; see the shipped .gitlab-ci.yml for the test job)
release:
  stage: deploy
  rules:
    - if: $CI_COMMIT_TAG
  script:
    - zip -rq sketch-${CI_COMMIT_TAG}.zip . -x '.git/*' -x '.gitlab-ci.yml'
    - |
      curl --header "JOB-TOKEN: ${CI_JOB_TOKEN}" \
           --upload-file sketch-${CI_COMMIT_TAG}.zip \
           "${CI_API_V4_URL}/projects/${CI_PROJECT_ID}/packages/generic/sketch/${CI_COMMIT_TAG}/sketch.zip"
```

**b. Publish a catalog JSON.** A second repo, or GitLab Pages on this one,
serving a `catalog.json` that lists sketch and its artifact URL.

**c. Point developers at it.**

```bash
export SPECKIT_CATALOG_URL="https://platform.pages.gitlab.example.com/catalog.json"
```

Per project instead of globally, use `.specify/extension-catalogs.yml`.

### Before you build this

The catalog JSON schema is not documented in this package, and inventing field
names will waste your afternoon. Copy an entry from the upstream community
catalog and edit it, rather than writing one from scratch. Confirm with:

```bash
specify extension search sketch
```

If that finds it, the entry is well formed. If your network cannot reach a
public catalog to copy from, use route 2 or 3 instead: they need no catalog at
all, and offline installation is supported for restricted networks.

---

## Manual install, no CLI

For a locked-down environment where running `specify extension add` is not an
option. This is what the CLI does for you.

```bash
mkdir -p .specify/extensions
cp -r /path/to/sketch .specify/extensions/sketch
chmod +x .specify/extensions/sketch/scripts/bash/*.sh
chmod +x .specify/extensions/sketch/scripts/lib/parse_catalog.py
```

Then register all three commands with your agent. The command names are
`speckit.sketch.specify`, `speckit.sketch.independent-read` and
`speckit.sketch.clarify`, which skills-based agents fold into single hyphenated
folder names by replacing every dot: `speckit-sketch-specify`,
`speckit-sketch-independent-read`, `speckit-sketch-clarify`.
For Claude Code:

```bash
for c in specify clarify independent-read; do
  mkdir -p ".claude/skills/speckit-sketch-$c"
  cp ".specify/extensions/sketch/commands/$c.md" \
     ".claude/skills/speckit-sketch-$c/SKILL.md"
done
```

### GitHub Copilot needs one decision first: which of its two modes

Copilot currently defaults to a legacy layout, and is moving to skills. Both
work; they are not interchangeable, and the file layout differs:

| Mode | Layout | Invocation |
|------|--------|------------|
| **Default (legacy)** | `.agent.md` under `.github/agents/`, a companion `.prompt.md` under `.github/prompts/`, plus a `.vscode/settings.json` merge | `/speckit.sketch.specify`, dots preserved |
| **Skills** (`--integration-options="--skills"`) | `speckit-sketch-specify/SKILL.md` under `.github/skills/` | `/speckit-sketch-specify`, dots hyphenated |

If the project was set up with `specify init --integration copilot`, you are on
legacy mode unless `--skills` was passed. Legacy mode is documented as
deprecated and expected to stop being the default in a future release, so if
you are setting Copilot up fresh, prefer `--skills`.

Manual install for Copilot skills mode mirrors Claude Code exactly, just under
`.github/skills/` instead of `.claude/skills/`:

```bash
for c in specify clarify independent-read; do
  mkdir -p ".github/skills/speckit-sketch-$c"
  cp ".specify/extensions/sketch/commands/$c.md" \
     ".github/skills/speckit-sketch-$c/SKILL.md"
done
```

Manual install for Copilot's legacy mode needs both an `.agent.md` and a
`.prompt.md` per command, copied from the same source file with different
extensions, at `.github/agents/speckit.sketch.specify.agent.md` and
`.github/prompts/speckit.sketch.specify.prompt.md`. This is fiddlier and the
settings.json merge is not something to hand-roll; use `specify extension add`
for legacy Copilot mode rather than the manual route if at all possible.

### Both agents read the same frontmatter

Copilot's own documented skill fields, `argument-hint`, `user-invocable`,
`disable-model-invocation`, are exactly the fields already in
`commands/specify.md` and `commands/clarify.md`. Nothing extension-specific was
needed to support Copilot; the same command source serves both agents. If a
skill fails to load on a particular Copilot surface (VS Code, Copilot CLI, and
the coding agent do not all parse frontmatter identically yet), the first thing
to try is trimming the frontmatter down to just `name` and `description` and
adding fields back one at a time, which isolates which key it objects to.

### Other agents

| Agent | Directory |
|-------|-----------|
| Claude Code | `.claude/skills` |
| GitHub Copilot (skills mode) | `.github/skills` |
| GitHub Copilot (legacy default) | `.github/agents` + `.github/prompts` |
| Codex CLI | `.agents/skills` |
| Cursor | `.cursor/skills` |
| Gemini CLI | `.gemini/commands` |

Run `specify integration list` for the current, authoritative list. Skills-based
agents derive the folder name by hyphenating every dot in the full command name,
so `speckit.sketch.specify` becomes `speckit-sketch-specify`, not `sketch-specify`.

Verify the manual install the same way:

```bash
.specify/extensions/sketch/scripts/bash/selftest.sh
```

---

## Continuous verification

The shipped `.gitlab-ci.yml` runs the self-test on every push and validates the
manifest. Nothing in it is sketch-specific beyond the paths, so it is safe to
extend.

```yaml
test:
  image: python:3.11-slim
  before_script:
    - apt-get update -qq && apt-get install -y -qq pandoc >/dev/null
    - pip install --quiet pyyaml
  script:
    - bash scripts/bash/selftest.sh
    - python3 -c "import yaml,sys; yaml.safe_load(open('extension.yml')); print('manifest OK')"
```

---

## Troubleshooting the install

| Symptom | Cause | Fix |
|---------|-------|-----|
| `sketch extension is not installed` | Command file registered but the extension directory is absent | Re-run `specify extension add --dev <path>` |
| Self-test reports missing assets (exit 6) | Partial copy, or a `.docx` lost by a text-only transfer | Re-extract the zip; do not copy through anything that rewrites binaries |
| Exit 7 on a create run | `pandoc` not on PATH | Install pandoc, or work Markdown-only with `-spec <file>.md` |
| `python3: command not found` | Python missing | Required on every platform for catalog parsing |
| Commands do not appear in the agent | Registered to the wrong agent directory | `specify integration list`, then check the table above |
| Manifest rejected on install | Command naming | Names must follow `speckit.{ext-id}.{cmd}`. Both already do |

Reinstall cleanly at any point:

```bash
specify extension remove sketch
specify extension add --dev /path/to/sketch
```
