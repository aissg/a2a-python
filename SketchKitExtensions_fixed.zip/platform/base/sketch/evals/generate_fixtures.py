#!/usr/bin/env python3
"""
Generate synthetic eval fixtures for the three sketch base commands.

Everything produced here is ARTIFICIAL. Ground truth is constructed by the
generator, not observed from real runs, so these fixtures test conformance to
the extension's documented conventions rather than real-world spec quality.
"""
import json, hashlib, random
from pathlib import Path

random.seed(20260802)

ROOT = Path("/home/claude/sketchkit/SketchKitExtensions/platform/base/sketch")
EV = ROOT / "evals"
FILES = EV / "files"
for d in (EV, FILES, EV / "scorers"):
    d.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------- ground facts
# Verified against scripts/lib/parse_catalog.py on 2026-08-02.
QUESTION_COUNTS = {
    ("generic", "lightweight"): 34, ("generic", "standard"): 92, ("generic", "exhaustive"): 122,
    ("ai", "lightweight"): 45,      ("ai", "standard"): 125,     ("ai", "exhaustive"): 186,
}
SECTIONS = {"generic": 14, "ai": 20}
APPENDICES = 2
GATED = {("ai", "lightweight"): [16]}   # section 16 gated out at ai/lightweight

GENERIC_SECTIONS = {
    1: "Purpose & Current State", 2: "Scope & Stakeholders", 3: "User Scenarios",
    4: "Functional Requirements", 5: "Data & Information", 6: "Delivery & Presentation",
    7: "Quality Attributes", 8: "Security, Privacy & Compliance", 9: "Audit, Logging & Retention",
    10: "Integrations & Dependencies", 11: "Failure & Edge Cases", 12: "Constraints & Decisions",
    13: "Acceptance Criteria", 14: "Open Items & Risks",
}
AI_SECTIONS = dict(GENERIC_SECTIONS)
AI_SECTIONS.update({
    13: "AI Classification & Justification", 14: "AI Behaviour & Output Validation",
    15: "Confidence & Human Review", 16: "Provenance & Lineage",
    17: "Evaluation & Test Evidence", 18: "Model Lifecycle & Monitoring",
    19: "Acceptance Criteria", 20: "Open Items & Risks",
})

# Real ids, format Q-<section3>-<seq2>, matching parse_catalog.py output.
def qid(section, seq):
    return f"Q-{section:03d}-{seq:02d}"

# ---------------------------------------------------------------- scenarios
SCENARIOS = [
    # (slug, title, track, one-line business context)
    ("risk-report",   "Quarterly risk report assembly",        "generic", "Assembling the quarterly market-risk pack from six source systems by hand"),
    ("kyc-screen",    "KYC document screening",                "ai",      "Screening onboarding document packs for missing or expired identity evidence"),
    ("tenk-extract",  "10-K figure extraction",                "ai",      "Pulling stated figures out of annual filings for the credit assessment cycle"),
    ("model-monitor", "Model monitoring dashboard",            "generic", "A dashboard showing drift and performance for models already in production"),
    ("trade-surv",    "Trade surveillance alert triage",       "ai",      "Triaging surveillance alerts so analysts see the ones that matter first"),
    ("onboard-flow",  "Client onboarding workflow",            "generic", "Tracking an onboarding case through legal, credit and operations sign-off"),
    ("reg-recon",     "Regulatory reporting reconciliation",   "generic", "Reconciling submitted regulatory returns against the golden source"),
    ("credit-memo",   "Credit memo drafting assistant",        "ai",      "Drafting the standard sections of a credit memo from the deal file"),
    ("collateral",    "Collateral valuation pipeline",         "generic", "Revaluing pledged collateral on a nightly cycle"),
    ("pay-except",    "Payment exception handling",            "generic", "Routing failed payments to the right operations queue"),
    ("mkt-data-qc",   "Market data quality checks",            "generic", "Catching stale and outlier prices before they reach the risk engine"),
    ("covenant",      "Loan covenant tracking",                "ai",      "Extracting covenant terms from facility agreements and tracking compliance"),
    ("complaints",    "Complaints classification",             "ai",      "Classifying inbound client complaints by theme and regulatory reportability"),
    ("sanctions",     "Sanctions list matching",               "ai",      "Matching counterparty names against consolidated sanctions lists"),
    ("rebalance",     "Portfolio rebalancing advisory",        "generic", "Proposing rebalancing trades against a target allocation"),
    ("expense-pol",   "Expense policy compliance",             "ai",      "Checking submitted expenses against the travel and entertainment policy"),
    ("vendor-risk",   "Vendor risk assessment",                "generic", "Scoring third-party vendors on a standard risk questionnaire"),
    ("postmortem",    "Incident post-mortem generation",       "ai",      "Drafting a post-mortem from incident timeline and chat logs"),
    ("audit-eviden",  "Audit evidence collection",             "generic", "Gathering control evidence ahead of the internal audit cycle"),
    ("stress-test",   "Stress test scenario authoring",        "generic", "Authoring and versioning macro scenarios for the stress testing run"),
    ("fee-billing",   "Fee billing reconciliation",            "generic", "Reconciling calculated advisory fees against what was actually billed"),
    ("suitability",   "Suitability assessment review",         "ai",      "Reviewing advice records for suitability against the client profile"),
    ("esg-agg",       "ESG data aggregation",                  "generic", "Aggregating ESG scores from three vendors into one portfolio view"),
    ("liquidity",     "Liquidity forecast reporting",          "generic", "Producing the daily liquidity forecast for treasury"),
    ("clause-extr",   "Contract clause extraction",            "ai",      "Extracting termination and liability clauses from master agreements"),
]

DEPTHS = ["lightweight", "standard", "exhaustive"]
DEPTH_FLAG = {"lightweight": "-l", "standard": "-s", "exhaustive": "-e"}

# Facts a transcript may or may not state. The absent ones are fabrication bait:
# every one is a value a model is tempted to supply a "reasonable" default for.
FACT_POOL = [
    ("daily_volume",      "volume and rhythm",          ["1,200 documents a day", "400 cases a day", "18,000 records a day", "90 packs a day"]),
    ("retention_period",  "audit retention period",     ["7 years", "10 years", "5 years"]),
    ("sla_latency",       "response time target",       ["under 4 seconds", "under 30 seconds", "same business day"]),
    ("source_of_truth",   "authoritative source system",["the Adaptiv risk store", "the golden source warehouse", "the front-office booking system"]),
    ("user_count",        "number of users",            ["about 40 analysts", "12 operations staff", "around 300 advisors"]),
    ("availability",      "availability expectation",   ["99.5% in business hours", "best effort", "99.9%"]),
    ("output_target",     "where output lands",         ["a SharePoint library", "the existing case management screen", "a nightly file drop"]),
    ("review_threshold",  "human review threshold",     ["below 0.85 confidence", "any flagged exception", "a 10% sample"]),
    ("data_classification","data classification",       ["client-identifying", "internal only", "strictly confidential"]),
    ("run_frequency",     "run frequency",              ["nightly at 02:00", "hourly", "on demand"]),
]


def make_transcript(slug, title, track, context, present, absent, depth):
    """A short synthetic interview transcript. `absent` facts are never stated."""
    lines = [
        f"# Interview transcript (synthetic fixture)",
        f"## {title}",
        "",
        f"**BA:** Thanks for the time. Can you walk me through how this works today?",
        f"**SME:** {context}. It is largely manual and it is the part everyone dreads.",
        "",
        "**BA:** What goes wrong most often?",
        "**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.",
        "",
    ]
    for key, label, _ in FACT_POOL:
        if key in present:
            lines += [f"**BA:** And the {label}?", f"**SME:** {present[key]}.", ""]
    if track == "ai":
        lines += [
            "**BA:** Are you expecting a model to make the call, or a person?",
            "**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.",
            "",
        ]
    lines += [
        "**BA:** Anything still genuinely open?",
        "**SME:** A few things we have not agreed yet. I would rather flag them than guess.",
        "",
        f"*(Synthetic fixture. Deliberately silent on: {', '.join(absent) if absent else 'nothing'}.)*",
    ]
    return "\n".join(lines)


def make_spec(slug, title, track, depth, answered_ids, unanswered_ids, planted_misreads=0):
    """A synthetic spec document, optionally with planted ambiguities."""
    secs = AI_SECTIONS if track == "ai" else GENERIC_SECTIONS
    n = SECTIONS[track]
    gated = GATED.get((track, depth), [])
    out = [f"# Requirement Specification: {title}", "",
           f"*Track: {'AI-Extended' if track == 'ai' else 'Generic'} | Depth: {depth.capitalize()} | Synthetic fixture*", ""]
    misread_budget = planted_misreads
    for i in range(1, n + 1):
        if i in gated:
            continue
        out.append(f"## {i}. {secs[i]}")
        if misread_budget > 0 and i in (4, 5, 7):
            # Planted ambiguity: a requirement readable two ways.
            out.append(f"- REQ-{i:02d}-01: The system shall process submissions promptly "
                       f"and notify the reviewer, unless the reviewer has already been notified.")
            misread_budget -= 1
        else:
            out.append(f"- REQ-{i:02d}-01: The system shall record each {secs[i].split()[0].lower()} event "
                       f"with its source and timestamp.")
        out.append("")
    out += ["## Appendix A: Glossary", "- Term: definition.", "",
            "## Appendix B: Compliance Mapping", "- Control: mapping.", ""]
    if track == "ai":
        out.insert(4, "*Part D present: AI Governance sections 13 to 18.*\n")
    return "\n".join(out)


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()[:16]


# ================================================================ SPECIFY (50)
def build_specify():
    evals = []
    # deterministic bucket plan across 50 records
    plan = []
    for i in range(50):
        sc = SCENARIOS[i % len(SCENARIOS)]
        depth = DEPTHS[i % 3]
        mode = "enhance" if i % 10 in (7, 8, 9) else "create"
        plan.append((i, sc, depth, mode))

    evals = []
    for idx, (i, sc, depth, mode) in enumerate(plan, start=1):
        slug, title, track, context = sc
        eid = f"spec-{idx:03d}"

        # error cases occupy fixed slots so the suite always exercises exit codes
        error_case = None
        if idx == 45: error_case = ("unknown_flag", 1, "-s -raw evals/files/specify/baseline.md --bogus")
        elif idx == 46: error_case = ("depth_conflict", 2, "-l -e -raw evals/files/specify/baseline.md")
        elif idx == 47: error_case = ("raw_unresolvable", 3, "-s -raw /nonexistent/nope.md")
        elif idx == 48: error_case = ("spec_unresolvable", 4, "-s -raw evals/files/specify/baseline.md -spec /nonexistent/base.md")
        elif idx == 49: error_case = ("spec_bad_extension", 5, "-s -raw evals/files/specify/baseline.md -spec evals/files/specify/baseline.xlsx")
        elif idx == 50: error_case = ("pandoc_absent", 7, "-s -raw evals/files/specify/baseline.md -spec evals/files/specify/baseline.docx")

        # track ambiguity cases must default to ai
        ambiguous = idx in (11, 22, 33, 44)
        effective_track = "ai" if ambiguous else track

        # fabrication bait: hold back 2-4 facts on ~30% of records
        adversarial = idx % 10 in (2, 5, 8)
        keys = [k for k, _, _ in FACT_POOL]
        random.shuffle(keys)
        n_absent = random.choice([3, 4]) if adversarial else random.choice([0, 1])
        absent_keys = keys[:n_absent]
        present_keys = [k for k in keys if k not in absent_keys][:6]
        present = {k: random.choice([v for kk, _, v in FACT_POOL if kk == k][0]) for k in present_keys}
        absent_labels = [lbl for k, lbl, _ in FACT_POOL if k in absent_keys]

        tpath = f"evals/files/specify/{eid}-transcript.md"
        if not error_case:
            (FILES / "specify").mkdir(parents=True, exist_ok=True)
            (FILES / "specify" / f"{eid}-transcript.md").write_text(
                make_transcript(slug, title, effective_track, context, present, absent_labels, depth))
            if mode == "enhance":
                # a thinner baseline at one rung below, so enhance has something to extend
                lower = {"standard": "lightweight", "exhaustive": "standard"}.get(depth, "lightweight")
                (FILES / "specify" / f"{eid}-baseline.md").write_text(
                    make_spec(slug, title, effective_track, lower, [], []))

        gated = GATED.get((effective_track, depth), [])
        expected_sections = SECTIONS[effective_track] - len(gated)

        if error_case:
            kind, code, args = error_case
            prompt = f"/speckit.sketch.specify {args}"
            expected_output = f"Resolver rejects the invocation with exit {code} and a hint naming the problem; no spec is written."
            gt = {
                "case_type": "error",
                "error_kind": kind,
                "expected_exit_code": code,
                "expect_artifact_written": False,
            }
            assertions = [
                {"id": "a1", "type": "deterministic", "scorer": "exit_code_match",
                 "text": f"Resolver exits {code}"},
                {"id": "a2", "type": "deterministic", "scorer": "no_artifact_written",
                 "text": "No spec file is created"},
                {"id": "a3", "type": "deterministic", "scorer": "hint_present",
                 "text": "Error output names the offending argument"},
            ]
        else:
            baseline = f"evals/files/specify/{eid}-baseline.md"
            prompt = (f"/speckit.sketch.specify {DEPTH_FLAG[depth]} -raw {tpath}"
                      + (f" -spec {baseline}" if mode == "enhance" else ""))
            expected_output = (
                f"A {depth} {'AI-Extended' if effective_track=='ai' else 'Generic'} specification with "
                f"{expected_sections} numbered sections plus {APPENDICES} appendices. Every fact present in the "
                f"transcript is carried through; every fact the transcript does not state is marked "
                f"NO ANSWER IN TRANSCRIPT rather than filled with a plausible default."
            )
            gt = {
                "case_type": "normal",
                "track": effective_track,
                "track_is_ambiguous": ambiguous,
                "depth": depth,
                "mode": mode,
                "expected_sections": expected_sections,
                "expected_appendices": APPENDICES,
                "gated_sections": gated,
                "questions_in_scope": QUESTION_COUNTS[(effective_track, depth)],
                "facts_stated_in_transcript": {k: present[k] for k in present},
                "facts_absent_from_transcript": absent_labels,
                "must_not_invent": absent_labels,
                "expected_gap_markers": len(absent_labels),
                "expected_exit_code": 0,
                "transcript_sha16": sha(make_transcript(slug, title, effective_track, context, present, absent_labels, depth)),
            }
            assertions = [
                {"id": "a1", "type": "deterministic", "scorer": "track_match",
                 "text": f"Output is on the {effective_track} track"
                         + (" (transcript is ambiguous, must default to ai)" if ambiguous else "")},
                {"id": "a2", "type": "deterministic", "scorer": "section_count_match",
                 "text": f"Spec has exactly {expected_sections} numbered sections and {APPENDICES} appendices"},
                {"id": "a3", "type": "deterministic", "scorer": "gated_section_absent",
                 "text": f"Gated sections {gated} do not appear" if gated else "No sections are gated at this depth"},
                {"id": "a4", "type": "deterministic", "scorer": "fabrication_rate",
                 "text": f"No value is supplied for any of: {', '.join(absent_labels) or '(none withheld)'}"},
                {"id": "a5", "type": "deterministic", "scorer": "gap_marker_recall",
                 "text": f"All {len(absent_labels)} withheld facts carry a NO ANSWER IN TRANSCRIPT marker"},
                {"id": "a6", "type": "deterministic", "scorer": "stated_fact_carryover",
                 "text": "Every fact the transcript does state appears in the spec unchanged"},
                {"id": "a7", "type": "judge", "scorer": "ears_conformance",
                 "text": "Requirements are phrased in EARS form, not as prose narrative"},
                {"id": "a8", "type": "judge", "scorer": "gap_visibility",
                 "text": "Gaps are visible at a glance, not buried mid-paragraph"},
            ]
            if mode == "enhance":
                assertions.append({"id": "a9", "type": "deterministic", "scorer": "baseline_preserved",
                                   "text": "Content present in the baseline spec is not silently dropped"})

        evals.append({
            "id": eid,
            "bucket": {"scenario": slug, "track": effective_track, "depth": depth,
                       "mode": mode, "adversarial": adversarial,
                       "track_ambiguous": ambiguous,
                       "case_type": "error" if error_case else "normal"},
            "prompt": prompt,
            "files": [] if error_case else [tpath],
            "expected_output": expected_output,
            "ground_truth": gt,
            "assertions": assertions,
        })
    return evals


# ================================================================ CLARIFY (50)
def build_clarify():
    evals = []
    for idx in range(1, 51):
        sc = SCENARIOS[(idx - 1) % len(SCENARIOS)]
        slug, title, track, context = sc
        depth = DEPTHS[(idx - 1) % 3]
        eid = f"clar-{idx:03d}"

        clar_error = None
        if idx == 46: clar_error = ("unknown_flag", 1, "-s -spec evals/files/clarify/clar-001-spec.md --bogus")
        elif idx == 47: clar_error = ("no_depth", 2, "-spec evals/files/clarify/clar-001-spec.md")
        elif idx == 48: clar_error = ("depth_conflict", 2, "-l -s -spec evals/files/clarify/clar-001-spec.md")
        elif idx == 49: clar_error = ("spec_not_found", 3, "-s -spec /nonexistent/spec.md")
        elif idx == 50: clar_error = ("spec_bad_format", 5, "-s -spec evals/files/clarify/clar-001-spec.xlsx")

        n_sections = SECTIONS[track]
        secs = list(range(1, n_sections + 1))

        # how many catalog questions this spec leaves unanswered
        if idx % 10 == 0:      n_unans = 0          # nothing to ask
        elif idx % 10 == 1:    n_unans = 3          # fewer than the budget
        elif idx % 10 == 5:    n_unans = 28         # far more than the budget
        else:                  n_unans = random.choice([6, 9, 12, 17])

        random.shuffle(secs)
        unanswered = [qid(s, random.randint(1, 3)) for s in secs[:min(n_unans, len(secs))]]
        while len(unanswered) < n_unans:
            unanswered.append(qid(random.choice(secs), random.randint(4, 6)))
        unanswered = sorted(set(unanswered))[:n_unans]

        expected_asked = min(5, len(unanswered))

        # adversarial: spec mentions a topic with no catalog question behind it
        bait = idx % 7 == 3
        bait_topic = random.choice([
            "carbon accounting methodology", "quantum-safe key rotation",
            "board-level escalation cadence", "vendor exit run-book",
        ]) if bait else None

        spec_text = make_spec(slug, title, track, depth, [], unanswered)
        if bait:
            spec_text += f"\n## Note\nThe team also raised {bait_topic}, which the catalog does not cover.\n"
        (FILES / "clarify").mkdir(parents=True, exist_ok=True)
        spath = f"evals/files/clarify/{eid}-spec.md"
        (FILES / "clarify" / f"{eid}-spec.md").write_text(spec_text)

        if clar_error:
            kind, code, args = clar_error
            evals.append({
                "id": eid,
                "bucket": {"scenario": slug, "track": track, "depth": depth,
                           "unanswered_volume": "n/a", "adversarial_bait": False,
                           "case_type": "error"},
                "prompt": f"/speckit.sketch.clarify {args}",
                "files": [],
                "expected_output": f"Resolver rejects the invocation with exit {code}; no questions are asked.",
                "ground_truth": {"case_type": "error", "error_kind": kind,
                                 "expected_exit_code": code, "expect_questions_asked": 0},
                "assertions": [
                    {"id": "a1", "type": "deterministic", "scorer": "exit_code_match",
                     "text": f"Resolver exits {code}"},
                    {"id": "a2", "type": "deterministic", "scorer": "no_artifact_written",
                     "text": "No questions are emitted"},
                    {"id": "a3", "type": "deterministic", "scorer": "hint_present",
                     "text": "Error output names the offending argument"},
                ],
            })
            continue

        evals.append({
            "id": eid,
            "bucket": {"scenario": slug, "track": track, "depth": depth,
                       "case_type": "normal",
                       "unanswered_volume": ("none" if n_unans == 0 else
                                             "below_budget" if n_unans < 5 else
                                             "above_budget" if n_unans > 20 else "normal"),
                       "adversarial_bait": bait},
            "prompt": f"/speckit.sketch.clarify {DEPTH_FLAG[depth]} -spec {spath}",
            "files": [spath],
            "expected_output": (
                "No questions are asked; the spec has no unanswered catalog questions at this depth."
                if n_unans == 0 else
                f"Up to five questions, each drawn from the shipped catalog and cited by id. "
                f"{expected_asked} question(s) expected here."
            ),
            "ground_truth": {
                "track_from_spec": track,
                "track_signal": "Part D present" if track == "ai" else "Part D absent",
                "depth": depth,
                "catalog_in_scope": QUESTION_COUNTS[(track, depth)],
                "unanswered_ids": unanswered,
                "expected_question_count": expected_asked,
                "max_question_budget": 5,
                "off_catalog_topic_present": bait,
                "off_catalog_topic": bait_topic,
                "expected_exit_code": 0,
                "spec_sha16": sha(spec_text),
            },
            "assertions": [
                {"id": "a1", "type": "deterministic", "scorer": "ring_fence_violations",
                 "text": "Every cited question id exists in the shipped catalog for this track and depth"},
                {"id": "a2", "type": "deterministic", "scorer": "question_budget",
                 "text": f"At most 5 questions asked; expected exactly {expected_asked}"},
                {"id": "a3", "type": "deterministic", "scorer": "question_selection_f1",
                 "text": "Asked ids are drawn from the unanswered set, not from answered questions"},
                {"id": "a4", "type": "deterministic", "scorer": "track_detection_match",
                 "text": f"Track detected as {track} from the spec structure"},
                {"id": "a5", "type": "deterministic", "scorer": "id_citation_present",
                 "text": "Every question is emitted with its catalog id, not paraphrased anonymously"},
                {"id": "a6", "type": "deterministic", "scorer": "off_catalog_abstention",
                 "text": (f"No question is invented about {bait_topic}" if bait
                          else "No question outside the catalog is invented")},
                {"id": "a7", "type": "judge", "scorer": "question_prioritisation",
                 "text": "When more than five are unanswered, the five chosen are the highest-impact ones"},
            ],
        })
    return evals


# ======================================================= INDEPENDENT-READ (50)
def build_independent_read():
    evals = []
    for idx in range(1, 51):
        sc = SCENARIOS[(idx - 1) % len(SCENARIOS)]
        slug, title, track, context = sc
        depth = DEPTHS[(idx - 1) % 3]
        eid = f"iread-{idx:03d}"

        ir_error = None
        if idx == 47: ir_error = ("unknown_flag", 1, "-spec evals/files/independent-read/iread-001-spec.md --bogus")
        elif idx == 48: ir_error = ("spec_not_found", 3, "-spec /nonexistent/spec.md")
        elif idx == 49: ir_error = ("spec_bad_format", 5, "-spec evals/files/independent-read/iread-001-spec.docx")
        elif idx == 46: ir_error = ("asset_missing", 6, "-spec evals/files/independent-read/iread-001-spec.md (reference asset removed)")

        verify_mode = idx % 5 == 0
        no_prior_findings = idx % 10 == 5     # verify with no findings file -> exit 9
        planted = 0 if idx % 9 == 4 else random.choice([1, 2, 3])
        findings_survive = verify_mode and idx % 15 == 0

        spec_text = make_spec(slug, title, track, depth, [], [], planted_misreads=planted)
        (FILES / "independent-read").mkdir(parents=True, exist_ok=True)
        spath = f"evals/files/independent-read/{eid}-spec.md"
        (FILES / "independent-read" / f"{eid}-spec.md").write_text(spec_text)

        if verify_mode and no_prior_findings:
            expected_exit, expected_output = 9, "Verify pass exits 9: no earlier findings file exists to verify against."
        elif verify_mode and findings_survive:
            expected_exit, expected_output = None, "Verify pass refuses to report pass: at least one earlier finding is still open. Exit code is not asserted here; the resolver's codes cover argument validity only, and the pass/fail verdict is a command-level outcome checked by no_pass_while_open."
        elif verify_mode:
            expected_exit, expected_output = 0, "Verify pass confirms every earlier finding is closed."
        else:
            expected_exit, expected_output = 0, (
                f"A findings file at reviews/independent-read-<date>.md logging {planted} confident misread(s). "
                f"The spec itself is byte-identical afterwards."
            )

        assertions = [
            {"id": "a1", "type": "deterministic", "scorer": "spec_immutability",
             "text": "The spec file is byte-identical before and after the run"},
        ]
        if expected_exit is not None:
            assertions.append({"id": "a2", "type": "deterministic", "scorer": "exit_code_match",
                               "text": f"Exits {expected_exit}"})
        if not verify_mode:
            assertions += [
                {"id": "a3", "type": "deterministic", "scorer": "findings_file_written",
                 "text": "A findings file is written under reviews/ with a dated name"},
                {"id": "a4", "type": "deterministic", "scorer": "finding_detection_recall",
                 "text": f"All {planted} planted ambiguity/ambiguities are logged as findings"},
                {"id": "a5", "type": "deterministic", "scorer": "finding_precision",
                 "text": "No finding is logged against an unambiguous requirement"},
                {"id": "a6", "type": "judge", "scorer": "paraphrase_isolation",
                 "text": "Each paraphrase reads the requirement in isolation, without importing context from neighbours"},
                {"id": "a7", "type": "judge", "scorer": "misread_is_confident",
                 "text": "Logged findings are confident misreads, not speculative 'could be clearer' notes"},
            ]
        else:
            assertions += [
                {"id": "a3", "type": "deterministic", "scorer": "verify_closure_check",
                 "text": "Each earlier finding is individually marked closed or still open"},
                {"id": "a4", "type": "deterministic", "scorer": "no_pass_while_open",
                 "text": "The run does not report pass while any finding remains open"},
            ]

        if ir_error:
            kind, code, args = ir_error
            evals.append({
                "id": eid,
                "bucket": {"scenario": slug, "track": track, "depth": depth,
                           "mode": "read", "planted_misreads": 0,
                           "edge": None, "case_type": "error"},
                "prompt": f"/speckit.sketch.independent-read {args}",
                "files": [],
                "expected_output": f"Resolver rejects the invocation with exit {code}; the spec is untouched.",
                "ground_truth": {"case_type": "error", "error_kind": kind,
                                 "expected_exit_code": code, "spec_must_be_unmodified": True},
                "assertions": [
                    {"id": "a1", "type": "deterministic", "scorer": "exit_code_match",
                     "text": f"Resolver exits {code}"},
                    {"id": "a2", "type": "deterministic", "scorer": "spec_immutability",
                     "text": "The spec file is byte-identical after the failed run"},
                    {"id": "a3", "type": "deterministic", "scorer": "hint_present",
                     "text": "Error output names the offending argument"},
                ],
            })
            continue

        evals.append({
            "id": eid,
            "bucket": {"scenario": slug, "track": track, "depth": depth,
                       "case_type": "normal",
                       "mode": "verify" if verify_mode else "read",
                       "planted_misreads": planted,
                       "edge": ("no_prior_findings" if no_prior_findings and verify_mode
                                else "findings_survive" if findings_survive
                                else "clean_spec" if planted == 0 else None)},
            "prompt": f"/speckit.sketch.independent-read -spec {spath}" + (" --verify" if verify_mode else ""),
            "files": [spath],
            "expected_output": expected_output,
            "ground_truth": {
                "track": track,
                "depth": depth,
                "mode": "verify" if verify_mode else "read",
                "planted_misread_count": planted,
                "planted_in_sections": [s for s in (4, 5, 7)][:planted],
                "expected_findings": planted,
                "expected_exit_code": expected_exit,
                "spec_must_be_unmodified": True,
                "spec_sha16_before": sha(spec_text),
                "prior_findings_file_exists": (verify_mode and not no_prior_findings),
                "findings_still_open": findings_survive,
            },
            "assertions": assertions,
        })
    return evals


# ---------------------------------------------------------------- scorer specs
SCORERS = [
    # deterministic
    {"name": "exit_code_match", "type": "deterministic", "returns": "bool",
     "measures": "Resolver exit code equals ground_truth.expected_exit_code.",
     "why": "Exit codes are a contract in this estate (1 usage, 2 mutually exclusive, 3 required input, 4 optional input, 5 format, 6 asset, 7 tool, 9 no prior findings). A wrong code is a silent failure."},
    {"name": "no_artifact_written", "type": "deterministic", "returns": "bool",
     "measures": "No spec or findings file exists after a run expected to fail.",
     "why": "A rejected invocation that still writes a partial artifact is worse than one that writes nothing."},
    {"name": "hint_present", "type": "deterministic", "returns": "bool",
     "measures": "stderr names the offending argument.",
     "why": "The authoring guide requires a failure you can act on, not a bare non-zero."},
    {"name": "track_match", "type": "deterministic", "returns": "bool",
     "measures": "Detected track equals ground_truth.track; ambiguous transcripts must resolve to ai.",
     "why": "extension.yml sets ambiguous_defaults_to: ai. Choosing generic on an ambiguous input silently drops sections 13 to 18."},
    {"name": "section_count_match", "type": "deterministic", "returns": "bool",
     "measures": "Numbered sections and appendices match the depth/track contract.",
     "why": "Coverage is a published number (generic 14, ai 20, plus 2 appendices). A short spec is a governance gap."},
    {"name": "gated_section_absent", "type": "deterministic", "returns": "bool",
     "measures": "Sections listed in gated_sections do not appear.",
     "why": "ai/lightweight gates section 16. Emitting it anyway means the depth flag did nothing."},
    {"name": "fabrication_rate", "type": "deterministic", "returns": "float (lower better, target 0.0)",
     "measures": "Count of values supplied for facts the transcript never stated, over facts withheld.",
     "why": "The single strongest convention in the base extension: an absent number is a visible gap, not a plausible default. This is the metric that should gate a release."},
    {"name": "gap_marker_recall", "type": "deterministic", "returns": "float 0-1 (target 1.0)",
     "measures": "Withheld facts carrying a NO ANSWER IN TRANSCRIPT marker, over facts withheld.",
     "why": "The complement of fabrication: a gap that is neither invented nor marked has simply vanished."},
    {"name": "stated_fact_carryover", "type": "deterministic", "returns": "float 0-1",
     "measures": "Facts stated in the transcript that appear unchanged in the spec.",
     "why": "Guards the opposite failure from fabrication: dropping or altering something the SME actually said."},
    {"name": "baseline_preserved", "type": "deterministic", "returns": "float 0-1",
     "measures": "In enhance mode, baseline requirement ids still present after the run.",
     "why": "Enhance must extend, never overwrite. Silent loss is the expensive failure here."},
    {"name": "ring_fence_violations", "type": "deterministic", "returns": "int (target 0)",
     "measures": "Cited question ids absent from the parsed catalog for that track and depth.",
     "why": "extension.yml states clarify asks only catalog questions, cited by id. Any id not in parse_catalog.py output is by definition invented. Non-zero must fail the build."},
    {"name": "question_budget", "type": "deterministic", "returns": "bool",
     "measures": "Questions asked is at most 5 and equals expected_question_count.",
     "why": "The command promises up to five. Asking eight makes clarify a second interview."},
    {"name": "question_selection_f1", "type": "deterministic", "returns": "float 0-1",
     "measures": "F1 of asked ids against ground_truth.unanswered_ids.",
     "why": "Separates 'asked five valid questions' from 'asked five questions the spec already answers'."},
    {"name": "track_detection_match", "type": "deterministic", "returns": "bool",
     "measures": "Track inferred from the spec matches; Part D present means AI-Extended.",
     "why": "extension.yml: clarify reads the track from the spec, not from a flag. Misreading it selects the wrong catalog."},
    {"name": "id_citation_present", "type": "deterministic", "returns": "float 0-1",
     "measures": "Emitted questions carrying a parseable Q-nnn-nn id.",
     "why": "An uncited question cannot be ring-fence-checked at all, by anyone, ever."},
    {"name": "off_catalog_abstention", "type": "deterministic", "returns": "bool",
     "measures": "No question is emitted about a topic present in the spec but absent from the catalog.",
     "why": "The adversarial half of the ring fence: a plausible, useful, uncatalogued question is still a violation."},
    {"name": "spec_immutability", "type": "deterministic", "returns": "bool",
     "measures": "SHA of the spec file is unchanged after the run.",
     "why": "independent-read is read-only by design; the spec changes only through clarify. A single byte of drift breaks that guarantee."},
    {"name": "findings_file_written", "type": "deterministic", "returns": "bool",
     "measures": "reviews/independent-read-<date>.md exists and parses.",
     "why": "The findings file is the artifact the verify pass later reads. No file, no audit trail."},
    {"name": "finding_detection_recall", "type": "deterministic", "returns": "float 0-1",
     "measures": "Planted ambiguities logged, over planted ambiguities.",
     "why": "The whole point of the command. Fixtures plant known misreads so recall is measurable rather than judged."},
    {"name": "finding_precision", "type": "deterministic", "returns": "float 0-1",
     "measures": "Logged findings that correspond to a planted ambiguity.",
     "why": "A reviewer who gets fourteen findings on a clean spec stops reading findings."},
    {"name": "verify_closure_check", "type": "deterministic", "returns": "bool",
     "measures": "Each prior finding is individually resolved to closed or open.",
     "why": "A summary verdict without per-finding status cannot be audited."},
    {"name": "no_pass_while_open", "type": "deterministic", "returns": "bool",
     "measures": "Run does not report pass while any finding is open.",
     "why": "Documented behaviour: verify refuses to pass while any finding survives."},
    # judge
    {"name": "ears_conformance", "type": "judge", "returns": "float 0-1",
     "measures": "Requirements follow EARS phrasing rather than narrative prose.",
     "why": "Not mechanically checkable without a parser; judged against a rubric with a pinned judge version."},
    {"name": "gap_visibility", "type": "judge", "returns": "float 0-1",
     "measures": "Gaps are visible at a glance rather than buried.",
     "why": "A marker that technically exists but sits mid-paragraph does not achieve the convention's intent."},
    {"name": "question_prioritisation", "type": "judge", "returns": "float 0-1",
     "measures": "When more than five questions are unanswered, the chosen five are the highest-impact.",
     "why": "Selection quality beyond mere validity; the only genuinely subjective clarify metric."},
    {"name": "paraphrase_isolation", "type": "judge", "returns": "float 0-1",
     "measures": "Each paraphrase reads one requirement without importing neighbouring context.",
     "why": "Isolation is the mechanism that makes the diff meaningful; a context-informed paraphrase cannot surface a misread."},
    {"name": "misread_is_confident", "type": "judge", "returns": "float 0-1",
     "measures": "Findings are confident misreads, not speculative clarity notes.",
     "why": "The command logs confident misreads specifically. Speculation dilutes the signal."},
]

AGGREGATE_METRICS = [
    {"name": "pass_rate", "definition": "Assertions passed over assertions evaluated, per condition (with_skill / baseline).",
     "report": "mean and stddev across >=3 runs per record"},
    {"name": "uplift_delta", "definition": "pass_rate(with_skill) minus pass_rate(baseline). The release gate.",
     "report": "point estimate plus spread; gate on a configured minimum"},
    {"name": "fabrication_rate", "definition": "Aggregate over the adversarial bucket only. Target 0.0.",
     "report": "hard gate: any non-zero fails the build"},
    {"name": "ring_fence_violations", "definition": "Aggregate count across the clarify suite. Target 0.",
     "report": "hard gate: any non-zero fails the build"},
    {"name": "cost_delta", "definition": "Tokens and wall-clock, with_skill minus baseline, from timing.json.",
     "report": "mean per record; a large uplift bought with 3x tokens is a different trade"},
    {"name": "per_bucket_breakdown", "definition": "All of the above, split by bucket (track, depth, mode, adversarial).",
     "report": "prevents a regression in one bucket hiding inside an aggregate"},
    {"name": "flakiness", "definition": "Records whose pass/fail differs across seeds.",
     "report": "high stddev means the fixture or the instruction is ambiguous, not that the model is bad"},
]


def wrap(cmd, evals, notes):
    return {
        "schema_version": "1.0",
        "skill_name": cmd,
        "fixture_provenance": "SYNTHETIC. Generated 2026-08-02 by evals/generate_fixtures.py. "
                              "Ground truth is constructed, not observed: these fixtures test conformance to the "
                              "extension's documented conventions, not real-world specification quality. "
                              "Replace with real transcripts before treating results as evidence.",
        "baseline_mode": "previous_version",
        "baseline_note": "with_skill vs. the previous released version of this command. A bare without_skill "
                         "baseline is near-meaningless here: the model has no access to the question catalog, "
                         "so the ablation only proves it cannot invent one.",
        "record_count": len(evals),
        "buckets": notes,
        "scorers": [s["name"] for s in SCORERS],
        "evals": evals,
    }


spec_evals = build_specify()
clar_evals = build_clarify()
iread_evals = build_independent_read()

(EV / "specify.json").write_text(json.dumps(wrap(
    "speckit.sketch.specify", spec_evals,
    {"track": "generic|ai (ambiguous cases must default to ai)",
     "depth": "lightweight|standard|exhaustive",
     "mode": "create|enhance",
     "adversarial": "facts deliberately withheld from the transcript as fabrication bait",
     "case_type": "normal|error (error cases exercise exit codes 2,3,5,6,7)"}
), indent=2))

(EV / "clarify.json").write_text(json.dumps(wrap(
    "speckit.sketch.clarify", clar_evals,
    {"unanswered_volume": "none|below_budget|normal|above_budget",
     "adversarial_bait": "spec raises a topic the catalog does not cover; must abstain",
     "track": "read from the spec, Part D present means ai"}
), indent=2))

(EV / "independent-read.json").write_text(json.dumps(wrap(
    "speckit.sketch.independent-read", iread_evals,
    {"mode": "read|verify",
     "planted_misreads": "0-3 deliberately ambiguous requirements per spec",
     "edge": "no_prior_findings (exit 9) | findings_survive (must not pass) | clean_spec (must find nothing)"}
), indent=2))

(EV / "scorers" / "scorers.json").write_text(json.dumps(
    {"schema_version": "1.0", "scorers": SCORERS, "aggregate_metrics": AGGREGATE_METRICS}, indent=2))

print("specify:", len(spec_evals), "clarify:", len(clar_evals), "independent-read:", len(iread_evals))
print("scorers:", len(SCORERS), "deterministic:", sum(1 for s in SCORERS if s["type"] == "deterministic"),
      "judge:", sum(1 for s in SCORERS if s["type"] == "judge"))
