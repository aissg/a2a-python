# Evals

Command-level evaluation for the three `sketch` base commands. One suite per
command, 50 records each, following the `evals/evals.json` convention from the
Agent Skills format and extended with a `ground_truth` block so most assertions
can be graded by code rather than by a judge.

```
evals/
├── specify.json            50 records
├── clarify.json            50 records
├── independent-read.json   50 records
├── scorers/scorers.json    27 scorer definitions, 22 deterministic and 5 judge
└── files/                  157 fixture inputs
```

---

## These fixtures are synthetic

Everything under `files/` was generated, and every `ground_truth` block was
constructed rather than observed. The suites test **conformance to this
extension's documented conventions**, not real-world specification quality.

That distinction matters for how far the results travel. A green run says the
command honours its own contract: the right track, the right section count, no
invented values, no question outside the catalog. It does not say the spec would
survive a Compliance review. Replace the fixtures with real transcripts and real
specs before treating any of this as evidence in a governance pack.

---

## What is tested, and what is not

`scripts/bash/selftest.sh` already tests the resolver contract: exit codes, flag
combinations, path forms. That is code testing code, and it is the right tool
for it.

These suites test the layer `selftest.sh` structurally cannot reach: whether the
agent, reading `commands/<cmd>.md`, produces output that honours the conventions
the command promises. Different question, different instrument, no overlap.

| | `selftest.sh` | `evals/` |
|---|---|---|
| Tests | The resolver | The agent reading the command |
| Model in the loop | No | Yes |
| Deterministic | Fully | Per-assertion; 22 of 27 scorers are |
| Fails on | A broken script | A weakened instruction |

---

## Baseline: previous version, not no-skill

The Agent Skills default is `with_skill` against `without_skill`. That ablation
is close to meaningless here, because the bare model has no access to the
question catalog, the track rules, or the gating table, so `without_skill` only
proves it cannot invent them.

These suites therefore default to `baseline_mode: previous_version`: snapshot
the previous released tag and compare against it. The question that earns its
keep for a mature extension is whether `0.4.0` regresses against `0.3.0` on the
same records, not whether it beats nothing.

Use a bare `without_skill` baseline only for a brand-new command, where
establishing that the instructions add anything at all is still an open
question.

---

## Buckets

Aggregate scores hide bucket regressions, so every suite is stratified and every
metric is reported per bucket as well as overall.

**specify** — track (generic 26 / ai 24, including 4 deliberately ambiguous
records that must resolve to ai), depth (17/17/16 across the three rungs), mode
(create 35 / enhance 15), adversarial (15 records withhold 3 to 4 facts as
fabrication bait), case type (44 normal / 6 error covering exits 1, 2, 3, 4, 5, 7).

**clarify** — unanswered volume (none, below budget, normal, above budget, so
both the "ask nothing" and the "pick five from twenty-eight" behaviours are
exercised), adversarial bait (7 records raise a topic with no catalog question
behind it and the command must abstain), track read from spec structure, 5 error
records covering exits 1, 2, 3, 5.

**independent-read** — mode (read / verify), planted misreads (0 to 3 per spec,
including 6 clean specs where the correct answer is to find nothing), edge cases
(`no_prior_findings` expecting exit 9, `findings_survive` which must not report
pass), 4 error records.

---

## Scorers

Full definitions with rationale in `scorers/scorers.json`. Deterministic scorers
carry the evidentiary weight; judges cover only what code cannot check.

### The two that should gate a release

**`fabrication_rate`** (target 0.0, hard gate). Values supplied for facts the
transcript never stated, over facts withheld. `extension.yml` calls this the
single strongest convention in the extension: an absent number is a visible gap,
not a plausible default. The adversarial bucket exists to measure exactly this,
and any non-zero result should fail the build.

**`ring_fence_violations`** (target 0, hard gate). Cited question ids absent
from `parse_catalog.py` output for that track and depth. The ring fence is what
makes clarify auditable rather than advisory; an id not in the bank is by
definition invented. The `off_catalog_abstention` scorer covers the adversarial
half, where the invented question would have been genuinely useful.

### The rest, deterministic

`exit_code_match`, `no_artifact_written`, `hint_present`, `track_match`,
`section_count_match`, `gated_section_absent`, `gap_marker_recall`,
`stated_fact_carryover`, `baseline_preserved`, `question_budget`,
`question_selection_f1`, `track_detection_match`, `id_citation_present`,
`spec_immutability`, `findings_file_written`, `finding_detection_recall`,
`finding_precision`, `verify_closure_check`, `no_pass_while_open`.

Two are worth calling out as complementary pairs. `gap_marker_recall` is the
complement of `fabrication_rate`: a withheld fact that is neither invented nor
marked has simply vanished, which is a quieter failure than inventing it.
`finding_precision` is the complement of `finding_detection_recall`: a reviewer
who receives fourteen findings on a clean spec stops reading findings.

### Judge scorers

`ears_conformance`, `gap_visibility`, `question_prioritisation`,
`paraphrase_isolation`, `misread_is_confident`.

Pin the judge model, its version and the rubric hash in the run record. A judge
change invalidates comparison against every earlier run, the same way a dataset
change would.

---

## Metrics

| Metric | Definition | Reporting |
|--------|-----------|-----------|
| `pass_rate` | Assertions passed over assertions evaluated, per condition | mean and stddev over at least 3 runs per record |
| `uplift_delta` | `pass_rate(current)` minus `pass_rate(baseline)` | the release gate; configure a minimum |
| `fabrication_rate` | Aggregate over the adversarial bucket | hard gate at 0.0 |
| `ring_fence_violations` | Aggregate over the clarify suite | hard gate at 0 |
| `cost_delta` | Tokens and wall clock against baseline, from `timing.json` | mean per record |
| `per_bucket_breakdown` | All of the above, split by bucket | prevents one bucket's regression hiding in an aggregate |
| `flakiness` | Records whose verdict differs across seeds | high variance means an ambiguous fixture or instruction, not a bad model |

A single run tells you almost nothing: these commands are nondeterministic and
`stddev` is only meaningful across repeats. Three seeds is a floor for
screening. Raise it on any record where the confidence intervals of two
candidate versions overlap.

---

## Reviewing a suite

When a record is added or changed, the reviewer's job is the assertions, not the
prose. The specific thing to catch, called out in the Agent Skills guidance, is
an assertion that passes in **both** conditions: it proves nothing, because the
model handled it without the command's help, and it silently inflates the
with-skill pass rate. Remove those, or replace them with something the baseline
actually fails.

Also worth checking: an assertion that fails in both conditions is either broken
or testing something the command was never meant to do. Fix it before the next
iteration rather than carrying it as permanent red.

---

## Regenerating

`generate_fixtures.py` rebuilds all three suites deterministically from
`seed=20260802`. It reads the real section and question counts from
`extension.yml` and the real exit codes from the three resolvers, so a change to
either shows up as a diff in the fixtures rather than as a silently stale
expectation.
