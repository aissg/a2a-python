# Interview transcript (synthetic fixture)
## Model monitoring dashboard

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** A dashboard showing drift and performance for models already in production. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 400 cases a day.

**BA:** And the authoritative source system?
**SME:** the golden source warehouse.

**BA:** And the where output lands?
**SME:** the existing case management screen.

**BA:** And the human review threshold?
**SME:** any flagged exception.

**BA:** And the data classification?
**SME:** internal only.

**BA:** And the run frequency?
**SME:** hourly.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: number of users.)*