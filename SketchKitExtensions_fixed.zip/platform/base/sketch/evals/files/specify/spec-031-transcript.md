# Interview transcript (synthetic fixture)
## Client onboarding workflow

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Tracking an onboarding case through legal, credit and operations sign-off. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 400 cases a day.

**BA:** And the response time target?
**SME:** under 4 seconds.

**BA:** And the number of users?
**SME:** 12 operations staff.

**BA:** And the availability expectation?
**SME:** 99.9%.

**BA:** And the where output lands?
**SME:** a SharePoint library.

**BA:** And the human review threshold?
**SME:** below 0.85 confidence.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: audit retention period.)*