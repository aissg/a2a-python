# Interview transcript (synthetic fixture)
## 10-K figure extraction

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Pulling stated figures out of annual filings for the credit assessment cycle. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 400 cases a day.

**BA:** And the audit retention period?
**SME:** 10 years.

**BA:** And the authoritative source system?
**SME:** the front-office booking system.

**BA:** And the number of users?
**SME:** around 300 advisors.

**BA:** And the where output lands?
**SME:** a SharePoint library.

**BA:** And the run frequency?
**SME:** hourly.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: availability expectation, human review threshold, data classification.)*