# Interview transcript (synthetic fixture)
## Fee billing reconciliation

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Reconciling calculated advisory fees against what was actually billed. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 18,000 records a day.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the availability expectation?
**SME:** best effort.

**BA:** And the where output lands?
**SME:** a SharePoint library.

**BA:** And the data classification?
**SME:** strictly confidential.

**BA:** And the run frequency?
**SME:** nightly at 02:00.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: nothing.)*