# Interview transcript (synthetic fixture)
## Vendor risk assessment

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Scoring third-party vendors on a standard risk questionnaire. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 1,200 documents a day.

**BA:** And the audit retention period?
**SME:** 7 years.

**BA:** And the authoritative source system?
**SME:** the golden source warehouse.

**BA:** And the availability expectation?
**SME:** 99.5% in business hours.

**BA:** And the where output lands?
**SME:** a nightly file drop.

**BA:** And the data classification?
**SME:** strictly confidential.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: response time target.)*