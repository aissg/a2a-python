# Interview transcript (synthetic fixture)
## Quarterly risk report assembly

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Assembling the quarterly market-risk pack from six source systems by hand. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the response time target?
**SME:** under 4 seconds.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the availability expectation?
**SME:** best effort.

**BA:** And the where output lands?
**SME:** a nightly file drop.

**BA:** And the human review threshold?
**SME:** any flagged exception.

**BA:** And the run frequency?
**SME:** nightly at 02:00.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: nothing.)*