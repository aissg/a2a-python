# Interview transcript (synthetic fixture)
## Suitability assessment review

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Reviewing advice records for suitability against the client profile. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the audit retention period?
**SME:** 10 years.

**BA:** And the response time target?
**SME:** same business day.

**BA:** And the authoritative source system?
**SME:** the golden source warehouse.

**BA:** And the number of users?
**SME:** 12 operations staff.

**BA:** And the availability expectation?
**SME:** 99.9%.

**BA:** And the data classification?
**SME:** client-identifying.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: volume and rhythm, where output lands, human review threshold.)*