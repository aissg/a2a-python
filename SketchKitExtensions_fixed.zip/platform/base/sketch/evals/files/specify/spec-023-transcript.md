# Interview transcript (synthetic fixture)
## ESG data aggregation

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Aggregating ESG scores from three vendors into one portfolio view. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the response time target?
**SME:** same business day.

**BA:** And the authoritative source system?
**SME:** the front-office booking system.

**BA:** And the availability expectation?
**SME:** best effort.

**BA:** And the where output lands?
**SME:** the existing case management screen.

**BA:** And the data classification?
**SME:** client-identifying.

**BA:** And the run frequency?
**SME:** hourly.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: number of users.)*