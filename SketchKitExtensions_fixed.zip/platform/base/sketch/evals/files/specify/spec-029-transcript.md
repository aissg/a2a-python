# Interview transcript (synthetic fixture)
## Model monitoring dashboard

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** A dashboard showing drift and performance for models already in production. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 18,000 records a day.

**BA:** And the audit retention period?
**SME:** 5 years.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the availability expectation?
**SME:** 99.5% in business hours.

**BA:** And the where output lands?
**SME:** the existing case management screen.

**BA:** And the run frequency?
**SME:** on demand.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: nothing.)*