# Interview transcript (synthetic fixture)
## Collateral valuation pipeline

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Revaluing pledged collateral on a nightly cycle. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 1,200 documents a day.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the availability expectation?
**SME:** 99.9%.

**BA:** And the where output lands?
**SME:** a SharePoint library.

**BA:** And the human review threshold?
**SME:** below 0.85 confidence.

**BA:** And the data classification?
**SME:** client-identifying.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: authoritative source system.)*