# Interview transcript (synthetic fixture)
## Expense policy compliance

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Checking submitted expenses against the travel and entertainment policy. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the response time target?
**SME:** under 30 seconds.

**BA:** And the authoritative source system?
**SME:** the Adaptiv risk store.

**BA:** And the availability expectation?
**SME:** 99.9%.

**BA:** And the where output lands?
**SME:** a SharePoint library.

**BA:** And the human review threshold?
**SME:** any flagged exception.

**BA:** And the run frequency?
**SME:** nightly at 02:00.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: volume and rhythm.)*