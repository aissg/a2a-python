# Interview transcript (synthetic fixture)
## Portfolio rebalancing advisory

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Proposing rebalancing trades against a target allocation. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the audit retention period?
**SME:** 5 years.

**BA:** And the response time target?
**SME:** same business day.

**BA:** And the authoritative source system?
**SME:** the golden source warehouse.

**BA:** And the number of users?
**SME:** around 300 advisors.

**BA:** And the human review threshold?
**SME:** below 0.85 confidence.

**BA:** And the run frequency?
**SME:** on demand.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: volume and rhythm, availability expectation, where output lands, data classification.)*