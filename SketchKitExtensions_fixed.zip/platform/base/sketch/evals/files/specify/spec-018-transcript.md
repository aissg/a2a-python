# Interview transcript (synthetic fixture)
## Incident post-mortem generation

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Drafting a post-mortem from incident timeline and chat logs. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the audit retention period?
**SME:** 10 years.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the availability expectation?
**SME:** best effort.

**BA:** And the human review threshold?
**SME:** any flagged exception.

**BA:** And the data classification?
**SME:** client-identifying.

**BA:** And the run frequency?
**SME:** hourly.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: volume and rhythm, response time target, where output lands.)*