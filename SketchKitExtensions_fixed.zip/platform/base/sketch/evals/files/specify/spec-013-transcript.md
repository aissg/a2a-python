# Interview transcript (synthetic fixture)
## Complaints classification

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Classifying inbound client complaints by theme and regulatory reportability. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 1,200 documents a day.

**BA:** And the authoritative source system?
**SME:** the front-office booking system.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the availability expectation?
**SME:** 99.9%.

**BA:** And the data classification?
**SME:** strictly confidential.

**BA:** And the run frequency?
**SME:** nightly at 02:00.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: nothing.)*