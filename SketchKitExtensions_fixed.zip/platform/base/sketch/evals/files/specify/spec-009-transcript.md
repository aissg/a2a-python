# Interview transcript (synthetic fixture)
## Collateral valuation pipeline

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Revaluing pledged collateral on a nightly cycle. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 400 cases a day.

**BA:** And the response time target?
**SME:** same business day.

**BA:** And the authoritative source system?
**SME:** the golden source warehouse.

**BA:** And the number of users?
**SME:** 12 operations staff.

**BA:** And the where output lands?
**SME:** a SharePoint library.

**BA:** And the data classification?
**SME:** internal only.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: availability expectation.)*