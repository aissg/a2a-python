# Interview transcript (synthetic fixture)
## Contract clause extraction

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Extracting termination and liability clauses from master agreements. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 1,200 documents a day.

**BA:** And the response time target?
**SME:** same business day.

**BA:** And the authoritative source system?
**SME:** the Adaptiv risk store.

**BA:** And the where output lands?
**SME:** a SharePoint library.

**BA:** And the data classification?
**SME:** internal only.

**BA:** And the run frequency?
**SME:** on demand.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: audit retention period, number of users, availability expectation, human review threshold.)*