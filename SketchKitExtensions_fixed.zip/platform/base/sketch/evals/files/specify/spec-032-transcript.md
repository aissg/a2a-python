# Interview transcript (synthetic fixture)
## Regulatory reporting reconciliation

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Reconciling submitted regulatory returns against the golden source. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 90 packs a day.

**BA:** And the authoritative source system?
**SME:** the Adaptiv risk store.

**BA:** And the number of users?
**SME:** 12 operations staff.

**BA:** And the availability expectation?
**SME:** 99.5% in business hours.

**BA:** And the where output lands?
**SME:** a SharePoint library.

**BA:** And the data classification?
**SME:** internal only.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: audit retention period, human review threshold, run frequency.)*