# Interview transcript (synthetic fixture)
## Credit memo drafting assistant

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Drafting the standard sections of a credit memo from the deal file. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 90 packs a day.

**BA:** And the audit retention period?
**SME:** 10 years.

**BA:** And the authoritative source system?
**SME:** the front-office booking system.

**BA:** And the number of users?
**SME:** 12 operations staff.

**BA:** And the availability expectation?
**SME:** best effort.

**BA:** And the where output lands?
**SME:** the existing case management screen.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: data classification.)*