# Interview transcript (synthetic fixture)
## Payment exception handling

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Routing failed payments to the right operations queue. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 18,000 records a day.

**BA:** And the audit retention period?
**SME:** 5 years.

**BA:** And the authoritative source system?
**SME:** the Adaptiv risk store.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the human review threshold?
**SME:** a 10% sample.

**BA:** And the data classification?
**SME:** strictly confidential.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: response time target, availability expectation, where output lands, run frequency.)*