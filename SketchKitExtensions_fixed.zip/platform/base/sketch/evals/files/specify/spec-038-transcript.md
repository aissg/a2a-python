# Interview transcript (synthetic fixture)
## Complaints classification

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Classifying inbound client complaints by theme and regulatory reportability. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the response time target?
**SME:** under 4 seconds.

**BA:** And the number of users?
**SME:** around 300 advisors.

**BA:** And the availability expectation?
**SME:** 99.5% in business hours.

**BA:** And the where output lands?
**SME:** a nightly file drop.

**BA:** And the human review threshold?
**SME:** any flagged exception.

**BA:** And the data classification?
**SME:** strictly confidential.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: volume and rhythm, audit retention period, authoritative source system.)*