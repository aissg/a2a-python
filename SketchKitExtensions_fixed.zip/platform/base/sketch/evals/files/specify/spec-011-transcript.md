# Interview transcript (synthetic fixture)
## Market data quality checks

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Catching stale and outlier prices before they reach the risk engine. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 400 cases a day.

**BA:** And the audit retention period?
**SME:** 10 years.

**BA:** And the response time target?
**SME:** under 4 seconds.

**BA:** And the authoritative source system?
**SME:** the Adaptiv risk store.

**BA:** And the human review threshold?
**SME:** any flagged exception.

**BA:** And the data classification?
**SME:** strictly confidential.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: where output lands.)*