# Interview transcript (synthetic fixture)
## Liquidity forecast reporting

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Producing the daily liquidity forecast for treasury. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 1,200 documents a day.

**BA:** And the authoritative source system?
**SME:** the Adaptiv risk store.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the availability expectation?
**SME:** 99.5% in business hours.

**BA:** And the data classification?
**SME:** strictly confidential.

**BA:** And the run frequency?
**SME:** on demand.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: nothing.)*