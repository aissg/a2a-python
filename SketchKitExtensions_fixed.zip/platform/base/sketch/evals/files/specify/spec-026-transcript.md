# Interview transcript (synthetic fixture)
## Quarterly risk report assembly

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Assembling the quarterly market-risk pack from six source systems by hand. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 90 packs a day.

**BA:** And the authoritative source system?
**SME:** the front-office booking system.

**BA:** And the number of users?
**SME:** around 300 advisors.

**BA:** And the availability expectation?
**SME:** 99.5% in business hours.

**BA:** And the where output lands?
**SME:** the existing case management screen.

**BA:** And the human review threshold?
**SME:** below 0.85 confidence.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: nothing.)*