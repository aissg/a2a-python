# Interview transcript (synthetic fixture)
## Portfolio rebalancing advisory

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Proposing rebalancing trades against a target allocation. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 90 packs a day.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the availability expectation?
**SME:** best effort.

**BA:** And the where output lands?
**SME:** a nightly file drop.

**BA:** And the data classification?
**SME:** client-identifying.

**BA:** And the run frequency?
**SME:** nightly at 02:00.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: nothing.)*