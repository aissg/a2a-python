# Interview transcript (synthetic fixture)
## 10-K figure extraction

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Pulling stated figures out of annual filings for the credit assessment cycle. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the audit retention period?
**SME:** 5 years.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the availability expectation?
**SME:** 99.9%.

**BA:** And the where output lands?
**SME:** a nightly file drop.

**BA:** And the data classification?
**SME:** strictly confidential.

**BA:** And the run frequency?
**SME:** hourly.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: nothing.)*