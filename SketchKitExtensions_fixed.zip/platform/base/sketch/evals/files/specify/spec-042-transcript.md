# Interview transcript (synthetic fixture)
## Vendor risk assessment

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Scoring third-party vendors on a standard risk questionnaire. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 400 cases a day.

**BA:** And the authoritative source system?
**SME:** the golden source warehouse.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the where output lands?
**SME:** a nightly file drop.

**BA:** And the human review threshold?
**SME:** below 0.85 confidence.

**BA:** And the run frequency?
**SME:** hourly.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: audit retention period, response time target, availability expectation, data classification.)*