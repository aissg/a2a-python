# Interview transcript (synthetic fixture)
## Stress test scenario authoring

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Authoring and versioning macro scenarios for the stress testing run. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the authoritative source system?
**SME:** the Adaptiv risk store.

**BA:** And the number of users?
**SME:** about 40 analysts.

**BA:** And the availability expectation?
**SME:** best effort.

**BA:** And the where output lands?
**SME:** the existing case management screen.

**BA:** And the data classification?
**SME:** internal only.

**BA:** And the run frequency?
**SME:** nightly at 02:00.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: human review threshold.)*