# Interview transcript (synthetic fixture)
## Client onboarding workflow

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Tracking an onboarding case through legal, credit and operations sign-off. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 400 cases a day.

**BA:** And the audit retention period?
**SME:** 7 years.

**BA:** And the response time target?
**SME:** same business day.

**BA:** And the authoritative source system?
**SME:** the Adaptiv risk store.

**BA:** And the human review threshold?
**SME:** a 10% sample.

**BA:** And the data classification?
**SME:** client-identifying.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: nothing.)*