# Interview transcript (synthetic fixture)
## Loan covenant tracking

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Extracting covenant terms from facility agreements and tracking compliance. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the audit retention period?
**SME:** 5 years.

**BA:** And the response time target?
**SME:** same business day.

**BA:** And the authoritative source system?
**SME:** the front-office booking system.

**BA:** And the number of users?
**SME:** around 300 advisors.

**BA:** And the availability expectation?
**SME:** 99.5% in business hours.

**BA:** And the where output lands?
**SME:** the existing case management screen.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: volume and rhythm, human review threshold, data classification.)*