# Interview transcript (synthetic fixture)
## KYC document screening

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Screening onboarding document packs for missing or expired identity evidence. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the audit retention period?
**SME:** 7 years.

**BA:** And the authoritative source system?
**SME:** the front-office booking system.

**BA:** And the availability expectation?
**SME:** best effort.

**BA:** And the where output lands?
**SME:** the existing case management screen.

**BA:** And the data classification?
**SME:** internal only.

**BA:** And the run frequency?
**SME:** on demand.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: human review threshold.)*