# Baseline raw input (synthetic fixture)

Minimal raw input used only by the specify error-path records.
