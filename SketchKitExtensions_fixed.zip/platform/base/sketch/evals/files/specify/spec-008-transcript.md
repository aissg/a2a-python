# Interview transcript (synthetic fixture)
## Credit memo drafting assistant

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Drafting the standard sections of a credit memo from the deal file. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 18,000 records a day.

**BA:** And the availability expectation?
**SME:** best effort.

**BA:** And the where output lands?
**SME:** a nightly file drop.

**BA:** And the human review threshold?
**SME:** any flagged exception.

**BA:** And the data classification?
**SME:** internal only.

**BA:** And the run frequency?
**SME:** nightly at 02:00.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: audit retention period, response time target, authoritative source system, number of users.)*