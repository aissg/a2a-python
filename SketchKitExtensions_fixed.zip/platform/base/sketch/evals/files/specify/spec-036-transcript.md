# Interview transcript (synthetic fixture)
## Market data quality checks

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Catching stale and outlier prices before they reach the risk engine. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 1,200 documents a day.

**BA:** And the audit retention period?
**SME:** 5 years.

**BA:** And the number of users?
**SME:** around 300 advisors.

**BA:** And the where output lands?
**SME:** a nightly file drop.

**BA:** And the data classification?
**SME:** internal only.

**BA:** And the run frequency?
**SME:** hourly.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: availability expectation.)*