# Interview transcript (synthetic fixture)
## Audit evidence collection

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Gathering control evidence ahead of the internal audit cycle. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the response time target?
**SME:** under 30 seconds.

**BA:** And the authoritative source system?
**SME:** the Adaptiv risk store.

**BA:** And the number of users?
**SME:** around 300 advisors.

**BA:** And the availability expectation?
**SME:** 99.9%.

**BA:** And the data classification?
**SME:** internal only.

**BA:** And the run frequency?
**SME:** on demand.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: where output lands.)*