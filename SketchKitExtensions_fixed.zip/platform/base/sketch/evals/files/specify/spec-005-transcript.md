# Interview transcript (synthetic fixture)
## Trade surveillance alert triage

**BA:** Thanks for the time. Can you walk me through how this works today?
**SME:** Triaging surveillance alerts so analysts see the ones that matter first. It is largely manual and it is the part everyone dreads.

**BA:** What goes wrong most often?
**SME:** Rework, mostly. Someone transposes a figure and we only find it at review.

**BA:** And the volume and rhythm?
**SME:** 90 packs a day.

**BA:** And the audit retention period?
**SME:** 7 years.

**BA:** And the response time target?
**SME:** same business day.

**BA:** And the number of users?
**SME:** around 300 advisors.

**BA:** And the availability expectation?
**SME:** 99.9%.

**BA:** And the where output lands?
**SME:** the existing case management screen.

**BA:** Are you expecting a model to make the call, or a person?
**SME:** The model proposes, a person signs off. We are not comfortable with it deciding alone.

**BA:** Anything still genuinely open?
**SME:** A few things we have not agreed yet. I would rather flag them than guess.

*(Synthetic fixture. Deliberately silent on: authoritative source system, human review threshold, data classification, run frequency.)*