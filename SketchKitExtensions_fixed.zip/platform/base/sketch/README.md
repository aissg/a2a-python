# sketch

**Sketch Base.** Sketch is the organization's official way to extend Spec Kit.
Base is its foundational tier: commands here apply to all software development
in the organization, not to one domain, team, or role. Extensions built on top
of Sketch, or specific to a domain, carry a suffixed id (`sketch-adr`,
`sketch-threat`, and so on) and are separate packages; this repository is Base
only.

A Spec Kit extension adding three commands for requirement work driven by
interview transcripts and a fixed, reviewable question catalog.

| Command | What it does | Tag |
|---------|--------------|-----|
| `/speckit.sketch.specify` | Authors a new requirement spec from a transcript, or extends an existing one | `sketch base` |
| `/speckit.sketch.independent-read` | Paraphrases each requirement and scenario in isolation and diffs against the spec, logging confident misreads; `--verify` confirms closure after clarify | `sketch base` |
| `/speckit.sketch.clarify` | Finds unanswered catalog questions in a spec and asks up to five of them | `sketch base` |

specify and clarify work at three depths, on two tracks, and neither takes a
track flag: the track is a finding, not an assertion. independent-read takes
no depth: it paraphrases what the spec contains.

## Documentation

| Document | Covers |
|----------|--------|
| [INSTALL.md](INSTALL.md) | Local, GitLab clone, submodule, catalog, and manual install |
| [docs/HOWTO.md](docs/HOWTO.md) | Full usage guide, both commands, worked walkthrough, troubleshooting |
| [docs/ARGUMENTS.md](docs/ARGUMENTS.md) | Flag reference and exit contract |
| [docs/MIGRATION.md](docs/MIGRATION.md) | Mapping from the stock spec-template |
| [bundle/README.md](bundle/README.md) | Org-wide distribution as a bundle |

## Install

Requires a project initialised with `specify init`, `python3` on PATH, and
`pandoc` for any invocation that writes a `.docx`. Full detail in
[INSTALL.md](INSTALL.md).

```bash
unzip sketch.zip                              # anywhere outside the project
cd /path/to/your/spec-kit/project
specify extension add --dev /path/to/sketch
```

The extension lands at `.specify/extensions/sketch/` and both commands are
registered with your agent at install time. Verify:

```bash
specify extension list
specify extension info sketch
.specify/extensions/sketch/scripts/bash/selftest.sh
```

The self-test runs 62 assertions on any machine, plus 14 more resolver
assertions and the converter suite when pandoc is installed. Pandoc-gated
assertions are reported as skipped, never as failures. CI runs the full set.

Uninstall with `specify extension remove sketch`.

### Claude Code and GitHub Copilot

Both are skills-based, and both read the same command source: nothing here is
agent-specific. Claude Code installs to `.claude/skills/`. Copilot has two
modes: skills (`.github/skills/`, matching Claude's layout) and a legacy
default (`.agent.md` + `.prompt.md` under `.github/agents/` and
`.github/prompts/`), selected at `specify init` with
`--integration-options="--skills"`. Legacy mode is deprecated and being phased
out, so prefer skills mode on a fresh Copilot setup.

The invocation differs by mode: skills-based agents hyphenate the full dotted
command name, `speckit.sketch.specify` becomes `/speckit-sketch-specify`.
Copilot's legacy mode keeps the dots, `/speckit.sketch.specify`. Full detail,
including manual install for each mode, is in
[INSTALL.md](INSTALL.md#github-copilot-needs-one-decision-first-which-of-its-two-modes).

## specify

```
/speckit.sketch.specify (-l | -s | -e) -raw <path> [-raw <path> ...] [-spec <path>]
```

| Flag | Required | Meaning |
|------|----------|---------|
| `-l` / `-s` / `-e` | exactly one | Lightweight, Standard, or Exhaustive depth |
| `-raw <path>` | yes, repeatable | Raw input: meeting notes, transcript, existing requirement doc, email export |
| `-spec <path>` | no | Existing spec to extend, `.docx` or `.md` |

Output rules, decided by the resolver rather than the agent:

| `-spec` | Format | Writes |
|---------|--------|--------|
| absent | n/a | `spec.docx` **and** `spec.md` |
| present | `.docx` | `spec.docx` **and** `spec.md` |
| present | `.md` | `spec.md` only |

### There is no -ai flag

Earlier versions took one. It was removed because whether Part D applies is a
property of the work, discoverable from the transcript, not something the caller
should have to assert correctly before reading anything.

The agent now decides, against stated evidence: a model doing the work, an
accuracy target, a human review step that exists because output may be wrong,
test data with known answers, or prompts and retrieval all indicate the
AI-Extended track. Deterministic rules, thresholds, joins and reporting indicate
generic. **Ambiguity resolves to AI-Extended**, because Part D answered "not
applicable, this is deterministic" is a recorded decision, whereas a generic
document has nowhere to record that Part D was considered at all.

In extend mode the baseline spec's structure supplies the answer and the agent
confirms it against the transcript.

## clarify

```
/speckit.sketch.clarify (-l | -s | -e) [-spec <path>]
```

Omit `-spec` and it discovers the active feature spec, via
`check-prerequisites.sh`, then `.specify/feature.json`, then the newest
`specs/*/spec.md`.

It reads the track from the spec: Part D present means AI-Extended. It then
scores every catalog question at that depth against the spec as Answered,
Partial or Missing, queues up to five, and asks them one at a time with a
recommended answer, exactly as stock `/speckit.clarify` does. Each answer is
written into the spec immediately, into the section the question belongs to.

### The ring fence

This is the difference that matters. Stock `/speckit.clarify` generates its
questions at runtime from a 10-category taxonomy, inventing the wording on the
spot, so no two runs are guaranteed to ask the same thing.

`/speckit.sketch.clarify` asks **only** questions that already exist in the
shipped catalog, each cited by a stable id such as `Q-008-03`. It cannot invent
one. If the agent judges something important to be missing from the catalog, it
reports it under "Outside the catalog" rather than asking it, so the catalog can
be amended and reviewed.

The point is auditability: a reviewer can read the catalog before any session
happens and know what will be asked. That is not possible with generated
questions.

The fence is mechanical, not advisory. `scripts/lib/parse_catalog.py` emits the
numbered bank the agent must cite from:

```bash
python3 scripts/lib/parse_catalog.py \
  questions/ai/AI_Requirement_Interview_Questions_Catalog.md \
  --depth standard --track ai --format text
```

### Markdown only

Clarification edits `.md`. Pointed at a `.docx` it exits 5 and tells you to use
the companion or convert first. If a `spec.docx` sits beside the `spec.md` it
edits, it reports that the `.docx` is now stale rather than pretending to
round-trip it: Markdown converted back to `.docx` loses the template styling.
Re-apply by running `specify -spec <the .docx>`.

## Structure and coverage

Parts A, B, C and E are identical in both tracks. The AI track adds Part D.

| | Generic | AI-Extended |
|---|---|---|
| Part A Context | 1-2 | 1-2 |
| Part B Behaviour | 3-6 | 3-6 |
| Part C Quality & Constraints | 7-12 | 7-12 |
| Part D AI Governance | none | 13-18 |
| Part E Closure | 19-20 | 19-20 |
| Appendices | A, B | A, B |
| **Sections** | **14** | **20** |

Questions asked, cumulative:

| Depth | Generic | AI-Extended |
|-------|---------|-------------|
| Lightweight | 34 | 45 |
| Standard | 92 | 125 |
| Exhaustive | 122 | 186 |

Only Section 16 is depth-gated, and only on the AI track at Lightweight.

**AI questions are not confined to Part D.** Of the 64 `[AI]` questions, 40 sit
in Sections 13 to 18 and the other 24 are spread across Sections 5, 6, 7, 8, 10,
11, 12, 19 and 20. The track decision therefore changes the question set across
the whole document.

## Exit contract

Shared by both resolvers:

| Code | Meaning |
|------|---------|
| 0 | resolution succeeded, JSON emitted |
| 1 | usage error: unknown flag, a flag missing its value, or `-ai` |
| 2 | depth error: none, several, or repeated |
| 3 | input error: transcript missing (specify), or no spec found (clarify) |
| 4 | spec path does not resolve (specify) |
| 5 | spec format unsupported: not `.docx`/`.md` (specify), not `.md` (clarify) |
| 6 | a reference file is missing from the extension |
| 7 | a `.docx` is required but pandoc is absent (specify) |

`scripts/bash/docx-to-md.sh` adds exit 8 for a failed or empty conversion.

## What ships here

| Path | Contents |
|------|----------|
| `commands/` | All three command skills |
| `templates/{generic,ai}/` | 12 files: 3 depths x 2 tracks x docx+md |
| `questions/{generic,ai}/` | 4 files: catalog per track, docx+md |
| `examples/{generic,ai}/` | 12 files: worked specimens at every depth |
| `checklists/` | Spec quality checklist |
| `evals/` | 3 command eval suites, 50 records each, 27 scorers, synthetic fixtures |
| `scripts/bash/` | All resolvers, converters, self-test, shared helpers |
| `scripts/lib/` | Catalog parser, the ring-fence mechanism |
| `scripts/powershell/` | Full Windows parity for all three resolvers |
| `bundle/` | `bundle.yml` for org-wide distribution |
| `extension.yml` | Manifest declaring all three commands |

## Typical sequence

```bash
# after the first interview
/speckit.sketch.specify -l -raw ./notes/first-interview.txt

# an independent read, before any questions touch the draft
/speckit.sketch.independent-read

# check the draft against the Lightweight question set, with the
# independent-read findings as a second source of questions
/speckit.sketch.clarify -l

# confirm every logged finding actually closed
/speckit.sketch.independent-read --verify

# after a follow-up session, extend to Standard
/speckit.sketch.specify -s -raw ./notes/followup.txt -spec ./specs/003-x/spec.docx

# check against the Standard set, which now includes every [S] question
/speckit.sketch.clarify -s

/speckit.plan
```

Running clarify at a deeper depth than the spec was authored at is legitimate
and useful: it shows exactly which questions the next tier would add.

## How this differs from stock

Preserved from `/speckit.specify` and `/speckit.clarify`: the frontmatter
contract, `$ARGUMENTS`, the full `before_*` / `after_*` hook protocol,
`SPECIFY_FEATURE_DIRECTORY` resolution, `.specify/feature.json`,
`constitution.md`, the 3-iteration checklist loop, the 5-question cap, one
question at a time, recommendation-first presentation, incremental write-back,
checklist re-validation, and the completion report shape.

Replaced: the template (14 of 22 blocks have no stock destination), the input
(transcript, not typed description), question generation (catalog, not invented),
guessing (an absent fact is a visible gap, never an inferred value), removal of
non-applicable sections (kept with a reason, because a deleted section is
indistinguishable from one nobody considered), EARS instead of `System MUST`,
and Section 7 versus Section 19 instead of a single Success Criteria that
collapses non-functional targets into metrics.

See `docs/MIGRATION.md`.
