# sketch-genai

**Sketch Genai** · `status: planned` · v0.1.0

RAG and agent applications.

## Install

```bash
specify bundle install sketch-genai
```

That is the whole developer-facing surface. Nobody installs the components
individually: the bundle is the unit of provisioning, extensions are the unit
of authorship.

## What it provisions

| Component | Type | Pinned at | Status |
|-----------|------|-----------|--------|
| `sketch` | extension | 0.3.0 | stable |
| `skt-genai` | extension | 0.1.0 | planned |
| `skt-pdfx` | extension | 0.1.0 | planned |
| `skt-docconv` | extension | 0.1.0 | planned |
| `skt-threat` | extension | 0.1.0 | planned |
| `skt-llmcost` | extension | 0.1.0 | planned |
| `sketch-constitution` | preset | 0.1.0 | stable |

> **This bundle is not installable yet.** `skt-genai`, `skt-pdfx`, `skt-docconv`, `skt-threat`, `skt-llmcost` are still `status: planned`, meaning the id is reserved but no
> command exists. The bundle validates and its pins resolve, so CI
> passes, but installing it today registers commands that do nothing.
>
> Use [`sketch-requirements`](../sketch-requirements/) instead: every
> component in it is stable.

## Why the pins are exact

Every component is pinned to an exact version, never a range. Two projects
provisioned six months apart with the same bundle version get provably the same
commands. A range would quietly let them diverge, and the first symptom would
be a bug that reproduces on one machine and not another.

Bumping a component means bumping this bundle: edit `bundle.yml`, tag, and open
a catalog merge request. CI refuses a tag whose version disagrees with the
manifest.

## Releasing

```bash
# 1. edit bundle.yml, bump bundle.version and any component pins
# 2. commit and tag
git tag v0.1.0 && git push origin v0.1.0
# 3. open a merge request bumping this bundle in the catalog fragment
```

Full detail in [../../../docs/RELEASING.md](../../../docs/RELEASING.md).
