# sketch-requirements

**Sketch Requirements** · `status: stable` · v0.1.0

The requirements workflow: author a depth-graded spec from raw inputs, read it independently, close catalog gaps. Everything here is stable and installable today.

## Install

```bash
specify bundle install sketch-requirements
```

That is the whole developer-facing surface. Nobody installs the components
individually: the bundle is the unit of provisioning, extensions are the unit
of authorship.

## What it provisions

| Component | Type | Pinned at | Status |
|-----------|------|-----------|--------|
| `sketch` | extension | 0.3.0 | stable |
| `sketch-constitution` | preset | 0.1.0 | stable |

Every component above is `stable`. This bundle is installable today and is the worked reference for authoring your own.

## Why the pins are exact

Every component is pinned to an exact version, never a range. Two projects
provisioned six months apart with the same bundle version get provably the same
commands. A range would quietly let them diverge, and the first symptom would
be a bug that reproduces on one machine and not another.

Bumping a component means bumping this bundle: edit `bundle.yml`, tag, and open
a catalog merge request. CI refuses a tag whose version disagrees with the
manifest.

## Releasing

```bash
# 1. edit bundle.yml, bump bundle.version and any component pins
# 2. commit and tag
git tag v0.1.0 && git push origin v0.1.0
# 3. open a merge request bumping this bundle in the catalog fragment
```

Full detail in [../../../docs/RELEASING.md](../../../docs/RELEASING.md).
