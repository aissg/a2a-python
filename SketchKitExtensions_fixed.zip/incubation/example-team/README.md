# example-team

A placeholder showing the shape of an incubation sandbox. Delete it once real
teams have their own.

```
incubation/example-team/
└── <whatever you like>
```

There is no required structure here, deliberately. The contract applies at
promotion, not while you are still working out whether the idea is any good.

When you are ready to promote, see
[../README.md](../README.md) and
[../../docs/HOWTO-AUTHOR-EXTENSION.md](../../docs/HOWTO-AUTHOR-EXTENSION.md).
