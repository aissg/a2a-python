# Incubation

Per-team sandboxes. Nothing here appears in any catalog channel, so nothing
here is installable by anyone outside the team that owns it.

```
incubation/
└── <team-slug>/        the team holds Maintainer on its own space
```

## What it is for

Building an extension before it is worth reviewing. No schema conformance, no
catalog entry, no CODEOWNERS routing, no approval queue. Iterate as fast as you
like and break whatever you want.

This exists because the alternative is worse: if the only place to build is a
governed subgroup, people either wait for permission they do not need yet, or
they build somewhere untracked and the platform team finds out at go-live.

## Rules

There are three.

1. Your team is Maintainer of `incubation/<your-team>/` and nothing else.
2. Nothing here is in a catalog channel. If someone outside your team is
   installing it, it has outgrown incubation.
3. Ids used here are not reserved. Two teams can both prototype `skt-thing`.
   Reservation happens at promotion, in the catalog, which is where collisions
   are caught.

## Promotion

When it is real:

1. Read [../docs/HOWTO-AUTHOR-EXTENSION.md](../docs/HOWTO-AUTHOR-EXTENSION.md)
   and bring the extension up to the contract: manifest, command naming,
   selftest, README.
2. Transfer the GitLab project into `domains/<division>/extensions/`. This is a
   project transfer, not a copy, so history and issues follow it.
3. Open a merge request adding it to your division's catalog fragment at
   `platform/catalog/catalog.d/<division>.yml`, with `status: alpha`.
4. CODEOWNERS routes that merge request to your division's leads.

Promotion is where the id is reserved, so check
[../platform/catalog/catalog.yml](../platform/catalog/catalog.yml) before
getting attached to a name.
