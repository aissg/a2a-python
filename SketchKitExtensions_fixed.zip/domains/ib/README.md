# Investment Bank

**Division subgroup: `ib`**

Division: Investment Bank.

This subgroup is the federated tier for Investment Bank. The division's leads hold
Maintainer here; `platform/` is read-only to them. Everything below inherits
that ownership, so no per-repo permission grants are needed.

```
domains/ib/
├── extensions/     capabilities authored by this division
└── bundles/        what this division's people actually install
```

## Status

Empty. The extensions and bundles below are **proposals**, not commitments:
each id is reserved in the catalog with `status: planned`, so pins resolve and
CI passes, but no runnable command exists yet. The division decides what is
built, in what order, and whether these are the right capabilities at all.

## Proposed extensions

| Id | Purpose |
|----|---------|
| `skt-ibpitch` | Pitchbook and comparables structure, banker review conventions |
| `skt-cpresearch` | Counterparty and issuer research, source attribution |
| `skt-creditmemo` | Credit memo and loan agreement section rules |
| `skt-mktintel` | Market intelligence under MiFID II research rules |

## Proposed bundles

| Bundle | Provisions | Components beyond the base |
|--------|-----------|----------------------------|
| `sketch-ib-pitch` | Pitch and comps production | `skt-ibpitch`, `skt-docconv` |
| `sketch-counterparty` | Counterparty research workflow | `skt-cpresearch`, `skt-pdfx` |
| `sketch-loan-agreement` | Credit memo and facility docs | `skt-creditmemo`, `skt-pdfx` |

Every bundle also includes `sketch` (the Layer 2 base) and the
`sketch-constitution` preset. That is a schema rule, not a convention: a bundle
without the base fails catalog validation.

## Getting started

1. Read [../../docs/HOWTO-AUTHOR-EXTENSION.md](../../docs/HOWTO-AUTHOR-EXTENSION.md).
   `platform/base/sketch` is the worked reference: a complete, tested extension.
2. Build in `incubation/<your-team>/` first. Nothing there is visible to any
   catalog channel, so you can iterate without review overhead.
3. When it is ready, promote: a GitLab project transfer into
   `domains/ib/extensions/`, plus a merge request against
   `platform/catalog/catalog.d/ib.yml`.
4. CODEOWNERS routes that merge request to your division's leads. The platform
   team is not in the path for routine domain publishes.

## Catalog fragment

This division's catalog entries live in one file:
`platform/catalog/catalog.d/ib.yml`

You own that file. No other division's merge request can touch it, and yours
touches no one else's.
