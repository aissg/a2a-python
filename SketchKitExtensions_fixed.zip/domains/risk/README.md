# Group Risk Control

**Division subgroup: `risk`**

Division: Group Risk Control.

This subgroup is the federated tier for Group Risk Control. The division's leads hold
Maintainer here; `platform/` is read-only to them. Everything below inherits
that ownership, so no per-repo permission grants are needed.

```
domains/risk/
├── extensions/     capabilities authored by this division
└── bundles/        what this division's people actually install
```

## Status

Empty. The extensions and bundles below are **proposals**, not commitments:
each id is reserved in the catalog with `status: planned`, so pins resolve and
CI passes, but no runnable command exists yet. The division decides what is
built, in what order, and whether these are the right capabilities at all.

## Proposed extensions

| Id | Purpose |
|----|---------|
| `skt-riskrep` | Regulatory risk report templates |
| `skt-riskmod` | Model change and VaR evaluation |
| `skt-stress` | Stress scenario definition and traceability |

## Proposed bundles

| Bundle | Provisions | Components beyond the base |
|--------|-----------|----------------------------|
| `sketch-risk-reporting` | Regulatory risk reporting | `skt-riskrep`, `skt-datasci` |
| `sketch-risk-modelling` | Model development and validation | `skt-riskmod`, `skt-mlops` |

Every bundle also includes `sketch` (the Layer 2 base) and the
`sketch-constitution` preset. That is a schema rule, not a convention: a bundle
without the base fails catalog validation.

## Getting started

1. Read [../../docs/HOWTO-AUTHOR-EXTENSION.md](../../docs/HOWTO-AUTHOR-EXTENSION.md).
   `platform/base/sketch` is the worked reference: a complete, tested extension.
2. Build in `incubation/<your-team>/` first. Nothing there is visible to any
   catalog channel, so you can iterate without review overhead.
3. When it is ready, promote: a GitLab project transfer into
   `domains/risk/extensions/`, plus a merge request against
   `platform/catalog/catalog.d/risk.yml`.
4. CODEOWNERS routes that merge request to your division's leads. The platform
   team is not in the path for routine domain publishes.

## Catalog fragment

This division's catalog entries live in one file:
`platform/catalog/catalog.d/risk.yml`

You own that file. No other division's merge request can touch it, and yours
touches no one else's.
