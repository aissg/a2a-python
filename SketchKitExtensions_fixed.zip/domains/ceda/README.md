# Client Experience, Data and Analytics

**Division subgroup: `ceda`**

Division: Client Experience, Data and Analytics.

> **Verify this expansion.** `ceda` was expanded from the acronym without
> confirmation. Correct it here and in `domains/README.md` if it is wrong;
> nothing else depends on the long name.

This subgroup is the federated tier for Client Experience, Data and Analytics. The division's leads hold
Maintainer here; `platform/` is read-only to them. Everything below inherits
that ownership, so no per-repo permission grants are needed.

```
domains/ceda/
├── extensions/     capabilities authored by this division
└── bundles/        what this division's people actually install
```

## Status

Empty. The extensions and bundles below are **proposals**, not commitments:
each id is reserved in the catalog with `status: planned`, so pins resolve and
CI passes, but no runnable command exists yet. The division decides what is
built, in what order, and whether these are the right capabilities at all.

## Proposed extensions

| Id | Purpose |
|----|---------|
| `skt-dataprod` | Data product specification and contracts |
| `skt-lineage` | Data lineage evidence under BCBS 239 |

## Proposed bundles

| Bundle | Provisions | Components beyond the base |
|--------|-----------|----------------------------|
| `sketch-data-product` | Data product delivery | `skt-dataprod`, `skt-datasci` |

Every bundle also includes `sketch` (the Layer 2 base) and the
`sketch-constitution` preset. That is a schema rule, not a convention: a bundle
without the base fails catalog validation.

## Getting started

1. Read [../../docs/HOWTO-AUTHOR-EXTENSION.md](../../docs/HOWTO-AUTHOR-EXTENSION.md).
   `platform/base/sketch` is the worked reference: a complete, tested extension.
2. Build in `incubation/<your-team>/` first. Nothing there is visible to any
   catalog channel, so you can iterate without review overhead.
3. When it is ready, promote: a GitLab project transfer into
   `domains/ceda/extensions/`, plus a merge request against
   `platform/catalog/catalog.d/ceda.yml`.
4. CODEOWNERS routes that merge request to your division's leads. The platform
   team is not in the path for routine domain publishes.

## Catalog fragment

This division's catalog entries live in one file:
`platform/catalog/catalog.d/ceda.yml`

You own that file. No other division's merge request can touch it, and yours
touches no one else's.
