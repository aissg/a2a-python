# Wealth Management Americas

**Division subgroup: `wma`**

Division: Wealth Management Americas.

> **Verify this expansion.** `wma` was expanded from the acronym without
> confirmation. Correct it here and in `domains/README.md` if it is wrong;
> nothing else depends on the long name.

This subgroup is the federated tier for Wealth Management Americas. The division's leads hold
Maintainer here; `platform/` is read-only to them. Everything below inherits
that ownership, so no per-repo permission grants are needed.

```
domains/wma/
├── extensions/     capabilities authored by this division
└── bundles/        what this division's people actually install
```

## Status

Empty. The extensions and bundles below are **proposals**, not commitments:
each id is reserved in the catalog with `status: planned`, so pins resolve and
CI passes, but no runnable command exists yet. The division decides what is
built, in what order, and whether these are the right capabilities at all.

## Proposed extensions

| Id | Purpose |
|----|---------|
| `skt-secreg` | SEC and FINRA filing structure |
| `skt-regbi` | Regulation Best Interest evidence capture |

## Proposed bundles

| Bundle | Provisions | Components beyond the base |
|--------|-----------|----------------------------|
| `sketch-us-advisory` | US advisory compliance workflow | `skt-secreg`, `skt-regbi` |

Every bundle also includes `sketch` (the Layer 2 base) and the
`sketch-constitution` preset. That is a schema rule, not a convention: a bundle
without the base fails catalog validation.

## Getting started

1. Read [../../docs/HOWTO-AUTHOR-EXTENSION.md](../../docs/HOWTO-AUTHOR-EXTENSION.md).
   `platform/base/sketch` is the worked reference: a complete, tested extension.
2. Build in `incubation/<your-team>/` first. Nothing there is visible to any
   catalog channel, so you can iterate without review overhead.
3. When it is ready, promote: a GitLab project transfer into
   `domains/wma/extensions/`, plus a merge request against
   `platform/catalog/catalog.d/wma.yml`.
4. CODEOWNERS routes that merge request to your division's leads. The platform
   team is not in the path for routine domain publishes.

## Catalog fragment

This division's catalog entries live in one file:
`platform/catalog/catalog.d/wma.yml`

You own that file. No other division's merge request can touch it, and yours
touches no one else's.
