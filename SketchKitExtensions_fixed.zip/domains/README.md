# Domains

The federated tier. Every division has the same shape, owns its own repos, and
publishes to the catalog without the platform team in the approval path.

```
domains/<division>/
├── extensions/     capabilities authored by that division
└── bundles/        what that division's people install
```

## Divisions

| Slug | Division | Proposed extensions | Proposed bundles |
|------|----------|--------------------|------------------|
| [`ib`](./ib/) | Investment Bank | 4 | 3 |
| [`gwm`](./gwm/) | Global Wealth Management | 3 | 2 |
| [`wmpc`](./wmpc/) | Wealth Management Products and Client Solutions * | 2 | 1 |
| [`wma`](./wma/) | Wealth Management Americas * | 2 | 1 |
| [`am`](./am/) | Asset Management | 3 | 2 |
| [`risk`](./risk/) | Group Risk Control | 3 | 2 |
| [`finance`](./finance/) | Group Finance | 2 | 1 |
| [`gcore`](./gcore/) | Group Core Functions * | 2 | 1 |
| [`hr`](./hr/) | Human Resources | 2 | 1 |
| [`legal`](./legal/) | Group Legal | 2 | 1 |
| [`gia`](./gia/) | Group Internal Audit | 2 | 1 |
| [`gic`](./gic/) | Group Internal Consulting * | 2 | 1 |
| [`ceda`](./ceda/) | Client Experience, Data and Analytics * | 2 | 1 |
| [`gcto`](./gcto/) | Group Chief Technology Office | 3 | 1 |
| [`caio`](./caio/) | Chief AI Office | 3 | 1 |

15 divisions. Entries marked `*` have an acronym expansion that was **guessed
and not verified**: correct them in the division's own README. Only the long
name is affected; slugs, ids and catalog entries do not depend on it.

## Everything here is a proposal

No division folder contains a working extension yet. Each division's README
lists proposed capabilities, and each has a catalog fragment where those ids are
reserved with `status: planned`. That means:

- The ids are taken, so two divisions cannot collide on one name.
- Bundle pins resolve, so catalog validation passes today.
- Nothing looks shipped that is not.

Divisions are expected to change these proposals. They were written by reading
the division name, not by talking to the division.

## Ownership

Division leads hold Maintainer on `domains/<division>/`. Inheritance covers
`extensions/`, `bundles/` and every repository below, so no per-repo grants are
needed. `platform/` is read-only to divisions.

Each division owns exactly one catalog fragment:
`platform/catalog/catalog.d/<division>.yml`. CODEOWNERS routes it. A division's
merge request touches only its own fragment.

See [../docs/GITLAB-SETUP.md](../docs/GITLAB-SETUP.md) for the group,
membership and CODEOWNERS configuration that enforces this.

## Adding a division

1. `mkdir -p domains/<slug>/{extensions,bundles}` with a README in each.
2. Add `platform/catalog/catalog.d/<slug>.yml`, even if it only contains
   `extensions: {}` and `bundles: {}`.
3. Add the CODEOWNERS line routing that fragment to the division's leads group.
4. Create the GitLab subgroup and grant the leads group Maintainer on it.
