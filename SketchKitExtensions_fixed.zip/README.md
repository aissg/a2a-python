# SketchKitExtensions

The bank's Spec Kit catalog. One install command per role, a governed catalog
deciding what reaches a developer's machine, and divisions publishing their own
capabilities without a central approval queue.

```bash
specify bundle install sketch-requirements
```

That is the entire developer-facing surface. Nobody installs extensions
individually.

---

## Start here

| You are | Read |
|---------|------|
| A developer who wants to use this | [docs/HOWTO-USE.md](docs/HOWTO-USE.md) |
| Writing an extension | [docs/HOWTO-AUTHOR-EXTENSION.md](docs/HOWTO-AUTHOR-EXTENSION.md) |
| Writing a bundle | [docs/HOWTO-AUTHOR-BUNDLE.md](docs/HOWTO-AUTHOR-BUNDLE.md) |
| Releasing a version | [docs/RELEASING.md](docs/RELEASING.md) |
| Setting up the GitLab groups | [docs/GITLAB-SETUP.md](docs/GITLAB-SETUP.md) |
| Trying to understand the layering | [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) |

The one worked example to copy is [`platform/base/sketch`](platform/base/sketch/):
a complete extension with three commands, resolver scripts, an 87-assertion
selftest and full documentation.

---

## The rule this is built on

**Extensions are the unit of authorship. Bundles are the unit of installation.**

Extensions stay small: one capability, one to five commands, a single command
is fine. Developers never install them directly. They install a bundle, which
pins exact component versions, so a project provisioned today and one
provisioned next quarter get provably the same commands.

The failure this avoids is the one the upstream community catalog demonstrates:
144 extensions, 23% shipping exactly one command, nothing grouping them, and an
explicit no-review disclaimer. Which ten make a working setup is tribal
knowledge. Here, that answer is an artifact the CLI can verify.

---

## Layout

```
SketchKitExtensions/
├── ci/                     reusable pipeline templates
├── docs/                   guides
├── platform/               central tier, platform team owns
│   ├── catalog/            schema, tooling, fragments: the control plane
│   ├── base/sketch/        Layer 2, in every bundle
│   ├── presets/            bank-wide presets
│   ├── extensions/         workload (L3) and cross-cutting (LX)
│   ├── mirrors/            upstream intake, scanned and pinned
│   └── bundles/            workload bundles
├── domains/                federated tier, one subgroup per division
│   └── <division>/
│       ├── extensions/
│       └── bundles/
└── incubation/             per-team sandboxes, in no catalog channel
    └── <team-slug>/
```

In production each extension, bundle and the catalog is its own GitLab project.
This repository is the skeleton: the same layout in one place, so it can be
reviewed and replicated. [docs/GITLAB-SETUP.md](docs/GITLAB-SETUP.md) covers
the split.

---

## What is actually built

Honesty matters more than a full-looking catalog, so the estate says plainly
what runs and what does not.

| | Count | Status |
|---|-------|--------|
| Working extension | 1 | `sketch`, three commands, 87 tests passing |
| Working preset | 1 | `sketch-constitution` |
| Installable bundle | 1 | `sketch-requirements` |
| Reserved extension ids | 55 | `status: planned`, no runnable commands |
| Declared bundles | 31 | 1 stable, 30 planned |
| Divisions scaffolded | 15 | all empty, proposals only |

`status: planned` means the id is reserved and the shape agreed, so bundle pins
resolve and CI passes, but nothing runs. A catalog that cannot express "not
built yet" forces authors to hide roadmap or fake maturity.

---

## The base extension

[`platform/base/sketch`](platform/base/sketch/) is Layer 2: it applies to all
software development in the bank, not to one domain or role.

| Command | What it does |
|---------|--------------|
| `/speckit.sketch.specify` | Author or extend a depth-graded requirement spec from raw inputs |
| `/speckit.sketch.independent-read` | Paraphrase and diff the spec in isolation, catching confident misreads |
| `/speckit.sketch.clarify` | Ask up to five questions drawn only from a fixed, reviewable catalog |

Three depths (Lightweight, Standard, Exhaustive), two tracks (generic and
AI-Extended), and neither command takes a track flag: the track is a finding
read from the source material, not an assertion by the caller.

The property worth knowing about `clarify`: it cannot invent a question. Every
question is cited by catalog id from a versioned file a reviewer can read
before any session happens. Stock `/speckit.clarify` generates its questions at
runtime, which is reasonable but not auditable in advance.

---

## Governance in one paragraph

The catalog is the control plane. Every installable unit is an entry with a
repo, an exact version and a layer. `catalog.schema.yml` validates every merge
request, so the CLI only ever sees what CI approved. Divisions own one fragment
each under `catalog.d/`, routed by CODEOWNERS to that division's leads, so a
domain publish needs no central review. The platform team keeps the schema, the
CI gates and the shared layers, and nothing else.

Enforcement is structural rather than procedural: subgroup membership, protected
branches, CODEOWNERS, schema CI. "Please only touch your own folders" fails at
the first urgent fix.

---

## Verifying this skeleton

Everything here is checked by the root pipeline, and every job runs locally:

```bash
# catalog validates and the aggregate is current
cd platform/catalog
python3 tools/validate_catalog.py
python3 tools/build_catalog.py

# the base extension's own tests
bash platform/base/sketch/scripts/bash/selftest.sh
```

Expect `0 error(s), 0 warning(s)` from the validator and `87 passed, 0 failed`
from the selftest.

---

## Requirements

- `specify` CLI, from `pip install specify-cli` or `uv tool install specify-cli`
- `python3`, for catalog tooling and the base extension's catalog parser
- `pandoc`, only for invocations that write a `.docx`

Extensions are **not** Python packages and are not distributed through PyPI.
Only the `specify` CLI itself is. Extensions are archives fetched from a URL,
which is what the release pipelines here produce.
