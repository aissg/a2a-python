# Contributing

## Where does my change go

| I want to | Read |
|-----------|------|
| Add a new command | [docs/HOWTO-AUTHOR-EXTENSION.md](docs/HOWTO-AUTHOR-EXTENSION.md) |
| Change how an existing command behaves | A preset: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) |
| Group capabilities for a role | [docs/HOWTO-AUTHOR-BUNDLE.md](docs/HOWTO-AUTHOR-BUNDLE.md) |
| Release a version | [docs/RELEASING.md](docs/RELEASING.md) |
| Add my division | [domains/README.md](domains/README.md) |

## Before opening a merge request

```bash
# catalog validates and the aggregate is current
cd platform/catalog
python3 tools/validate_catalog.py
python3 tools/build_catalog.py

# if you touched the base extension
bash platform/base/sketch/scripts/bash/selftest.sh
```

Both must be clean. CI runs the same checks and will not let a stale
`catalog.yml` merge.

## Who approves

CODEOWNERS routes automatically. A change to your division's catalog fragment
goes to your division's leads. A change to the schema, the CI templates or the
shared layers goes to the platform team. You do not need to find a reviewer;
the routing does it.

## House conventions

These are enforced or checked, not preferences:

- **Exact versions everywhere.** No ranges in any pin, ever.
- **Command names are `speckit.{ext-id}.{cmd}`.** Spec Kit rejects anything else.
- **Ids name the capability, not the audience.** Roles live in bundles.
- **`status` is honest.** `planned` is fine and preferred over an `0.0.1` that
  looks shipped.
- **No em-dashes or en-dashes** in Markdown or YAML. Checked by CI, advisory.

## Adding a division

1. `domains/<slug>/{extensions,bundles}` with a README in each.
2. `platform/catalog/catalog.d/<slug>.yml`, even if empty.
3. A CODEOWNERS line routing that fragment to the division's leads.
4. Create the GitLab subgroup, grant the leads group Maintainer.

See [docs/GITLAB-SETUP.md](docs/GITLAB-SETUP.md).
