import json

import httpx
import pytest

from approval_router.extractors.azure_decision1 import AzureDecision1Extractor
from approval_router.extractors.base import CHOICES
from approval_router.logic import Tri
from approval_router.router import Outcome, route

from .conftest import memo

# ---- Azure Microsoft-Decision-1 (System One wire format) ----------------


def azure_extractor(answers, capture):
    def handler(request: httpx.Request) -> httpx.Response:
        capture["url"] = str(request.url)
        capture["headers"] = dict(request.headers)
        capture["body"] = json.loads(request.content)
        return httpx.Response(
            200,
            headers={"apim-request-id": "req-123"},
            json={"model": "decision-1", "answers": answers, "usage": {"input_tokens": 400}},
        )

    return AzureDecision1Extractor(
        endpoint="https://res.services.ai.azure.com/",
        deployment="decision-1",
        api_key="k",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )


def choice(c, conf):
    probs = {k: (conf if k == c else (1 - conf) / 2) for k in CHOICES}
    return {"type": "choice", "choice": c, "probabilities": probs, "confidence": conf}


def test_azure_request_and_parsing(ruleset):
    cap = {}
    answers = {
        "owner_in_europe": choice("yes", 0.97),
        "aircraft_cost_below_1m": choice("yes", 0.99),
        "pays_cash": choice("yes", 0.98),
        "financing_above_3m": choice("no", 0.97),
        "pledged_equity_below_1m": {"type": "refusal"},
    }
    res = route(memo("02_officer_1"), ruleset, azure_extractor(answers, cap))

    assert cap["url"] == "https://res.services.ai.azure.com/providers/microsoft/v1/systemone"
    assert cap["headers"]["api-key"] == "k"
    body = cap["body"]
    assert body["model"] == "decision-1"
    assert body["state"].startswith("CREDIT MEMO")
    q = body["questions"]["pays_cash"]
    assert q["type"] == "choice" and set(q["criteria"]) == {"yes", "no", "not_stated"}

    assert res.facts["owner_in_europe"].value == Tri.TRUE
    assert res.facts["pledged_equity_below_1m"].refused
    assert res.outcome == Outcome.NEEDS_INFO  # R2 cannot be ruled out without the refused fact
    assert res.audit["calls"][0]["request_id"] == "req-123"


def test_azure_http_error_raises(ruleset):
    ext = AzureDecision1Extractor(
        endpoint="https://x",
        api_key="k",
        http_client=httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(429))),
    )
    with pytest.raises(httpx.HTTPStatusError):
        route("memo", ruleset, ext)


def test_azure_uses_entra_token_without_key(ruleset):
    cap = {}
    ext = azure_extractor({}, cap)
    ext.api_key = None
    ext._token_provider = lambda: "tok"
    route("memo", ruleset, ext)
    assert cap["headers"]["authorization"] == "Bearer tok"


def test_batches_above_question_limit(ruleset):
    calls = []

    def handler(request):
        calls.append(len(json.loads(request.content)["questions"]))
        return httpx.Response(200, json={"answers": {}})

    ext = AzureDecision1Extractor(
        endpoint="https://x", api_key="k", http_client=httpx.Client(transport=httpx.MockTransport(handler))
    )
    ext.max_questions_per_call = 2
    ext.extract("memo", ruleset.facts)
    assert calls == [2, 2, 1]


# ---- OpenAI Decisions via LangChain --------------------------------------

lc = pytest.importorskip("langchain_openai.decisions")


class FakeDecisions:
    def __init__(self, response):
        self.response = response
        self.last_input = None

    def invoke(self, payload):
        self.last_input = payload
        return self.response


def test_openai_adapter(ruleset):
    from approval_router.extractors.openai_decisions import OpenAIDecisionsExtractor

    def ca(c, conf):
        return lc.ChoiceAnswer(type="choice", **{k: v for k, v in choice(c, conf).items() if k != "type"})

    response = lc.DecisionResponse(
        model="gpt-6-luna",
        request_id="req_abc",
        usage={"input_tokens": 500, "output_tokens": 5},
        answers={
            "owner_in_europe": ca("not_stated", 0.96),
            "aircraft_cost_below_1m": ca("yes", 0.99),
            "pays_cash": ca("yes", 0.99),
            "financing_above_3m": ca("no", 0.97),
            "pledged_equity_below_1m": lc.RefusalAnswer(type="refusal"),
        },
    )
    fake = FakeDecisions(response)
    ext = OpenAIDecisionsExtractor(client=fake, min_confidence=0.9)
    res = route(memo("01_needs_info"), ruleset, ext)

    q = fake.last_input["questions"]["pays_cash"]
    assert isinstance(q, lc.Choice) and set(q.choices) == {"yes", "no", "not_stated"}
    assert "not_stated" in q.instructions  # guidance appended
    assert res.facts["owner_in_europe"].value == Tri.UNKNOWN
    assert res.facts["pledged_equity_below_1m"].refused
    assert res.outcome == Outcome.NEEDS_INFO
    assert res.audit["calls"][0]["request_id"] == "req_abc"
