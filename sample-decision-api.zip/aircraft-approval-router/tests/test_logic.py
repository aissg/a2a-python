import pytest

from approval_router.logic import Tri, all_of, any_of, evaluate, leaf_facts, not_

T, F, U = Tri.TRUE, Tri.FALSE, Tri.UNKNOWN


@pytest.mark.parametrize(
    "values,expected",
    [([T, T], T), ([T, F], F), ([T, U], U), ([F, U], F), ([U, U], U)],
)
def test_all_of(values, expected):
    assert all_of(values) == expected


@pytest.mark.parametrize(
    "values,expected",
    [([F, F], F), ([T, F], T), ([F, U], U), ([T, U], T), ([U, U], U)],
)
def test_any_of(values, expected):
    assert any_of(values) == expected


def test_not():
    assert not_(T) == F and not_(F) == T and not_(U) == U


def test_nested_evaluation():
    node = {"all": ["a", {"any": ["b", {"not": "c"}]}]}
    assert evaluate(node, {"a": T, "b": F, "c": F}) == T
    assert evaluate(node, {"a": T, "b": F, "c": T}) == F
    assert evaluate(node, {"a": T, "b": U, "c": T}) == U
    assert evaluate(node, {"a": F}) == F  # short-circuits despite missing facts


def test_missing_fact_is_unknown():
    assert evaluate("x", {}) == U


def test_leaf_facts_order_and_dedup():
    assert leaf_facts({"any": ["b", {"all": ["a", "b"]}, {"not": "c"}]}) == ["b", "a", "c"]


def test_bad_node():
    with pytest.raises(ValueError):
        evaluate({"xor": ["a"]}, {})
