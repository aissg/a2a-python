import json

import pytest
from pydantic import ValidationError

from approval_router.rules import RuleSet


def base(**overrides):
    data = {
        "version": "t1",
        "facts": {"a": "Is fact A true?", "b": {"question": "Is fact B true?", "hint": "h"}},
        "rules": [{"id": "R1", "approver": "x", "when": {"all": ["a", "b"]}}],
    }
    data.update(overrides)
    return data


def test_string_facts_are_coerced():
    rs = RuleSet.model_validate(base())
    assert rs.facts["a"].question == "Is fact A true?"
    assert rs.facts["b"].hint == "h"


def test_undefined_fact_rejected():
    with pytest.raises(ValidationError, match="undefined fact 'zzz'"):
        RuleSet.model_validate(base(rules=[{"id": "R1", "approver": "x", "when": "zzz"}]))


def test_unknown_operator_rejected():
    with pytest.raises(ValidationError, match="unknown operator"):
        RuleSet.model_validate(base(rules=[{"id": "R1", "approver": "x", "when": {"xor": ["a"]}}]))


def test_empty_list_rejected():
    with pytest.raises(ValidationError, match="non-empty list"):
        RuleSet.model_validate(base(rules=[{"id": "R1", "approver": "x", "when": {"all": []}}]))


def test_duplicate_ids_rejected():
    rule = {"id": "R1", "approver": "x", "when": "a"}
    with pytest.raises(ValidationError, match="Duplicate rule ids"):
        RuleSet.model_validate(base(rules=[rule, rule]))


def test_default_policy_needs_approver():
    with pytest.raises(ValidationError, match="default_approver"):
        RuleSet.model_validate(base(policy={"on_no_match": "default"}))


def test_unused_facts_and_sha_stable():
    rs = RuleSet.model_validate(base(rules=[{"id": "R1", "approver": "x", "when": "a"}]))
    assert rs.unused_facts() == ["b"]
    assert rs.sha == RuleSet.model_validate(json.loads(rs.model_dump_json())).sha


def test_shipped_rules_valid(ruleset):
    assert ruleset.unused_facts() == []
    assert {r.id for r in ruleset.rules} == {"R1", "R2"}
