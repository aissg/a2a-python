import pytest

from approval_router.extractors import FixtureExtractor
from approval_router.logic import Tri
from approval_router.router import Outcome, decide, route
from approval_router.rules import RuleSet

from .conftest import memo

T, F, U = Tri.TRUE, Tri.FALSE, Tri.UNKNOWN


@pytest.mark.parametrize(
    "case,outcome,approver",
    [
        ("01_needs_info", Outcome.NEEDS_INFO, None),
        ("02_officer_1", Outcome.ROUTED, "risk_officer_1"),
        ("03_officer_2", Outcome.ROUTED, "risk_officer_2"),
        ("04_conflict", Outcome.ESCALATE, None),
        ("05_no_match", Outcome.ESCALATE, None),
        ("06_low_confidence", Outcome.NEEDS_INFO, None),
    ],
)
def test_example_cases(ruleset, examples_dir, case, outcome, approver):
    ext = FixtureExtractor.from_file(examples_dir / "answers" / f"{case}.json", ruleset.policy.min_confidence)
    res = route(memo(case), ruleset, ext)
    assert res.outcome == outcome
    assert res.approver == approver


def test_user_example_lists_missing_facts(ruleset, examples_dir):
    ext = FixtureExtractor.from_file(examples_dir / "answers" / "01_needs_info.json")
    res = route(memo("01_needs_info"), ruleset, ext)
    assert [m.fact for m in res.missing_facts] == ["owner_in_europe", "pledged_equity_below_1m"]
    assert res.rule_results == {"R1": U, "R2": U}


def test_low_confidence_becomes_unknown(ruleset, examples_dir):
    ext = FixtureExtractor.from_file(examples_dir / "answers" / "06_low_confidence.json", 0.9)
    res = route(memo("06_low_confidence"), ruleset, ext)
    fact = res.facts["owner_in_europe"]
    assert fact.choice == "yes" and fact.below_threshold and fact.value == U


def test_refusal_becomes_unknown(ruleset):
    ext = FixtureExtractor({"owner_in_europe": {"refused": True}})
    res = route("memo", ruleset, ext)
    assert res.facts["owner_in_europe"].refused
    assert res.facts["owner_in_europe"].value == U


def test_audit_block_has_no_memo_text(ruleset):
    res = route("secret client memo", ruleset, FixtureExtractor({}))
    assert "secret" not in res.model_dump_json(exclude={"facts"})
    assert res.audit["ruleset_sha"] == ruleset.sha
    assert len(res.audit["memo_sha256"]) == 64


# ---- policy behaviour on the pure decide() step -------------------------


def rules(policy=None, r2_approver="officer_2"):
    return RuleSet.model_validate(
        {
            "version": "t",
            "facts": {"a": "Is A true?", "b": "Is B true?"},
            "rules": [
                {"id": "R1", "approver": "officer_1", "when": "a", "priority": 20},
                {"id": "R2", "approver": r2_approver, "when": "b", "priority": 10},
            ],
            "policy": policy or {},
        }
    )


def test_conflict_escalates_by_default():
    assert decide({"a": T, "b": T}, rules()).outcome == Outcome.ESCALATE


def test_conflict_priority_policy_picks_lowest_number():
    res = decide({"a": T, "b": T}, rules({"on_conflict": "priority"}))
    assert res.outcome == Outcome.ROUTED and res.approver == "officer_2"


def test_matched_rule_waits_for_undecided_rule_with_other_approver():
    res = decide({"a": T, "b": U}, rules())
    assert res.outcome == Outcome.NEEDS_INFO
    assert res.matched_rule == "R1"
    assert [m.fact for m in res.missing_facts] == ["b"]


def test_undecided_rule_with_same_approver_does_not_block():
    res = decide({"a": T, "b": U}, rules(r2_approver="officer_1"))
    assert res.outcome == Outcome.ROUTED and res.approver == "officer_1"


def test_wait_for_undecided_off_routes_immediately():
    res = decide({"a": T, "b": U}, rules({"wait_for_undecided": False}))
    assert res.outcome == Outcome.ROUTED and res.approver == "officer_1"


def test_priority_policy_ignores_lower_priority_undecided():
    # R2 (priority 10) matched; R1 (priority 20) undecided cannot outrank it.
    res = decide({"a": U, "b": T}, rules({"on_conflict": "priority"}))
    assert res.outcome == Outcome.ROUTED and res.approver == "officer_2"


def test_no_match_default_approver():
    res = decide({"a": F, "b": F}, rules({"on_no_match": "default", "default_approver": "senior_credit"}))
    assert res.outcome == Outcome.ROUTED and res.approver == "senior_credit"


def test_no_match_escalates_by_default():
    assert decide({"a": F, "b": F}, rules()).outcome == Outcome.ESCALATE
