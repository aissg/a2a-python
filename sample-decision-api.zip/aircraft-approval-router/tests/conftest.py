from pathlib import Path

import pytest

from approval_router.rules import load_ruleset

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "examples"


@pytest.fixture
def ruleset():
    return load_ruleset(ROOT / "config" / "rules.json")


@pytest.fixture
def examples_dir():
    return EXAMPLES


def memo(name: str) -> str:
    return (EXAMPLES / "memos" / f"{name}.txt").read_text(encoding="utf-8")
