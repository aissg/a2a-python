import json

import pytest

from approval_router.audit import AuditLogger
from approval_router.cli import main
from approval_router.evaluate import load_dataset, run_eval
from approval_router.extractors import FixtureExtractor

from .conftest import ROOT, memo


def test_cli_validate(capsys):
    assert main(["validate", "--rules", str(ROOT / "config/rules.json")]) == 0
    assert "OK" in capsys.readouterr().out


def test_cli_route_fixture_and_audit(tmp_path, capsys):
    log = tmp_path / "audit.jsonl"
    code = main(
        [
            "route",
            "--rules", str(ROOT / "config/rules.json"),
            "--memo", str(ROOT / "examples/memos/02_officer_1.txt"),
            "--extractor", "fixture",
            "--answers", str(ROOT / "examples/answers/02_officer_1.json"),
            "--audit-log", str(log),
            "--case-id", "CASE-7",
        ]
    )
    out = capsys.readouterr().out
    assert code == 0 and "risk_officer_1" in out
    record = json.loads(log.read_text().splitlines()[0])
    assert record["case_id"] == "CASE-7" and record["approver"] == "risk_officer_1"
    assert "memo" not in record  # memo text is not logged by default


def test_cli_route_needs_info_exit_code(capsys):
    code = main(
        [
            "route",
            "--rules", str(ROOT / "config/rules.json"),
            "--memo", str(ROOT / "examples/memos/01_needs_info.txt"),
            "--extractor", "fixture",
            "--answers", str(ROOT / "examples/answers/01_needs_info.json"),
        ]
    )
    assert code == 2
    assert "owner_in_europe" in capsys.readouterr().out


def test_eval_oracle_passes(ruleset):
    report = run_eval(load_dataset(ROOT / "examples/eval_set.jsonl"), ruleset, None)
    assert report["routing_accuracy"] == 1.0
    assert report["wrong_approver"] == []


def test_eval_flags_wrong_approver(ruleset):
    # An extractor that always says yes produces conflicts and wrong routes.
    always_yes = FixtureExtractor({f: "yes" for f in ruleset.facts})
    report = run_eval(load_dataset(ROOT / "examples/eval_set.jsonl"), ruleset, always_yes)
    assert report["routing_accuracy"] < 1.0
    assert report["fact_accuracy"] < 1.0


def test_audit_logger_include_memo(tmp_path, ruleset):
    from approval_router.router import route

    log = AuditLogger(tmp_path / "a.jsonl", include_memo=True)
    res = route(memo("01_needs_info"), ruleset, FixtureExtractor({}))
    log.write(res, memo="hello")
    assert json.loads((tmp_path / "a.jsonl").read_text())["memo"] == "hello"


# ---- REST API -----------------------------------------------------------

fastapi = pytest.importorskip("fastapi")


def test_api_route(tmp_path, ruleset, examples_dir):
    from fastapi.testclient import TestClient

    from approval_router.api import create_app

    ext = FixtureExtractor.from_file(examples_dir / "answers/03_officer_2.json")
    app = create_app(ruleset, ext, AuditLogger(tmp_path / "api.jsonl"))
    client = TestClient(app)

    assert client.get("/health").json()["ruleset_sha"] == ruleset.sha
    r = client.post("/route", json={"memo": memo("03_officer_2"), "case_id": "C1"})
    assert r.status_code == 200
    assert r.json()["approver"] == "risk_officer_2"
    assert (tmp_path / "api.jsonl").exists()


def test_api_provider_failure_is_502(tmp_path, ruleset):
    from fastapi.testclient import TestClient

    from approval_router.api import create_app

    class Broken(FixtureExtractor):
        def _extract_batch(self, memo, facts):
            raise RuntimeError("timeout")

    client = TestClient(create_app(ruleset, Broken({}), AuditLogger(tmp_path / "x.jsonl")))
    r = client.post("/route", json={"memo": "m"})
    assert r.status_code == 502
