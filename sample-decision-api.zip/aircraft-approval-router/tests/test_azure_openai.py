"""Azure OpenAI Decisions API adapter, tested against the real OpenAI SDK with a mocked HTTP layer."""

import json

import httpx
import pytest

pytest.importorskip("openai")

from approval_router.extractors import make_extractor
from approval_router.extractors.azure_openai_decisions import AzureOpenAIDecisionsExtractor, _base_url
from approval_router.logic import Tri
from approval_router.router import Outcome, route

from .conftest import memo

ENDPOINT = "https://ubs-risk.openai.azure.com"


def choice_answer(name, value, conf):
    probs = [{"value": v, "probability": conf if v == value else (1 - conf) / 2} for v in ("yes", "no", "not_stated")]
    return {"type": "choice", "name": name, "choice": value, "confidence": conf, "probabilities": probs}


def make(answers_fn, cap, api_key="k", **kw):
    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        cap.setdefault("requests", []).append(
            {"url": str(request.url), "headers": dict(request.headers), "body": body}
        )
        return httpx.Response(
            200,
            headers={"apim-request-id": "apim-42"},
            json={
                "model": "gpt-6-luna",
                "answers": answers_fn(body),
                "usage": {"input_tokens": 512, "output_tokens": 0, "total_tokens": 512},
            },
        )

    return AzureOpenAIDecisionsExtractor(
        endpoint=ENDPOINT,
        deployment="luna-decisions-prod",
        api_key=api_key,
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
        max_retries=0,
        **kw,
    )


ANSWERS_01 = {
    "owner_in_europe": ("not_stated", 0.97),
    "aircraft_cost_below_1m": ("yes", 0.99),
    "pays_cash": ("yes", 0.98),
    "financing_above_3m": ("no", 0.97),
    "pledged_equity_below_1m": ("not_stated", 0.95),
}


def from_table(table):
    return lambda body: [choice_answer(q["name"], *table[q["name"]]) for q in body["questions"]]


def test_base_url():
    assert _base_url(ENDPOINT) == f"{ENDPOINT}/openai/v1/"
    assert _base_url(f"{ENDPOINT}/openai/v1/") == f"{ENDPOINT}/openai/v1/"


def test_request_shape_and_user_example(ruleset):
    cap = {}
    res = route(memo("01_needs_info"), ruleset, make(from_table(ANSWERS_01), cap))

    req = cap["requests"][0]
    assert req["url"] == f"{ENDPOINT}/openai/v1/decisions"
    assert req["headers"]["authorization"] == "Bearer k"
    body = req["body"]
    assert body["model"] == "luna-decisions-prod"  # deployment name, not model name
    assert body["input"].startswith("CREDIT MEMO")
    assert [q["name"] for q in body["questions"]] == list(ruleset.facts)
    q = body["questions"][0]
    assert q["type"] == "choice"
    assert [c["value"] for c in q["choices"]] == ["yes", "no", "not_stated"]
    assert "country of residence" in q["instructions"]  # fact hint is passed through

    assert res.outcome == Outcome.NEEDS_INFO
    assert [m.fact for m in res.missing_facts] == ["owner_in_europe", "pledged_equity_below_1m"]
    assert res.facts["pays_cash"].probabilities["yes"] == pytest.approx(0.98)
    call = res.audit["calls"][0]
    assert call["provider"] == "azure-openai" and call["request_id"] == "apim-42"
    assert call["usage"]["input_tokens"] == 512


def test_routes_to_officer_2(ruleset):
    table = {
        "owner_in_europe": ("no", 0.97),
        "aircraft_cost_below_1m": ("no", 0.99),
        "pays_cash": ("no", 0.99),
        "financing_above_3m": ("yes", 0.99),
        "pledged_equity_below_1m": ("no", 0.96),
    }
    res = route(memo("03_officer_2"), ruleset, make(from_table(table), {}))
    assert res.outcome == Outcome.ROUTED and res.approver == "risk_officer_2"


def test_refusal_with_null_name_matched_by_position(ruleset):
    def answers(body):
        out = [choice_answer(q["name"], *ANSWERS_01[q["name"]]) for q in body["questions"]]
        out[0] = {"type": "refusal", "name": None}
        return out

    res = route(memo("01_needs_info"), ruleset, make(answers, {}))
    assert res.facts["owner_in_europe"].refused
    assert res.facts["owner_in_europe"].value == Tri.UNKNOWN


def test_low_confidence_threshold(ruleset):
    table = dict(ANSWERS_01, owner_in_europe=("yes", 0.62))
    res = route(memo("06_low_confidence"), ruleset, make(from_table(table), {}))
    assert res.facts["owner_in_europe"].below_threshold


def test_entra_token_callable(ruleset):
    cap = {}
    route("memo", ruleset, make(from_table(ANSWERS_01), cap, api_key=lambda: "entra-token"))
    assert cap["requests"][0]["headers"]["authorization"] == "Bearer entra-token"


def test_batching(ruleset):
    cap = {}
    ext = make(from_table(ANSWERS_01), cap)
    ext.max_questions_per_call = 2
    res = route("memo", ruleset, ext)
    assert [len(r["body"]["questions"]) for r in cap["requests"]] == [2, 2, 1]
    assert len(res.facts) == 5 and len(res.audit["calls"]) == 3


def test_http_error_propagates(ruleset):
    import openai

    ext = AzureOpenAIDecisionsExtractor(
        endpoint=ENDPOINT,
        api_key="k",
        max_retries=0,
        http_client=httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(429, json={}))),
    )
    with pytest.raises(openai.RateLimitError):
        route("memo", ruleset, ext)


def test_factory_and_missing_endpoint(monkeypatch):
    monkeypatch.delenv("AZURE_OPENAI_ENDPOINT", raising=False)
    with pytest.raises(ValueError, match="AZURE_OPENAI_ENDPOINT"):
        make_extractor("azure-openai", api_key="k")
    ext = make_extractor("azure-openai", endpoint=ENDPOINT, api_key="k", deployment="d")
    assert ext.name == "azure-openai" and ext.deployment == "d"
