# Aircraft Approval Router

Routes an aircraft-financing credit memo to the risk officer who must approve it.

**Core principle:** the AI model never picks the approver. It only answers atomic fact questions about the memo (yes, no or not stated). A deterministic rule engine applies your JSON logic gates to those facts. Missing or low-confidence facts are never guessed; the system asks for them.

```
credit memo ──► Fact extraction ──► facts (TRUE / FALSE / UNKNOWN) ──► Rule engine ──► ROUTED       risk_officer_N
                (decision model,                                       (3-valued        NEEDS_INFO   + missing facts
                 one call, one                                          logic,           ESCALATE     conflict / no match
                 question per fact)                                     policies)
                                         └──────────────── audit record (JSONL) ◄──────────────┘
```

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev,api]"

approval-router validate                     # check config/rules.json
pytest                                       # 63 tests, no network needed

# Offline demo with recorded model answers
approval-router route --memo examples/memos/01_needs_info.txt \
    --extractor fixture --answers examples/answers/01_needs_info.json
```

Output for the example memo (29-year-old, pays cash, 750,000, no country stated):

```
Outcome : NEEDS_INFO
Reason  : Rules ['R1', 'R2'] cannot be decided from the memo.
Missing :
  - owner_in_europe: Is the aircraft owner domiciled in a European country? (blocks R1)
  - pledged_equity_below_1m: Is the equity the client has pledged below 1,000,000? (blocks R2)
```

## Live models

| Extractor | Service and model | Status (Oct 2026) | Setup |
|---|---|---|---|
| `azure-openai` (default) | Azure OpenAI Decisions API, `gpt-6-luna` | **GA** in Foundry since 23 Oct 2026 | `pip install -e ".[azure-openai]"`, set `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_DECISIONS_DEPLOYMENT`, and `AZURE_OPENAI_API_KEY` or use Entra ID |
| `openai` | OpenAI Decisions API, `gpt-6-luna` | Public beta | `pip install -e ".[openai]"`, set `OPENAI_API_KEY`, optional `OPENAI_BASE_URL` for an internal gateway |
| `azure-decision1` | Microsoft-Decision-1 on Foundry | Public preview, text only, no Swiss region | `pip install -e ".[azure-decision1]"`, set `AZURE_DECISION_ENDPOINT`, `AZURE_DECISION_DEPLOYMENT`, and `AZURE_DECISION_API_KEY` or use Entra ID |
| `fixture` | Recorded answers | n/a | `--answers file.json` |

```bash
approval-router route --memo memo.txt --extractor azure-openai --audit-log audit/audit.jsonl --case-id DEAL-123
```

See `.env.example` for all settings.

### Azure OpenAI Decisions API

The default adapter calls `POST https://<resource>.openai.azure.com/openai/v1/decisions` through the official OpenAI Python SDK (`openai>=3.26.0`), as in Microsoft's how-to guide.

1. Deploy `gpt-6-luna` in your Azure OpenAI resource. East US 2 is excluded from the rollout; check that your target region and deployment type (for example Data Zone EU) are offered for the model.
2. Set `AZURE_OPENAI_ENDPOINT` and `AZURE_OPENAI_DECISIONS_DEPLOYMENT`. The request's `model` field carries your **deployment name**, not the model name.
3. Authenticate with `AZURE_OPENAI_API_KEY`, or leave it empty to use Entra ID through `DefaultAzureCredential` (managed identity on AKS, `az login` locally). Override the token scope with `AZURE_OPENAI_TOKEN_SCOPE` if your tenant needs a different one.

Each fact is sent as a `choice` question with the values `yes`, `no` and `not_stated`. Up to 400 questions go in one call, and the APIM request ID is stored in the audit log. A refusal on one question makes only that fact UNKNOWN.

**Microsoft-Decision-1 note:** Microsoft has not fully documented the Foundry request format for Decision-1. The adapter uses the System One schema (`state`, `questions` with `type` / `instructions` / `criteria`) at `/providers/microsoft/v1/systemone`. Check it against the "View code" sample in your Foundry deployment and override `AZURE_DECISION_PATH` if needed. Deployment names must not contain the word "Microsoft".

## REST API

```bash
approval-router serve --port 8000          # or: uvicorn approval_router.api:create_app --factory
curl -X POST localhost:8000/route -H 'content-type: application/json' \
     -d '{"memo": "Client is 29 years old ...", "case_id": "DEAL-123"}'
```

| Endpoint | Purpose |
|---|---|
| `POST /route` | Route one memo, returns the full result and writes the audit log |
| `GET /rules` | Active rule set with version and hash |
| `GET /health` | Liveness plus rule set version |

A provider error returns HTTP 502. The service never falls back to guessing an approver.

Docker: `docker build -t approval-router . && docker run -p 8000:8000 --env-file .env approval-router`

## Writing rules

`config/rules.json` (schema in `config/rules.schema.json`):

```json
{
  "version": "aircraft-approval-2026.10.1",
  "facts": {
    "pays_cash": { "question": "Is the client paying the full price in cash ...?", "hint": "optional guidance" }
  },
  "rules": [
    { "id": "R1", "approver": "risk_officer_1", "priority": 20,
      "when": { "all": ["owner_in_europe", "aircraft_cost_below_1m", "pays_cash"] } }
  ],
  "policy": { "min_confidence": 0.9, "on_conflict": "escalate", "on_no_match": "escalate",
              "default_approver": null, "wait_for_undecided": true }
}
```

- **Facts:** one yes/no question each. Phrase thresholds into the question ("below 1,000,000") rather than asking the model for a number.
- **Gates:** a node is a fact name, `{"all": [...]}`, `{"any": [...]}` or `{"not": node}`, nested freely.
- **Unknowns:** evaluated with three-valued logic. `FALSE AND UNKNOWN` is FALSE, `TRUE OR UNKNOWN` is TRUE, otherwise UNKNOWN propagates.

| Policy | Values | Effect |
|---|---|---|
| `min_confidence` | 0 to 1 | Answers below this confidence count as UNKNOWN |
| `on_conflict` | `escalate`, `priority` | Two matched rules with different approvers: escalate, or take the lowest `priority` number |
| `on_no_match` | `escalate`, `default` | All rules FALSE: escalate, or route to `default_approver` |
| `wait_for_undecided` | true, false | A rule matched but another rule with a different approver is still UNKNOWN: ask for the missing facts (true) or route now (false) |

Run `approval-router validate` after every change. It rejects undefined facts, unknown operators, empty gates and duplicate IDs, and warns about unused facts.

## Evaluation

`examples/eval_set.jsonl` holds labelled cases (memo, expected facts, expected outcome and approver).

```bash
approval-router eval --dataset examples/eval_set.jsonl --extractor oracle   # tests rules and labels only
approval-router eval --dataset examples/eval_set.jsonl --extractor azure-openai   # tests the live model
approval-router eval --dataset examples/eval_set.jsonl --extractor azure-openai --mlflow
```

Reported metrics: fact accuracy (overall and per fact), outcome accuracy, routing accuracy, abstain rate, and **wrong_approver**, the list of cases routed to the wrong officer. That last metric is the one to gate releases on; the command exits non-zero if it is not empty. Use `--mlflow` to log every run with the rule set hash and confidence threshold.

## Governance notes

- **Audit trail:** every result carries the rule set version and SHA, the memo SHA-256, each fact answer with choice, confidence and probabilities, the model name and the provider request ID. The memo text is not logged unless you set `include_memo=True`.
- **Model scope:** the model performs extraction only, and the routing logic is plain code under version control. This keeps the model-risk surface small and testable for SR 11-7 validation.
- **Data residency:** memo text is sent to the model on every call. With Azure OpenAI it stays inside your Azure tenant boundary, but processing location depends on deployment type: Global can process anywhere, Data Zone EU processes in the EU, and neither is Switzerland. Confirm against your FINMA outsourcing assessment.
- **Release status:** the Azure OpenAI Decisions API is GA (23 Oct 2026). The OpenAI Decisions API is in public beta and Microsoft-Decision-1 is in public preview. Re-run the eval set on every model or deployment change.

## Open business questions in the sample rules

1. **Pledged equity on cash deals.** As written, a cash buyer who pledges less than 1m triggers R2, so `04_conflict` escalates. Decide whether R2 should only apply to financed deals.
2. **"In Europe".** The sample hint uses residency or country of incorporation, not nationality. Confirm with the business and update the `hint`.
3. **Currency.** Thresholds are applied to the amount in the currency stated. Add FX handling in the question or a pre-processing step if needed.

## Project layout

```
config/rules.json              rule set
config/rules.schema.json       JSON schema for editors
src/approval_router/
  logic.py                     three-valued logic
  rules.py                     rule model and validation
  router.py                    decide() and route()
  extractors/                  azure_openai_decisions (default), openai_decisions,
                               azure_decision1, fixture
  audit.py                     JSONL audit log
  evaluate.py                  eval harness, MLflow logging
  cli.py, api.py               CLI and FastAPI service
examples/                      memos, recorded answers, eval set
tests/                         pytest suite
```
