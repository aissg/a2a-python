"""Append-only JSONL audit log.

Each line holds the full routing result: every fact answer with its confidence,
rule results, the rule set version and hash, the model and request id.
The memo text is NOT stored by default, only its SHA-256, so the log can sit
outside the client-data perimeter. Set include_memo=True only where permitted.
"""

from __future__ import annotations

import json
import threading
from pathlib import Path

from .router import RoutingResult


class AuditLogger:
    def __init__(self, path: str | Path, include_memo: bool = False) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.include_memo = include_memo
        self._lock = threading.Lock()

    def write(self, result: RoutingResult, memo: str | None = None, case_id: str | None = None) -> None:
        record = result.model_dump(mode="json")
        if case_id:
            record["case_id"] = case_id
        if self.include_memo and memo is not None:
            record["memo"] = memo
        line = json.dumps(record, ensure_ascii=False)
        with self._lock, self.path.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
