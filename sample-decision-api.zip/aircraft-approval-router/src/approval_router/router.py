"""Deterministic routing from extracted facts to an approver."""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Mapping

from pydantic import BaseModel

from .extractors.base import ExtractionResult, FactAnswer, FactExtractor
from .logic import Tri, evaluate, leaf_facts
from .rules import Rule, RuleSet


class Outcome(str, Enum):
    ROUTED = "ROUTED"
    NEEDS_INFO = "NEEDS_INFO"
    ESCALATE = "ESCALATE"


class MissingFact(BaseModel):
    fact: str
    question: str
    blocks_rules: list[str]


class RoutingResult(BaseModel):
    outcome: Outcome
    approver: str | None
    matched_rule: str | None
    reason: str
    missing_facts: list[MissingFact] = []
    rule_results: dict[str, Tri] = {}
    facts: dict[str, FactAnswer] = {}
    audit: dict[str, Any] = {}


def decide(fact_values: Mapping[str, Tri], ruleset: RuleSet) -> RoutingResult:
    """Pure decision step: facts in, routing result out. No model calls."""
    policy = ruleset.policy
    rule_results = {r.id: evaluate(r.when, fact_values) for r in ruleset.rules}
    matched = sorted(
        (r for r in ruleset.rules if rule_results[r.id] == Tri.TRUE), key=lambda r: r.priority
    )
    undecided = [r for r in ruleset.rules if rule_results[r.id] == Tri.UNKNOWN]

    def result(outcome, approver=None, rule=None, reason="", blocking=()):
        return RoutingResult(
            outcome=outcome,
            approver=approver,
            matched_rule=rule.id if rule else None,
            reason=reason,
            missing_facts=_missing(blocking, fact_values, ruleset),
            rule_results=rule_results,
        )

    # 1. One or more rules matched.
    if matched:
        approvers = {r.approver for r in matched}
        if len(approvers) > 1:
            top = [r for r in matched if r.priority == matched[0].priority]
            if policy.on_conflict == "escalate" or len({r.approver for r in top}) > 1:
                ids = [r.id for r in matched]
                return result(Outcome.ESCALATE, reason=f"Conflict: rules {ids} point to different approvers.")
        winner = matched[0]

        blocking = [
            r
            for r in undecided
            if r.approver != winner.approver
            and (policy.on_conflict == "escalate" or r.priority <= winner.priority)
        ]
        if blocking and policy.wait_for_undecided:
            ids = [r.id for r in blocking]
            return result(
                Outcome.NEEDS_INFO,
                rule=winner,
                reason=(
                    f"Rule {winner.id} matched ({winner.approver}), but rules {ids} could route "
                    "elsewhere once the missing facts are known."
                ),
                blocking=blocking,
            )
        return result(
            Outcome.ROUTED,
            approver=winner.approver,
            rule=winner,
            reason=f"Rule {winner.id} matched; no other rule routes elsewhere.",
        )

    # 2. Nothing matched yet, but some rules are undecided.
    if undecided:
        ids = [r.id for r in undecided]
        return result(
            Outcome.NEEDS_INFO,
            reason=f"Rules {ids} cannot be decided from the memo.",
            blocking=undecided,
        )

    # 3. Every rule is FALSE.
    if policy.on_no_match == "default":
        return result(
            Outcome.ROUTED,
            approver=policy.default_approver,
            reason="No rule matched; routed to the default approver.",
        )
    return result(Outcome.ESCALATE, reason="No rule matched.")


def _missing(rules: list[Rule], fact_values: Mapping[str, Tri], ruleset: RuleSet) -> list[MissingFact]:
    out: dict[str, MissingFact] = {}
    for rule in rules:
        for fact in leaf_facts(rule.when):
            if fact_values.get(fact, Tri.UNKNOWN) != Tri.UNKNOWN:
                continue
            if fact not in out:
                out[fact] = MissingFact(
                    fact=fact, question=ruleset.facts[fact].question, blocks_rules=[]
                )
            out[fact].blocks_rules.append(rule.id)
    order = list(ruleset.facts)
    return sorted(out.values(), key=lambda m: order.index(m.fact))


def route(memo: str, ruleset: RuleSet, extractor: FactExtractor) -> RoutingResult:
    """Extract facts from the memo with the decision model, then decide."""
    extraction: ExtractionResult = extractor.extract(memo, ruleset.facts)
    values = {name: ans.value for name, ans in extraction.answers.items()}
    result = decide(values, ruleset)
    result.facts = extraction.answers
    result.audit = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "ruleset_version": ruleset.version,
        "ruleset_sha": ruleset.sha,
        "memo_sha256": hashlib.sha256(memo.encode("utf-8")).hexdigest(),
        "min_confidence": extractor.min_confidence,
        **extraction.meta,
    }
    return result
