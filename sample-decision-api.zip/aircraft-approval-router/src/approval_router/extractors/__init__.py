from __future__ import annotations

from typing import Any

from .base import CHOICES, ExtractionResult, FactAnswer, FactExtractor, RawAnswer
from .fixture import FixtureExtractor

__all__ = [
    "CHOICES",
    "ExtractionResult",
    "FactAnswer",
    "FactExtractor",
    "RawAnswer",
    "FixtureExtractor",
    "EXTRACTORS",
    "make_extractor",
]


EXTRACTORS = ("azure-openai", "openai", "azure-decision1", "fixture")


def make_extractor(kind: str, min_confidence: float = 0.9, **kwargs: Any) -> FactExtractor:
    """Build an extractor by name.

    azure-openai     Azure OpenAI Decisions API, gpt-6-luna (GA)
    openai           OpenAI Decisions API via LangChain (public beta)
    azure-decision1  Microsoft-Decision-1 on Foundry (public preview)
    fixture          recorded answers (answers=... or answers_path=...)
    """
    kind = kind.lower()
    if kind == "azure-openai":
        from .azure_openai_decisions import AzureOpenAIDecisionsExtractor

        return AzureOpenAIDecisionsExtractor(min_confidence=min_confidence, **kwargs)
    if kind == "openai":
        from .openai_decisions import OpenAIDecisionsExtractor

        return OpenAIDecisionsExtractor(min_confidence=min_confidence, **kwargs)
    if kind == "azure-decision1":
        from .azure_decision1 import AzureDecision1Extractor

        return AzureDecision1Extractor(min_confidence=min_confidence, **kwargs)
    if kind == "fixture":
        if "answers_path" in kwargs:
            return FixtureExtractor.from_file(kwargs["answers_path"], min_confidence)
        return FixtureExtractor(kwargs.get("answers", {}), min_confidence)
    raise ValueError(f"Unknown extractor '{kind}' (use one of {', '.join(EXTRACTORS)})")
