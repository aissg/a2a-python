"""Offline extractor that returns pre-recorded answers.

Used for tests, demos and for checking rules against labelled data
("oracle" mode in the eval harness) without calling a model.

Answer values may be "yes" / "no" / "not_stated", or an object:
    {"choice": "yes", "confidence": 0.97}
    {"refused": true}
Facts missing from the fixture come back as UNKNOWN.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from ..rules import FactDef
from .base import FactExtractor, RawAnswer


class FixtureExtractor(FactExtractor):
    name = "fixture"

    def __init__(self, answers: Mapping[str, Any], min_confidence: float = 0.9) -> None:
        super().__init__(min_confidence)
        self.answers = dict(answers)

    @classmethod
    def from_file(cls, path: str | Path, min_confidence: float = 0.9) -> "FixtureExtractor":
        return cls(json.loads(Path(path).read_text(encoding="utf-8")), min_confidence)

    def _extract_batch(
        self, memo: str, facts: Mapping[str, FactDef]
    ) -> tuple[dict[str, RawAnswer], dict[str, Any]]:
        raw: dict[str, RawAnswer] = {}
        for name in facts:
            if name not in self.answers:
                continue
            value = self.answers[name]
            if isinstance(value, str):
                raw[name] = RawAnswer(choice=value, confidence=1.0)
            else:
                raw[name] = RawAnswer(**value)
        return raw, {"provider": "fixture"}
