"""OpenAI Decisions API adapter, via LangChain (langchain-openai>=1.7.0).

Status: the Decisions API is in public beta and gpt-6-luna is the only model.
Set OPENAI_BASE_URL to route through an internal gateway instead of api.openai.com.
"""

from __future__ import annotations

import os
from typing import Any, Mapping

from ..rules import FactDef
from .base import CHOICES, FactExtractor, RawAnswer, build_instructions


class OpenAIDecisionsExtractor(FactExtractor):
    name = "openai"

    def __init__(
        self,
        model: str | None = None,
        min_confidence: float = 0.9,
        base_url: str | None = None,
        client: Any | None = None,
    ) -> None:
        super().__init__(min_confidence)
        self.model = model or os.getenv("OPENAI_DECISIONS_MODEL", "gpt-6-luna")
        if client is None:
            from langchain_openai.decisions import OpenAIDecisions

            client = OpenAIDecisions(
                model=self.model, base_url=base_url or os.getenv("OPENAI_BASE_URL") or None
            )
        self.client = client

    def _extract_batch(
        self, memo: str, facts: Mapping[str, FactDef]
    ) -> tuple[dict[str, RawAnswer], dict[str, Any]]:
        from langchain_openai.decisions import Choice

        questions = {
            name: Choice(instructions=build_instructions(fact), choices=CHOICES)
            for name, fact in facts.items()
        }
        resp = self.client.invoke({"input": memo, "questions": questions})

        raw: dict[str, RawAnswer] = {}
        refusals = getattr(resp, "refusals", {}) or {}
        for name in facts:
            if name in refusals:
                raw[name] = RawAnswer(refused=True)
                continue
            ans = (getattr(resp, "choices", {}) or {}).get(name)
            if ans is None:
                continue
            raw[name] = RawAnswer(
                choice=str(ans.choice),
                confidence=ans.confidence,
                probabilities={str(k): float(v) for k, v in (ans.probabilities or {}).items()},
            )

        usage = getattr(resp, "usage", None)
        meta = {
            "provider": "openai",
            "model": getattr(resp, "model", self.model),
            "request_id": getattr(resp, "request_id", None),
            "usage": usage.model_dump() if hasattr(usage, "model_dump") else usage,
        }
        return raw, meta
