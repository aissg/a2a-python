"""Azure OpenAI Decisions API adapter (Microsoft Foundry).

Status: generally available in Microsoft Foundry since 23 Oct 2026.
Model: gpt-6-luna is the only supported model. Rolling out to regions where
gpt-6-luna is available; East US 2 is excluded. Check your target region and
deployment type (Global, Data Zone EU) in the Foundry portal before use.

Wire format (OpenAI SDK, openai>=3.26.0):
    POST {endpoint}/openai/v1/decisions
    {"model": <deployment name>, "input": <memo>,
     "questions": [{"type": "choice", "name": ..., "instructions": ...,
                    "choices": [{"value": ..., "description": ...}]}]}
    -> {"model": ..., "answers": [{"type": "choice", "name": ..., "choice": ...,
        "confidence": ..., "probabilities": [{"value": ..., "probability": ...}]}
        | {"type": "refusal", "name": ...}], "usage": {...}}

Environment:
    AZURE_OPENAI_ENDPOINT               https://<resource>.openai.azure.com
    AZURE_OPENAI_DECISIONS_DEPLOYMENT   deployment name of gpt-6-luna (default gpt-6-luna)
    AZURE_OPENAI_API_KEY                key auth; if unset, Entra ID is used
    AZURE_OPENAI_TOKEN_SCOPE            Entra scope (default https://cognitiveservices.azure.com/.default)
"""

from __future__ import annotations

import os
from typing import Any, Callable, Mapping

from ..rules import FactDef
from .base import CHOICES, FactExtractor, RawAnswer, build_instructions

DEFAULT_SCOPE = "https://cognitiveservices.azure.com/.default"


def _base_url(endpoint: str) -> str:
    endpoint = endpoint.rstrip("/")
    if not endpoint.endswith("/openai/v1"):
        endpoint += "/openai/v1"
    return endpoint + "/"


class AzureOpenAIDecisionsExtractor(FactExtractor):
    name = "azure-openai"
    max_questions_per_call = 400

    def __init__(
        self,
        endpoint: str | None = None,
        deployment: str | None = None,
        api_key: str | Callable[[], str] | None = None,
        min_confidence: float = 0.9,
        timeout: float = 30.0,
        max_retries: int = 2,
        client: Any | None = None,
        http_client: Any | None = None,
    ) -> None:
        super().__init__(min_confidence)
        self.deployment = deployment or os.getenv("AZURE_OPENAI_DECISIONS_DEPLOYMENT", "gpt-6-luna")
        if client is None:
            from openai import OpenAI

            endpoint = endpoint or os.getenv("AZURE_OPENAI_ENDPOINT", "")
            if not endpoint:
                raise ValueError("Set AZURE_OPENAI_ENDPOINT or pass endpoint=")
            client = OpenAI(
                base_url=_base_url(endpoint),
                api_key=api_key or os.getenv("AZURE_OPENAI_API_KEY") or self._entra_token_provider(),
                timeout=timeout,
                max_retries=max_retries,
                http_client=http_client,
            )
        self.client = client

    @staticmethod
    def _entra_token_provider() -> Callable[[], str]:
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider

        scope = os.getenv("AZURE_OPENAI_TOKEN_SCOPE", DEFAULT_SCOPE)
        return get_bearer_token_provider(DefaultAzureCredential(), scope)

    @staticmethod
    def build_questions(facts: Mapping[str, FactDef]) -> list[dict[str, Any]]:
        choices = [{"value": v, "description": d} for v, d in CHOICES.items()]
        return [
            {"type": "choice", "name": name, "instructions": build_instructions(fact), "choices": choices}
            for name, fact in facts.items()
        ]

    def _extract_batch(
        self, memo: str, facts: Mapping[str, FactDef]
    ) -> tuple[dict[str, RawAnswer], dict[str, Any]]:
        questions = self.build_questions(facts)
        raw_resp = self.client.decisions.with_raw_response.create(
            model=self.deployment, input=memo, questions=questions
        )
        decision = raw_resp.parse()

        raw: dict[str, RawAnswer] = {}
        for i, ans in enumerate(decision.answers or []):
            # Answers come back in question order; fall back to position if name is missing.
            name = getattr(ans, "name", None) or (questions[i]["name"] if i < len(questions) else None)
            if name not in facts:
                continue
            if ans.type == "refusal":
                raw[name] = RawAnswer(refused=True)
            elif ans.type == "choice":
                raw[name] = RawAnswer(
                    choice=str(ans.choice),
                    confidence=ans.confidence,
                    probabilities={str(p.value): float(p.probability) for p in (ans.probabilities or [])},
                )

        usage = getattr(decision, "usage", None)
        headers = raw_resp.headers
        meta = {
            "provider": "azure-openai",
            "model": getattr(decision, "model", self.deployment),
            "deployment": self.deployment,
            "request_id": headers.get("apim-request-id") or headers.get("x-request-id"),
            "usage": usage.model_dump() if hasattr(usage, "model_dump") else usage,
        }
        return raw, meta
