"""Fact extractor interface shared by all decision-model adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Mapping

from pydantic import BaseModel

from ..logic import Tri
from ..rules import FactDef

# Every fact is asked as a three-way choice so the model can say "not stated"
# instead of being forced into yes or no.
CHOICES: dict[str, str] = {
    "yes": "The memo explicitly states this is true, or states facts that make it true.",
    "no": "The memo explicitly states this is false, or states facts that make it false.",
    "not_stated": "The memo does not contain enough information to tell.",
}

GUIDANCE = (
    "Answer only from what the credit memo states. "
    "If the memo does not state it, answer not_stated. Do not assume or infer missing facts."
)

_CHOICE_TO_TRI = {"yes": Tri.TRUE, "no": Tri.FALSE, "not_stated": Tri.UNKNOWN}


def build_instructions(fact: FactDef) -> str:
    parts = [fact.question]
    if fact.hint:
        parts.append(fact.hint)
    parts.append(GUIDANCE)
    return " ".join(parts)


class RawAnswer(BaseModel):
    """What a provider returned for one question, before thresholding."""

    choice: str | None = None
    confidence: float | None = None
    probabilities: dict[str, float] | None = None
    refused: bool = False


class FactAnswer(BaseModel):
    """A fact after thresholding, as used by the rule engine."""

    value: Tri
    choice: str | None
    confidence: float | None
    probabilities: dict[str, float] | None = None
    refused: bool = False
    below_threshold: bool = False


class ExtractionResult(BaseModel):
    answers: dict[str, FactAnswer]
    meta: dict[str, Any] = {}


class FactExtractor(ABC):
    """Asks one question per fact and converts answers to TRUE / FALSE / UNKNOWN."""

    name: str = "base"
    max_questions_per_call: int = 64

    def __init__(self, min_confidence: float = 0.9) -> None:
        self.min_confidence = min_confidence

    def extract(self, memo: str, facts: Mapping[str, FactDef]) -> ExtractionResult:
        names = list(facts)
        raw: dict[str, RawAnswer] = {}
        calls: list[dict[str, Any]] = []
        for start in range(0, len(names), self.max_questions_per_call):
            batch = {n: facts[n] for n in names[start : start + self.max_questions_per_call]}
            batch_raw, batch_meta = self._extract_batch(memo, batch)
            raw.update(batch_raw)
            calls.append(batch_meta)

        answers = {n: self._to_answer(raw.get(n)) for n in names}
        return ExtractionResult(answers=answers, meta={"extractor": self.name, "calls": calls})

    def _to_answer(self, raw: RawAnswer | None) -> FactAnswer:
        if raw is None or raw.refused or raw.choice is None:
            return FactAnswer(
                value=Tri.UNKNOWN, choice=None, confidence=None, refused=bool(raw and raw.refused)
            )
        value = _CHOICE_TO_TRI.get(raw.choice, Tri.UNKNOWN)
        below = raw.confidence is not None and raw.confidence < self.min_confidence
        return FactAnswer(
            value=Tri.UNKNOWN if below else value,
            choice=raw.choice,
            confidence=raw.confidence,
            probabilities=raw.probabilities,
            below_threshold=below,
        )

    @abstractmethod
    def _extract_batch(
        self, memo: str, facts: Mapping[str, FactDef]
    ) -> tuple[dict[str, RawAnswer], dict[str, Any]]:
        """Return raw answers keyed by fact name, plus call metadata."""
