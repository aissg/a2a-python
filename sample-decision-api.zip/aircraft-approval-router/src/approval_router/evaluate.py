"""Evaluation harness over a labelled set of memos.

Dataset: JSONL, one case per line:
    {"id": "case-01",
     "memo": "...",                       or "memo_path": "examples/memos/x.txt"
     "expected_facts": {"pays_cash": "yes", ...},
     "expected_outcome": "ROUTED" | "NEEDS_INFO" | "ESCALATE",
     "expected_approver": "risk_officer_1" | null}

Metrics:
    fact_accuracy       share of facts where the thresholded answer matches the label
    outcome_accuracy    share of cases with the expected outcome
    routing_accuracy    share of cases with the expected outcome AND approver
    wrong_approver      cases routed to an approver other than the expected one
                        (the metric that matters most for a credit control)
    abstain_rate        share of facts that came back UNKNOWN when the label was yes/no

Extractor "oracle" feeds the labelled facts straight into the rule engine.
It tests the rules and labels, not the model.
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from .extractors import FactExtractor, FixtureExtractor
from .logic import Tri
from .router import route
from .rules import RuleSet

_LABEL = {"yes": Tri.TRUE, "no": Tri.FALSE, "not_stated": Tri.UNKNOWN}


def load_dataset(path: str | Path) -> list[dict[str, Any]]:
    base = Path(path).parent
    cases = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        case = json.loads(line)
        if "memo" not in case:
            memo_path = Path(case["memo_path"])
            if not memo_path.is_absolute() and not memo_path.exists():
                memo_path = base / memo_path
            case["memo"] = memo_path.read_text(encoding="utf-8")
        cases.append(case)
    return cases


def run_eval(
    cases: list[dict[str, Any]], ruleset: RuleSet, extractor: FactExtractor | None
) -> dict[str, Any]:
    per_fact: dict[str, list[int]] = defaultdict(lambda: [0, 0])
    abstain = [0, 0]
    outcome_ok = routing_ok = 0
    wrong_approver: list[str] = []
    details = []

    for case in cases:
        ext = extractor or FixtureExtractor(case["expected_facts"], ruleset.policy.min_confidence)
        res = route(case["memo"], ruleset, ext)

        for fact, label in case.get("expected_facts", {}).items():
            got = res.facts[fact].value if fact in res.facts else Tri.UNKNOWN
            want = _LABEL[label]
            per_fact[fact][0] += int(got == want)
            per_fact[fact][1] += 1
            if want != Tri.UNKNOWN:
                abstain[0] += int(got == Tri.UNKNOWN)
                abstain[1] += 1

        o_ok = res.outcome.value == case["expected_outcome"]
        r_ok = o_ok and res.approver == case.get("expected_approver")
        outcome_ok += o_ok
        routing_ok += r_ok
        if res.approver and res.approver != case.get("expected_approver"):
            wrong_approver.append(case["id"])
        details.append(
            {
                "id": case["id"],
                "expected": [case["expected_outcome"], case.get("expected_approver")],
                "got": [res.outcome.value, res.approver],
                "pass": r_ok,
            }
        )

    n = len(cases) or 1
    total_correct = sum(c for c, _ in per_fact.values())
    total_facts = sum(t for _, t in per_fact.values()) or 1
    return {
        "cases": len(cases),
        "fact_accuracy": round(total_correct / total_facts, 4),
        "fact_accuracy_by_fact": {f: round(c / t, 4) for f, (c, t) in per_fact.items()},
        "outcome_accuracy": round(outcome_ok / n, 4),
        "routing_accuracy": round(routing_ok / n, 4),
        "wrong_approver": wrong_approver,
        "abstain_rate": round(abstain[0] / (abstain[1] or 1), 4),
        "details": details,
    }


def log_to_mlflow(report: dict[str, Any], ruleset: RuleSet, extractor_name: str) -> None:
    import mlflow

    with mlflow.start_run(run_name=f"approval-router-eval-{extractor_name}"):
        mlflow.log_params(
            {
                "extractor": extractor_name,
                "ruleset_version": ruleset.version,
                "ruleset_sha": ruleset.sha,
                "min_confidence": ruleset.policy.min_confidence,
            }
        )
        for key in ("fact_accuracy", "outcome_accuracy", "routing_accuracy", "abstain_rate"):
            mlflow.log_metric(key, report[key])
        mlflow.log_metric("wrong_approver_count", len(report["wrong_approver"]))
        for fact, acc in report["fact_accuracy_by_fact"].items():
            mlflow.log_metric(f"fact_accuracy.{fact}", acc)
        mlflow.log_dict(report, "eval_report.json")
