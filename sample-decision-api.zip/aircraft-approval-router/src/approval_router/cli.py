"""Command line interface.

    approval-router validate --rules config/rules.json
    approval-router route    --memo examples/memos/01_needs_info.txt --extractor fixture \
                             --answers examples/answers/01_needs_info.json
    approval-router route    --memo memo.txt --extractor azure-openai
    approval-router eval     --dataset examples/eval_set.jsonl --extractor oracle
    approval-router serve    --port 8000
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from .audit import AuditLogger
from .evaluate import load_dataset, log_to_mlflow, run_eval
from .extractors import EXTRACTORS, make_extractor
from .router import route
from .rules import load_ruleset

DEFAULT_RULES = os.getenv("RULES_PATH", "config/rules.json")


def _extractor(args, ruleset):
    kwargs = {}
    if args.extractor == "fixture":
        if not args.answers:
            sys.exit("--answers is required with --extractor fixture")
        kwargs["answers_path"] = args.answers
    return make_extractor(args.extractor, ruleset.policy.min_confidence, **kwargs)


def cmd_validate(args) -> int:
    ruleset = load_ruleset(args.rules)
    print(f"OK  version={ruleset.version}  sha={ruleset.sha}")
    print(f"    {len(ruleset.facts)} facts, {len(ruleset.rules)} rules")
    for fact in ruleset.unused_facts():
        print(f"WARN fact '{fact}' is defined but not used by any rule")
    return 0


def cmd_route(args) -> int:
    ruleset = load_ruleset(args.rules)
    memo = Path(args.memo).read_text(encoding="utf-8") if args.memo != "-" else sys.stdin.read()
    result = route(memo, ruleset, _extractor(args, ruleset))
    if args.audit_log:
        AuditLogger(args.audit_log).write(result, memo=memo, case_id=args.case_id)

    if args.json:
        print(result.model_dump_json(indent=2))
    else:
        print(f"Outcome : {result.outcome.value}")
        print(f"Approver: {result.approver or '-'}")
        print(f"Reason  : {result.reason}")
        if result.missing_facts:
            print("Missing :")
            for m in result.missing_facts:
                print(f"  - {m.fact}: {m.question} (blocks {', '.join(m.blocks_rules)})")
        print("Facts   :")
        for name, ans in result.facts.items():
            conf = f"{ans.confidence:.2f}" if ans.confidence is not None else "-"
            flag = " (below threshold)" if ans.below_threshold else " (refused)" if ans.refused else ""
            print(f"  - {name:<26} {ans.value.value:<8} choice={ans.choice} conf={conf}{flag}")
    return 0 if result.outcome.value == "ROUTED" else 2


def cmd_eval(args) -> int:
    ruleset = load_ruleset(args.rules)
    cases = load_dataset(args.dataset)
    extractor = None if args.extractor == "oracle" else make_extractor(args.extractor, ruleset.policy.min_confidence)
    report = run_eval(cases, ruleset, extractor)
    if args.mlflow:
        log_to_mlflow(report, ruleset, args.extractor)
    print(json.dumps(report, indent=2))
    return 0 if not report["wrong_approver"] else 1


def cmd_serve(args) -> int:
    import uvicorn

    os.environ.setdefault("RULES_PATH", args.rules)
    uvicorn.run("approval_router.api:create_app", factory=True, host=args.host, port=args.port)
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="approval-router", description=__doc__.split("\n")[0])
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("--rules", default=DEFAULT_RULES, help="Path to rules.json")

    sp = sub.add_parser("validate", help="Validate a rule file")
    common(sp)
    sp.set_defaults(func=cmd_validate)

    sp = sub.add_parser("route", help="Route one credit memo")
    common(sp)
    sp.add_argument("--memo", required=True, help="Memo text file, or - for stdin")
    sp.add_argument("--extractor", default=os.getenv("ROUTER_EXTRACTOR", "azure-openai"),
                    choices=list(EXTRACTORS))
    sp.add_argument("--answers", help="Fixture answers JSON (extractor=fixture)")
    sp.add_argument("--audit-log", default=os.getenv("AUDIT_LOG"), help="Append result to this JSONL file")
    sp.add_argument("--case-id", help="Case reference stored in the audit log")
    sp.add_argument("--json", action="store_true", help="Print the full result as JSON")
    sp.set_defaults(func=cmd_route)

    sp = sub.add_parser("eval", help="Evaluate against a labelled dataset")
    common(sp)
    sp.add_argument("--dataset", required=True)
    sp.add_argument("--extractor", default="oracle",
                    choices=["oracle"] + [e for e in EXTRACTORS if e != "fixture"])
    sp.add_argument("--mlflow", action="store_true", help="Log metrics to MLflow")
    sp.set_defaults(func=cmd_eval)

    sp = sub.add_parser("serve", help="Run the REST API")
    common(sp)
    sp.add_argument("--host", default="0.0.0.0")
    sp.add_argument("--port", type=int, default=8000)
    sp.set_defaults(func=cmd_serve)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
