"""Rule set model, loading and validation."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .logic import leaf_facts


class FactDef(BaseModel):
    """One atomic question the decision model answers about the memo."""

    model_config = ConfigDict(extra="forbid")

    question: str = Field(min_length=5)
    hint: str | None = Field(
        default=None,
        description="Extra guidance for the model, e.g. how to treat edge cases.",
    )


class Rule(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str = Field(min_length=1)
    approver: str = Field(min_length=1)
    when: Any
    priority: int = Field(default=100, description="Lower number wins under on_conflict=priority.")
    description: str | None = None


class Policy(BaseModel):
    model_config = ConfigDict(extra="forbid")

    min_confidence: float = Field(default=0.9, ge=0.0, le=1.0)
    on_conflict: Literal["escalate", "priority"] = "escalate"
    on_no_match: Literal["escalate", "default"] = "escalate"
    default_approver: str | None = None
    wait_for_undecided: bool = Field(
        default=True,
        description=(
            "If a rule matched but another rule pointing to a different approver is still "
            "UNKNOWN, ask for the missing facts instead of routing."
        ),
    )

    @model_validator(mode="after")
    def _default_needs_approver(self) -> "Policy":
        if self.on_no_match == "default" and not self.default_approver:
            raise ValueError("policy.default_approver is required when on_no_match is 'default'")
        return self


class RuleSet(BaseModel):
    model_config = ConfigDict(extra="forbid")

    version: str = Field(min_length=1)
    facts: dict[str, FactDef]
    rules: list[Rule] = Field(min_length=1)
    policy: Policy = Field(default_factory=Policy)

    @model_validator(mode="before")
    @classmethod
    def _drop_schema_key(cls, value: Any) -> Any:
        if isinstance(value, dict) and "$schema" in value:
            value = {k: v for k, v in value.items() if k != "$schema"}
        return value

    @field_validator("facts", mode="before")
    @classmethod
    def _coerce_fact_strings(cls, value: Any) -> Any:
        if isinstance(value, dict):
            return {k: ({"question": v} if isinstance(v, str) else v) for k, v in value.items()}
        return value

    @model_validator(mode="after")
    def _check_references(self) -> "RuleSet":
        ids = [r.id for r in self.rules]
        dupes = {i for i in ids if ids.count(i) > 1}
        if dupes:
            raise ValueError(f"Duplicate rule ids: {sorted(dupes)}")
        for rule in self.rules:
            _check_node(rule.when, self.facts, f"rules[{rule.id}].when")
        return self

    @property
    def sha(self) -> str:
        """Short content hash, recorded in every audit entry."""
        payload = json.dumps(self.model_dump(mode="json"), sort_keys=True).encode()
        return hashlib.sha256(payload).hexdigest()[:12]

    def unused_facts(self) -> list[str]:
        used = {f for r in self.rules for f in leaf_facts(r.when)}
        return [f for f in self.facts if f not in used]


def _check_node(node: Any, facts: dict[str, FactDef], path: str) -> None:
    if isinstance(node, str):
        if node not in facts:
            raise ValueError(f"{path}: references undefined fact '{node}'")
        return
    if not isinstance(node, dict) or len(node) != 1:
        raise ValueError(f"{path}: a node must be a fact name or an object with one key: all, any or not")
    (op, arg), = node.items()
    if op in ("all", "any"):
        if not isinstance(arg, list) or not arg:
            raise ValueError(f"{path}.{op}: must be a non-empty list")
        for i, child in enumerate(arg):
            _check_node(child, facts, f"{path}.{op}[{i}]")
    elif op == "not":
        _check_node(arg, facts, f"{path}.not")
    else:
        raise ValueError(f"{path}: unknown operator '{op}' (use all, any or not)")


def load_ruleset(path: str | Path) -> RuleSet:
    return RuleSet.model_validate(json.loads(Path(path).read_text(encoding="utf-8")))
