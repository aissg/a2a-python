"""Three-valued (Kleene) logic for rule evaluation.

A fact the memo does not state is UNKNOWN. UNKNOWN propagates through the
gates unless the result is already decided:
    FALSE AND UNKNOWN = FALSE      TRUE OR UNKNOWN = TRUE
    TRUE  AND UNKNOWN = UNKNOWN    FALSE OR UNKNOWN = UNKNOWN
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Iterable, Mapping


class Tri(str, Enum):
    TRUE = "TRUE"
    FALSE = "FALSE"
    UNKNOWN = "UNKNOWN"


def all_of(values: Iterable[Tri]) -> Tri:
    values = list(values)
    if Tri.FALSE in values:
        return Tri.FALSE
    return Tri.UNKNOWN if Tri.UNKNOWN in values else Tri.TRUE


def any_of(values: Iterable[Tri]) -> Tri:
    values = list(values)
    if Tri.TRUE in values:
        return Tri.TRUE
    return Tri.UNKNOWN if Tri.UNKNOWN in values else Tri.FALSE


def not_(value: Tri) -> Tri:
    return {Tri.TRUE: Tri.FALSE, Tri.FALSE: Tri.TRUE}.get(value, Tri.UNKNOWN)


def evaluate(node: Any, facts: Mapping[str, Tri]) -> Tri:
    """Evaluate a rule node.

    A node is a fact name, {"all": [...]}, {"any": [...]} or {"not": node}.
    """
    if isinstance(node, str):
        return facts.get(node, Tri.UNKNOWN)
    if "all" in node:
        return all_of(evaluate(n, facts) for n in node["all"])
    if "any" in node:
        return any_of(evaluate(n, facts) for n in node["any"])
    if "not" in node:
        return not_(evaluate(node["not"], facts))
    raise ValueError(f"Unsupported rule node: {node!r}")


def leaf_facts(node: Any) -> list[str]:
    """Fact names referenced by a node, in order of first appearance."""
    if isinstance(node, str):
        return [node]
    if "not" in node:
        children = [node["not"]]
    else:
        children = node.get("all") or node.get("any") or []
    seen: list[str] = []
    for child in children:
        for name in leaf_facts(child):
            if name not in seen:
                seen.append(name)
    return seen
