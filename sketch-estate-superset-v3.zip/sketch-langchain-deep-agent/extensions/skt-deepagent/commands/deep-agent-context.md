---
name: "speckit.skt-deepagent.context"
description: "Compose the deep agent constitution layer and plan sections, before the plan command reads either."
compatibility: "Requires the skt-compose extension and python3 on PATH."
metadata:
  author: "sketch"
  source: "commands/deep-agent-context.md"
user-invocable: true
disable-model-invocation: false
---

# Deep agent plan context

Runs as a `before_plan` hook. The plan command waits for it, then runs
`setup-plan`, which copies `plan-template.md` into the feature folder and reads
`.specify/memory/constitution.md`. Both of those files are what this produces,
which is why it has to finish first.

Nothing here is interpretive. What gets composed is declared in
[`compose.yml`](../compose.yml), and the composing is done by `skt-compose`,
which ships in the sketch-base bundle every project already installs. This command
runs it and reports the result.

An alternative to running it here is `/speckit.skt-compose.compose`, which is the same
composer with the same arguments.

## Outline

1. **Run the composer** from the repository root. Use the variant matching this
   project's script type:

   ```bash
   SK=".specify/extensions/skt-compose"
   [ -d "$SK" ] || { echo "skt-compose is not installed; this work type is inert without it"; exit 1; }

   "$SK/scripts/bash/sketch-compose.sh" --json
   ```

   ```powershell
   $SK = ".specify/extensions/skt-compose"
   if (-not (Test-Path $SK)) { Write-Error "skt-compose is not installed; this work type is inert without it"; exit 1 }

   & "$SK/scripts/powershell/sketch-compose.ps1" -Json
   ```

   Where only one variant is present, run that one. Pass no `--extension` filter:
   the composer picks up every `compose.yml` in the project, so a second work type
   or a review overlay installed alongside this one contributes in the same pass
   rather than being overwritten.

2. **Parse the result** and report:
   - which extensions contributed
   - the constitution path, layer count and byte size
   - slots filled per template target
   - every entry in `notes` and `warnings`, verbatim

3. **On `ok: false`**, report the error exactly as returned and stop. Do not
   continue to the Outline of the plan command, and do not write either file by
   hand. A constitution assembled by an agent rather than by the composer is a
   ruleset nobody reviewed.

## What it produces

| File | Role |
|------|------|
| `.specify/memory/constitution.md` | Generated. Bank-wide base plus every installed layer |
| `.specify/memory/constitution.base.md` | The pristine base, captured on first run |
| `.specify/templates/plan-template.md` | Generated. The Sketch plan template with slots filled |
| `.specify/templates/plan-template.base.md` | The pristine template, slots empty |

The two `.base` files are why repeated plan runs cannot accumulate duplicated
sections: every run rebuilds from them rather than from its own previous output.

## Key rules

- Never edit the generated files. Edits belong in `constitution.d/` or `plan.d/`,
  and the target set is declared in `compose.yml`.
- Never edit the `.base` snapshots. They mirror what the presets installed.
- Report warnings rather than suppressing them. "No base constitution" means the
  project is running on this layer alone, without the bank-wide principles, and
  that must be visible in the plan run.
- Where slots filled is zero, say so. It means the stock Spec Kit plan template is
  in place rather than the Sketch one, so the governance and evaluation sections
  are absent from this plan.

## Done When

- [ ] Composer run and its JSON parsed
- [ ] Contributing extensions, layer count, slot counts, notes and warnings reported
- [ ] Any failure surfaced verbatim, with the plan run stopped
