# skt-deepagent

**Sketch Deep Agent** · Layer L3 · `status: alpha` · v0.2.0

The work-type extension for LangChain Deep Agent applications. One command,
invoked by a `before_plan` hook rather than by hand.

For the full explanation of the mechanism, see the
[bundle README](../../README.md). In short:

- `constitution.d/10-deep-agent.md` holds principles VII to XVI. The composer
  merges them with the bank-wide base into the single file the plan command reads,
  because Spec Kit resolves one file per name and never merges.
- `plan.d/*.md` hold the plan sections. The composer fills the `SKETCH-SLOT`
  markers in the Sketch plan template.
- Both run in a `before_plan` hook, which the plan command waits for before
  `setup-plan` copies the template. That ordering is what makes this work without
  forking anything.

## Contents

| Path | Role |
|------|------|
| `commands/deep-agent-context.md` | The hook command. Runs the composer, reports the result |
| `constitution.d/10-deep-agent.md` | Principles VII to XVI |
| `plan.d/10-governance.md` | Harness configuration, skills inventory, interrupt policy |
| `plan.d/20-evaluation.md` | Task-level and adversarial evaluation |
| `plan.d/30-bounds.md` | Bounds and subagents |
| `plan.d/40-structure.md` | Starting layout |
| `compose.yml` | What this work type contributes. The whole configuration |

There is no `scripts/` directory. Composition belongs to `skt-compose`, pinned by
the bundle. At 0.1.0 this extension carried about 700 lines of bash and PowerShell
that had to be kept behaviourally identical by hand; 0.2.0 replaced all of it with
a 40 line declaration.

## Run it by hand

Useful when diagnosing. The library composes every declaration in the project, so
this is the same thing the hook does:

```bash
.specify/extensions/skt-compose/scripts/bash/sketch-compose.sh
.specify/extensions/skt-compose/scripts/bash/sketch-compose.sh --check
.specify/extensions/skt-compose/scripts/bash/sketch-compose.sh --json
```

## Development

```bash
specify extension add --dev /path/to/skt-compose      # the library first
specify extension add --dev /path/to/skt-deepagent
python3 .specify/extensions/skt-compose/scripts/lib/selftest.py
```

The composer selftest lives with the library, and includes a case asserting this
extension's real `compose.yml` validates.
