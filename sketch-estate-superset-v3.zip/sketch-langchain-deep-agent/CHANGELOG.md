# Changelog

## 0.2.0

- Replaced the bundled bash and PowerShell composers with a `compose.yml`
  declaration read by `skt-compose`, pinned from `platform/sketch-shared`
- Removed `extensions/skt-deepagent/scripts/` entirely: about 700 lines of shell
  became a 40 line declaration
- Several work types can now be installed in one project. `skt-compose` applies
  every declaration in declared order, so they compose rather than overwrite one
  another. Two per-work-type hooks writing the same file meant last hook wins
- CI validates the declaration instead of the shell: every declared file exists,
  every shipped fragment is declared, no orphans, no `scripts/` directory

## 0.1.0

- First release of the LangChain Deep Agent work type
- `skt-deepagent` extension: `before_plan` hook composing the constitution and
  the plan template, bash and PowerShell variants
- Constitution layer: principles VII to XVI, covering harness, backend
  confinement, interrupts, durable state, skill versioning, bounds, tracing,
  injection, subagents and task-level evidence
- Four plan fragments: harness configuration and skills inventory, agent
  evaluation, bounds and subagents, starting layout
- Selftest covering idempotency across repeated runs, principle ordering, and
  the degraded paths where the base constitution or the Sketch plan template is
  absent
