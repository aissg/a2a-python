# skt-compose

**Sketch Compose** · Layer LX · `status: alpha` · v0.1.0

Declarative composition for the plan phase. A work-type extension ships a
`compose.yml` and its markdown. It writes no shell.

Ships from this repository alongside the `sketch` extension and both presets, so
it costs no extra repository, pipeline, catalog entry beyond one component, or
install step for anyone.

## Why this exists

Spec Kit resolves **one file per name and never merges**. It walks the priority
stack, takes the first match, and stops.

So a work type cannot add constitution principles or plan sections through a
second preset: it would replace the first rather than layer onto it. And copying
the bank-wide constitution into each work type means the same control exists in
triplicate and drifts within a year.

The composition therefore has to happen in a `before_plan` hook, which the plan
command waits for before `setup-plan` reads the constitution or copies the
template. This is that composition, done by declaration.

## Why a separate extension rather than part of sketch

Folding it into the `sketch` extension would bump that extension to 0.4.0, and
**ten division bundles pin `sketch` 0.3.0 exactly**. Those fragments are owned by
division leads, so it would mean ten merge requests across teams for a change none
of them asked for. The catalog validator catches this, which is how it was found.

A separate extension in the same repository costs one component and one catalog
entry, and breaks nothing.

## What a work type ships

```
skt-<worktype>/
├── extension.yml           registers a before_plan hook, requires skt-compose
├── compose.yml             what it contributes
├── commands/context.md     thin: run the composer, report the result
├── constitution.d/*.md     the principles
└── plan.d/*.md             the plan sections
```

No scripts directory. Before this existed, the same work type carried about 700
lines of bash and PowerShell that had to be kept behaviourally identical by hand.

## compose.yml

```yaml
schema_version: "1.0"

compose:
  id: skt-deepagent
  order: 50

constitution:
  layers:
    - constitution.d/10-deep-agent.md
  insert_before: '^##\s+Governance\s*$'

templates:
  - target: .specify/templates/plan-template.md
    slots:
      governance: [plan.d/10-governance.md]
      evaluation: [plan.d/20-evaluation.md]
      technical-context: [plan.d/30-bounds.md]
      structure: [plan.d/40-structure.md]
```

Full contract in [`compose.schema.yml`](compose.schema.yml).

`insert_before` is the one non-obvious field. Layers land immediately above the
first match rather than at the end of the file, which keeps a trailing section
such as `## Governance` at the bottom. Without it, principle numbering reads I to
VI, Governance, VII to XVI.

`order` decides sequence when several extensions contribute to one target. Ties
break by id, so the output is stable rather than dependent on directory listing
order.

## Four guarantees

**Idempotent.** Every run rebuilds each target from a pristine `.base` snapshot
taken before anything was written. The hook fires on every plan run, so naive
appending would compound; instead a hundred runs give the same bytes as one.

**Additive across extensions.** Several extensions may contribute to one target,
including to the same slot. Layers apply in declared order, each in its own marker
block. **A per-work-type shell script cannot do this**, and it is the main reason
this is a library: with one script each, two work types installed together means
two hooks writing the same file and last hook wins, silently.

**Confined.** Paths resolve against the declaring extension's own directory. A
declaration reaching outside it is rejected, so one work type's output cannot
depend on another's install path.

**Fail early.** Every declared file is checked before anything is written. A
missing fragment fails with the path rather than half way through composing.

## Use it

```bash
scripts/bash/sketch-compose.sh                      # compose everything installed
scripts/bash/sketch-compose.sh --check              # report, write nothing
scripts/bash/sketch-compose.sh --json               # machine-readable
scripts/bash/sketch-compose.sh --extension skt-foo  # just one declaration
```

Or as a library, which is how a CI conformance check would use it:

```python
from sketch_compose import compose, discover
result = compose(discover(repo_root), repo_root, check=True)
for w in result["warnings"]:
    print(w)
```

The bash and PowerShell entry points are short wrappers around the same Python
file, so they cannot drift in behaviour. That was a real risk with the
hand-written pair they replace.

## Output

```
sketch-compose: 2 extension(s): skt-alpha, skt-beta
sketch-compose: constitution 2 layer(s) from skt-alpha, skt-beta -> /p/.specify/memory/constitution.md (11204 bytes)
sketch-compose: /p/.specify/templates/plan-template.md slots filled: 4
```

JSON adds per-target `contributors` and `slots_missing`, and the constitution's
`inserted_before_match`, so a caller can tell an `insert_before` that matched from
one that silently fell through to appending.

## Warnings worth reading

| Warning | Means |
|---------|-------|
| no base constitution content | The project is gated on work-type layers alone, without the bank-wide principles |
| no SKETCH-SLOT markers | The stock Spec Kit template is installed, so the governance and evaluation sections are absent from the plan |
| slot X declared but no marker found | The template preset is older than the work type, or the slot name is a typo |

None of these fail the run. All three change what the plan is gated against, so
the hook command reports them verbatim.

## Development

```bash
python3 scripts/lib/selftest.py
# passed 54, failed 0
```

The selftest builds synthetic work types in a temporary directory, so it needs only
`python3` and `pyyaml` and touches nothing else. It covers the single and
multi-extension paths, idempotency across four runs in both, snapshot recovery,
both degraded paths, a declared slot with no marker, check mode, four validation
failures including directory escape, the CLI, and the shipped `skt-deepagent`
declaration.
