# sketch-compose: compose layered constitutions and slot-filled templates.
#
# Thin wrapper. The work is in scripts/lib/sketch_compose.py, so the bash and
# PowerShell entry points cannot drift in behaviour.
#
# Called by a work-type extension's before_plan hook, not usually by hand.
$ErrorActionPreference = 'Stop'

$extRoot = Split-Path -Parent $PSScriptRoot
$lib = Join-Path $extRoot 'scripts/lib/sketch_compose.py'
if (-not (Test-Path -LiteralPath $lib)) {
    Write-Error "Reference asset missing: scripts/lib/sketch_compose.py"
    exit 6
}
& python3 $lib @args
exit $LASTEXITCODE
