#!/usr/bin/env bash
# sketch-compose: compose layered constitutions and slot-filled templates.
#
# Thin wrapper. The work is in scripts/lib/sketch_compose.py, so the bash and
# PowerShell entry points cannot drift in behaviour.
#
# Called by a work-type extension's before_plan hook, not usually by hand.
set -euo pipefail

EXT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
LIB="$EXT_ROOT/scripts/lib/sketch_compose.py"
[[ -r "$LIB" ]] || { echo "Reference asset missing: scripts/lib/sketch_compose.py" >&2; exit 6; }

exec python3 "$LIB" "$@"
