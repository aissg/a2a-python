#!/usr/bin/env python3
"""
sketch_compose: compose layered constitutions and slot-filled templates.

Spec Kit resolves one file per name and never merges. A work type that needs to
add constitution principles or plan sections therefore cannot ship a second
preset: it would replace the first rather than layer onto it. The composition has
to happen in a before_plan hook instead, which the plan command waits for before
setup-plan reads either file.

This library is that composition, driven by declaration rather than by code. A
work-type extension ships a compose.yml and its markdown. It writes no shell.

Importable:

    from sketch_compose import compose, discover
    result = compose(discover("/path/to/repo"), repo_root="/path/to/repo")

Or as a command:

    sketch_compose.py [--repo-root PATH] [--extension ID] [--json] [--check]

Two properties the callers depend on:

Idempotent. Every run rebuilds each target from a pristine .base snapshot taken
before anything was written, so repeated plan runs cannot accumulate duplicated
sections. Running it a hundred times gives the same bytes as running it once.

Additive across extensions. Several extensions may contribute to the same target.
Their layers are applied in declared order, so two work types installed together
compose rather than overwrite one another. A single-extension shell script cannot
do this, which is the main reason this exists as a library.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    print("ERROR: pyyaml is required. pip install pyyaml", file=sys.stderr)
    sys.exit(2)

SCHEMA_VERSION = "1.0"

SLOT_MARKER = "<!-- SKETCH-SLOT: {slot} -->"
LAYER_BEGIN = "<!-- SKETCH-LAYER-BEGIN: {id} -->"
LAYER_END = "<!-- SKETCH-LAYER-END: {id} -->"

# Any marker from any extension, used when recovering a lost snapshot.
ANY_BEGIN = re.compile(r"<!--\s*SKETCH-LAYER-BEGIN:\s*[^>]*?-->")
ANY_END = re.compile(r"<!--\s*SKETCH-LAYER-END:\s*[^>]*?-->")

DEFAULT_ORDER = 50


class ComposeError(Exception):
    """A declaration is malformed, or a declared file is missing."""


@dataclass
class Declaration:
    """One extension's compose.yml, resolved against its own directory."""

    id: str
    order: int
    ext_dir: Path
    source: Path
    constitution: dict = field(default_factory=dict)
    templates: list = field(default_factory=list)

    def resolve(self, rel: str) -> Path:
        """Paths in compose.yml are relative to the extension directory.

        An extension may only read its own files. A declaration reaching outside
        its directory is rejected: it would make one work type's output depend on
        another's install path, and the failure would appear only in the
        combination.
        """
        p = (self.ext_dir / rel).resolve()
        try:
            p.relative_to(self.ext_dir.resolve())
        except ValueError:
            raise ComposeError(
                f"{self.source}: {rel!r} escapes the extension directory"
            )
        return p


def _require(d: dict, key: str, where: str):
    if key not in d:
        raise ComposeError(f"{where}: missing required key {key!r}")
    return d[key]


def load_declaration(path: Path) -> Declaration:
    """Read and validate one compose.yml."""
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as e:
        raise ComposeError(f"{path}: invalid YAML: {e}")

    version = str(raw.get("schema_version", ""))
    if version != SCHEMA_VERSION:
        raise ComposeError(
            f"{path}: schema_version is {version!r}, this library speaks {SCHEMA_VERSION!r}"
        )

    block = _require(raw, "compose", str(path))
    cid = _require(block, "id", f"{path} compose")
    if not re.fullmatch(r"[a-z][a-z0-9-]*", str(cid)):
        raise ComposeError(f"{path}: compose.id {cid!r} must be lowercase alphanumeric and hyphens")

    order = block.get("order", DEFAULT_ORDER)
    if not isinstance(order, int):
        raise ComposeError(f"{path}: compose.order must be an integer")

    decl = Declaration(
        id=str(cid),
        order=order,
        ext_dir=path.parent,
        source=path,
        constitution=raw.get("constitution") or {},
        templates=raw.get("templates") or [],
    )

    # Fail on a missing file here rather than half way through writing.
    if decl.constitution:
        layers = decl.constitution.get("layers") or []
        if not layers:
            raise ComposeError(f"{path}: constitution declared with no layers")
        for rel in layers:
            if not decl.resolve(rel).is_file():
                raise ComposeError(f"{path}: constitution layer {rel!r} not found")

    for i, t in enumerate(decl.templates):
        _require(t, "target", f"{path} templates[{i}]")
        slots = t.get("slots") or {}
        if not slots:
            raise ComposeError(f"{path}: templates[{i}] declares no slots")
        for slot, files in slots.items():
            if isinstance(files, str):
                files = [files]
            for rel in files:
                if not decl.resolve(rel).is_file():
                    raise ComposeError(f"{path}: slot {slot!r} fragment {rel!r} not found")

    return decl


def discover(repo_root: str | Path, extension: str | None = None) -> list[Declaration]:
    """Find every compose.yml under .specify/extensions/, in declared order.

    Ties on order are broken by id, so the result is stable rather than dependent
    on directory listing order. A composition whose output changes between runs on
    the same inputs is not reviewable.
    """
    root = Path(repo_root)
    found = []
    ext_root = root / ".specify" / "extensions"
    if ext_root.is_dir():
        for cfg in sorted(ext_root.glob("*/compose.yml")):
            decl = load_declaration(cfg)
            if extension and decl.id != extension:
                continue
            found.append(decl)
    return sorted(found, key=lambda d: (d.order, d.id))


def _strip_own_layers(text: str) -> str:
    """Remove every SKETCH-LAYER block, whichever extension wrote it.

    Used only to recover a lost .base snapshot. Taking a merged file as the new
    base is the one failure that compounds silently: every later run would layer
    onto an already-layered file.
    """
    while True:
        b = ANY_BEGIN.search(text)
        if not b:
            break
        e = ANY_END.search(text, b.end())
        if not e:
            break
        text = text[: b.start()] + text[e.end() :]
    return text.rstrip() + "\n"


def _snapshot(target: Path, base: Path, check: bool, notes: list, warnings: list) -> str:
    """Return the pristine content for a target, capturing a snapshot if needed."""
    if base.is_file():
        return base.read_text(encoding="utf-8")

    if not target.is_file():
        warnings.append(f"{target} not found; nothing to compose onto")
        if not check:
            base.parent.mkdir(parents=True, exist_ok=True)
            base.write_text("", encoding="utf-8")
        return ""

    current = target.read_text(encoding="utf-8")
    if ANY_BEGIN.search(current):
        recovered = _strip_own_layers(current)
        notes.append(f"recovered {base.name} from a previously composed file")
        if not check:
            base.write_text(recovered, encoding="utf-8")
        return recovered

    notes.append(f"captured {base.name} from the installed file")
    if not check:
        base.write_text(current, encoding="utf-8")
    return current


def _base_path(target: Path) -> Path:
    """foo.md -> foo.base.md"""
    return target.with_suffix(".base" + target.suffix)


def _block(cid: str, body: str) -> str:
    return (
        LAYER_BEGIN.format(id=cid)
        + "\n\n<!-- Generated by sketch-compose. Do not edit here.\n"
        + f"     Source: .specify/extensions/{cid}/ -->\n\n"
        + body.rstrip()
        + "\n\n"
        + LAYER_END.format(id=cid)
    )


def _compose_constitution(decls, repo_root: Path, check: bool, notes, warnings) -> dict | None:
    """Append each extension's layers to the base constitution, in order."""
    contributors = [d for d in decls if d.constitution]
    if not contributors:
        return None

    targets = {d.constitution.get("target", ".specify/memory/constitution.md") for d in contributors}
    if len(targets) > 1:
        raise ComposeError(f"extensions disagree on the constitution target: {sorted(targets)}")
    target = repo_root / targets.pop()
    base = _base_path(target)

    text = _snapshot(target, base, check, notes, warnings)
    if not text.strip():
        warnings.append(
            "no base constitution content; the layers will stand alone. Install the "
            "bundle that provides the bank-wide constitution."
        )

    # insert_before lets a layer land above a trailing section such as
    # Governance, so principle numbering stays contiguous and the amendment
    # procedure stays at the end. First contributor declaring one wins.
    pattern = next(
        (d.constitution["insert_before"] for d in contributors if d.constitution.get("insert_before")),
        None,
    )

    blocks = []
    for d in contributors:
        layers = d.constitution["layers"]
        body = "\n\n".join(d.resolve(rel).read_text(encoding="utf-8").rstrip() for rel in layers)
        blocks.append(_block(d.id, body))
    joined = "\n\n".join(blocks)

    if pattern:
        m = re.search(pattern, text, re.MULTILINE)
        if m:
            merged = text[: m.start()].rstrip() + "\n\n" + joined + "\n\n" + text[m.start() :]
        else:
            merged = text.rstrip() + "\n\n" + joined + "\n"
    else:
        merged = text.rstrip() + "\n\n" + joined + "\n"

    if not check:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(merged, encoding="utf-8")

    return {
        "path": str(target),
        "contributors": [d.id for d in contributors],
        "layers": sum(len(d.constitution["layers"]) for d in contributors),
        "bytes": len(merged.encode("utf-8")),
        "inserted_before_match": bool(pattern and re.search(pattern, text, re.MULTILINE)),
    }


def _compose_templates(decls, repo_root: Path, check: bool, notes, warnings) -> list:
    """Fill SKETCH-SLOT markers, gathering every extension's fragments per slot."""
    by_target: dict[str, list] = {}
    for d in decls:
        for t in d.templates:
            by_target.setdefault(t["target"], []).append((d, t))

    results = []
    for rel_target, entries in sorted(by_target.items()):
        target = repo_root / rel_target
        base = _base_path(target)
        text = _snapshot(target, base, check, notes, warnings)

        if not text.strip():
            results.append({"path": str(target), "slots_filled": 0, "contributors": []})
            continue

        if "SKETCH-SLOT" not in text:
            warnings.append(
                f"{base.name} carries no SKETCH-SLOT markers, so nothing was injected. "
                "Install the preset that provides the slotted template, or the stock "
                "template is in place."
            )
            if not check:
                target.write_text(text, encoding="utf-8")
            results.append({"path": str(target), "slots_filled": 0, "contributors": []})
            continue

        # Collect per slot across extensions first, so a slot several work types
        # contribute to gets one block per extension in declared order rather
        # than whichever ran last.
        per_slot: dict[str, list] = {}
        for d, t in entries:
            slots = t.get("slots") or {}
            for slot, files in slots.items():
                if isinstance(files, str):
                    files = [files]
                body = "\n\n".join(
                    d.resolve(rel).read_text(encoding="utf-8").rstrip() for rel in files
                )
                per_slot.setdefault(slot, []).append(_block(d.id, body))

        filled = 0
        unknown = []
        for slot, blocks in per_slot.items():
            marker = SLOT_MARKER.format(slot=slot)
            if marker not in text:
                unknown.append(slot)
                continue
            # The marker is kept after the injected content, so the next run's
            # base still has a slot to fill and a reader can see where the
            # boundary is.
            text = text.replace(marker, "\n\n".join(blocks) + "\n\n" + marker)
            filled += 1

        for slot in unknown:
            warnings.append(
                f"slot {slot!r} declared but no marker found in {base.name}; nothing injected"
            )

        if not check:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text, encoding="utf-8")

        results.append(
            {
                "path": str(target),
                "slots_filled": filled,
                "slots_missing": unknown,
                "contributors": sorted({d.id for d, _ in entries}),
            }
        )
    return results


def compose(declarations, repo_root: str | Path, check: bool = False) -> dict:
    """Compose every declared target. Returns a JSON-serialisable result."""
    root = Path(repo_root)
    notes: list = []
    warnings: list = []

    if not declarations:
        return {
            "ok": True,
            "check_only": check,
            "constitution": None,
            "templates": [],
            "notes": [],
            "warnings": ["no compose.yml found under .specify/extensions/; nothing to do"],
        }

    ids = [d.id for d in declarations]
    if len(ids) != len(set(ids)):
        raise ComposeError(f"two declarations share an id: {ids}")

    constitution = _compose_constitution(declarations, root, check, notes, warnings)
    templates = _compose_templates(declarations, root, check, notes, warnings)

    return {
        "ok": True,
        "check_only": check,
        "extensions": ids,
        "constitution": constitution,
        "templates": templates,
        "notes": notes,
        "warnings": warnings,
    }


def _repo_root(explicit: str | None) -> Path:
    if explicit:
        return Path(explicit)
    import subprocess

    try:
        out = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=10,
        )
        if out.returncode == 0 and out.stdout.strip():
            return Path(out.stdout.strip())
    except (OSError, subprocess.SubprocessError):
        pass
    return Path.cwd()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Compose layered constitutions and slot-filled templates from compose.yml declarations."
    )
    ap.add_argument("--repo-root", help="project root; defaults to the git toplevel, then cwd")
    ap.add_argument("--extension", help="compose only this extension id")
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    ap.add_argument("--check", action="store_true", help="report what would change, write nothing")
    args = ap.parse_args(argv)

    root = _repo_root(args.repo_root)

    try:
        decls = discover(root, args.extension)
        result = compose(decls, root, check=args.check)
    except ComposeError as e:
        if args.json:
            print(json.dumps({"ok": False, "error": str(e)}))
        else:
            print(f"sketch-compose: ERROR {e}", file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps(result))
        return 0

    if not result.get("extensions"):
        print("sketch-compose: nothing to compose")
    else:
        print(f"sketch-compose: {len(result['extensions'])} extension(s): {', '.join(result['extensions'])}")
    c = result.get("constitution")
    if c:
        print(f"sketch-compose: constitution {c['layers']} layer(s) from {', '.join(c['contributors'])} -> {c['path']} ({c['bytes']} bytes)")
    for t in result.get("templates", []):
        print(f"sketch-compose: {t['path']} slots filled: {t['slots_filled']}")
    for n in result.get("notes", []):
        print(f"sketch-compose: note {n}")
    for w in result.get("warnings", []):
        print(f"sketch-compose: WARNING {w}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
