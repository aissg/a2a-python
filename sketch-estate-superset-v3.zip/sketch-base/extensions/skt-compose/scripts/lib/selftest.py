#!/usr/bin/env python3
"""
Selftest for sketch_compose. Builds throwaway projects and asserts what the
library produces.

Run:  python3 extensions/skt-compose/scripts/lib/selftest.py
Exits non-zero on the first failure.
"""

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from sketch_compose import ComposeError, compose, discover, load_declaration  # noqa: E402

PASS = 0
FAIL = 0


def ok(msg):
    global PASS
    PASS += 1
    print(f"  ok    {msg}")


def bad(msg):
    global FAIL
    FAIL += 1
    print(f"  FAIL  {msg}")


def check(msg, cond):
    ok(msg) if cond else bad(msg)


BASE_CONSTITUTION = """# Engineering constitution

## I. Specification before implementation

Body.

## VI. Regulated work carries its evidence

Body.

## Governance

Amendment procedure.
"""

SLOTTED_TEMPLATE = """# Implementation Plan

## Governance Context

**AI classification**: [value]

<!-- SKETCH-SLOT: governance -->

## Evaluation Design

<!-- SKETCH-SLOT: evaluation -->

## Technical Context

<!-- SKETCH-SLOT: technical-context -->

## Project Structure

<!-- SKETCH-SLOT: structure -->

## Spec Coverage

<!-- SKETCH-SLOT: coverage -->
"""

STOCK_TEMPLATE = "# Implementation Plan\n\n## Technical Context\n\n**Language**: [value]\n"


def make_project(root: Path, base_constitution=True, template="slotted"):
    (root / ".specify/memory").mkdir(parents=True, exist_ok=True)
    (root / ".specify/templates").mkdir(parents=True, exist_ok=True)
    if base_constitution:
        (root / ".specify/memory/constitution.md").write_text(BASE_CONSTITUTION)
    if template == "slotted":
        (root / ".specify/templates/plan-template.md").write_text(SLOTTED_TEMPLATE)
    elif template == "stock":
        (root / ".specify/templates/plan-template.md").write_text(STOCK_TEMPLATE)


def add_extension(root: Path, ext_id, order, principle_title, slot_map, insert_before=None):
    """Install a synthetic work-type extension: compose.yml plus its markdown."""
    d = root / ".specify/extensions" / ext_id
    (d / "constitution.d").mkdir(parents=True, exist_ok=True)
    (d / "plan.d").mkdir(parents=True, exist_ok=True)
    (d / "constitution.d/10-layer.md").write_text(f"## {principle_title}\n\nBody for {ext_id}.\n")

    slots = {}
    for slot in slot_map:
        (d / f"plan.d/{slot}.md").write_text(f"### {slot} section from {ext_id}\n\nBody.\n")
        slots[slot] = [f"plan.d/{slot}.md"]

    cfg = {
        "schema_version": "1.0",
        "compose": {"id": ext_id, "order": order},
        "constitution": {"layers": ["constitution.d/10-layer.md"]},
        "templates": [{"target": ".specify/templates/plan-template.md", "slots": slots}],
    }
    if insert_before:
        cfg["constitution"]["insert_before"] = insert_before

    import yaml

    (d / "compose.yml").write_text(yaml.safe_dump(cfg, sort_keys=False))
    return d


def main():
    work = Path(tempfile.mkdtemp())
    try:
        # ------------------------------------------------------- 1. single extension
        print("1. one extension, the ordinary case")
        p = work / "single"
        make_project(p)
        add_extension(p, "skt-alpha", 50, "VII. Alpha principle",
                      ["governance", "evaluation"], insert_before=r"^##\s+Governance\s*$")

        r = compose(discover(p), p)
        c = p / ".specify/memory/constitution.md"
        t = p / ".specify/templates/plan-template.md"

        check("returns ok", r["ok"])
        check("one contributor reported", r["constitution"]["contributors"] == ["skt-alpha"])
        check("base snapshot captured", (p / ".specify/memory/constitution.base.md").is_file())
        check("template snapshot captured", (p / ".specify/templates/plan-template.base.md").is_file())
        check("two slots filled", r["templates"][0]["slots_filled"] == 2)
        check("base principle survives", "I. Specification before implementation" in c.read_text())
        check("layer principle present", "VII. Alpha principle" in c.read_text())
        heads = [ln for ln in c.read_text().splitlines() if ln.startswith("## ")]
        check("Governance stays last", heads[-1].strip() == "## Governance")
        check("insert_before matched", r["constitution"]["inserted_before_match"])
        check("governance fragment injected", "governance section from skt-alpha" in t.read_text())
        check("unmapped slot left intact", "SKETCH-SLOT: coverage" in t.read_text())

        # ---------------------------------------------------------- 2. idempotency
        print("\n2. idempotency across repeated plan runs")
        size1, tsize1 = c.stat().st_size, t.stat().st_size
        for _ in range(3):
            compose(discover(p), p)
        check("constitution byte size unchanged after 4 runs", c.stat().st_size == size1)
        check("template byte size unchanged after 4 runs", t.stat().st_size == tsize1)
        check("exactly one BEGIN marker in constitution",
              c.read_text().count("SKETCH-LAYER-BEGIN") == 1)
        check("principle appears exactly once",
              c.read_text().count("VII. Alpha principle") == 1)
        check("fragment appears exactly once in template",
              t.read_text().count("governance section from skt-alpha") == 1)

        # ------------------------------------- 3. two extensions compose, not clobber
        print("\n3. two work types installed together, the case a single script cannot do")
        p2 = work / "two"
        make_project(p2)
        add_extension(p2, "skt-beta", 60, "VIII. Beta principle",
                      ["governance", "structure"])
        add_extension(p2, "skt-alpha", 50, "VII. Alpha principle",
                      ["governance", "evaluation"], insert_before=r"^##\s+Governance\s*$")

        r2 = compose(discover(p2), p2)
        c2 = (p2 / ".specify/memory/constitution.md").read_text()
        t2 = (p2 / ".specify/templates/plan-template.md").read_text()

        check("both extensions discovered", r2["extensions"] == ["skt-alpha", "skt-beta"])
        check("both principles present", "VII. Alpha" in c2 and "VIII. Beta" in c2)
        check("order respected: alpha before beta", c2.index("VII. Alpha") < c2.index("VIII. Beta"))
        check("one marker block per extension", c2.count("SKETCH-LAYER-BEGIN") == 2)
        check("both contributed to the shared governance slot",
              "governance section from skt-alpha" in t2 and "governance section from skt-beta" in t2)
        check("shared slot keeps declared order",
              t2.index("from skt-alpha") < t2.index("from skt-beta"))
        check("slots union counted", r2["templates"][0]["slots_filled"] == 3)
        check("both listed as template contributors",
              r2["templates"][0]["contributors"] == ["skt-alpha", "skt-beta"])

        # Idempotent with two extensions too, which is the harder case.
        s = len(c2)
        compose(discover(p2), p2)
        compose(discover(p2), p2)
        check("two-extension merge idempotent",
              len((p2 / ".specify/memory/constitution.md").read_text()) == s)

        # ------------------------------------------------------ 4. filter one extension
        print("\n4. composing a single extension by id")
        p3 = work / "filtered"
        make_project(p3)
        add_extension(p3, "skt-alpha", 50, "VII. Alpha principle", ["governance"])
        add_extension(p3, "skt-beta", 60, "VIII. Beta principle", ["structure"])
        r3 = compose(discover(p3, extension="skt-alpha"), p3)
        c3 = (p3 / ".specify/memory/constitution.md").read_text()
        check("only the named extension applied", r3["extensions"] == ["skt-alpha"])
        check("other extension absent", "VIII. Beta" not in c3)

        # ------------------------------------------------------- 5. snapshot recovery
        print("\n5. recovery when a base snapshot is lost")
        (p / ".specify/memory/constitution.base.md").unlink()
        r4 = compose(discover(p), p)
        c4 = c.read_text()
        check("recovery reported", any("recovered" in n for n in r4["notes"]))
        check("base principle survives recovery", "I. Specification before implementation" in c4)
        check("layer not duplicated by recovery", c4.count("VII. Alpha principle") == 1)
        check("size stable after recovery", c.stat().st_size == size1)

        # ----------------------------------------------------------- 6. degraded paths
        print("\n6. degraded, no base constitution installed")
        p5 = work / "nobase"
        make_project(p5, base_constitution=False)
        add_extension(p5, "skt-alpha", 50, "VII. Alpha principle", ["governance"])
        r5 = compose(discover(p5), p5)
        check("warns the base is missing", any("stand alone" in w for w in r5["warnings"]))
        check("layer still written", "VII. Alpha principle" in (p5 / ".specify/memory/constitution.md").read_text())

        print("\n7. degraded, stock template with no slot markers")
        p6 = work / "stock"
        make_project(p6, template="stock")
        add_extension(p6, "skt-alpha", 50, "VII. Alpha principle", ["governance"])
        r6 = compose(discover(p6), p6)
        check("warns no markers found", any("no SKETCH-SLOT markers" in w for w in r6["warnings"]))
        check("zero slots filled", r6["templates"][0]["slots_filled"] == 0)
        check("constitution still merged", "VII. Alpha" in (p6 / ".specify/memory/constitution.md").read_text())

        print("\n8. declared slot with no matching marker")
        p7 = work / "badslot"
        make_project(p7)
        add_extension(p7, "skt-alpha", 50, "VII. Alpha principle", ["governance", "nonexistent-slot"])
        r7 = compose(discover(p7), p7)
        check("warns about the missing slot", any("nonexistent-slot" in w for w in r7["warnings"]))
        check("the valid slot still filled", r7["templates"][0]["slots_filled"] == 1)
        check("missing slot reported in the result",
              r7["templates"][0]["slots_missing"] == ["nonexistent-slot"])

        # ---------------------------------------------------------------- 9. check mode
        print("\n9. check mode writes nothing")
        p8 = work / "checkonly"
        make_project(p8)
        add_extension(p8, "skt-alpha", 50, "VII. Alpha principle", ["governance"])
        before = (p8 / ".specify/templates/plan-template.md").read_bytes()
        compose(discover(p8), p8, check=True)
        after = (p8 / ".specify/templates/plan-template.md").read_bytes()
        check("template untouched", before == after)
        check("no snapshot written", not (p8 / ".specify/templates/plan-template.base.md").is_file())

        # ------------------------------------------------------- 10. validation errors
        print("\n10. malformed declarations fail early with the path")
        d = p8 / ".specify/extensions/skt-broken"
        d.mkdir(parents=True)

        (d / "compose.yml").write_text('schema_version: "9.9"\ncompose:\n  id: skt-broken\n')
        try:
            load_declaration(d / "compose.yml")
            bad("wrong schema_version rejected")
        except ComposeError as e:
            check("wrong schema_version rejected", "schema_version" in str(e))

        (d / "compose.yml").write_text('schema_version: "1.0"\ncompose: {}\n')
        try:
            load_declaration(d / "compose.yml")
            bad("missing id rejected")
        except ComposeError as e:
            check("missing id rejected", "id" in str(e))

        (d / "compose.yml").write_text(
            'schema_version: "1.0"\ncompose:\n  id: skt-broken\n'
            'constitution:\n  layers: [does-not-exist.md]\n'
        )
        try:
            load_declaration(d / "compose.yml")
            bad("missing layer file rejected before writing")
        except ComposeError as e:
            check("missing layer file rejected before writing", "not found" in str(e))

        (d / "compose.yml").write_text(
            'schema_version: "1.0"\ncompose:\n  id: skt-broken\n'
            'constitution:\n  layers: ["../../../etc/passwd"]\n'
        )
        try:
            load_declaration(d / "compose.yml")
            bad("path escaping the extension directory rejected")
        except ComposeError as e:
            check("path escaping the extension directory rejected", "escapes" in str(e))

        shutil.rmtree(d)

        # --------------------------------------------------------------- 11. CLI
        print("\n11. command line interface")
        lib = HERE / "sketch_compose.py"
        out = subprocess.run(
            [sys.executable, str(lib), "--repo-root", str(p), "--json"],
            capture_output=True, text=True,
        )
        check("cli exits zero", out.returncode == 0)
        try:
            payload = json.loads(out.stdout)
            check("cli emits valid json", payload["ok"] is True)
            check("cli reports the contributor", payload["extensions"] == ["skt-alpha"])
        except (json.JSONDecodeError, KeyError) as e:
            bad(f"cli emits valid json: {e}")

        out = subprocess.run(
            [sys.executable, str(lib), "--repo-root", str(work / "empty"), "--json"],
            capture_output=True, text=True,
        )
        payload = json.loads(out.stdout)
        check("empty project is not an error", payload["ok"] is True)
        check("empty project warns nothing to do", any("nothing to do" in w for w in payload["warnings"]))

        # --------------------------------------------------- 12. real declaration
        print("\n12. the shipped skt-deepagent declaration")
        # Walk up looking for a sibling work-type repo, so this works whether
        # the selftest runs from the shared repo alone or from an estate snapshot.
        real = None
        for up in Path(__file__).resolve().parents:
            cand = up / "sketch-langchain-deep-agent/extensions/skt-deepagent/compose.yml"
            if cand.is_file():
                real = cand
                break
        if real is None:
            real = Path("/nonexistent")
        if real.is_file():
            decl = load_declaration(real)
            check("real compose.yml validates", decl.id == "skt-deepagent")
            check("declares one constitution layer", len(decl.constitution["layers"]) == 1)
            check("declares four slots", len(decl.templates[0]["slots"]) == 4)
            check("declares insert_before", "Governance" in decl.constitution["insert_before"])
        else:
            print(f"  skip  real compose.yml not found at {real}")

    finally:
        shutil.rmtree(work, ignore_errors=True)

    print("\n" + "-" * 43)
    print(f"passed {PASS}, failed {FAIL}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
