---
name: "speckit.skt-compose.compose"
description: "Merge every installed constitution layer and fill plan template slots, from the compose.yml declarations in this project."
argument-hint: "[--extension <id>] [--check]"
compatibility: "Requires a project initialised with specify init, and python3 on PATH."
metadata:
  author: "sketch"
  source: "commands/compose.md"
user-invocable: true
disable-model-invocation: false
---

# Compose

Ordinarily not invoked by hand. A work-type extension registers a `before_plan`
hook that calls this, and the plan command waits for it before `setup-plan` reads
the constitution or copies the plan template.

## Why this exists

Spec Kit resolves one file per name and never merges. It walks the priority stack,
takes the first match, and stops.

So a work type cannot add constitution principles or plan sections through a
second preset: it would replace the first rather than layer onto it. And copying
the bank-wide constitution into each work type means the same control exists in
triplicate and drifts within a year.

This composes instead, from declarations. A work type ships a `compose.yml` and
its markdown, and writes no shell. Contract:
[`compose.schema.yml`](../compose.schema.yml).

## Outline

1. **Run the composer** from the repository root. Resolve the install root first,
   then run the variant matching this project's script type:

   ```bash
   SK=".specify/extensions/skt-compose"
   [ -d "$SK" ] || { echo "skt-compose is not installed"; exit 1; }

   "$SK/scripts/bash/sketch-compose.sh" --json
   ```

   ```powershell
   $SK = ".specify/extensions/skt-compose"
   if (-not (Test-Path $SK)) { Write-Error "skt-compose is not installed"; exit 1 }

   & "$SK/scripts/powershell/sketch-compose.ps1" -Json
   ```

   Where only one variant is present, run that one. Both wrap the same Python
   library, so their output is identical.

   Where only one variant is present, run that one.

2. **Parse the result** and report:
   - which extensions contributed
   - the constitution path, layer count and byte size
   - slots filled per template target
   - every entry in `notes` and `warnings`, verbatim

3. **On `ok: false`**, report the error exactly as returned and stop. Where this
   ran as a `before_plan` hook, do not continue to the Outline of the plan
   command, and do not compose either file by hand. A constitution assembled by an
   agent rather than by the composer is a ruleset nobody reviewed.

## Arguments

```text
$ARGUMENTS
```

| Argument | Effect |
|----------|--------|
| `--extension <id>` | Compose only that extension's declaration |
| `--check` | Report what would change, write nothing |
| `--repo-root <path>` | Override root discovery |

Pass no `--extension` from a hook. The composer picks up every `compose.yml` in the
project, so two work types installed together contribute in one pass rather than
overwriting one another.

## What it produces

| File | Role |
|------|------|
| `.specify/memory/constitution.md` | Generated. Bank-wide base plus every installed layer |
| `.specify/memory/constitution.base.md` | The pristine base, captured on first run |
| `<each declared template target>` | Generated, slots filled |
| `<target>.base.<ext>` | The pristine template, slots empty |

The `.base` files are why repeated plan runs cannot accumulate duplicated
sections: every run rebuilds from them rather than from its own previous output.

## Key rules

- Never edit a generated target, and never edit a `.base` snapshot. Edits belong
  in the markdown a `compose.yml` declares.
- Report warnings rather than suppressing them. A missing base constitution means
  the project is gated on work-type layers alone, without the bank-wide
  principles. A template with no slot markers means the stock Spec Kit plan
  template is in place, so the governance and evaluation sections are absent.
- Where a project has no `compose.yml` at all, say "nothing to compose" and stop.
  That is the ordinary case for a project with no work type installed, not an
  error.

## Done When

- [ ] Composer run and its JSON parsed
- [ ] Contributors, layer count, slot counts, notes and warnings reported
- [ ] Any failure surfaced verbatim
