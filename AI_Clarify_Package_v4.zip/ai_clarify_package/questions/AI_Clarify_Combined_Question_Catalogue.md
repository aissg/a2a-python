**AI CLARIFY: COMBINED QUESTION CATALOGUE**

**Generic + AI Interview Questions**

*Distributable as an independent AI Clarify package. Every AI-specific addition is marked and colour-coded against the generic Spec Kit clarify baseline.*

> This catalogue is the union of two sets. The generic set matches Spec Kit's own /speckit.clarify taxonomy exactly and would be asked of any software feature. The AI set is everything added on top, because clarify's taxonomy was written for generic software and has no category for model classification, confidence calibration, review routing, audit provenance, or evaluation data.
> Sections 1 and 12 to 15 are entirely AI-specific: they do not exist in stock clarify at all. Sections 2 to 11 are stock clarify categories, with AI-specific questions added inside them and marked individually.
> Grading key: [L] Lightweight (asked at all depths), [S] Standard (Standard and Exhaustive), [E] Exhaustive only.

**How to read this document**

| **Marker**           | **Meaning**                                                                                   |
|----------------------|-----------------------------------------------------------------------------------------------|
| Black text, no badge | Generic question. Present in stock Spec Kit /speckit.clarify. Ask for any feature.            |
| Blue text, AI badge  | AI-specific addition. Not in stock clarify. Ask only when the feature is classified as AI/ML. |

## First Interview Key Points
*Use this for the very first conversation, before anyone has agreed to build anything. Do not read the numbered questions in this catalogue aloud: a list intimidates people and turns a conversation into an interrogation. Instead hold a normal discussion that covers the points below, and let the recording or your notes fill in the Lightweight requirement document afterwards. These points are the Lightweight tier expressed as a conversation. Getting through them in about an hour gives a business analyst and a technical architect enough to size the work at a high level. Once the project is prioritised, work the Standard questions one by one; keep the Exhaustive set for full implementation.*

### Part A: The conversation, in the order it usually flows

- **Today's process:** How is this done today? Walk through the current workflow end to end, and what it produces at the end.

- **Pain points:** What goes wrong most often: errors, rework, delays, wasted effort? Ask for a recent concrete example, not a general grumble.

- **Where AI would help:** `[AI]` Where in that workflow would AI actually save time? And, honestly, could plain rules or a lookup do it instead? Knowing why a model is needed matters as much as knowing that it is.

- **The goal, in a sentence:** What is the core goal, in one or two sentences? What would success look like, and how would they know it had been achieved?

- **The data:** What data is involved? Name it their way: documents, spreadsheets, datasets, feeds. Where does it come from, and which system is the source of truth?

- **Document or input complexity:** `[AI]` If documents or inputs are involved, are they simple, medium, or complex, and roughly what mix? A model that handles clean one-pagers may fail on the messy, multi-table ones, and the hard cases decide feasibility.

- **Volume and rhythm:** `[AI]` Roughly how much has to be processed, and how often: a number like 500 documents a quarter or 200 a day. And does it arrive as one big batch, or as individual requests through the day? This sizes everything and sets how much processing capacity to reserve.

- **What comes out, and where it goes:** What is the output, and where does it need to land: a screen, a spreadsheet, a file, another system? If it writes into something like an Excel sheet or a database, name that target and who owns it.

- **Roughly how fast:** About how quickly does a result need to come back for the main action? An approximate answer is fine at this stage.

- **The words that matter:** Which two or three terms here are most likely to be misunderstood, and does any of them already mean something different elsewhere in the firm?

- **What done looks like:** What single, checkable condition has to be true for this to count as done?

- **What's still open:** Which decisions are still genuinely open, the ones that would send the build down a different path depending on the answer?

### Part B: Assumption checks, where first interviews quietly go wrong
*These four are the assumptions clients most often carry into a first meeting unexamined. Each one, left unspoken, has derailed a real project. Surface them gently but explicitly before the conversation ends.*

- **The delivery surface:** How will people actually trigger this and see the result? Clients often assume an existing IT system will host it, or that a screen already exists. Confirm that assumption with the system owner, not just the business user. A GUI nobody agreed to build is a common surprise, and it changes the estimate completely.

- **The accuracy expectation:** `[AI]` What accuracy do they expect? Many say 100 percent. Explain early, and kindly, that no AI extraction is perfect, and that the practical answer is a human in the loop: the model does the heavy lifting, a person checks and corrects. Agreeing this in the first hour prevents a broken promise later.

- **The human review path:** `[AI]` Given that, who checks the uncertain cases, and how? Even a light answer now, one reviewer, a simple queue, tells the architect whether review is an afterthought or a core part of the flow.

- **The test data:** `[AI]` How many real examples with known-correct answers can they give you? As a rule of thumb, thirty to fifty is the minimum to tell whether the approach works at all. If they cannot supply any, that itself is a finding worth knowing on day one.

## First Interview Key Points
*Use this for the very first conversation, before anyone has agreed to build anything. Do not read the numbered questions in this catalogue aloud: a list intimidates people and turns a conversation into an interrogation. Instead hold a normal discussion that covers the points below, and let the recording or your notes fill in the Lightweight requirement document afterwards. These points are the Lightweight tier expressed as a conversation. Getting through them in about an hour gives a business analyst and a technical architect enough to size the work at a high level. Once the project is prioritised, work the Standard questions one by one; keep the Exhaustive set for full implementation.*

### Part A: The conversation, in the order it usually flows

- **Today's process:** How is this done today? Walk through the current workflow end to end, and what it produces at the end.

- **Pain points:** What goes wrong most often: errors, rework, delays, wasted effort? Ask for a recent concrete example, not a general grumble.

- **Where AI would help:** `[AI]` Where in that workflow would AI actually save time? And, honestly, could plain rules or a lookup do it instead? Knowing why a model is needed matters as much as knowing that it is.

- **The goal, in a sentence:** What is the core goal, in one or two sentences? What would success look like, and how would they know it had been achieved?

- **The data:** What data is involved? Name it their way: documents, spreadsheets, datasets, feeds. Where does it come from, and which system is the source of truth?

- **Document or input complexity:** `[AI]` If documents or inputs are involved, are they simple, medium, or complex, and roughly what mix? A model that handles clean one-pagers may fail on the messy, multi-table ones, and the hard cases decide feasibility.

- **Volume and rhythm:** `[AI]` Roughly how much has to be processed, and how often: a number like 500 documents a quarter or 200 a day. And does it arrive as one big batch, or as individual requests through the day? This sizes everything and sets how much processing capacity to reserve.

- **What comes out, and where it goes:** What is the output, and where does it need to land: a screen, a spreadsheet, a file, another system? If it writes into something like an Excel sheet or a database, name that target and who owns it.

- **Roughly how fast:** About how quickly does a result need to come back for the main action? An approximate answer is fine at this stage.

- **The words that matter:** Which two or three terms here are most likely to be misunderstood, and does any of them already mean something different elsewhere in the firm?

- **What done looks like:** What single, checkable condition has to be true for this to count as done?

- **What's still open:** Which decisions are still genuinely open, the ones that would send the build down a different path depending on the answer?

### Part B: Assumption checks, where first interviews quietly go wrong
*These four are the assumptions clients most often carry into a first meeting unexamined. Each one, left unspoken, has derailed a real project. Surface them gently but explicitly before the conversation ends.*

- **The delivery surface:** How will people actually trigger this and see the result? Clients often assume an existing IT system will host it, or that a screen already exists. Confirm that assumption with the system owner, not just the business user. A GUI nobody agreed to build is a common surprise, and it changes the estimate completely.

- **The accuracy expectation:** `[AI]` What accuracy do they expect? Many say 100 percent. Explain early, and kindly, that no AI extraction is perfect, and that the practical answer is a human in the loop: the model does the heavy lifting, a person checks and corrects. Agreeing this in the first hour prevents a broken promise later.

- **The human review path:** `[AI]` Given that, who checks the uncertain cases, and how? Even a light answer now, one reviewer, a simple queue, tells the architect whether review is an afterthought or a core part of the flow.

- **The test data:** `[AI]` How many real examples with known-correct answers can they give you? As a rule of thumb, thirty to fifty is the minimum to tell whether the approach works at all. If they cannot supply any, that itself is a finding worth knowing on day one.

## 1. AI Use Case Classification
*Entirely AI-specific. This section does not exist in stock clarify. It is the gate: answer No to the first question and Sections 12 to 15 do not apply at all.*

- **[L]** `[AI]` Is this an AI/ML feature at all? If No, skip every AI-marked question in this catalogue.

- **[L]** `[AI]` Which of the six topics best matches it? DMO / Data Agent, Compliance Check, Re/Write Productivity, Agentic AI, RAG Document Extraction, RAG and Auto Commentary.

- **[S]** `[AI]` Does it span more than one topic? If so, which is primary, and why does that one lead?

- **[E]** `[AI]` Has the model risk treatment for this classification been confirmed with the risk owner, and what did they say?

- **[E]** `[AI]` What is the deployment target for this iteration? PoC (throwaway), MVP (user-facing, limited support), or Production (fully IT-supported, formal SLA)?

## 2. Functional Scope & Behavior
*Stock clarify category. AI additions challenge whether a model is needed at all, and define where the system must refuse to answer.*

- **[L]** What is the core goal of this feature, in one or two sentences?

- **[L]** What does success look like, and how would you know it was achieved?

- **[L]** What is explicitly out of scope for this piece of work?

- **[L]** Before we talk about the change: how is this done today? Walk me through the current process and what it produces.

- **[L]** What goes wrong most often today: errors, rework, misunderstandings, wasted effort? Can you give me a recent example?

- **[S]** If this replaces something that already exists: which parts of the current version do people really use and value, and which are rarely looked at? What could we drop without anyone missing it?

- **[S]** Who are the different types of users, and what does each of them do differently?

- **[S]** Is there anything one type of user must not be able to do that another can?

- **[S]** If we had to shrink the output to a fraction of its size, what absolutely must stay, and what is nice-to-have?

- **[E]** For each requirement, who is the one person who can confirm it is correct?

- **[S]** `[AI]` Why does this need AI at all? Could ordinary rules or a lookup table do the job? If so, why use a model?

- **[E]** `[AI]` Where would a wrong answer be worse than no answer? Where should the system say “unknown” instead of guessing?

- **[E]** `[AI]` Is the AI making the decision, or recommending one for a person to decide? The two carry very different governance.

## 3. Domain & Data Model
*Stock clarify category. AI additions cover input size against the model's context limit, and the right to send this data to a model at all.*

- **[L]** What data does this read or produce? Name it the way your team does: datasets, tables, files, or feeds.

- **[L]** For each dataset, which few fields actually matter here, and which field tells one record apart from another?

- **[S]** Where does each dataset live? Enterprise data mesh, a governed warehouse, a shared drive, or a local sandbox copy provided for this work?

- **[S]** Is the same data available in more than one system? Which one is the source of truth, and why that one?

- **[S]** Is the data coming from an approved, official source? And is it used as-is, or changed in some way before this feature uses it?

- **[S]** How is each dataset accessed? SQL query, Python read, a REST or company-specific API, a file drop, or a manual export. Name the interface.

- **[S]** Is the access read-only, or does the feature write back? If it writes, to where, and who owns that target?

- **[S]** Does the feature just pass data through, or does it keep a copy somewhere: a folder, a database, or an object store?

- **[S]** How do the datasets connect? Which field links them, and can one record on one side match many on the other, like one filing with many line items?

- **[S]** How fresh does the data need to be, and how does it arrive: live query, scheduled batch, or a one-off snapshot?

- **[E]** What is the expected data volume today, and the expected growth rate over the next one to two years?

- **[L]** `[AI]` What is the largest single input the model must handle? State it in the unit that actually binds: pages, tokens, records, or conversation turns.

- **[S]** `[AI]` Is the source data reachable by the model's runtime at all, or does it sit behind an API, VPN, or entitlement the model host cannot call directly?

- **[S]** What data quality problems exist in the source today: missing fields, stale values, duplicates, or systems contradicting each other? Which do we have to live with, and which must be fixed?

- **[S]** Does the data include client-identifying details or other restricted information? If so, which fields?

- **[E]** `[AI]` Are there data usage rights constraints on sending this data to a model? Licensing, client consent, or cross-border transfer, as distinct from where the data is stored.

- **[E]** `[AI]` Is any training, fine-tuning, or few-shot example data involved, and where did it come from? Who owns it?

## 4. Interaction & UX Flow
*Stock clarify category. AI additions cover disclosure that the output is machine-generated, and how uncertainty reaches the user.*

- **[L]** Walk through the single most important user journey, step by step, from the user's first action to the outcome they need.

- **[S]** Beyond the main flow, how else is this used? Things that only happen during a failure, a correction, or an audit count too.

- **[S]** For each of those: who does it, what sets it off, and is it everyday use or a rare case?

- **[E]** Did anyone describe a way of using this that never made it into a requirement? Something mentioned in an interview that nobody ever built.

- **[S]** What should the user see the very first time, before there is any data to show?

- **[S]** Can users move to other screens while they wait for the action to finish, or must they stay put?

- **[S]** Does this need its own screen, or would another channel do: Teams, a Copilot agent, a chatbot, a downloaded file, or output dropped in a folder?

- **[S]** What does the user see while something is loading, and how long is too long to wait without feedback?

- **[S]** What does the user see when an action fails? Is the error message specific enough to act on?

- **[E]** Are there accessibility standards this must meet (e.g. WCAG level)?

- **[E]** Does this need to support more than one language or locale? If so, which, and are there any that read right-to-left?

- **[S]** `[AI]` How does the user know an answer came from AI rather than a fixed calculation?

- **[E]** `[AI]` Will users deal only with this one AI feature, or will the flow pass through other agents, AI tools, or handoffs between tools?

- **[E]** `[AI]` Does the user need to see the reasoning, evidence, or sources behind the AI's answer, right there on screen?

- **[E]** `[AI]` Should users be able to look back at earlier AI interactions and reopen or reuse them later?

- **[S]** `[AI]` How does the user see how confident the system is, and would they understand what that signal means?

- **[E]** `[AI]` Can the user correct a model output in the interface? If so, what happens to that correction afterwards?

## 5. Non-Functional Quality Attributes
*Stock clarify category. Security and access control sit here, and for a regulated institution they start at Standard depth, not Exhaustive. AI additions cover running cost, model unavailability, and the ways a model can quietly defeat an access-control model that looks correct on paper.*

- **[L]** What is an acceptable response time for the main user action, at least approximately?

- **[S]** How many people will use this at the same time at peak, and how much work must it get through?

- **[L]** `[AI]` Roughly how much needs to be processed, and how often: for example, 500 filings a quarter, or 200 tickets a day? This is the number that sizes everything else.

- **[L]** `[AI]` Do requests come in as one big batch, like overnight or end of quarter, or as individual requests spread across the day in real time, or a mix of both? This changes whether we need dedicated capacity or can share a pool.

- **[L]** `[AI]` Does this need guaranteed, reserved processing capacity, or is shared, best-effort capacity acceptable? Reserved capacity costs more but protects against slow responses when demand spikes elsewhere.

- **[S]** What availability is required, and during which hours or windows does that apply?

- **[S]** Where must data reside, and are there regions or environments it must never leave?

- **[E]** What logging, metrics, or tracing must exist so an incident can be diagnosed after the fact?

- **[E]** Are there regulatory or compliance constraints that apply, even indirectly, through downstream consumers of this system's output?

- **[S]** SECURITY: What is the data classification of the information this system handles? Public, Internal, Confidential, or Restricted. If more than one, name the highest.

- **[S]** SECURITY: Does the system process personal data or client-identifying information? Name the specific fields, not just yes or no.

- **[S]** SECURITY: How do users authenticate? Corporate SSO, or something bespoke? A bespoke mechanism needs an explicit justification, not a default.

- **[S]** SECURITY: What is the authorization model? Role-based, attribute-based, or record-level? Be specific: “only their own portfolios” is record-level, not role-based, and they are built differently.

- **[S]** SECURITY: Who grants and revokes access, and how quickly does a revocation actually take effect? At the next login, or immediately?

- **[E]** SECURITY: What are the encryption requirements, at rest and in transit? Are there fields requiring encryption beyond the platform default?

- **[E]** SECURITY: How are secrets stored and rotated? API keys, credentials, connection strings. They must never live in code or in a config file in the repository.

- **[E]** SECURITY: What is logged for security purposes: who accessed what, when, and from where? How long is that log retained, and who can read it?

- **[E]** SECURITY: Is a penetration test, threat model, or security review required before go-live? Who signs it off?

- **[E]** SECURITY: Is there a segregation-of-duties constraint? Can the person who builds or operates this system also approve its output, or must those be different people?

- **[S]** `[AI]` What is the acceptable running cost? Per query, per batch, or per month, and who owns that budget?

- **[S]** `[AI]` SECURITY: Can a user obtain, through the model, information their own access rights would deny them directly? A retrieval system that indexes documents the asker cannot open has bypassed access control, not implemented it. State how per-user permissions are enforced at retrieval time, not just at the document store.

- **[S]** `[AI]` SECURITY: Does the model provider retain, log, or train on the data you send it? Cite the contractual terms, not the marketing page. For Confidential or Restricted data this is a gating question, not a detail.

- **[E]** `[AI]` What happens when the model or its API is unavailable? A manual fallback, a queue and retry, or a hard stop?

- **[E]** `[AI]` If the main model is down, is it acceptable to quietly switch to a cheaper or weaker one? If not, say so explicitly, because many systems do it by default.

- **[E]** `[AI]` SECURITY: Are prompts and system instructions treated as secrets, version-controlled outside the application code, and reviewed on change? A prompt containing a business rule is a business rule, wherever it lives.

## 6. Integration & External Dependencies
*Stock clarify category. AI additions treat the model provider as what it is: an external dependency with its own deprecation cycle.*

- **[L]** Does this feature depend on any other system, upstream or downstream? Name each one, or state “none.”

- **[S]** For each external dependency, what happens when it is slow, unavailable, or returns an error?

- **[S]** Is any system this depends on due to be changed, migrated, or switched off in the near future? Building on a platform that is already being retired is something we need to know now.

- **[S]** What data import or export formats must be supported?

- **[E]** What protocol or API version assumptions are being made, and how is a breaking change from an upstream dependency handled?

- **[E]** Is there a fallback or degraded mode when a dependency is down, or does the whole feature stop working?

- **[S]** `[AI]` Which model provider and endpoint is this using? A hosted third-party API, an internally hosted model, or an open-weights model you run yourself?

- **[E]** `[AI]` What deprecation notice does the model provider give, and what happens when they force a version migration you did not choose?

## 7. Edge Cases & Failure Handling
*Stock clarify category. AI additions cover the error-cost asymmetry that shapes every threshold downstream, and deliberate misuse of the model.*

- **[L]** What is the single most likely way this feature could fail or be misused?

- **[S]** What should happen when a required input is missing, wrong, or out of range?

- **[S]** What happens at unusually busy times, or when someone repeats the same action rapidly?

- **[E]** What happens when two users act on the same record at the same time? Is there a conflict-resolution rule, or is the second action simply rejected?

- **[E]** What are the known edge cases from any existing manual process this feature replaces?

- **[S]** `[AI]` Which is worse here: flagging something that is actually fine, or missing something that should have been caught? This one answer shapes thresholds and review routing everywhere else.

- **[E]** `[AI]` What does the system do with an input unlike anything it has seen before? Does it abstain, or does it confidently produce nonsense?

- **[E]** `[AI]` Could a user deliberately misuse this? Prompt injection, extracting data they should not see, or laundering a decision through the model to avoid personal accountability.

## 8. Constraints & Tradeoffs
*Stock clarify category. AI additions demand evidence, not assertion, that a non-AI approach was genuinely considered.*

- **[S]** Are there technical constraints fixed in advance: a mandated language, database, hosting environment, or platform?

- **[S]** Are there constraints from outside engineering entirely: budget, timeline, or a vendor contract already in place?

- **[E]** What other approaches were considered and rejected, and why?

- **[E]** Are there tradeoffs being made on purpose, like simple over complete or fast over cheap, that we should write down for future readers?

- **[E]** `[AI]` Was a non-AI approach actually built or trialled before choosing a model? State the evidence, not just the belief that it would not work.

- **[E]** `[AI]` Are there constraints on model choice? An approved model list, a ban on external APIs, an open-weights-only policy, or a data residency rule that rules out certain providers.

## 9. Terminology & Consistency
*Stock clarify category. AI additions cover terms the model will not know natively, and definitions that must be injected into its context.*

- **[L]** Which two or three terms here are most likely to be misunderstood, and what exactly does each one mean?

- **[L]** Is there a term used elsewhere in the organization that sounds like one used here but means something different?

- **[S]** Are there synonyms that should be deliberately avoided in this project, because they are ambiguous or already mean something else elsewhere?

- **[S]** Does this feature's data eventually feed, or get consumed by, another team's system? If so, do they use the same terms the same way?

- **[E]** Is there an official glossary or data dictionary this must follow, whether company-wide, regulatory, or industry? Do our terms match it, and if not, is the difference written down?

- **[E]** If a term's meaning changed during the project, did we keep a note of the old meaning rather than silently replacing it?

- **[S]** `[AI]` Which domain terms will the model not know natively, and therefore must be defined for it in the prompt or retrieved into its context?

- **[E]** `[AI]` Where a term's meaning differs by jurisdiction or standard, how is the correct definition injected into the model's context, and is that injection recorded on the output?

## 10. Completion Signals
*Stock clarify category. AI additions require accuracy stated per output type, since a single blended number hides the weakest path.*

- **[L]** What specific, testable condition must be true for this to be considered done?

- **[S]** For each functional requirement, what is the exact pass or fail test?

- **[S]** Is there a Definition of Done checklist beyond the individual acceptance criteria (e.g. documentation updated, monitoring in place)?

- **[E]** Does every requirement have at least one test that proves it was met? Is there any requirement we could not verify?

- **[S]** `[AI]` What accuracy target must be met, stated separately per output type or content type? A single blended figure hides the fact that the hardest cases fail most.

- **[E]** `[AI]` What is the go / no-go decision for release, who makes it, and against what evidence?

## 11. Misc / Placeholders
*Stock clarify category. The AI addition catches untested capability claims, which are the AI equivalent of an unquantified adjective.*

- **[L]** Which open questions, if answered one way versus another, would send the build down a different path? List the decisions still outstanding that the design genuinely hinges on.

- **[E]** Once the requirements are signed off, how are later changes handled, and who can approve a change to scope, controls, data use, or model behaviour?

- **[S]** Wherever the spec says “robust,” “intuitive,” “fast,” or “scalable”: what is the actual number or test behind each one?

- **[E]** Are there any remaining TODO markers, bracketed placeholders, or “TBD” notes anywhere in the specification? List them; do not let any reach sign-off unresolved.

- **[E]** `[AI]` Are there claims in this specification about what the model can do that have not actually been tested? A capability assumed is a capability unproven.

## 12. AI Behavior & Validation Rules
*Entirely AI-specific. Not a generic business rule: these are correctness checks on what the AI system produces, whether that is a single model output or the result of an agentic workflow, and context-conditional rules where an absent value is expected rather than an error.*

- **[S]** `[AI]` What business or correctness rules must every output the AI system produces satisfy before it can be used? This applies whether the output comes from a single model call or an agent taking several steps.

- **[S]** `[AI]` What cross-field or cross-source consistency checks apply to the output? What must reconcile against what?

- **[E]** `[AI]` Which of these rules are regulatory rather than business preference? Cite the rule or standard.

- **[E]** `[AI]` Are any validation rules conditional on jurisdiction, legal entity, product, or context?

- **[E]** `[AI]` Where is a blank value normal rather than a mistake? Tell us where an automatic check would wrongly flag it as an error.

- **[E]** `[AI]` On breach of a rule, what happens: reject the output, flag it for review, or accept it with a warning? For an agentic system, does it stop, retry, or escalate?

## 13. Confidence & Human Review Routing
*Entirely AI-specific. For outputs that carry uncertainty: how sure the system is, and when a human must be in the loop.*

- **[S]** `[AI]` When the system gives an answer, does it also tell you how sure it is? And has that been checked, so that answers it calls “high confidence” really are right more often than “low confidence” ones? A number that looks certain but has never been checked is dangerous, because people trust it.

- **[S]** `[AI]` What confidence level is high enough to act on without any human review?

- **[S]** `[AI]` Who reviews low-confidence outputs, and within what SLA?

- **[E]** `[AI]` Should the threshold vary by output type, by input type, or by the materiality of the decision being made?

- **[E]** `[AI]` Are there outputs that always require human sign-off regardless of how confident the model is?

- **[E]** `[AI]` How are human corrections captured, who owns acting on them, and how do they feed back into improving the system? A correction log nobody reads satisfies the question but not the intent.

- **[E]** `[AI]` At which points must a human sign off before things move on: before design, before planning, before build, before release, or before the evidence is approved?

## 14. Audit Trail & Provenance
*Entirely AI-specific. What must be recorded so any output can be traced back and defended later, long after the model version that produced it has been retired.*

- **[E]** `[AI]` What must be reconstructable after the fact, and for how long must it remain so?

- **[E]** `[AI]` Must each output record its source, method, model version, prompt version, confidence, and timestamp?

- **[E]** `[AI]` Must the original input be retained alongside the output, not just the derived result?

- **[E]** `[AI]` When the model or prompt version changes, whether by choice or by provider deprecation, what re-validation is required before the new version reaches production?

- **[E]** `[AI]` Who is accountable for monitoring model performance once it is live, and what degradation triggers a rollback?

- **[E]** `[AI]` Must every AI output carry a record of what it was based on: the data, documents, records, prompts, or sources used to produce it?

## 15. Evaluation & Test Data
*Entirely AI-specific. The evidence needed to prove the thing actually works, and to keep proving it as the world drifts underneath it.*

- **[S]** `[AI]` How much test data, with known correct answers, can you provide? As a rule of thumb we ask for a minimum of 30 to 50 examples so the results are statistically meaningful; more is better, because a small set makes the system look more accurate than it is.

- **[S]** `[AI]` Where does ground truth come from, and who verifies it is actually correct?

- **[E]** `[AI]` Must the test set include edge cases, adversarial inputs, and deliberate failure paths, not just the happy path?

- **[E]** `[AI]` Is production-like data permitted in test, or must it be synthetic or masked?

- **[E]** `[AI]` Who owns keeping the test set current as real inputs drift over time, and how often is it refreshed? A stale benchmark silently overstates accuracy.

## Depth Grading Summary
*Counts are cumulative. Standard includes every Lightweight question; Exhaustive includes every Standard question.*

| **\#** | **Category**                        | **Generic** | **AI** | **L** | **S** | **E** |
|--------|-------------------------------------|-------------|--------|-------|-------|-------|
| 1      | AI Use Case Classification          | 0           | 5      | 2     | 3     | 5     |
| 2      | Functional Scope & Behavior         | 10          | 3      | 5     | 10    | 13    |
| 3      | Domain & Data Model                 | 13          | 4      | 3     | 14    | 17    |
| 4      | Interaction & UX Flow               | 11          | 6      | 1     | 10    | 17    |
| 5      | Non-Functional Quality Attributes   | 16          | 9      | 4     | 15    | 25    |
| 6      | Integration & External Dependencies | 6           | 2      | 1     | 5     | 8     |
| 7      | Edge Cases & Failure Handling       | 5           | 3      | 1     | 4     | 8     |
| 8      | Constraints & Tradeoffs             | 4           | 2      | 0     | 2     | 6     |
| 9      | Terminology & Consistency           | 6           | 2      | 2     | 5     | 8     |
| 10     | Completion Signals                  | 4           | 2      | 1     | 4     | 6     |
| 11     | Misc / Placeholders                 | 4           | 1      | 1     | 2     | 5     |
| 12     | AI Behavior & Validation Rules      | 0           | 6      | 0     | 2     | 6     |
| 13     | Confidence & Human Review Routing   | 0           | 7      | 0     | 3     | 7     |
| 14     | Audit Trail & Provenance            | 0           | 6      | 0     | 0     | 6     |
| 15     | Evaluation & Test Data              | 0           | 5      | 0     | 2     | 5     |

**Totals by question set:**

| **Question set**                 | **Lightweight** | **Standard** | **Exhaustive** |
|----------------------------------|-----------------|--------------|----------------|
| Generic (stock clarify baseline) | 15              | 56           | 79             |
| AI-specific additions            | 6               | 25           | 63             |
| Combined total                   | 21              | 81           | 142            |

*Of the 142 questions asked at Exhaustive depth, 63 are AI-specific additions that do not exist anywhere in stock Spec Kit clarify. That gap is the reason this package exists.*
