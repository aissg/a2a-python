**AI PROJECT: TECHNICAL REQUIREMENTS SPECIFICATION**

**\[Project / Feature Name\]: Lightweight**

*PoC / spike depth, AI-extended, reusable template, convert to Markdown for /speckit.specify*

**Document Control**

| **Version** | **Date**       | **Author**      | **Change Summary** |
|-------------|----------------|-----------------|--------------------|
| 0.1         | \[YYYY-MM-DD\] | \[name / role\] | Initial draft      |
|             |                |                 |                    |
|             |                |                 |                    |

**How to convert this document to Markdown for Spec Kit:**

> 1. Complete all sections below, then save this file as .docx (keep the built-in Heading 1/2 styles intact, do not retype section titles as plain text).
> 2. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 3. Save the result into your Spec Kit feature branch, e.g. specs/&lt;feature&gt;/spec.md.
> 4. Run /speckit.specify against spec.md, or paste its contents into the command directly.
> Note: if headings do not convert to # in step 2, re-save the .docx once through Word or LibreOffice first, since this normalizes the file for pandoc.

# First Interview Key Points
*Use this for the very first conversation, before anyone has agreed to build anything. Do not read the numbered questions in this catalogue aloud: a list intimidates people and turns a conversation into an interrogation. Instead hold a normal discussion that covers the points below, and let the recording or your notes fill in the Lightweight requirement document afterwards. These points are the Lightweight tier expressed as a conversation. Getting through them in about an hour gives a business analyst and a technical architect enough to size the work at a high level. Once the project is prioritised, work the Standard questions one by one; keep the Exhaustive set for full implementation.*

### Part A: The conversation, in the order it usually flows

- **Today's process:** How is this done today? Walk through the current workflow end to end, and what it produces at the end.

- **Pain points:** What goes wrong most often: errors, rework, delays, wasted effort? Ask for a recent concrete example, not a general grumble.

- **Where AI would help:** `[AI]` Where in that workflow would AI actually save time? And, honestly, could plain rules or a lookup do it instead? Knowing why a model is needed matters as much as knowing that it is.

- **The goal, in a sentence:** What is the core goal, in one or two sentences? What would success look like, and how would they know it had been achieved?

- **The data:** What data is involved? Name it their way: documents, spreadsheets, datasets, feeds. Where does it come from, and which system is the source of truth?

- **Document or input complexity:** `[AI]` If documents or inputs are involved, are they simple, medium, or complex, and roughly what mix? A model that handles clean one-pagers may fail on the messy, multi-table ones, and the hard cases decide feasibility.

- **Volume and rhythm:** `[AI]` Roughly how much has to be processed, and how often: a number like 500 documents a quarter or 200 a day. And does it arrive as one big batch, or as individual requests through the day? This sizes everything and sets how much processing capacity to reserve.

- **What comes out, and where it goes:** What is the output, and where does it need to land: a screen, a spreadsheet, a file, another system? If it writes into something like an Excel sheet or a database, name that target and who owns it.

- **Roughly how fast:** About how quickly does a result need to come back for the main action? An approximate answer is fine at this stage.

- **The words that matter:** Which two or three terms here are most likely to be misunderstood, and does any of them already mean something different elsewhere in the firm?

- **What done looks like:** What single, checkable condition has to be true for this to count as done?

- **What's still open:** Which decisions are still genuinely open, the ones that would send the build down a different path depending on the answer?

### Part B: Assumption checks, where first interviews quietly go wrong
*These four are the assumptions clients most often carry into a first meeting unexamined. Each one, left unspoken, has derailed a real project. Surface them gently but explicitly before the conversation ends.*

- **The delivery surface:** How will people actually trigger this and see the result? Clients often assume an existing IT system will host it, or that a screen already exists. Confirm that assumption with the system owner, not just the business user. A GUI nobody agreed to build is a common surprise, and it changes the estimate completely.

- **The accuracy expectation:** `[AI]` What accuracy do they expect? Many say 100 percent. Explain early, and kindly, that no AI extraction is perfect, and that the practical answer is a human in the loop: the model does the heavy lifting, a person checks and corrects. Agreeing this in the first hour prevents a broken promise later.

- **The human review path:** `[AI]` Given that, who checks the uncertain cases, and how? Even a light answer now, one reviewer, a simple queue, tells the architect whether review is an afterthought or a core part of the flow.

- **The test data:** `[AI]` How many real examples with known-correct answers can they give you? As a rule of thumb, thirty to fifty is the minimum to tell whether the approach works at all. If they cannot supply any, that itself is a finding worth knowing on day one.


# 0. Depth Selector
|                                            |                                                                                                                |
|--------------------------------------------|----------------------------------------------------------------------------------------------------------------|
| **Depth level**                            | Lightweight                                                                                                    |
| **Rationale (required if not Exhaustive)** | \[why this depth was chosen instead of Exhaustive\]                                                            |
| **When to use this tier**                  | Internal spike or proof of concept. Single scenario, no production path. Roughly 15 to 20 minutes to complete. |

## Interview Coverage Gaps
> This is a status check on the interview itself, not a section about the system. It exists so a gap in the answers cannot silently disappear into a 15-section document nobody rereads in full.
> After the interview, paste the Coverage Gaps rollup generated by the structuring prompt here. If every section was fully answered, write: "No coverage gaps. All sections addressed."
> Do not proceed to sign-off with an unresolved Not Asked row still in this table.

**Not Asked** = section not covered. **Partial** = section started but incomplete. Apply these colours to the Status column once populated.

| **Section**                 | **Status**              | **What's Missing**               |
|-----------------------------|-------------------------|----------------------------------|
| \[section number and name\] | \[Not Asked / Partial\] | \[what still needs to be asked\] |

# 1. AI Use Case Classification
> <strong>What it means:</strong> Which of the six AI archetypes this use case is. Sets its risk profile, platform pattern, and governance path from the outset.
> <strong>Example:</strong> A tool that answers questions about client suitability policy by retrieving from the internal policy library is RAG: retrieval over documents.

**Is this an AI/ML feature?**

\[ Yes / No \]

**If yes, which topic best matches this use case?**

|     | **Topic**                   |
|-----|-----------------------------|
| ☐   | 1\) DMO / Data Agent        |
| ☐   | 2\) Compliance Check        |
| ☐   | 3\) Re/Write Productivity   |
| ☐   | 4\) Agentic AI              |
| ☐   | 5\) RAG Document Extraction |
| ☐   | 6\) RAG and Auto Commentary |

# 2. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

\[what the system does, in plain language\]

**Success criteria:**

\[what good looks like\]

**Explicit out of scope:**

- \[item\]

**Functional requirements:**

> Every functional requirement must be testable. If a tester cannot write a pass or fail test against it, it is not a requirement yet: it is an intention.
> Keep each one atomic. One requirement, one behaviour. Do not narrate a usage scenario here: scenarios belong in the Usage Scenarios table, and each requirement traces back to the scenarios it serves.
> From Standard depth onward, write them in EARS form: While/When/If &lt;trigger or state&gt;, the &lt;system&gt; shall &lt;response&gt;.

| **ID** | **Requirement** | **Priority** |
|--------|-----------------|--------------|
| FR-1   | \[requirement\] | Must         |

# 3. Domain & Data Model
> <strong>What it means:</strong> The data this feature actually touches: what it is, where it lives, and how you reach it. Name it the way your team does, as datasets, tables, files, or feeds, not as abstract entities.
> <strong>Example:</strong> SEC filings dataset in the enterprise data mesh, read via SQL; a local sandbox copy of 50 filings provided for the spike, read from Parquet files with Python.

**Datasets in scope (name, key fields):**

| **Dataset / file / feed**         | **Key fields that matter here** | **Identifies a row by**           |
|-----------------------------------|---------------------------------|-----------------------------------|
| \[name as the team calls it\]     | \[the few fields used\]         | \[unique key or "generated"\]     |

# 4. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Usage scenarios:**

*Capture every distinct way the system is used, not just the main one. A pattern that only appears in a failure, a correction, or an audit still counts. Each functional requirement should trace back to at least one scenario here.*

| **ID** | **Scenario**                           | **Actor** |
|--------|----------------------------------------|-----------|
| US-1   | \[the primary way the system is used\] | \[who\]   |

**Critical user journey (step by step):**

\[walk the primary scenario end to end, from the user's first action to the outcome they need\]

# 5. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**        | **Target**       |
|--------|------------------------|------------------|
| NFR-1  | \[e.g. response time\] | \[target value\] |

**Security & access control:**

*\[Not required at Lightweight depth, unless the spike touches Confidential or Restricted data. If it does, promote to Standard.\]*

# 6. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Other systems this depends on, if any:**

\[list, or "none"\]

# 7. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**The single most likely way this could fail:**

\[failure mode\]

# 8. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

*\[not required at Lightweight depth\]*

# 9. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term** | **Single definitive meaning** |
|----------|-------------------------------|
| \[term\] | \[definition\]                |

# 10. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                     | **Traces to** |
|--------|-----------------------------------|---------------|
| AC-1   | \[testable, pass/fail condition\] | FR-1          |

# 11. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question** | **Status** |
|--------|--------------|------------|
| 1      | \[question\] | Open       |

# 12. AI Behavior & Validation Rules
> <strong>What it means:</strong> Not a generic business rule: this is specifically about correctness checks on model output, and jurisdiction- or context-conditional rules where an absent value is expected rather than an error.
> <strong>Example:</strong> An AI-generated client summary must never state a risk rating that does not appear in the source client file.

**Why AI:**

\[why this needs a model rather than deterministic logic\]

# 13. Confidence & Human Review Routing
> <strong>What it means:</strong> For AI outputs that carry uncertainty: how sure the system is, and when to trust it automatically versus send it to a human.
> <strong>Example:</strong> A KYC field extracted with high certainty is auto-populated. A low-certainty one is routed to a compliance reviewer before the file can progress.

*\[not required at Lightweight depth\]*

# 14. Audit Trail & Provenance
> <strong>What it means:</strong> What must be recorded so any output can be traced back and defended later: its source, method, and how certain it was.
> <strong>Example:</strong> Each extracted figure records the source filing and page, the model and prompt version, and the confidence at the time, so it can be defended in a model validation review.

*\[not required below Exhaustive depth\]*

# 15. Evaluation & Test Data
> <strong>What it means:</strong> The evidence needed to prove accuracy: what labelled data and verified answers are required, and which cases they must cover.
> <strong>Example:</strong> 200 annual reports with figures independently verified by two analysts, including filings with restatements and figures shown only in charts.

*\[not required at Lightweight depth\]*

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown, not a table, so it can be checked off directly in GitHub or by /speckit.clarify.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
- [ ] AI Use Case Classification is completed: Yes/No answered, not left blank
- [ ] If this is an AI feature: all four AI-specific sections (12-15) are completed, not left as placeholder text
