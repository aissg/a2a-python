**AI PROJECT: TECHNICAL REQUIREMENTS SPECIFICATION**

**10-K / 20-F Financial Field Extraction: Exhaustive**

*Worked example, regulated multi-jurisdiction extraction feeding a risk platform*

**Document Control**

| **Version** | **Date**   | **Author**           | **Change Summary**                                |
|-------------|------------|----------------------|---------------------------------------------------|
| 0.1         | 2026-05-04 | J. Chen, AI Champion | Initial draft, combined interview                 |
| 0.2         | 2026-05-19 | M. Weber, Model Risk | Added audit trail, provenance, confidence capping |
| 0.3         | 2026-06-02 | R. Patel, Data Eng   | Added IFRS edge cases and chart confidence floors |
| 1.0         | 2026-06-11 | M. Weber, Model Risk | Approved for build. SR 11-7 evidence pack opened. |

**How to convert this document to Markdown for Spec Kit:**

> 1. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 2. Save into the Spec Kit feature branch, e.g. specs/10k-extraction/spec.md.
> 3. Run /speckit.specify against spec.md.

# 0. Depth Selector
|                           |                                                                                                                                                                                                                                                 |
|---------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **Depth level**           | Exhaustive                                                                                                                                                                                                                                      |
| **Rationale**             | Regulated programme. Extractions feed a model-risk-governed risk analytics platform under SR 11-7 and FINMA 08/2024. Multi-jurisdiction (US GAAP and IFRS), multi-content-type (text, tables, charts), subject to independent model validation. |
| **Questions answered**    | 103 (52 generic, 51 AI-specific)                                                                                                                                                                                                                |
| **When to use this tier** | Regulated, multi-scenario, cross-source, production at scale.                                                                                                                                                                                   |

## Interview Coverage Gaps
> Status check on the interview itself, not a section about the system. Every section was fully covered; the two remaining items are recorded as non-blocking open questions in Section 11.

No coverage gaps. All sections addressed.

# 1. AI Use Case Classification
> <strong>What it means:</strong> Which of the six AI archetypes this use case is. Sets its risk profile, platform pattern, and governance path from the outset.
> <strong>Example:</strong> A tool that answers questions about client suitability policy by retrieving from the internal policy library is RAG: retrieval over documents.

**Is this an AI/ML feature?**

Yes.

**Which topic best matches this use case?**

|     | **Topic**                   |
|-----|-----------------------------|
| ☐   | 1\) DMO / Data Agent        |
| ☐   | 2\) Compliance Check        |
| ☐   | 3\) Re/Write Productivity   |
| ☐   | 4\) Agentic AI              |
| ☑   | 5\) RAG Document Extraction |
| ☐   | 6\) RAG and Auto Commentary |

**Deployment target for this iteration:**

|     | **Target**                                 |
|-----|--------------------------------------------|
| ☐   | PoC: throwaway, no production path         |
| ☐   | MVP: user-facing, limited support          |
| ☑   | Production: fully IT-supported, formal SLA |

**Model risk treatment:**

Confirmed with the Model Risk Owner on 2026-05-19: in scope for independent model validation under SR 11-7. Classified as a Tier 2 model (material but not capital-determining).

# 2. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

A governed extraction pipeline reading annual filings across US GAAP (Form 10-K) and IFRS (Form 20-F), resolving jurisdiction-specific field definitions correctly and recording full provenance for every value it produces, adequate for SR 11-7 evidence.

**Success criteria:**

Text-source accuracy at or above 99.5 percent, chart-source at or above 92 percent, 100 percent per-field provenance, and under 25 percent of filings requiring human review.

**Explicit out of scope:**

- Non-English filings. Excluded, not deferred.

- Handwritten or annotated documents.

- Filings sourced outside the SEC EDGAR channel.

**Deferred (not rejected):**

- Swiss GAAP FER filers. Phase 2, once the IFRS injection pattern is proven.

- Sustainability frameworks (GRI, CSRD, ISSB). Phase 2; chart extraction built here is the prerequisite.

**User roles / personas:**

| **Role**            | **How they differ from other roles**                                                        |
|---------------------|---------------------------------------------------------------------------------------------|
| Risk Analyst        | Reviews flagged and jurisdiction-injected extractions within SLA.                           |
| Senior Risk Analyst | Signs off fallback-resolved mandatory fields and chart-sourced values.                      |
| Model Risk Owner    | Owns SR 11-7 evidence, approves model version changes, samples 10 percent of output.        |
| Data Engineer       | Operates the pipeline. Cannot approve or override extracted values (segregation of duties). |

**Why AI rather than deterministic parsing?**

The same conceptual field carries different definitions across accounting standards: a lease liability under IFRS 16 is not the equivalent US GAAP line. Filers use inconsistent labels, and a material minority of values appear only inside charts. A deterministic parser was trialled and reached 71 percent field coverage, and could not handle IFRS at all. That is measured evidence, not an assumption.

**Is the model deciding, or recommending?**

Recommending. Every value it produces is either auto-approved against a calibrated threshold or routed to a named human. No figure reaches the risk platform without either passing a threshold derived from a labelled benchmark or receiving explicit human sign-off.

**Where a wrong answer is worse than no answer:**

Every mandatory field. FR-5 requires abstention over inference. A pie-chart absolute value is never extracted at all, because the extraction is not reliable enough to be worth the risk of a silent error.

**Functional requirements:**

| **ID** | **Requirement (EARS form)**                                                                                                                                                                                                      | **Priority** | **Traces to** |
|--------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------|---------------|
| FR-1   | The system shall record, for every extracted field, the source document, page, content type, extraction method, jurisdiction standard applied, fallback-used flag, and confidence score. (ubiquitous)                            | Must         | US-1, US-6    |
| FR-2   | When a filing is ingested, the system shall determine its reporting standard from the form type and filing metadata before any extraction is attempted. (event-driven)                                                           | Must         | US-1          |
| FR-3   | When a field's definition diverges between the detected standard and the system default, the system shall inject the applicable standard's definition into the extraction context and tag the output accordingly. (event-driven) | Must         | US-1, US-2    |
| FR-4   | If a mandatory field is resolved only via a fallback source, then the system shall flag the filing for senior review regardless of the confidence score. (unwanted behaviour)                                                    | Must         | US-3          |
| FR-5   | If the system cannot locate a field above its content-type confidence floor, then the system shall return “not found” and shall abstain rather than infer a value. (unwanted behaviour)                                          | Must         | US-2          |
| FR-6   | While a filing is under review for a detected prior-year restatement, the system shall withhold all restated figures from load. (state-driven)                                                                                   | Must         | US-4          |
| FR-7   | Where chart extraction is enabled, the system shall apply the chart-specific confidence floor and shall never auto-approve a chart-sourced value below it. (optional feature)                                                    | Must         | US-3          |
| FR-8   | When two source documents give conflicting values for the same field, the system shall record both values, the resolution rule applied, and the reason, and shall route the conflict for review. (event-driven)                  | Must         | US-5          |

# 3. Domain & Data Model
> <strong>What it means:</strong> The data this feature actually touches: what it is, where it lives, and how you reach it.
> <strong>Example:</strong> SEC filings dataset in the enterprise data mesh, read via SQL; a local sandbox copy of 50 filings provided for the spike, read from Parquet files with Python.

**Datasets in scope (name, key fields):**

| **Dataset / file / feed**           | **Key fields that matter here**                         | **Identifies a row by**           |
|-------------------------------------|---------------------------------------------------------|-----------------------------------|
| SEC filings corpus (10-K, 20-F)     | accession number, filer, fiscal year end, form type     | SEC accession number              |
| Extracted fields output             | field name, value, unit, source page, confidence        | filing accession + field name     |

**Location and access method:**

| **Dataset**                 | **Location**                                  | **Access method**                                            | **Read / write** |
|-----------------------------|-----------------------------------------------|--------------------------------------------------------------|------------------|
| SEC filings corpus          | Enterprise data mesh (governed)               | SQL query to the filings table; documents fetched by URI     | Read-only        |
| Extracted fields output     | Project schema in the analytics warehouse     | Written via the pipeline's warehouse connector               | Write            |

**Source of truth:**

SEC EDGAR is the authoritative source; the mesh copy is a governed mirror. Where a value also appears in a commercial data vendor feed, the filing itself is treated as source of truth, the vendor feed only as a cross-check.

**Relationships and freshness:**

One filing yields many extracted fields (one-to-many), joined on the accession number. Freshness is not real-time: filings are processed in a scheduled batch after each quarter's submissions close.

**Data quality issues in the source:**

Known issues in the source: scanned or image-only filings have no text layer and are rejected to a manual queue; older filings occasionally tag financial statement sections inconsistently. Neither is fixed upstream; the pipeline tolerates both by flagging rather than guessing.

**AI data access and rights:**

Largest single input: the largest 10-K in the corpus is about 400 pages, roughly 600,000 tokens. Filings over the single-pass context are chunked by statement section, never truncated. The filings are public regulatory disclosures reachable directly by the pipeline; no VPN or per-user entitlement blocks access.

**Data volume / scale assumptions:**

About 500 filings per quarter today, growing with coverage expansion to an estimated 700 to 800 per quarter within two years.

# 4. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Usage scenarios:**

*Capture every distinct way the system is used, not just the main one. A pattern that only appears in a failure, a correction, or an audit still counts. Each functional requirement should trace back to at least one scenario here.*

| **ID** | **Scenario**                                                                               | **Actor**           | **Trigger**                                                    | **Priority** |
|--------|--------------------------------------------------------------------------------------------|---------------------|----------------------------------------------------------------|--------------|
| US-1   | Run governed extraction across 10-K and 20-F filings, recording provenance for every field | Data Engineer       | Scheduled extraction run                                       | Primary      |
| US-2   | Review a low-confidence or jurisdiction-injected extraction within SLA                     | Risk Analyst        | Field below its floor, or a non-default standard was applied   | Secondary    |
| US-3   | Sign off a fallback-resolved mandatory field or a chart-sourced value                      | Senior Risk Analyst | Fallback used on a mandatory field, or chart value below floor | Secondary    |
| US-4   | Withhold restated prior-year figures until a human decides                                 | Risk Analyst        | Filing contains a prior-year restatement                       | Edge         |
| US-5   | Resolve two source documents that give different values for the same field                 | Senior Risk Analyst | Conflicting values detected across sources                     | Edge         |
| US-6   | Sample live output and evidence model performance for validation                           | Model Risk Owner    | Periodic model validation cycle                                | Secondary    |

**Critical user journey:**

A risk analyst reviews a 20-F extraction where the IFRS lease-liability definition was injected as context, sees that the system has capped its own confidence because it was not natively trained on IFRS, checks the value against the filing, and approves it.

**Error / empty / loading states:**

- A field resolved via fallback is visually distinct from one resolved from the primary source.

- A jurisdiction-injected field is labelled with the standard applied, so an analyst is never shown a bare number.

**Disclosure that output is machine-generated:**

Every value carries its confidence, its content type (text, table, or chart), and a click-through to the exact source page. A chart-derived value is explicitly marked as such, since its reliability profile differs materially from a text-derived one.

**User correction:**

Corrections are captured against the provenance record, not overwritten into it. The original model output remains visible alongside the human-corrected value, since an auditor must be able to see what the model said, not only what a human decided it should have said.

**Accessibility and localization:**

WCAG 2.1 AA. Interface in English only; source documents are English-only by scope.

**Delivery surface:**

No bespoke UI for the batch path: the pipeline runs headless and writes to the warehouse. The review queue for flagged fields is the only user-facing surface, delivered through the existing analyst workbench rather than a new screen.

# 5. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**                        | **Target**                                                                                                                                                                                   |
|--------|----------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| NFR-1  | Processing time, text and table only   | Under 3 minutes per filing                                                                                                                                                                   |
| NFR-2  | Processing time, with chart extraction | Under 8 minutes per filing                                                                                                                                                                   |
| NFR-3  | Extraction accuracy, text source       | 99.5 percent or higher                                                                                                                                                                       |
| NFR-4  | Extraction accuracy, chart source      | 92 percent or higher                                                                                                                                                                         |
| NFR-5  | Data residency                         | EU / Switzerland region only. Must never leave.                                                                                                                                              |
| NFR-6  | Model risk governance                  | SR 11-7, FINMA 08/2024, EU AI Act. Full audit trail, independent validation.                                                                                                                 |
| NFR-7  | Availability                           | Business hours, 99.5 percent.                                                                                                                                                                |
| NFR-8  | Running cost                           | Under CHF 3.50 per filing including chart extraction. Owner: Risk Analytics cost centre.                                                                                                     |
| NFR-9  | Model or API unavailable               | Queue and retry for 4 hours, then hard stop with alert. Silent degradation to a weaker model is expressly prohibited.                                                                        |
| NFR-10 | Scalability                            | Current 2,000 filings per year. Must scale to 8,000 by 2028 without redesign.                                                                                                                |
| NFR-11 | Security                               | Corporate SSO authentication, role-based authorization, encryption at rest and in transit. Prompts and standard definitions held in a governed configuration store, not in application code. |

**Processing volume and capacity:**

Volume and rhythm: About 500 filings per quarter, concentrated in the weeks after each quarter's filing deadline. A burst batch, not steady real-time traffic: the bulk arrives in a two to three week window after quarter close, near-idle otherwise. Shared, best-effort capacity is acceptable between quarters; reserved throughput is needed only during the post-close window, provisioned for that period and released after.

# 6. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Dependencies:**

| **Dependency**                            | **Owner**       | **Failure mode / fallback**                                               |
|-------------------------------------------|-----------------|---------------------------------------------------------------------------|
| SEC EDGAR bulk feed                       | SEC (external)  | No SLA available. Pipeline halts; no alternative source. Accepted risk.   |
| IFRS / US GAAP standard texts (RAG store) | Risk Control    | Context injection fails. Filings are flagged, never silently mis-defined. |
| Model endpoint (hosted, region-pinned)    | Platform        | 99.9 percent SLA. Queue 4 hours, then hard stop per NFR-9.                |
| Model risk registry                       | Model Risk Mgmt | Cannot open SR 11-7 evidence record. Load is blocked.                     |

**Model provider, endpoint, and deprecation:**

Hosted third-party API on a region-pinned endpoint. The provider gives limited notice on model deprecation, which is a live risk: a forced version migration triggers the full re-validation in Section 14 before the new version may process production filings. This is budgeted for, not hoped against.

# 7. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**Known edge cases:**

| **ID** | **Situation**                                                                         | **Expected behaviour**                                                                                |
|--------|---------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------|
| EC-1   | Prior-year restatement. The filing contains two sets of historical figures.           | Extract both. Tag original versus restated. Withhold restated from load until a human decides. (FR-6) |
| EC-2   | A 20-F reports in USD but the functional currency is CHF.                             | Extract as reported. Tag functional currency. Flag for FX review.                                     |
| EC-3   | A segment value exists only in a stacked bar chart, with no text or table equivalent. | Apply the stacked-bar confidence floor. Never auto-approve. Route to senior review. (FR-7)            |
| EC-4   | IFRS lease liability with no direct US GAAP equivalent.                               | Inject the IFRS 16 definition. Tag jurisdiction_standard_applied. Cap confidence per CR-4. (FR-3)     |
| EC-5   | Two documents give conflicting values for the same field.                             | Record both, the rule applied, and the reason. Route for review. Never silently pick one. (FR-8)      |
| EC-6   | A mandatory field appears only in a pie chart as an absolute value.                   | Abstain. Return “not found”. Pie charts are not reliable for absolute values. (FR-5)                  |
| EC-7   | Filing exceeds context and cannot be chunked without severing a cross-page reference. | Flag. Do not partially process.                                                                       |

**Relative cost of a false positive versus a false negative:**

A false negative (a wrong value silently approved) is materially worse than a false positive (a correct value needlessly flagged), because the risk platform consumes these figures without further challenge. Every threshold in Section 13 is deliberately set to over-flag rather than under-flag. This asymmetry is the single most important design input in this document.

**Out-of-distribution input:**

A filing whose structure matches nothing in the benchmark set is flagged for senior review, never force-fitted. The system must not produce a confident answer to a document it has effectively never seen.

**Deliberate misuse:**

An analyst could attempt to route a judgement call through the system to avoid personal accountability for it. Mitigated by CR-3 and CR-5, which force named human sign-off on any fallback-resolved or chart-sourced value. Prompt injection via a maliciously crafted filing is assessed as low likelihood (filings are SEC-published) but the extraction prompt is held in a governed configuration store, version-controlled outside the application code, and the model is not permitted to execute instructions found in retrieved content.

# 8. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

**Technical constraints:**

Model must be on the platform's approved allowlist and region-pinned to EU/Switzerland. External non-approved APIs are prohibited by policy. No new risk calculation engine is to be introduced.

**Rejected alternatives:**

| **Alternative considered**              | **Reason rejected**                                                                                                                                                                                               |
|-----------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Deterministic rules-based parser        | Trialled. Reached 71 percent field coverage on US GAAP and could not handle IFRS semantic divergence at all. Evidence, not assumption.                                                                            |
| Fine-tuning a model on labelled filings | Rejected in favour of RAG with injected standard definitions, because the injected definition is inspectable and auditable, and a fine-tuned model's reasoning is not. Auditability outweighed the accuracy gain. |
| Self-hosted open-weights model          | Deferred. Operational burden not justified at current volume, though this would remove the provider-deprecation risk noted in Section 6.                                                                          |

# 9. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term**              | **Single definitive meaning**                                                                                                                        |
|-----------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|
| Revenue               | Total net sales per the primary statement, under the accounting standard applicable to that filer.                                                   |
| Not found             | The system searched and abstained. Distinct from a reported value of zero, and distinct from a field that does not apply under the filer's standard. |
| Fallback-resolved     | The value came from a secondary source document, not the authoritative primary statement.                                                            |
| Jurisdiction-injected | The definition applied came from the RAG store, not from the model's native training.                                                                |

**Avoided synonyms:**

“Confidence” always refers to the model's calibrated score, never to an analyst's subjective certainty. The two are never conflated in the UI or in exports.

**Terms the model does not know natively:**

IFRS-specific definitions (IFRS 16 lease liability, IFRS 15 revenue recognition timing, development cost capitalisation) are not reliably known by the base model and must be retrieved from the RAG store into the extraction context.

**Cross-team consistency check:**

The Group Finance data dictionary defines “revenue” under US GAAP only. This system extends it to IFRS filers, a genuine divergence. Every export is labelled with the standard applied, so a downstream consumer can never mistake an IFRS revenue figure for a US GAAP one.

**Injection recorded on output:**

Where a definition was injected, the field's provenance record names the standard applied (see Section 14). A value is never delivered without stating which definition produced it.

# 10. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                                                                                                     | **Traces to** |
|--------|-------------------------------------------------------------------------------------------------------------------|---------------|
| AC-1   | Every loaded record carries a complete provenance record with all nine attributes populated. Zero exceptions.     | FR-1          |
| AC-2   | 20-F filings are detected as IFRS and the IFRS definition is applied to every divergent field.                    | FR-2, FR-3    |
| AC-3   | Restated prior-year figures are withheld from load until a human decides.                                         | FR-6          |
| AC-4   | No chart-sourced value auto-approves below its chart-type floor. No pie-chart absolute value is ever loaded.      | FR-7          |
| AC-5   | Text-source accuracy at least 99.5 percent; chart-source at least 92 percent on the benchmark set.                | NFR-3, NFR-4  |
| AC-6   | Every fallback-resolved mandatory field is routed to senior review regardless of confidence.                      | FR-4          |
| AC-7   | Where sources conflict, both values and the resolution reason are recorded and the conflict is routed for review. | FR-8          |
| AC-8   | Jurisdiction-injected fields have confidence capped at 0.90 and are never auto-approved.                          | CR-4          |

**Accuracy target, stated per content type:**

Text 99.5 percent, structured table 99.5 percent, bar/column chart 92 percent, stacked bar 92 percent, pie (absolute values) not applicable (always abstained). A single blended figure is expressly rejected, because it would hide chart failures behind text successes.

**Over-flagging versus under-flagging:**

An over-flag rate up to 20 percent is acceptable and expected, given the asymmetry in Section 7. The under-flag rate (a wrong value auto-approved) must remain below 0.5 percent. These are not symmetric targets and must not be optimised jointly.

**Go / no-go:**

Decided by the Head of Model Risk, on evidence of all acceptance criteria met, zero critical defects, every edge case in Section 7 passing, and a complete SR 11-7 evidence pack.

# 11. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question**                                                           | **Status**                                                                                      |
|--------|------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------|
| 1      | Should stacked-bar charts be in scope at all, given their reliability? | Open (non-blocking). In scope but never auto-approved. Review after 6 months of flag-rate data. |
| 2      | Swiss GAAP FER filers: phase 2, or defer indefinitely?                 | Open (non-blocking). Phase 2, contingent on IFRS injection proving out.                         |

**Untested capability claims:**

The 92 percent chart-extraction target is an assumption carried from a small pilot (40 charts), not a proven figure at scale. It is explicitly listed here as untested, and validating it is a gate on go-live, not an assumption baked into the plan.

# 12. AI Behavior & Validation Rules
> <strong>What it means:</strong> Not a generic business rule: this is specifically about correctness checks on model output, and jurisdiction- or context-conditional rules where an absent value is expected rather than an error.
> <strong>Example:</strong> An AI-generated client summary must never state a risk rating that does not appear in the source client file.

**Validation rules on model output:**

| **ID** | **Rule**                                                                                 | **Tolerance** | **Breach action**  |
|--------|------------------------------------------------------------------------------------------|---------------|--------------------|
| VR-1   | Gross profit = revenue minus cost of sales                                               | Rounding only | Flag for review    |
| VR-2   | Total assets = total liabilities plus total equity                                       | Rounding only | Flag for review    |
| VR-3   | Component lines tie to their stated totals                                               | Rounding only | Flag for review    |
| VR-4   | Currency is consistent within a single statement                                         | Exact         | Flag for FX review |
| VR-5   | Reported currency matches functional currency, or the divergence is explicitly disclosed | Exact         | Flag for FX review |

**Jurisdiction-conditional rules. These are the rules a generic validator gets wrong:**

| **ID** | **Rule**                                                                                                                   | **Applies to**         |
|--------|----------------------------------------------------------------------------------------------------------------------------|------------------------|
| JR-1   | LIFO inventory valuation is not permitted. Its presence is an extraction error, not a valid value.                         | IFRS filers only       |
| JR-2   | Development costs capitalised on the balance sheet are expected and valid. Under US GAAP their presence would be an error. | IFRS filers only       |
| JR-3   | Absence of a separately disclosed lease liability line is expected, not a missing mandatory field.                         | Certain US GAAP filers |
| JR-4   | Absence of a reserves disclosure required under Swiss CO is expected in an IFRS filing, not an error.                      | IFRS filers            |

**Regulatory rather than business-preference rules:**

JR-1 and JR-2 derive directly from IFRS itself, not from internal preference. They are cited to the standard, not to a policy document, and cannot be waived by a business owner.

# 13. Confidence & Human Review Routing
> <strong>What it means:</strong> For AI outputs that carry uncertainty: how sure the system is, and when to trust it automatically versus send it to a human.
> <strong>Example:</strong> A KYC field extracted with high certainty is auto-populated. A low-certainty one is routed to a compliance reviewer before the file can progress.

*Thresholds are set per content type. A chart-derived value cannot share a threshold with a text-derived one: the failure modes are entirely different.*

| **Content type**            | **Auto-approve**   | **Flag for review** | **Reject / abstain** |
|-----------------------------|--------------------|---------------------|----------------------|
| Machine-readable text       | 0.95 and above     | 0.80 to 0.94        | Below 0.80           |
| Structured table            | 0.92 and above     | 0.78 to 0.91        | Below 0.78           |
| Bar / column chart          | 0.85 and above     | 0.70 to 0.84        | Below 0.70           |
| Stacked bar chart           | Never auto-approve | 0.70 and above      | Below 0.70           |
| Line chart                  | Never auto-approve | 0.70 and above      | Below 0.70           |
| Pie chart (absolute values) | Never              | Never               | Always abstain       |

**Calibration:**

Floors were derived from the 280-filing labelled set (Section 15), not chosen by intuition. An uncalibrated score would be worse than no score, because reviewers would trust it.

| **ID** | **Trigger**                                       | **Action**                              | **Owner**        | **SLA**   |
|--------|---------------------------------------------------|-----------------------------------------|------------------|-----------|
| CR-1   | All fields above floor, no fallback, no injection | Auto-approve                            | System           | Immediate |
| CR-2   | Any field below its content-type floor            | Flag for review                         | Risk Analyst     | 4 hours   |
| CR-3   | Mandatory field resolved via fallback source      | Senior review, regardless of confidence | Senior Analyst   | 8 hours   |
| CR-4   | Jurisdiction standard was context-injected        | Cap confidence at 0.90. Senior review.  | Senior Analyst   | 8 hours   |
| CR-5   | Any chart-sourced value                           | Senior review                           | Senior Analyst   | 8 hours   |
| CR-6   | Two or more validation rules breached             | Escalate                                | Model Risk Owner | 24 hours  |

**Rationale for CR-4:**

The model was not trained on IFRS. Where its understanding of a field comes from injected context rather than training, its self-reported confidence is unreliable and must be capped, not trusted.

**Correction feedback loop:**

Corrections are logged against the provenance record. The Model Risk Owner is accountable for acting on them at the monthly review; a correction log nobody reads would satisfy the letter of this requirement but not its intent.

# 14. Audit Trail & Provenance
> <strong>What it means:</strong> What must be recorded so any output can be traced back and defended later: its source, method, and how certain it was.
> <strong>Example:</strong> Each extracted figure records the source filing and page, the model and prompt version, and the confidence at the time, so it can be defended in a model validation review.

**Per-field provenance record. Every extracted value carries all of the following:**

| **Attribute**                 | **Example value**                                     |
|-------------------------------|-------------------------------------------------------|
| source_document               | nvs-20241231.htm (SEC accession 0001370368-25-000004) |
| source_page                   | F-42                                                  |
| source_field_label            | “Lease liabilities, non-current”                      |
| content_type                  | structured_table                                      |
| jurisdiction_standard_applied | IFRS 16 (context-injected)                            |
| fallback_used                 | false                                                 |
| confidence                    | 0.88 (capped at 0.90 per CR-4)                        |
| model_version                 | claude-sonnet-4-6 / prompt v2.3                       |
| extracted_at                  | 2026-07-02T04:17:11Z                                  |

| **Requirement**                             | **Answer**                                                                                                                                                                                                        |
|---------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Original filing retained alongside output   | Yes, 7 years. The regulator requires the source, not only the derived figure.                                                                                                                                     |
| Extracted data retention                    | 10 years.                                                                                                                                                                                                         |
| Cross-document resolution decision recorded | Yes. Where sources disagreed, both values, the rule applied, and the reason are stored. (FR-8)                                                                                                                    |
| Model version change re-validation          | Any model or prompt version change requires re-running the full 280-filing benchmark and Model Risk Owner sign-off before the new version processes production filings. Provider deprecation does not waive this. |
| Production performance monitoring owner     | Model Risk Owner, Risk Control.                                                                                                                                                                                   |
| Degradation trigger                         | A fall of more than 1 percentage point in text-source accuracy, or 3 points in chart-source accuracy, between benchmark runs triggers a Model Risk review and possible rollback to the prior model version.       |

# 15. Evaluation & Test Data
> <strong>What it means:</strong> The evidence needed to prove accuracy: what labelled data and verified answers are required, and which cases they must cover.
> <strong>Example:</strong> 200 annual reports with figures independently verified by two analysts, including filings with restatements and figures shown only in charts.

| **Field**                       | **Value**                                                                                                                                              |
|---------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
| Labelled 10-K filings (US GAAP) | 200                                                                                                                                                    |
| Labelled 20-F filings (IFRS)    | 80                                                                                                                                                     |
| Ground truth source             | Each filing keyed independently by two risk analysts. Disagreements adjudicated by the Model Risk Owner, who also samples 10 percent.                  |
| Refresh cadence and owner       | Reviewed semi-annually by the Model Risk Owner. Filer conventions and accounting standards both drift; a stale benchmark silently overstates accuracy. |
| Production-like data in test    | Permitted. All source filings are public. No masking required.                                                                                         |

**The test set must include:**

- Filings under both US GAAP and IFRS.

- Fields available only in charts, covering each supported chart type.

- At least one unsupported chart type (pie, heatmap), to prove the system abstains rather than guesses.

- Prior-year restatement examples (EC-1).

- Multi-currency 20-F examples where reporting and functional currency differ (EC-2).

- Filings with deliberately absent mandatory fields, to exercise fallback chains and senior-review routing.

- Filings exceeding single-pass context, to prove cross-page reference preservation.

**Benchmark configuration:**

The 280-filing labelled set is the ground truth. Metrics are per-content-type field accuracy, over-flag rate, and under-flag rate. Acceptance thresholds are set per content type, not blended.

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
- [ ] AI Use Case Classification is completed: Yes/No answered, not left blank
- [ ] If this is an AI feature: all four AI-specific sections (12-15) are completed, not left as placeholder text
