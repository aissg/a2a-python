**AI PROJECT: TECHNICAL REQUIREMENTS SPECIFICATION**

**10-K Financial Field Extraction: Lightweight**

*Worked example, PoC spike on a single public 10-K*

**Document Control**

| **Version** | **Date**   | **Author**           | **Change Summary**                    |
|-------------|------------|----------------------|---------------------------------------|
| 0.1         | 2026-06-15 | J. Chen, AI Champion | Initial draft from combined interview |
| 0.2         | 2026-06-18 | J. Chen, AI Champion | EPS default resolved to diluted       |

**How to convert this document to Markdown for Spec Kit:**

> 1. Convert with pandoc: pandoc -t markdown "&lt;this-file&gt;.docx" -o spec.md
> 2. Save into the Spec Kit feature branch, e.g. specs/10k-extraction/spec.md.
> 3. Run /speckit.specify against spec.md.

# 0. Depth Selector
|                           |                                                                                                                                             |
|---------------------------|---------------------------------------------------------------------------------------------------------------------------------------------|
| **Depth level**           | Lightweight                                                                                                                                 |
| **Rationale**             | Single-developer spike to prove extraction accuracy on one real filing. No production path, no downstream consumer, no regulatory exposure. |
| **Questions answered**    | 15 (13 generic, 2 AI-specific)                                                                                                              |
| **When to use this tier** | Internal PoC or feasibility spike.                                                                                                          |

## Interview Coverage Gaps
> Status check on the interview itself, not a section about the system. The gaps below are expected at Lightweight depth: the spike is verified by hand end to end, so confidence routing and a labelled evaluation set do not yet apply.

**Not Asked** = section not covered. **Partial** = section started but incomplete.

| **Section**                           | **Status** | **What's Missing**                                                                                                                |
|---------------------------------------|------------|-----------------------------------------------------------------------------------------------------------------------------------|
| 5. Non-Functional Quality Attributes  | Partial    | Processing time agreed. Running cost, availability, and data residency were not discussed. Required before promotion to Standard. |
| 12. AI Behavior & Validation Rules    | Partial    | Only the never-fabricate rule was agreed. Cross-field arithmetic checks are not yet defined.                                      |
| 13. Confidence & Human Review Routing | Not Asked  | No confidence thresholds set. Every field is checked by hand at this depth, so no routing exists.                                 |
| 15. Evaluation & Test Data            | Partial    | One filing used as evidence. No labelled set. Whether this is enough to justify promotion is open question 2.                     |

# 1. AI Use Case Classification
> <strong>What it means:</strong> Which of the six AI archetypes this use case is. Sets its risk profile, platform pattern, and governance path from the outset.
> <strong>Example:</strong> A tool that answers questions about client suitability policy by retrieving from the internal policy library is RAG: retrieval over documents.

**Is this an AI/ML feature?**

Yes.

**Which topic best matches this use case?**

|     | **Topic**                   |
|-----|-----------------------------|
| ☐   | 1\) DMO / Data Agent        |
| ☐   | 2\) Compliance Check        |
| ☐   | 3\) Re/Write Productivity   |
| ☐   | 4\) Agentic AI              |
| ☑   | 5\) RAG Document Extraction |
| ☐   | 6\) RAG and Auto Commentary |

**Deployment target for this iteration:**

|     | **Target**                                 |
|-----|--------------------------------------------|
| ☑   | PoC: throwaway, no production path         |
| ☐   | MVP: user-facing, limited support          |
| ☐   | Production: fully IT-supported, formal SLA |

# 2. Functional Scope & Behavior
> <strong>What it means:</strong> What the system does, who it is for, and where the line is drawn around this piece of work.
> <strong>Example:</strong> A settlement exception dashboard: surface failed settlements and let an operations analyst assign an owner to each. Out of scope: correcting the underlying trade.

**Core user goal:**

Prove that an LLM pipeline can pull the 10 most decision-relevant financial fields from a single public 10-K accurately enough to be worth building properly.

**Success criteria:**

At least 9 of the 10 fields match a careful manual read of the same filing.

**Explicit out of scope:**

- Any document type other than a US GAAP Form 10-K.

- Multiple filers, multiple years, IFRS filings, charts, scanned pages.

- Human review workflow, downstream integration, production deployment.

**Why AI rather than deterministic parsing?**

Filers use inconsistent line-item labels (“Total net sales” vs “Total revenues” vs “Revenue, net”) and place statements at different points in the document. This spike is partly a test of whether that label variance is the real problem, or whether a regex-based parser would in fact be sufficient. If a parser wins, we do not build the AI version.

**Functional requirements:**

| **ID** | **Requirement**                                                                                | **Priority** |
|--------|------------------------------------------------------------------------------------------------|--------------|
| FR-1   | Accept a 10-K filing URL or an uploaded HTML file as input.                                    | Must         |
| FR-2   | Locate the Consolidated Statements of Operations and Balance Sheets within the filing.         | Must         |
| FR-3   | Extract the 10 target fields for the most recent fiscal year.                                  | Must         |
| FR-4   | Report any field it cannot locate as “not found”. Never substitute a value from another field. | Must         |

# 3. Domain & Data Model
> <strong>What it means:</strong> The data this feature actually touches: what it is, where it lives, and how you reach it.
> <strong>Example:</strong> SEC filings dataset in the enterprise data mesh, read via SQL; a local sandbox copy of 50 filings provided for the spike, read from Parquet files with Python.

**Datasets in scope (name, key fields):**

| **Dataset / file / feed**           | **Key fields that matter here**                         | **Identifies a row by**           |
|-------------------------------------|---------------------------------------------------------|-----------------------------------|
| SEC filings corpus (10-K, 20-F)     | accession number, filer, fiscal year end, form type     | SEC accession number              |
| Extracted fields output             | field name, value, unit, source page, confidence        | filing accession + field name     |

# 4. Interaction & UX Flow
> <strong>What it means:</strong> The path a user actually walks through the system, including what happens when things go wrong or are empty.
> <strong>Example:</strong> An analyst filters failed settlements by counterparty. If nothing has failed, show “No exceptions today”, not an empty grid.

**Usage scenarios:**

*Capture every distinct way the system is used, not just the main one. A pattern that only appears in a failure, a correction, or an audit still counts. Each functional requirement should trace back to at least one scenario here.*

| **ID** | **Scenario**                                                                                   | **Actor**                   |
|--------|------------------------------------------------------------------------------------------------|-----------------------------|
| US-1   | Extract the 10 headline fields from one filing and check each value against the source by hand | Developer running the spike |
| US-2   | Submit a filing where a target field is genuinely absent                                       | Developer running the spike |

**Critical user journey:**

A developer submits the Apple 10-K URL, receives the 10 fields as structured output within a minute, and checks each value against the filing by hand.

**Delivery surface:**

No bespoke UI for the batch path: the pipeline runs headless and writes to the warehouse. The review queue for flagged fields is the only user-facing surface, delivered through the existing analyst workbench rather than a new screen.

# 5. Non-Functional Quality Attributes
> <strong>What it means:</strong> How well the system must perform, scale, stay available, and stay secure. The quality bar, not the behaviour.
> <strong>Example:</strong> The exception list loads within 2 seconds. Available 99.9 percent during settlement hours. Client data is encrypted at rest and never leaves the approved region.

**Non-functional requirements:**

| **ID** | **Requirement**            | **Target**       |
|--------|----------------------------|------------------|
| NFR-1  | Processing time per filing | Under 60 seconds |

**Processing volume and capacity:**

Volume and rhythm: About 500 filings per quarter, concentrated in the weeks after each quarter's filing deadline. A burst batch, not steady real-time traffic: the bulk arrives in a two to three week window after quarter close, near-idle otherwise. Shared, best-effort capacity is acceptable between quarters; reserved throughput is needed only during the post-close window, provisioned for that period and released after.

# 6. Integration & External Dependencies
> <strong>What it means:</strong> The other systems this one has to talk to, and what happens when they are unavailable.
> <strong>Example:</strong> Prices come from a market data vendor at end of day. If the feed is late, use the prior close and flag every affected valuation as stale.

**Other systems this depends on:**

SEC EDGAR, for the source filing. Public, no authentication. No downstream consumer at this stage.

# 7. Edge Cases & Failure Handling
> <strong>What it means:</strong> The unusual and negative paths: bad input, overload, and two people acting on the same thing at once.
> <strong>Example:</strong> Two analysts claim the same settlement exception simultaneously. The second claim is rejected with a message to refresh.

**The single most likely way this could fail:**

The model finds a plausible-looking number in the MD&A narrative (which frequently reports non-GAAP figures) rather than in the audited statements, and reports it confidently as if it were the real value.

# 8. Constraints & Tradeoffs
> <strong>What it means:</strong> What is fixed in advance, and what was considered and deliberately rejected, with the reason why.
> <strong>Example:</strong> Must read positions from the existing books and records system. A parallel position store was considered and rejected: it would create a reconciliation break.

*\[Not required at Lightweight depth.\]*

# 9. Terminology & Consistency
> <strong>What it means:</strong> The words this project uses, defined once, so different people and different systems do not quietly mean different things by the same term.
> <strong>Example:</strong> “Exposure” means market value in base currency. The general ledger uses the same word to mean notional. The conflict is documented and every export states which definition applies.

**Canonical glossary:**

| **Term** | **Single definitive meaning**                                                                                    |
|----------|------------------------------------------------------------------------------------------------------------------|
| Revenue  | Total net sales as reported on the Consolidated Statement of Operations, not any non-GAAP figure quoted in MD&A. |
| EPS      | Diluted earnings per share, unless explicitly labelled basic.                                                    |

# 10. Completion Signals
> <strong>What it means:</strong> The definition of done: specific, testable conditions that must be true before this is accepted, not a feeling that it looks finished.
> <strong>Example:</strong> Accepted when an analyst reaches the underlying trade from the exception list in two clicks, and the daily total ties to books and records within 0.1 percent.

**Acceptance criteria:**

| **ID** | **Criterion**                                                                                 | **Traces to** |
|--------|-----------------------------------------------------------------------------------------------|---------------|
| AC-1   | Given the Apple FY2025 10-K, at least 9 of the 10 fields match a manual read within rounding. | FR-3          |
| AC-2   | No field is reported with a fabricated value in place of “not found”.                         | FR-4          |

# 11. Misc / Placeholders
> <strong>What it means:</strong> The hygiene pass: unresolved decisions and vague words that were never actually quantified.
> <strong>Example:</strong> “The report should be timely” is not a requirement until “timely” becomes a cut-off, such as available by 07:00 local time.

**Open questions / unresolved decisions:**

| **\#** | **Question**                                                        | **Status**               |
|--------|---------------------------------------------------------------------|--------------------------|
| 1      | Diluted or basic EPS when the filing reports both?                  | Resolved: diluted (v0.2) |
| 2      | Is one filing sufficient evidence to justify promotion to Standard? | Open                     |

# 12. AI Behavior & Validation Rules
> <strong>What it means:</strong> Not a generic business rule: this is specifically about correctness checks on model output, and jurisdiction- or context-conditional rules where an absent value is expected rather than an error.
> <strong>Example:</strong> An AI-generated client summary must never state a risk rating that does not appear in the source client file.

*\[Minimal at Lightweight depth. The “why AI” justification is recorded in Section 2. Full validation rules are deferred to Standard.\]*

# 13. Confidence & Human Review Routing
> <strong>What it means:</strong> For AI outputs that carry uncertainty: how sure the system is, and when to trust it automatically versus send it to a human.
> <strong>Example:</strong> A KYC field extracted with high certainty is auto-populated. A low-certainty one is routed to a compliance reviewer before the file can progress.

*\[Not required at Lightweight depth. There is no review workflow in a single-developer spike.\]*

# 14. Audit Trail & Provenance
> <strong>What it means:</strong> What must be recorded so any output can be traced back and defended later: its source, method, and how certain it was.
> <strong>Example:</strong> Each extracted figure records the source filing and page, the model and prompt version, and the confidence at the time, so it can be defended in a model validation review.

*\[Not required below Exhaustive depth.\]*

# 15. Evaluation & Test Data
> <strong>What it means:</strong> The evidence needed to prove accuracy: what labelled data and verified answers are required, and which cases they must cover.
> <strong>Example:</strong> 200 annual reports with figures independently verified by two analysts, including filings with restatements and figures shown only in charts.

*\[Not required at Lightweight depth. Evidence at this tier is a single filing checked by hand.\]*

## Review & Acceptance Checklist
*This closing checklist matches the one Spec Kit's own spec.md ends with. It converts to real GFM checkboxes (- \[ \]) in the exported Markdown.*

- [ ] No implementation details (languages, frameworks, APIs) appear in this specification
- [ ] Every functional requirement is testable and unambiguous
- [ ] Every acceptance criterion is measurable
- [ ] Edge cases and failure modes are identified
- [ ] Terminology is defined once and used consistently throughout
- [ ] No placeholder text or unresolved TODO remains
- [ ] AI Use Case Classification is completed: Yes/No answered, not left blank
- [ ] If this is an AI feature: all four AI-specific sections (12-15) are completed, not left as placeholder text
